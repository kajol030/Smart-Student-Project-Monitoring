import { useEffect, useState } from "react";
import { ClipboardCheck } from "lucide-react";
import { api } from "../api/api";

export default function AdminRequests() {
  const [requests, setRequests] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const data = await api.getSupervisorRequests();
        if (!Array.isArray(data)) {
          throw new Error("Supervisor requests could not be loaded.");
        }
        if (!ignore) setRequests(data);
      } catch (requestError) {
        if (!ignore) setError(requestError.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => { ignore = true; };
  }, []);

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading supervisor requests…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 admin-dashboard">
      <section className="admin-welcome">
        <div className="admin-welcome-copy">
          <p className="eyebrow">Admin workspace</p>
          <h1>Supervisor Requests</h1>
          <p>Review all student requests and their supervisor responses.</p>
        </div>
        <div className="welcome-illustration" aria-hidden="true">
          <div className="illustration-orbit illustration-orbit-one" />
          <div className="illustration-orbit illustration-orbit-two" />
          <div className="illustration-book"><ClipboardCheck size={42} /></div>
        </div>
      </section>

      {error && <div className="form-alert error" role="alert">{error}</div>}

      <section className="dashboard-card">
        <div className="card-heading">
          <h2><ClipboardCheck size={17} /> All Supervisor Requests</h2>
          <span className="muted-copy">{requests.length} total</span>
        </div>

        {requests.length === 0 ? (
          !error && (
            <div className="empty-state" style={{ padding: "40px 20px" }}>
              <div className="metric-icon violet"><ClipboardCheck size={20} /></div>
              <h2>No supervisor requests</h2>
              <p className="muted-copy">Student requests will appear here when submitted.</p>
            </div>
          )
        ) : (
          <div className="overflow-x-auto">
            <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--line)" }}>
                  {["Request ID", "Student", "Supervisor", "Project", "Preference", "Status"].map((heading) => (
                    <th
                      key={heading}
                      style={{ padding: "10px 12px", textAlign: "left", color: "var(--muted)", fontWeight: 600, fontSize: 11, textTransform: "uppercase", letterSpacing: ".06em" }}
                    >
                      {heading}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {requests.map((request) => (
                  <tr key={request.id} style={{ borderBottom: "1px solid var(--line)" }}>
                    <td style={{ padding: "12px" }}>#{request.id}</td>
                    <td style={{ padding: "12px" }}>{request.student_name || "Unknown"}</td>
                    <td style={{ padding: "12px" }}>{request.supervisor_name || "Unknown"}</td>
                    <td style={{ padding: "12px" }}>{request.title || "Untitled project"}</td>
                    <td style={{ padding: "12px" }}>#{request.preference_order ?? "—"}</td>
                    <td style={{ padding: "12px" }}>
                      <span className={`status-badge ${request.status === "accepted" ? "completed" : request.status === "pending" ? "proposal" : ""}`}>
                        {request.status || "unknown"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
