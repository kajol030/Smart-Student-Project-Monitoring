
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Bell,
  CheckCheck,
  CircleAlert,
  Info,
  Sparkles,
  Trash2,
  Eye,
} from "lucide-react";
import { api } from "../api/api";

const KNOWN_ROUTES = new Set([
  "/student", "/supervisor", "/admin",
  "/projects", "/milestones", "/weekly-logs",
  "/documents", "/plagiarism", "/feedback",
  "/meetings", "/announcements", "/evaluations",
  "/ai-insights", "/groups", "/notifications",
  "/preferences", "/settings", "/reports", "/topic-review",
  "/academic", "/audit-logs", "/search",
  "/supervisor/students", "/supervisor/reviews",
  "/supervisor/requests",
  "/admin/users", "/admin/requests",
  "/admin/assignments", "/admin/deadlines",
  "/admin/analytics",
]);

const LEGACY_ROUTE_ALIASES = {
  "/student/my-project": "/projects",
};

function resolveLink(link) {
  if (!link || typeof link !== "string") return null;

  const path = link.trim().replace(/^\/app(?=\/)/, "");

  if (!path.startsWith("/") || path.startsWith("//")) {
    return null;
  }

  const suffixIndex = path.search(/[?#]/);
  const pathname =
    suffixIndex === -1 ? path : path.slice(0, suffixIndex);
  const suffix =
    suffixIndex === -1 ? "" : path.slice(suffixIndex);

  const clean = pathname.replace(/\/+$/, "") || "/";
  const target = LEGACY_ROUTE_ALIASES[clean] || clean;

  return KNOWN_ROUTES.has(target)
    ? `${target}${suffix}`
    : null;
}

export default function Notifications() {
  const navigate = useNavigate();

  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let ignore = false;

    async function load() {
      try {
        const data = await api.getNotifications();
        const rows = Array.isArray(data)
          ? data
          : data.notifications || [];

        if (!ignore) {
          setItems(rows);
          setUnread(
            typeof data.unread === "number"
              ? data.unread
              : rows.filter((r) => !r.is_read).length
          );
        }
      } catch (err) {
        if (!ignore) setError(err.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    }

    load();

    return () => {
      ignore = true;
    };
  }, []);

  const markAll = async () => {
    try {
      await api.markAllNotificationsRead();
      setItems((prev) =>
        prev.map((n) => ({ ...n, is_read: 1 }))
      );
      setUnread(0);
    } catch (err) {
      setError(err.message);
    }
  };

  const markOne = async (id) => {
    try {
      await api.markNotificationRead(id);

      setItems((prev) =>
        prev.map((n) =>
          n.id === id ? { ...n, is_read: 1 } : n
        )
      );

      setUnread((c) => Math.max(0, c - 1));
    } catch (err) {
      setError(err.message);
    }
  };

  const deleteOne = async (id) => {
    const target = items.find((n) => n.id === id);

    try {
      await api.deleteNotification(id);

      setItems((prev) =>
        prev.filter((n) => n.id !== id)
      );

      if (target && !target.is_read) {
        setUnread((c) => Math.max(0, c - 1));
      }
    } catch (err) {
      setError(err.message);
    }
  };

  // Weekly Log notifications open the existing Weekly Logs page.
  const getNotificationTarget = (item) => {
    const title = (item.title || "").toLowerCase();
    const message = (item.message || "").toLowerCase();

    const isWeeklyLog =
      title.includes("weekly log") ||
      title.includes("week log") ||
      message.includes("submitted week") ||
      message.includes("weekly log");

    if (isWeeklyLog) {
      return "/weekly-logs";
    }

    return resolveLink(item.link);
  };

  const openItem = (item) => {
    const target = getNotificationTarget(item);

    if (!target) return;

    if (!item.is_read) {
      markOne(item.id);
    }

    navigate(target);
  };

  const iconFor = (type) => {
    if (type === "warning" || type === "error") {
      return <CircleAlert size={16} />;
    }

    if (type === "success") {
      return <Sparkles size={16} />;
    }

    if (type === "info") {
      return <Info size={16} />;
    }

    return <Bell size={16} />;
  };

  const colorFor = (type) => {
    if (type === "warning" || type === "error") {
      return "amber";
    }

    if (type === "success") {
      return "teal";
    }

    return "violet";
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading notifications…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="notif-header">
        <div>
          <p className="eyebrow">Your inbox</p>

          <h1 className="page-title">
            Notifications
            {unread > 0 && (
              <span className="notif-header-badge">
                {unread}
              </span>
            )}
          </h1>

          <p className="page-subtitle">
            Stay up to date with project activity and academic deadlines.
          </p>
        </div>

        {items.length > 0 && (
          <button
            className="notif-markall-btn"
            onClick={markAll}
          >
            <CheckCheck size={15} />
            Mark all read
          </button>
        )}
      </div>

      {error && (
        <div className="form-alert error">
          {error}
        </div>
      )}

      <section className="dashboard-card notif-card">
        {items.length === 0 ? (
          <div className="empty-state">
            <div className="metric-icon teal">
              <Bell size={20} />
            </div>

            <h2>No notifications yet</h2>

            <p className="muted-copy">
              Updates about your projects, meetings and submissions
              will appear here.
            </p>
          </div>
        ) : (
          items.map((item) => {
            const clickable = Boolean(
              getNotificationTarget(item)
            );

            return (
              <article
                key={item.id}
                className={`notif-row ${
                  item.is_read ? "is-read" : "is-unread"
                }`}
                style={
                  clickable
                    ? { cursor: "pointer" }
                    : undefined
                }
                role={clickable ? "link" : undefined}
                tabIndex={clickable ? 0 : undefined}
                onClick={
                  clickable
                    ? () => openItem(item)
                    : undefined
                }
                onKeyDown={
                  clickable
                    ? (e) => {
                        if (e.key === "Enter") {
                          openItem(item);
                        }
                      }
                    : undefined
                }
              >
                {!item.is_read && (
                  <span className="notif-unread-dot" />
                )}

                <span
                  className={`list-icon ${colorFor(item.type)}`}
                >
                  {iconFor(item.type)}
                </span>

                <div className="notif-body">
                  <strong>{item.title}</strong>
                  <p>{item.message}</p>

                  <time>
                    {item.created_at
                      ? new Date(
                          item.created_at
                        ).toLocaleString()
                      : ""}
                  </time>
                </div>

                <div className="notif-actions">
                  {!item.is_read && (
                    <button
                      className="notif-action-btn"
                      title="Mark as read"
                      onClick={(e) => {
                        e.stopPropagation();
                        markOne(item.id);
                      }}
                    >
                      <Eye size={14} />
                    </button>
                  )}

                  <button
                    className="notif-action-btn danger"
                    title="Delete"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteOne(item.id);
                    }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </article>
            );
          })
        )}
      </section>
    </div>
  );
}
