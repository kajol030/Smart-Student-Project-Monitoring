import { useMemo, useState } from "react";
import {
  ArrowRight, Check, ChevronDown, Eye, EyeOff,
  GraduationCap, ShieldCheck, UserCheck,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api, saveSession, getDashboardPath } from "../api/api";

/* ─── Password requirements ─── */
const CHECKS = [
  ["length",  "At least 8 characters",   (v) => v.length >= 8],
  ["upper",   "One uppercase letter",     (v) => /[A-Z]/.test(v)],
  ["lower",   "One lowercase letter",     (v) => /[a-z]/.test(v)],
  ["number",  "One number",               (v) => /\d/.test(v)],
  ["special", "One special character",    (v) => /[^A-Za-z0-9]/.test(v)],
];

/* ─── Role definitions ─── */
const ROLES = [
  {
    id: "student",
    label: "Student",
    desc: "Register as a student to submit your FYP proposal and track progress.",
    icon: GraduationCap,
  },
  {
    id: "supervisor",
    label: "Supervisor",
    desc: "Register as a supervisor to guide and monitor FYP projects.",
    icon: UserCheck,
  },
  {
    id: "admin",
    label: "Admin",
    desc: "Admin accounts are created by existing administrators only.",
    icon: ShieldCheck,
    disabled: true,
  },
];

/* ─── Initial form state ─── */
const BASE_FORM = {
  name: "", email: "", password: "", confirmPassword: "", phone: "", terms: false,
};
const STUDENT_FORM = {
  ...BASE_FORM, studentId: "", program: "BSCS", batch: "", semester: "", section: "",
};
const SUPERVISOR_FORM = {
  ...BASE_FORM, employeeId: "", department: "", designation: "", specialization: "",
};

export default function Register() {
  const navigate = useNavigate();
  const [role, setRole]             = useState("student");
  const [formData, setFormData]     = useState(STUDENT_FORM);
  const [showPassword, setShowPwd]  = useState(false);
  const [showConfirm, setShowConf]  = useState(false);
  const [errors, setErrors]         = useState({});
  const [loading, setLoading]       = useState(false);

  /* ─── Password strength ─── */
  const pwdChecks = useMemo(
    () => CHECKS.map(([, , test]) => test(formData.password)),
    [formData.password],
  );
  const strength = pwdChecks.filter(Boolean).length;
  const strengthLabel =
    strength === 0 ? "Add a password" :
    strength < 3   ? "Weak" :
    strength < 5   ? "Getting stronger" : "Strong password";
  const strengthClass = strength < 3 ? "weak" : strength < 5 ? "fair" : "strong";

  /* ─── Role switch ─── */
  const handleRoleChange = (newRole) => {
    if (newRole === role) return;
    setRole(newRole);
    setFormData(newRole === "student" ? STUDENT_FORM : SUPERVISOR_FORM);
    setErrors({});
  };

  /* ─── Field change ─── */
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
    setErrors((prev) => ({ ...prev, [name]: "", api: "" }));
  };

  /* ─── Validation ─── */
  const validate = () => {
    const next = {};
    if (formData.name.trim().length < 3)        next.name  = "Enter your full name (min 3 chars).";
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) next.email = "Use a valid email address.";

    if (role === "student") {
      if (!formData.studentId.trim()) next.studentId = "Student ID is required.";
      if (!formData.batch.trim())     next.batch     = "Batch is required.";
      if (!formData.semester.trim())  next.semester  = "Semester is required.";
      if (!formData.section.trim())   next.section   = "Section is required.";
    }
    if (role === "supervisor") {
      if (!formData.employeeId.trim())    next.employeeId    = "Employee ID is required.";
      if (!formData.department.trim())    next.department    = "Department is required.";
      if (!formData.designation.trim())   next.designation   = "Designation is required.";
    }

    if (strength < CHECKS.length)
      next.password = "Meet all password requirements.";
    if (formData.password !== formData.confirmPassword)
      next.confirmPassword = "Passwords do not match.";
    if (!formData.terms) next.terms = "Accept the terms to continue.";

    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* ─── Submit ─── */
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const payload = {
        name:     formData.name,
        email:    formData.email,
        password: formData.password,
        phone:    formData.phone,
        role,
        ...(role === "student" ? {
          studentId:    formData.studentId,
          program:      formData.program,
          batch:        formData.batch,
          semester:     formData.semester,
          section:      formData.section,
        } : {
          employeeId:     formData.employeeId,
          department:     formData.department,
          designation:    formData.designation,
          specialization: formData.specialization,
        }),
      };
      const data = await api.register(payload);
      saveSession(data.user, data.token);
      navigate(getDashboardPath(data.user.role));
    } catch (err) {
      setErrors({ api: err.message });
    } finally {
      setLoading(false);
    }
  };

  const isStudent    = role === "student";
  const isSupervisor = role === "supervisor";

  return (
    <div className="auth-page register-page">
      {/* ── Left rail ── */}
      <section className="auth-rail">
        <Link to="/login" className="auth-brand">
          <span className="brand-mark"><GraduationCap size={20} /></span>
          <span>
            <strong>Smart Student</strong>
            <small>FYP Management System</small>
          </span>
        </Link>
        <div className="auth-rail-copy">
          <p className="eyebrow">ICT Department · FYP workspace</p>
          <h1>Join Smart Student</h1>
          <p className="register-role-prompt">
            Select your role below — your form fields will update automatically.
          </p>
          <div className="role-selector" aria-label="Select your account role">
            {ROLES.map(({ id, label, desc, icon: Icon, disabled }) => (
              <button
                key={id}
                type="button"
                className={`role-card ${role === id ? "selected" : ""} ${disabled ? "disabled" : ""}`}
                onClick={() => !disabled && handleRoleChange(id)}
                disabled={disabled}
                title={disabled ? "Contact your administrator to create an admin account." : undefined}
                aria-pressed={role === id}
              >
                <span className="role-card-icon"><Icon size={18} /></span>
                <span className="role-card-body">
                  <strong>{label}</strong>
                  <span>{desc}</span>
                </span>
                {role === id && !disabled && (
                  <span className="role-card-check"><Check size={13} /></span>
                )}
                {disabled && <span className="role-card-lock">Admin only</span>}
              </button>
            ))}
          </div>
        </div>
        <div className="auth-rail-footer">
          <span className="rail-dot" /> BSCS &amp; BSAI · FYP Cycle
        </div>
      </section>

      {/* ── Right form panel ── */}
      <main className="auth-form-panel">
        <div className="auth-form-wrap">
          <div className="mobile-auth-brand">
            <span className="brand-mark"><GraduationCap size={19} /></span>
            <strong>Smart Student</strong>
          </div>

          <p className="eyebrow">FYP workspace registration</p>
          <h2>Create Your Account</h2>

          {errors.api && <div className="form-alert error">{errors.api}</div>}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-grid">
              <Field
                label="Full name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                error={errors.name}
                placeholder="e.g. Ayesha Khan"
              />
              <Field
                label="University email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                error={errors.email}
                placeholder="name@university.edu.pk"
              />
              <Field
                label="Phone number"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+92 300 0000000"
              />

              {/* ── Student-only fields ── */}
              {isStudent && (
                <>
                  <Field
                    label="Student ID"
                    name="studentId"
                    value={formData.studentId}
                    onChange={handleChange}
                    error={errors.studentId}
                    placeholder="e.g. ICT-23-104"
                  />
                  <SelectField
                    label="Program"
                    name="program"
                    value={formData.program}
                    onChange={handleChange}
                    options={[
                      ["BSCS", "BSCS · Computer Science"],
                      ["BSAI", "BSAI · Artificial Intelligence"],
                    ]}
                  />
                  <Field
                    label="Batch"
                    name="batch"
                    value={formData.batch}
                    onChange={handleChange}
                    error={errors.batch}
                    placeholder="e.g. 2023"
                  />
                  <Field
                    label="Semester"
                    name="semester"
                    value={formData.semester}
                    onChange={handleChange}
                    error={errors.semester}
                    placeholder="e.g. 7th"
                  />
                  <Field
                    label="Section"
                    name="section"
                    value={formData.section}
                    onChange={handleChange}
                    error={errors.section}
                    placeholder="e.g. A"
                  />
                </>
              )}

              {/* ── Supervisor-only fields ── */}
              {isSupervisor && (
                <>
                  <Field
                    label="Employee ID"
                    name="employeeId"
                    value={formData.employeeId}
                    onChange={handleChange}
                    error={errors.employeeId}
                    placeholder="e.g. EMP-001"
                  />
                  <Field
                    label="Department"
                    name="department"
                    value={formData.department}
                    onChange={handleChange}
                    error={errors.department}
                    placeholder="e.g. ICT Department"
                  />
                  <Field
                    label="Designation"
                    name="designation"
                    value={formData.designation}
                    onChange={handleChange}
                    error={errors.designation}
                    placeholder="e.g. Lecturer / Assistant Professor"
                  />
                  <Field
                    label="Specialization (optional)"
                    name="specialization"
                    value={formData.specialization}
                    onChange={handleChange}
                    placeholder="e.g. Machine Learning, Web Dev"
                  />
                </>
              )}
            </div>

            <div className="form-grid register-password-grid">
              <PasswordField
                label="Password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                show={showPassword}
                onToggle={() => setShowPwd((v) => !v)}
                error={errors.password}
              />
              <PasswordField
                label="Confirm password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                show={showConfirm}
                onToggle={() => setShowConf((v) => !v)}
                error={errors.confirmPassword}
              />
              {/* Show strength + requirements only after user starts typing */}
              {formData.password.length > 0 && (
                <>
                  <div className="strength-meter register-strength-meter">
                    <div className="strength-bars">
                      {CHECKS.map(([id], i) => (
                        <span key={id} className={i < strength ? strengthClass : ""} />
                      ))}
                    </div>
                    <span className="strength-label">{strengthLabel}</span>
                  </div>

                  <div className="password-requirements register-password-requirements">
                    {CHECKS.map(([id, label], i) => (
                      <span key={id} className={pwdChecks[i] ? "valid" : ""}>
                        {pwdChecks[i] ? <Check size={12} /> : <span className="requirement-dot" />}
                        {label}
                      </span>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Terms */}
            <label className="terms-row">
              <input type="checkbox" name="terms" checked={formData.terms} onChange={handleChange} />
              <span>
                I agree to the FYP workspace{" "}
                <span className="text-button" style={{ cursor: "default" }}>terms</span>{" "}
                and academic integrity policy.
              </span>
            </label>
            {errors.terms && <p className="field-error" style={{ marginTop: -10, marginBottom: 12 }}>{errors.terms}</p>}

            <button className="auth-submit" disabled={loading}>
              {loading
                ? "Creating account…"
                : `Create ${isStudent ? "student" : "supervisor"} account`}
              <ArrowRight size={18} />
            </button>
          </form>

          <p className="auth-switch">
            Already registered? <Link to="/login">Sign in to Smart Student</Link>
          </p>
        </div>
      </main>
    </div>
  );
}

/* ─── Reusable field components ─── */
function Field({ label, error, ...props }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input {...props} />
      <small className="field-error">{error || " "}</small>
    </label>
  );
}

function SelectField({ label, options, ...props }) {
  return (
    <label className="field">
      <span>{label}</span>
      <div className="select-wrap">
        <select {...props}>
          {options.map(([value, text]) => (
            <option key={value} value={value}>{text}</option>
          ))}
        </select>
        <ChevronDown size={14} className="select-chevron" />
      </div>
      <small className="field-error"> </small>
    </label>
  );
}

function PasswordField({ label, show, onToggle, error, ...props }) {
  return (
    <label className="field">
      <span>{label}</span>
      <div className="password-wrap">
        <input
          {...props}
          type={show ? "text" : "password"}
          autoComplete="new-password"
          aria-invalid={Boolean(error)}
        />
        <button
          type="button"
          onClick={onToggle}
          aria-label={show ? `Hide ${label}` : `Show ${label}`}
          aria-pressed={show}
        >
          {show ? <EyeOff size={17} /> : <Eye size={17} />}
        </button>
      </div>
      <small className={`field-error ${error ? "has-error" : ""}`} aria-live="polite">
        {error || " "}
      </small>
    </label>
  );
}
