import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Bell,
  Globe2,
  Info,
  KeyRound,
  Palette,
  Save,
  UserRound,
} from "lucide-react";
import { api, clearSession, getStoredUser } from "../api/api";

const NOTIFICATION_TYPES = [
  ["deadline_reminders", "Deadline Reminders"],
  ["feedback", "Feedback"],
  ["project_updates", "Project Updates"],
  ["evaluation_updates", "Evaluation Updates"],
  ["announcements", "Announcements"],
  ["ai_risk_alerts", "AI Risk Alerts"],
  ["weekly_log_notifications", "Weekly Log Notifications"],
  ["meeting_reminders", "Meeting Reminders"],
];

const EMPTY_PROFILE = {
  name: "",
  email: "",
  phone: "",
  bio: "",
  cgpa: "",
  specialization: "",
  max_students: "",
};

function getErrorMessage(error) {
  return error instanceof Error ? error.message : "Something went wrong. Please try again.";
}

export default function Preferences() {
  const navigate = useNavigate();
  const user = getStoredUser();
  const role = user?.role || "student";
  const [profile, setProfile] = useState(EMPTY_PROFILE);
  const [profileForm, setProfileForm] = useState(EMPTY_PROFILE);
  const [profileLoading, setProfileLoading] = useState(true);
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileError, setProfileError] = useState("");
  const [profileMessage, setProfileMessage] = useState("");
  const [items, setItems] = useState([]);
  const [preferencesLoading, setPreferencesLoading] = useState(true);
  const [preferencesError, setPreferencesError] = useState("");
  const [preferencesMessage, setPreferencesMessage] = useState("");
  const [savingEvent, setSavingEvent] = useState("");
  const [password, setPassword] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordError, setPasswordError] = useState("");
  const [passwordSaving, setPasswordSaving] = useState(false);
  const locale = navigator.language || "en";
  const timeZone = useMemo(
    () => Intl.DateTimeFormat().resolvedOptions().timeZone || "System default",
    [],
  );
  const profileChanged = Object.keys(profileForm).some(
    (key) => key !== "email" && String(profileForm[key] ?? "") !== String(profile[key] ?? ""),
  );

  useEffect(() => {
    let ignore = false;

    api.getProfile()
      .then((data) => {
        if (ignore) return;
        const nextProfile = {
          ...EMPTY_PROFILE,
          ...data,
          cgpa: data.cgpa ?? "",
          max_students: data.max_students ?? "",
        };
        setProfile(nextProfile);
        setProfileForm(nextProfile);
      })
      .catch((error) => {
        if (!ignore) setProfileError(getErrorMessage(error));
      })
      .finally(() => {
        if (!ignore) setProfileLoading(false);
      });

    api.getPreferences()
      .then((data) => {
        if (!Array.isArray(data)) throw new Error("Notification preferences could not be loaded.");
        if (!ignore) setItems(data);
      })
      .catch((error) => {
        if (!ignore) setPreferencesError(getErrorMessage(error));
      })
      .finally(() => {
        if (!ignore) setPreferencesLoading(false);
      });

    return () => {
      ignore = true;
    };
  }, []);

  const handleProfileChange = (event) => {
    const { name, value } = event.target;
    setProfileForm((current) => ({ ...current, [name]: value }));
    setProfileError("");
    setProfileMessage("");
  };

  const saveProfile = async (event) => {
    event.preventDefault();
    const changes = {};
    for (const key of ["name", "phone", "bio", "cgpa", "specialization", "max_students"]) {
      if (String(profileForm[key] ?? "") === String(profile[key] ?? "")) continue;
      if (key === "cgpa" || key === "max_students") {
        if (profileForm[key] === "") continue;
        changes[key] = Number(profileForm[key]);
      } else {
        changes[key] = profileForm[key].trim();
      }
    }

    if (!Object.keys(changes).length) return;

    setProfileSaving(true);
    setProfileError("");
    setProfileMessage("");
    try {
      await api.updateProfile(changes);
      const nextProfile = { ...profile, ...changes };
      setProfile(nextProfile);
      setProfileForm(nextProfile);
      if (changes.name) {
        const updatedUser = { ...getStoredUser(), name: changes.name };
        localStorage.setItem("user", JSON.stringify(updatedUser));
        window.dispatchEvent(new CustomEvent("projectflow:profile-updated", { detail: updatedUser }));
      }
      setProfileMessage("Profile settings saved.");
    } catch (error) {
      setProfileError(getErrorMessage(error));
    } finally {
      setProfileSaving(false);
    }
  };

  const updatePreference = async (item, channel) => {
    setSavingEvent(item.event_key);
    setPreferencesError("");
    setPreferencesMessage("");
    const next = { ...item, [channel]: item[channel] ? 0 : 1 };
    try {
      await api.updatePreference(next);
      setItems((current) =>
        current.map((entry) => entry.event_key === item.event_key ? next : entry),
      );
      setPreferencesMessage("Notification preference saved.");
    } catch (error) {
      setPreferencesError(getErrorMessage(error));
    } finally {
      setSavingEvent("");
    }
  };

  const changePassword = async (event) => {
    event.preventDefault();
    setPasswordError("");
    if (password.newPassword !== password.confirmPassword) {
      setPasswordError("The new passwords do not match.");
      return;
    }

    setPasswordSaving(true);
    try {
      await api.changePassword({
        currentPassword: password.currentPassword,
        newPassword: password.newPassword,
      });
      clearSession();
      navigate("/login", {
        replace: true,
        state: { logoutWarning: "Password changed. Please sign in with your new password." },
      });
    } catch (error) {
      setPasswordError(getErrorMessage(error));
      setPasswordSaving(false);
    }
  };

  return (
    <div className="settings-page">
      <header className="settings-heading">
        <p className="eyebrow">Workspace settings</p>
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Manage your profile, security, and notification preferences.</p>
      </header>

      <section className="dashboard-card settings-card" aria-labelledby="profile-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><UserRound size={18} /></span>
          <div>
            <h2 id="profile-settings-title">Profile Settings</h2>
            <p>Update the personal information used in your workspace.</p>
          </div>
        </div>
        {profileError && <p className="settings-alert error" role="alert">{profileError}</p>}
        {profileMessage && <p className="settings-alert success" role="status">{profileMessage}</p>}
        {profileLoading ? (
          <p className="settings-feedback" role="status">Loading profile settings…</p>
        ) : (
          <form className="settings-form" onSubmit={saveProfile}>
            <div className="settings-form-grid">
              <label className="settings-field">
                <span>Full name</span>
                <input name="name" value={profileForm.name} onChange={handleProfileChange} required minLength={2} maxLength={100} />
              </label>
              <label className="settings-field">
                <span>Email address</span>
                <input type="email" value={profileForm.email} readOnly />
              </label>
              <label className="settings-field">
                <span>Phone</span>
                <input name="phone" value={profileForm.phone} onChange={handleProfileChange} maxLength={30} />
              </label>
              {role === "student" && (
                <label className="settings-field">
                  <span>CGPA</span>
                  <input name="cgpa" type="number" min="0" max="4" step="0.01" value={profileForm.cgpa} onChange={handleProfileChange} />
                </label>
              )}
              {role === "supervisor" && (
                <>
                  <label className="settings-field">
                    <span>Specialization</span>
                    <input name="specialization" value={profileForm.specialization} onChange={handleProfileChange} maxLength={200} />
                  </label>
                  <label className="settings-field">
                    <span>Maximum students</span>
                    <input name="max_students" type="number" min="1" max="100" step="1" value={profileForm.max_students} onChange={handleProfileChange} />
                  </label>
                </>
              )}
              <label className="settings-field settings-field-wide">
                <span>About me</span>
                <textarea name="bio" rows="3" maxLength={2000} value={profileForm.bio} onChange={handleProfileChange} />
              </label>
            </div>
            <button className="settings-primary-button" type="submit" disabled={!profileChanged || profileSaving}>
              <Save size={16} /> {profileSaving ? "Saving…" : "Save profile"}
            </button>
          </form>
        )}
      </section>

      <section className="dashboard-card settings-card" aria-labelledby="password-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><KeyRound size={18} /></span>
          <div>
            <h2 id="password-settings-title">Change Password</h2>
            <p>Changing your password will sign you out of this session.</p>
          </div>
        </div>
        {passwordError && <p className="settings-alert error" role="alert">{passwordError}</p>}
        <form className="settings-form" onSubmit={changePassword}>
          <div className="settings-form-grid">
            <label className="settings-field">
              <span>Current password</span>
              <input type="password" autoComplete="current-password" required value={password.currentPassword} onChange={(event) => setPassword({ ...password, currentPassword: event.target.value })} />
            </label>
            <label className="settings-field">
              <span>New password</span>
              <input type="password" autoComplete="new-password" minLength={8} pattern="(?=.*[A-Z])(?=.*[0-9]).{8,}" title="Use at least 8 characters, including an uppercase letter and a number." required value={password.newPassword} onChange={(event) => setPassword({ ...password, newPassword: event.target.value })} />
            </label>
            <label className="settings-field">
              <span>Confirm new password</span>
              <input type="password" autoComplete="new-password" minLength={8} required value={password.confirmPassword} onChange={(event) => setPassword({ ...password, confirmPassword: event.target.value })} />
            </label>
          </div>
          <button className="settings-primary-button" type="submit" disabled={passwordSaving}>
            <KeyRound size={16} /> {passwordSaving ? "Updating…" : "Update password"}
          </button>
        </form>
      </section>

      <section className="dashboard-card settings-card" aria-labelledby="notification-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><Bell size={18} /></span>
          <div>
            <h2 id="notification-settings-title">Notification Preferences</h2>
            <p>Choose separately how each type of update reaches you.</p>
          </div>
        </div>
        {preferencesError && <p className="settings-alert error" role="alert">{preferencesError}</p>}
        {preferencesMessage && <p className="settings-alert success" role="status">{preferencesMessage}</p>}
        {preferencesLoading ? (
          <p className="settings-feedback" role="status">Loading notification preferences…</p>
        ) : (
          <div className="settings-notifications">
            <div className="settings-notification-header" aria-hidden="true">
              <span>Notification type</span><span>In-App</span><span>Email</span>
            </div>
            {NOTIFICATION_TYPES.map(([key, label]) => {
              const item = items.find((preference) => preference.event_key === key);
              if (!item) return null;
              return (
                <div className="settings-notification-row" key={key}>
                  <span className="settings-notification-name">{label}</span>
                  {["in_app", "email"].map((channel) => (
                    <button
                      className={`settings-toggle ${item[channel] ? "is-on" : ""}`}
                      key={channel}
                      type="button"
                      role="switch"
                      aria-checked={Boolean(item[channel])}
                      aria-label={`${label} ${channel === "in_app" ? "In-App" : "Email"}`}
                      disabled={savingEvent === key}
                      onClick={() => updatePreference(item, channel)}
                    >
                      <span />
                    </button>
                  ))}
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="dashboard-card settings-card" aria-labelledby="appearance-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><Palette size={18} /></span>
          <div>
            <h2 id="appearance-settings-title">Appearance</h2>
            <p>ProjectFlow uses the workspace’s professional corporate blue theme.</p>
          </div>
        </div>
        <div className="settings-info-row">
          <span>Active theme</span><strong>Corporate blue</strong>
        </div>
      </section>

      <section className="dashboard-card settings-card" aria-labelledby="language-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><Globe2 size={18} /></span>
          <div>
            <h2 id="language-settings-title">Language &amp; Region</h2>
            <p>Regional defaults detected from this browser and device.</p>
          </div>
        </div>
        <div className="settings-info-grid">
          <div className="settings-info-row"><span>Browser language</span><strong>{locale}</strong></div>
          <div className="settings-info-row"><span>Time zone</span><strong>{timeZone}</strong></div>
        </div>
      </section>

      <section className="dashboard-card settings-card" aria-labelledby="about-settings-title">
        <div className="settings-section-heading">
          <span className="settings-section-icon"><Info size={18} /></span>
          <div>
            <h2 id="about-settings-title">About System</h2>
            <p>ProjectFlow FYP Management System</p>
          </div>
        </div>
        <div className="settings-info-grid">
          <div className="settings-info-row"><span>Workspace</span><strong>FYP Management</strong></div>
          <div className="settings-info-row"><span>Account role</span><strong className="settings-role">{role}</strong></div>
        </div>
      </section>
    </div>
  );
}
