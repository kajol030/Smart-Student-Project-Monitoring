import { useEffect, useState } from "react";
import {
  AlertTriangle, ArrowUpRight, CheckCircle2, CircleAlert,
  FolderKanban, GitBranch, Loader, Pencil, Plus,
  RefreshCw, Sparkles, X,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";
import { probabilityToPercent } from "../utils/probability";

/* ─── Constants ─────────────────────────────────────────────── */
const CATEGORIES = [
  "Web Application", "Mobile Application", "Desktop Application",
  "AI / Machine Learning", "Data Science", "IoT / Embedded Systems",
  "Cybersecurity", "Networking", "Blockchain", "Other",
];
const DOMAINS = [
  "Computer Science", "Software Engineering", "Information Technology",
  "Artificial Intelligence", "Data Science", "Cyber Security",
];

const GITHUB_RE = /^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/;

/* ─── Risk colour helper ─────────────────────────────────────── */
function riskTone(level) {
  if (level === "high")   return "rose";
  if (level === "medium") return "amber";
  return "teal";
}
function riskColor(level) {
  if (level === "high")   return "#de687b";
  if (level === "medium") return "#e4b45e";
  return "#16a34a";
}
function formatRiskConfidence(prediction) {
  const probabilities = Object.values(prediction?.risk_probabilities || {});
  return probabilities.length
    ? `${probabilityToPercent(Math.max(...probabilities))}%`
    : "Unavailable";
}

/* ══════════════════════════════════════════════════════════════
   MAIN COMPONENT
══════════════════════════════════════════════════════════════ */
export default function Projects() {
  const user = getStoredUser();
  const role = user?.role || "student";
  const isStudent = role === "student";
  const canManageRepo = isStudent || role === "supervisor";
  const canManageOutcomes = role === "supervisor" || role === "admin";

  /* ── project list state ── */
  const [projects,    setProjects]    = useState([]);
  const [supervisors, setSupervisors] = useState([]);
  const [groups, setGroups] = useState([]);
  const [form, setForm] = useState({
    title: "", description: "", category: "", keywords: "", domain: "", group_id: "",
    preferred_supervisors: [],
  });
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState("");
  const [showForm, setShowForm] = useState(false);

  /* ── per-project detail state ── */
  const [ghData,   setGhData]   = useState({});   // { [pid]: data | null | "loading" | "error" }
  const [predData, setPredData] = useState({});    // { [pid]: data | null | "loading" | "error" }

  /* ── github URL edit state ── */
  const [editingGh,  setEditingGh]  = useState(null);  // pid being edited
  const [ghUrlInput, setGhUrlInput] = useState("");
  const [ghUrlError, setGhUrlError] = useState("");
  const [ghUrlSaving, setGhUrlSaving] = useState(false);
  const [outcomeForms, setOutcomeForms] = useState({});
  const [outcomeSaving, setOutcomeSaving] = useState({});
  const [outcomeErrors, setOutcomeErrors] = useState({});

  const updateProjectOutcome = async (projectId, form, verify = false) => {
    setOutcomeSaving((current) => ({ ...current, [projectId]: true }));
    setOutcomeErrors((current) => ({ ...current, [projectId]: "" }));
    try {
      let outcome = await api.saveProjectOutcome(projectId, {
        expected_completion_date: form.expected_completion_date,
        actual_completion_date: form.actual_completion_date || null,
        outcome_status: form.outcome_status || null,
      });
      if (verify) outcome = await api.verifyProjectOutcome(projectId);
      setProjects((current) => current.map((project) =>
        project.id === projectId ? { ...project, ...outcome } : project
      ));
      setOutcomeForms((current) => ({ ...current, [projectId]: outcome }));
    } catch (error) {
      setOutcomeErrors((current) => ({ ...current, [projectId]: error.message }));
    } finally {
      setOutcomeSaving((current) => ({ ...current, [projectId]: false }));
    }
  };

  const load = async () => {
    try {
      const [data, sups] = await Promise.all([
        api.getProjects(),
        api.getSupervisors().catch(() => []),
      ]);
      setProjects(data);
      setSupervisors(sups);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const [data, sups, groupData] = await Promise.all([
  api.getProjects(),
  api.getSupervisors().catch(() => []),
  api.getGroups().catch(() => []),
]);

if (!ignore) {
  setProjects(data);
  setSupervisors(sups);
  setGroups(
    Array.isArray(groupData)
      ? groupData
      : groupData.groups || []
  );
}
      } catch (err) { if (!ignore) setError(err.message); }
      finally      { if (!ignore) setLoading(false); }
    })();
    return () => { ignore = true; };
  }, []);

  /* ── fetch GitHub + prediction data for a project ── */
  const loadProjectDetails = async (p) => {
    const pid = p.id;
    /* GitHub */
    if (p.github_url) {
      setGhData((prev) => ({ ...prev, [pid]: "loading" }));
      try {
        const gh = await api.getGithubData(pid);
        setGhData((prev) => ({ ...prev, [pid]: gh }));
      } catch {
        setGhData((prev) => ({ ...prev, [pid]: "error" }));
      }
    } else {
      setGhData((prev) => ({ ...prev, [pid]: null }));
    }
    /* Prediction */
    setPredData((prev) => ({ ...prev, [pid]: "loading" }));
    try {
      const pred = await api.getPrediction(pid);
      setPredData((prev) => ({ ...prev, [pid]: pred }));
    } catch {
      setPredData((prev) => ({ ...prev, [pid]: "error" }));
    }
  };

  /* Auto-load details for all projects after list loads */
  useEffect(() => {
    if (!projects.length) return;
    projects.forEach(loadProjectDetails);
  }, [projects.map((p) => p.id).join(",")]); // eslint-disable-line

  /* ── create project ── */
  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.createProject(form);
      setForm({ title: "", description: "", category: "", keywords: "", domain: "",group_id: "", preferred_supervisors: [] });
      setShowForm(false);
      load();
    } catch (err) { setError(err.message); }
  };

  /* ── save GitHub URL ── */
  const saveGithubUrl = async (pid) => {
    const url = ghUrlInput.trim().replace(/\/$/, "");
    if (!GITHUB_RE.test(url)) {
      setGhUrlError("Enter a valid GitHub repository URL: https://github.com/username/repo");
      return;
    }
    setGhUrlSaving(true);
    setGhUrlError("");
    try {
      await api.updateGithubUrl(pid, url);
      /* Update local project list */
      setProjects((prev) => prev.map((p) => p.id === pid ? { ...p, github_url: url } : p));
      setEditingGh(null);
      setGhUrlInput("");
      /* Reload GitHub data for this project */
      setGhData((prev) => ({ ...prev, [pid]: "loading" }));
      try {
        const gh = await api.getGithubData(pid);
        setGhData((prev) => ({ ...prev, [pid]: gh }));
      } catch {
        setGhData((prev) => ({ ...prev, [pid]: "error" }));
      }
    } catch (err) {
      setGhUrlError(err.message);
    } finally {
      setGhUrlSaving(false);
    }
  };

  if (loading) return <div className="loading-state"><div /><div /><div /><p>Loading projects…</p></div>;

  return (
    <div className="space-y-6">

      {/* ── Header ── */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="eyebrow">Student workspace</p>
          <h1 className="page-title">My Project</h1>
          <p className="page-subtitle">Create and manage your FYP proposal.</p>
        </div>
        {isStudent && projects.length === 0 && (
          <button
            className="auth-submit"
            style={{ width: "auto", padding: "0 18px" }}
            onClick={() => setShowForm((v) => !v)}
          >
            {showForm ? <><X size={15} /> Cancel</> : <><Plus size={15} /> New Project</>}
          </button>
        )}
      </div>

      {error && <div className="form-alert error">{error}</div>}

      {/* ── Create project form ── */}
      {showForm && (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2><FolderKanban size={16} /> Submit FYP Topic</h2>
          </div>
          <form onSubmit={handleCreate} className="grid gap-4">
            <label className="field">
              <span>Project Title / Topic <span style={{ color: "#de687b" }}>*</span></span>
              <input placeholder="Enter your proposed topic" value={form.title} minLength={5} maxLength={200}
                onChange={(e) => setForm({ ...form, title: e.target.value })} required />
            </label>
            {/* Select Project Group */}
<label className="field">
  <span>Select Project Group</span>

  <select
    value={form.group_id}
    required
    onChange={(e) =>
      setForm({ ...form, group_id: e.target.value })
    }
  >
    <option value="">Select Your Group</option>

    {groups
      .filter((group) => String(group.leader_id) === String(user?.id))
      .map((group) => (
      <option key={group.id} value={group.id}>
        {group.name}
      </option>
    ))}
  </select>
</label>
            <div className="form-grid">
              <label className="field">
                <span>Project Category <span style={{ color: "#de687b" }}>*</span></span>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} required>
                  <option value="">Select Category</option>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
              <label className="field">
                <span>Domain / Department <span style={{ color: "#de687b" }}>*</span></span>
                <select value={form.domain} onChange={(e) => setForm({ ...form, domain: e.target.value })} required>
                  <option value="">Select Department</option>
                  {DOMAINS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </label>
            </div>
            <label className="field">
              <span>Project Description / Abstract <span style={{ color: "#de687b" }}>*</span></span>
              <textarea placeholder="Write a brief description of your proposed project…"
                maxLength={5000}
                value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                required style={{ height: 100, resize: "vertical" }} />
            </label>
            <label className="field">
              <span>Keywords <span style={{ color: "var(--muted)" }}>(optional)</span></span>
              <input placeholder="e.g. machine learning, NLP, prediction" value={form.keywords}
                onChange={(e) => setForm({ ...form, keywords: e.target.value })} />
            </label>
            <label className="field">
              <span>Preferred Supervisors <span style={{ color: "var(--muted)" }}>(up to 3)</span></span>
              <select value="" disabled={form.preferred_supervisors.length >= 3}
                onChange={(e) => {
                  const id = e.target.value; if (!id) return;
                  setForm((cur) => ({ ...cur, preferred_supervisors: cur.preferred_supervisors.includes(id) ? cur.preferred_supervisors : [...cur.preferred_supervisors, id] }));
                }}>
                <option value="">Select Supervisor</option>
                {supervisors.filter((s) => !form.preferred_supervisors.includes(String(s.id)))
                  .map((s) => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
              </select>
            </label>
            {form.preferred_supervisors.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {form.preferred_supervisors.map((id) => {
                  const sup = supervisors.find((s) => String(s.id) === id);
                  return (
                    <span key={id} className="status-badge in_progress" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11 }}>
                      {sup?.name || "Supervisor"}
                      <button type="button"
                        onClick={() => setForm((cur) => ({ ...cur, preferred_supervisors: cur.preferred_supervisors.filter((sid) => sid !== id) }))}
                        style={{ background: "none", border: "none", cursor: "pointer", color: "#de687b", fontWeight: 700, fontSize: 14, lineHeight: 1 }}>×</button>
                    </span>
                  );
                })}
              </div>
            )}
            <label style={{ display: "flex", alignItems: "flex-start", gap: 9, color: "var(--muted)", fontSize: 12, cursor: "pointer" }}>
              <input type="checkbox" required style={{ marginTop: 2, accentColor: "#63f477", width: 15, height: 15 }} />
              I confirm that this topic is original and not submitted elsewhere.
            </label>
            <div>
              <button className="auth-submit" style={{ width: "auto", padding: "0 28px" }}>Submit Topic</button>
            </div>
          </form>
        </section>
      )}

      {/* ── Project list ── */}
      {projects.length === 0 ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon violet"><FolderKanban size={20} /></div>
          <h2>No project yet</h2>
          <p className="muted-copy">Submit your FYP topic to unlock milestones, document reviews and AI performance insights.</p>
        </div>
      ) : (
        projects.map((p) => (
          <div key={p.id} className="space-y-6">
            {/* ── Main project card ── */}
            <section className="dashboard-card">
              <div className="card-heading">
                <div>
                  <p className="eyebrow">Current project</p>
                  <h2>{p.title}</h2>
                </div>
                <span className={`status-badge ${p.status || "proposal"}`}>
                  {(p.status || "proposal").replace("_", " ")}
                </span>
              </div>

              <p className="muted-copy">{p.description}</p>

              {(p.category || p.domain || p.keywords) && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginTop: 12 }}>
                  {p.category && <span className="status-badge review">{p.category}</span>}
                  {p.domain   && <span className="status-badge in_progress">{p.domain}</span>}
                  {p.keywords && <span className="status-badge proposal">{p.keywords}</span>}
                </div>
              )}

              <div className="progress-track" style={{ marginTop: 16 }}>
                <span style={{ width: `${p.progress || 0}%` }} />
              </div>
              <p className="muted-copy" style={{ marginTop: 6 }}>{p.progress || 0}% complete</p>

              <div className="mini-grid" style={{ marginTop: 16 }}>
                <div><span>Supervisor</span><strong>{p.supervisor_name || "Not assigned"}</strong></div>
                <div><span>Progress</span><strong>{p.progress || 0}%</strong></div>
                <div><span>Risk Level</span>
                  <strong style={{ textTransform: "capitalize", color: predData[p.id]?.prediction_available ? riskColor(predData[p.id].risk_level) : "var(--muted)" }}>
                    {predData[p.id]?.prediction_available ? predData[p.id].risk_level : "Unavailable"}
                  </strong>
                </div>
                <div><span>Risk Classifier Confidence</span><strong>{formatRiskConfidence(predData[p.id])}</strong></div>
              </div>

              {canManageOutcomes && (() => {
                const outcome = outcomeForms[p.id] || p;
                const form = {
                  expected_completion_date: outcome.expected_completion_date?.slice(0, 10) || "",
                  actual_completion_date: outcome.actual_completion_date?.slice(0, 10) || "",
                  outcome_status: outcome.outcome_status || "",
                };
                const changeForm = (field, value) => setOutcomeForms((current) => ({
                  ...current,
                  [p.id]: {
                    ...form,
                    [field]: value,
                    ...(field === "outcome_status" && value === "failed"
                      ? { actual_completion_date: "" }
                      : {}),
                  },
                }));
                return (
                  <section className="dashboard-card" style={{ marginTop: 16 }}>
                    <p className="eyebrow">Verified project outcome</p>
                    <div className="grid gap-3 md:grid-cols-3" style={{ marginTop: 10 }}>
                      <label className="field">
                        <span>Expected completion date</span>
                        <input type="date" value={form.expected_completion_date}
                          onChange={(event) => changeForm("expected_completion_date", event.target.value)} />
                      </label>
                      <label className="field">
                        <span>Actual completion date</span>
                        <input type="date" value={form.actual_completion_date}
                          disabled={form.outcome_status === "failed"}
                          onChange={(event) => changeForm("actual_completion_date", event.target.value)} />
                      </label>
                      <label className="field">
                        <span>Outcome</span>
                        <select value={form.outcome_status}
                          onChange={(event) => changeForm("outcome_status", event.target.value)}>
                          <option value="">Not completed yet — record date only</option>
                          <option value="completed_on_time" disabled={p.status !== "completed"}>Completed On Time</option>
                          <option value="delayed" disabled={p.status !== "completed"}>Delayed</option>
                          <option value="failed" disabled={p.status === "completed"}>Failed (explicit supervisor/admin decision)</option>
                        </select>
                      </label>
                    </div>
                    <p className="muted-copy" style={{ marginTop: 8 }}>
                      Completed outcomes are checked against the expected date. Unfinished projects are never automatically marked failed.
                      {outcome.outcome_verified
                        ? ` Verified ${outcome.verified_at ? `on ${new Date(outcome.verified_at).toLocaleDateString()}` : ""}.`
                        : " Saving records an unverified outcome; verify it separately to include it in model training."}
                    </p>
                    {outcomeErrors[p.id] && (
                      <p role="alert" className="form-alert error" style={{ marginTop: 8 }}>{outcomeErrors[p.id]}</p>
                    )}
                    <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                      <button className="auth-submit" style={{ width: "auto", padding: "0 16px" }}
                        disabled={outcomeSaving[p.id]}
                        onClick={() => updateProjectOutcome(p.id, form)}>
                        Save outcome
                      </button>
                      <button className="auth-submit" style={{ width: "auto", padding: "0 16px" }}
                        disabled={outcomeSaving[p.id] || !outcome.outcome_status || outcome.outcome_verified}
                        onClick={() => updateProjectOutcome(p.id, form, true)}>
                        Verify outcome
                      </button>
                    </div>
                  </section>
                );
              })()}

              {/* ── GitHub URL management ── */}
              {canManageRepo && (
                <div style={{ marginTop: 20, paddingTop: 16, borderTop: "1px solid var(--line)" }}>
                  {editingGh === p.id ? (
                    /* Edit mode */
                    <div style={{ display: "flex", gap: 10, alignItems: "flex-start", flexWrap: "wrap" }}>
                      <div style={{ flex: 1, minWidth: 240 }}>
                        <label className="field" style={{ margin: 0 }}>
                          <span><GitBranch size={12} style={{ display: "inline", marginRight: 5 }} />GitHub Repository URL</span>
                          <input
                            placeholder="https://github.com/username/repository"
                            value={ghUrlInput}
                            onChange={(e) => { setGhUrlInput(e.target.value); setGhUrlError(""); }}
                            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); saveGithubUrl(p.id); } }}
                          />
                        </label>
                        {ghUrlError && <span style={{ color: "#de687b", fontSize: 11, marginTop: 4, display: "block" }}>{ghUrlError}</span>}
                      </div>
                      <div style={{ display: "flex", gap: 7, alignSelf: "flex-end", paddingBottom: 1 }}>
                        <button
                          className="auth-submit"
                          style={{ width: "auto", padding: "0 16px", height: 43 }}
                          onClick={() => saveGithubUrl(p.id)}
                          disabled={ghUrlSaving}
                        >
                          {ghUrlSaving ? <Loader size={14} style={{ animation: "spin 1s linear infinite" }} /> : "Save"}
                        </button>
                        <button
                          className="icon-button"
                          style={{ width: 43, height: 43, border: "1px solid var(--line)" }}
                          onClick={() => { setEditingGh(null); setGhUrlInput(""); setGhUrlError(""); }}
                        ><X size={15} /></button>
                      </div>
                    </div>
                  ) : (
                    /* Display mode */
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <GitBranch size={15} style={{ color: "var(--muted)", flex: "none" }} />
                      {p.github_url ? (
                        <>
                          <a
                            href={p.github_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="primary-link"
                            style={{ fontSize: 12 }}
                          >
                            {p.github_url.replace("https://github.com/", "")}
                            <ArrowUpRight size={12} />
                          </a>
                          <button
                            className="icon-button"
                            title="Edit GitHub URL"
                            style={{ width: 28, height: 28 }}
                            onClick={() => { setEditingGh(p.id); setGhUrlInput(p.github_url); }}
                          ><Pencil size={13} /></button>
                        </>
                      ) : (
                        <>
                          <span className="muted-copy" style={{ flex: 1 }}>No GitHub repository linked.</span>
                          <button
                            className="text-button"
                            style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12 }}
                            onClick={() => { setEditingGh(p.id); setGhUrlInput(""); }}
                          ><Plus size={13} /> Link repository</button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* supervisor/admin: show URL as read-only link */}
              {!canManageRepo && p.github_url && (
                <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid var(--line)", display: "flex", alignItems: "center", gap: 8 }}>
                  <GitBranch size={14} style={{ color: "var(--muted)" }} />
                  <a href={p.github_url} target="_blank" rel="noopener noreferrer" className="primary-link" style={{ fontSize: 12 }}>
                    {p.github_url.replace("https://github.com/", "")} <ArrowUpRight size={12} />
                  </a>
                </div>
              )}

              <div style={{ marginTop: 16 }}>
                <a href="/milestones" className="primary-link">View Milestones <ArrowUpRight size={13} /></a>
              </div>
            </section>

            {/* ── GitHub Insights card ── */}
            <GithubInsightsCard ghState={ghData[p.id]} githubUrl={p.github_url}
              onRefresh={() => {
                if (!p.github_url) return;
                setGhData((prev) => ({ ...prev, [p.id]: "loading" }));
                api.getGithubData(p.id)
                  .then((gh) => setGhData((prev) => ({ ...prev, [p.id]: gh })))
                  .catch(() => setGhData((prev) => ({ ...prev, [p.id]: "error" })));
              }}
            />

            {/* ── AI Prediction card ── */}
            <AiPredictionCard predState={predData[p.id]}
              onRefresh={() => {
                setPredData((prev) => ({ ...prev, [p.id]: "loading" }));
                api.getPrediction(p.id)
                  .then((pred) => setPredData((prev) => ({ ...prev, [p.id]: pred })))
                  .catch(() => setPredData((prev) => ({ ...prev, [p.id]: "error" })));
              }}
            />
          </div>
        ))
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   GITHUB INSIGHTS CARD
══════════════════════════════════════════════════════════════ */
function GithubInsightsCard({ ghState, githubUrl, onRefresh }) {
  /* No URL configured */
  if (!githubUrl) {
    return (
      <section className="dashboard-card">
        <div className="card-heading">
          <h2><GitBranch size={16} /> GitHub Insights</h2>
        </div>
        <div className="empty-state" style={{ padding: "28px 20px" }}>
          <div className="metric-icon teal"><GitBranch size={18} /></div>
          <h2>No repository linked</h2>
          <p className="muted-copy">Link your GitHub repository above to see development activity and commit insights.</p>
        </div>
      </section>
    );
  }

  /* Loading */
  if (ghState === "loading" || ghState === undefined) {
    return (
      <section className="dashboard-card">
        <div className="card-heading">
        <h2><GitBranch size={16} /> GitHub Insights</h2>        </div>
        <div className="loading-state" style={{ maxWidth: "100%", margin: "20px 0" }}>
          <div /><div /><div style={{ width: "56%" }} />
          <p>Fetching repository data…</p>
        </div>
      </section>
    );
  }

  /* Error */
  if (ghState === "error") {
    return (
      <section className="dashboard-card">
        <div className="card-heading">
          <h2><GitBranch size={16} /> GitHub Insights</h2>
          <button className="icon-button" title="Retry" onClick={onRefresh}><RefreshCw size={14} /></button>
        </div>
        <div className="form-alert error" style={{ margin: 0 }}>
          Could not load GitHub data. The repository may be private, deleted, or GitHub is rate-limiting requests.
        </div>
      </section>
    );
  }

  /* Data */
  const { data } = ghState;
  if (!data) return null;
  const repo     = data.repository   || {};
  const commits  = data.commits      || {};
  const branches = data.branches     || {};
  const prs      = data.pull_requests || {};
  const issues   = data.issues       || {};
  const activity = data.activity     || {};

  return (
    <section className="dashboard-card">
      <div className="card-heading">
        <div>
          <p className="eyebrow">Development activity</p>
          <h2 style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <GitBranch size={16} /> GitHub Insights
          </h2>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {repo.language && <span className="status-badge review">{repo.language}</span>}
          <button className="icon-button" title="Refresh" onClick={onRefresh}><RefreshCw size={14} /></button>
          <a href={repo.html_url} target="_blank" rel="noopener noreferrer" className="card-link">
            View on GitHub <ArrowUpRight size={13} />
          </a>
        </div>
      </div>

      {repo.description && <p className="muted-copy" style={{ marginBottom: 16 }}>{repo.description}</p>}

      {/* Stat row */}
      <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", marginBottom: 18 }}>
        <StatTile label="Commits fetched"  value={commits.total_fetched ?? 0} tone="teal"   />
        <StatTile label="Branches fetched" value={branches.total_fetched ?? 0} tone="violet" />
        <StatTile label="Active Days"      value={activity.active_days ?? 0}  tone="violet" />
        <StatTile label="Open PRs"         value={prs.open_count ?? 0}         tone="blue"   />
        <StatTile label="Merged PRs"       value={prs.merged_count ?? 0}       tone="teal"   />
        <StatTile label="Open Issues"      value={issues.open_count ?? 0}      tone="amber"  />
        <StatTile label="Closed Issues"    value={issues.recent_closed_count ?? 0} tone="teal" />
      </div>

      {/* Activity metrics */}
      <div style={{ borderTop: "1px solid var(--line)", paddingTop: 14 }}>
        <p className="eyebrow" style={{ marginBottom: 10 }}>Activity metrics</p>
        <div className="simple-bars">
          <MetricBar label="Commit frequency"    value={`${activity.commit_frequency ?? 0} / active day`} pct={Math.min((activity.commit_frequency ?? 0) / 10 * 100, 100)} color="#42bdc8" />
          <MetricBar label="Days since last push" value={`${activity.recent_activity_days ?? "—"} days`}   pct={Math.min((activity.recent_activity_days ?? 0) / 90 * 100, 100)} color="#e4b45e" />
        </div>
      </div>

      {/* Recent commits */}
      {Array.isArray(commits.commits) && commits.commits.length > 0 && (
        <div style={{ marginTop: 16, borderTop: "1px solid var(--line)", paddingTop: 14 }}>
          <p className="eyebrow" style={{ marginBottom: 10 }}>Recent commits</p>
          {commits.commits.slice(0, 5).map((c) => (
            <div className="list-row" key={c.sha}>
              <div className="list-icon teal"><GitBranch size={13} /></div>
              <div className="list-main">
                <strong title={c.message}>{c.message?.slice(0, 72) || "—"}</strong>
                <span>{c.author_login || c.author_name || "Unknown"} · {c.date ? new Date(c.date).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "—"}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {Array.isArray(branches.branches) && branches.branches.length > 0 && (
        <div style={{ marginTop: 16, borderTop: "1px solid var(--line)", paddingTop: 14 }}>
          <p className="eyebrow" style={{ marginBottom: 10 }}>Branches</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
            {branches.branches.slice(0, 12).map((branch) => (
              <span className="status-badge review" key={branch.name}>{branch.name}</span>
            ))}
          </div>
        </div>
      )}

      <p className="muted-copy" style={{ marginTop: 12, fontSize: 10 }}>
        Default branch: <strong>{repo.default_branch || "—"}</strong>
        {typeof repo.size === "number" && <> · Repo size: <strong>{(repo.size / 1024).toFixed(1)} MB</strong></>}
        {(commits.capped || branches.capped || prs.capped || issues.capped) &&
          <> · Some lists are capped at 300 fetched records.</>}
      </p>
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   AI PREDICTION CARD
══════════════════════════════════════════════════════════════ */
function AiPredictionCard({ predState, onRefresh }) {
  if (predState === "loading" || predState === undefined) {
    return (
      <section className="dashboard-card ai-card">
        <div className="ai-heading">
          <span className="ai-icon"><Sparkles size={16} /></span>
          <div><p className="eyebrow">AI prediction</p><h2>Analysing project…</h2></div>
        </div>
        <div className="loading-state" style={{ maxWidth: "100%", margin: "16px 0 0" }}>
          <div /><div />
        </div>
      </section>
    );
  }

  if (predState === "error") {
    return (
      <section className="dashboard-card ai-card">
        <div className="card-heading">
          <div className="ai-heading">
            <span className="ai-icon"><Sparkles size={16} /></span>
            <div><p className="eyebrow">AI prediction</p><h2>Unavailable</h2></div>
          </div>
          <button className="icon-button" title="Retry" onClick={onRefresh}><RefreshCw size={14} /></button>
        </div>
        <p className="muted-copy">Prediction service is currently unavailable. Try again later.</p>
      </section>
    );
  }

  const pred = predState || {};
  const risk = ["low", "medium", "high"].includes(String(pred.risk_level || "").toLowerCase())
    ? pred.risk_level.toLowerCase()
    : "Unavailable";
  const riskProbabilities = Object.values(pred.risk_probabilities || {});
  const confidence = riskProbabilities.length
    ? `${probabilityToPercent(Math.max(...riskProbabilities))}%`
    : "—";
  const modelInfo = pred.model_info;
  const evaluationMetrics = modelInfo?.evaluation_metrics;
  const metricSummary = evaluationMetrics
    ? ["accuracy", "macro_f1", "macro_precision", "macro_recall"]
      .filter((name) => Number.isFinite(evaluationMetrics[name]))
      .map((name) => `${name}: ${evaluationMetrics[name].toFixed(3)}`)
      .join(" · ")
    : "";

  return (
    <section className="dashboard-card ai-card">
      <div className="card-heading">
        <div className="ai-heading">
          <span className="ai-icon"><Sparkles size={16} /></span>
          <div><p className="eyebrow">AI prediction</p><h2>Project risk analysis</h2></div>
        </div>
        <button className="icon-button" title="Refresh prediction" onClick={onRefresh}><RefreshCw size={14} /></button>
      </div>

      {/* Three metric tiles */}
      <div className="grid gap-4 md:grid-cols-3" style={{ marginBottom: 18 }}>
        {/* Risk level */}
        <div className="metric-card">
          <div className={`metric-icon ${risk === "Unavailable" ? "blue" : riskTone(risk)}`}><CircleAlert size={17} /></div>
          <p>Risk level</p>
          <strong className="capitalize" style={{ color: risk === "Unavailable" ? "var(--muted)" : riskColor(risk) }}>{risk}</strong>
          <span>{risk === "Unavailable" ? "No trained ML model" : modelInfo?.model_name || "Logistic Regression"}</span>
        </div>
        <div className="metric-card">
          <div className="metric-icon violet"><AlertTriangle size={17} /></div>
          <p>Classifier confidence</p>
          <strong>{pred.prediction_available ? confidence : "—"}</strong>
          <span>Maximum synthetic class probability</span>
        </div>
        <div className="metric-card">
          <div className="metric-icon blue"><CheckCircle2 size={17} /></div>
          <p>Training records</p>
          <strong>{modelInfo?.dataset?.record_count ?? "—"}</strong>
          <span>Synthetic; not real-world validation</span>
        </div>
      </div>

      <div role="status" className="form-alert">
        <strong>{modelInfo?.model_name || "Logistic Regression not available"}</strong>
        <p style={{ marginTop: 6 }}>
          Synthetic Dataset Evaluation — Not Real-world Validation. {modelInfo?.message || "The synthetic Logistic Regression model is unavailable."}
        </p>
        <p style={{ marginTop: 6 }}>
          {metricSummary
            ? `Held-out synthetic test metrics: ${metricSummary}`
            : "Synthetic evaluation metrics are unavailable."}
        </p>
      </div>
      {pred.prediction_available && (
        <div className="mini-grid" style={{ marginBottom: 16 }}>
          <div><span>Predicted risk class</span><strong>{pred.risk_class || pred.predicted_outcome || "—"}</strong></div>
          <div><span>Synthetic training records</span><strong>{modelInfo?.dataset?.record_count ?? "—"}</strong></div>
          <div><span>Held-out test records</span><strong>{modelInfo?.evaluation_metrics?.test_class_counts
            ? Object.values(modelInfo.evaluation_metrics.test_class_counts).reduce((sum, count) => sum + count, 0)
            : "—"}</strong></div>
          {Object.entries(pred.risk_probabilities || {}).map(([label, probability]) => (
            <div key={label}><span>{label} risk probability</span><strong>{probabilityToPercent(probability)}%</strong></div>
          ))}
        </div>
      )}

      {/* Recommendations */}
      {Array.isArray(pred.recommendations) && pred.recommendations.length > 0 && (
        <div>
          <p className="eyebrow" style={{ marginBottom: 10 }}>Recommendations</p>
          <div className="recommendation-list">
            {pred.recommendations.map((r) => (
              <div className="recommendation" key={r.message}>
                <CheckCircle2 size={14} />
                <span>{r.message}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {pred.features?.github_evidence_note && (
        <p className="muted-copy" style={{ marginTop: 10 }}>
          {pred.features.github_evidence_note}
        </p>
      )}

      <p className="muted-copy" style={{ marginTop: 10, fontSize: 10 }}>
        Model: <strong>{modelInfo?.model_name || pred.model_used || "Logistic Regression not available"}</strong>
        {" · "}
        <a href="/ai-insights" className="ai-link" style={{ fontSize: 10 }}>Full details <ArrowUpRight size={11} /></a>
      </p>
    </section>
  );
}

/* ── Small helpers ─────────────────────────────────────────── */
function StatTile({ label, value, tone }) {
  return (
    <div className="metric-card" style={{ padding: 14 }}>
      <div className={`metric-icon ${tone}`} style={{ width: 28, height: 28, marginBottom: 10 }}></div>
      <p>{label}</p>
      <strong style={{ fontSize: 20 }}>{value}</strong>
    </div>
  );
}

function MetricBar({ label, value, pct, color }) {
  return (
    <div className="simple-bar-row">
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <div><i style={{ width: `${Math.max(pct, 2)}%`, background: color }} /></div>
      <b style={{ whiteSpace: "nowrap" }}>{value}</b>
    </div>
  );
}
