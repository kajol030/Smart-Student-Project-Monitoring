import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  BookOpen,
  CircleAlert,
  ClipboardCheck,
  Users,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";
import { buildProjectMonitoringView } from "../utils/projectMonitoring";
import { getGreeting } from "../utils/greeting";

export default function SupervisorDashboard() {
  const user = getStoredUser();
  const [projects,  setProjects]  = useState([]);
  const [requests,  setRequests]  = useState([]);
  const [error,     setError]     = useState("");
  const [success,   setSuccess]   = useState("");
  const [loading,   setLoading]   = useState(true);
  const [monitoringProject, setMonitoringProject] = useState(null);
  const [monitorData, setMonitorData] = useState(null);

  const monitorProject = async (project) => {
    if (monitoringProject === project.id) {
      setMonitoringProject(null);
      setMonitorData(null);
      return;
    }

    setMonitoringProject(project.id);
    setMonitorData({ loading: true });
    const [github, alignment, prediction] = await Promise.allSettled([
      project.github_url ? api.getGithubData(project.id) : Promise.resolve(null),
      api.getProposalAlignment(project.id),
      api.getPrediction(project.id),
    ]);
    setMonitorData({
      github: github.status === "fulfilled" ? github.value : null,
      githubError: github.status === "rejected" ? github.reason.message : null,
      alignment: alignment.status === "fulfilled" ? alignment.value : null,
      alignmentError: alignment.status === "rejected" ? alignment.reason.message : null,
      prediction: prediction.status === "fulfilled" ? prediction.value : null,
      predictionError: prediction.status === "rejected" ? prediction.reason.message : null,
    });
  };

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const [projectData, requestData] = await Promise.all([
          api.getProjects(),
          api.getSupervisorRequests().catch(() => []),
        ]);
        if (!ignore) { setProjects(projectData); setRequests(requestData); }
      } catch (err) { if (!ignore) setError(err.message); }
      finally       { if (!ignore) setLoading(false); }
    })();
    return () => { ignore = true; };
  }, []);

  const respond = async (id, status) => {
    try {
      await api.respondToSupervisorRequest(id, status);
      setRequests((cur) =>
        cur.map((r) => r.id === id ? { ...r, status, preference_status: status } : r)
      );
      setSuccess(`Request ${status}. Admin will confirm the final assignment.`);
    } catch (err) { setError(err.message); }
  };

  const highRisk = projects.filter((p) => p.risk_level === "high").length;
  const avgProg  = projects.length
    ? Math.round(projects.reduce((a, p) => a + (p.progress || 0), 0) / projects.length)
    : 0;

  const pending = requests.filter((r) => r.status === "pending");
  const monitoringView = monitorData && !monitorData.loading
    ? buildProjectMonitoringView(monitorData)
    : null;

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading your workspace…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div>
        <p className="eyebrow">Supervisor workspace</p>
        <h1 className="page-title">
          {getGreeting()}, {user?.name?.split(" ")[0] || "Supervisor"}.
        </h1>
        <p className="page-subtitle">
          Monitor assigned students and manage project risks.
        </p>
      </div>

      {error   && <div className="form-alert error">{error}</div>}
      {success && <div className="form-alert" style={{ color: "#2c8d7b", background: "#eaf8f4" }}>{success}</div>}

      {/* ── Stat cards ── */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <div className="metric-card">
          <div className="metric-icon teal"><Users size={18} /></div>
          <p>Assigned Students</p>
          <strong>{projects.length}</strong>
          <span>Active FYP projects</span>
        </div>
        <div className="metric-card">
          <div className="metric-icon rose"><CircleAlert size={18} /></div>
          <p>High Risk Projects</p>
          <strong>{highRisk}</strong>
          <span>Require immediate attention</span>
        </div>
        <div className="metric-card">
          <div className="metric-icon violet"><BookOpen size={18} /></div>
          <p>Avg Progress</p>
          <strong>{avgProg}%</strong>
          <span>Across all projects</span>
        </div>
      </div>

      {/* ── Pending student requests ── */}
      {pending.length > 0 && (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2><ClipboardCheck size={17} /> Pending Student Requests</h2>
            <span className="muted-copy">{pending.length} awaiting response</span>
          </div>
          {pending.map((r) => (
            <div className="list-row" key={r.id} style={{ alignItems: "center" }}>
              <div className="list-icon violet"><ClipboardCheck size={15} /></div>
              <div className="list-main">
                <strong>{r.title}</strong>
                <span>{r.student_name} · Preference #{r.preference_order || "—"}</span>
              </div>
              <div style={{ display: "flex", gap: 8, flex: "none" }}>
                <button
                  onClick={() => respond(r.id, "accepted")}
                  className="auth-submit"
                  style={{ width: "auto", padding: "5px 14px", fontSize: 12, height: "auto", borderRadius: 8 }}
                >
                  Accept
                </button>
                <button
                  onClick={() => respond(r.id, "rejected")}
                  className="icon-button"
                  style={{ width: "auto", padding: "5px 12px", fontSize: 12, height: "auto", borderRadius: 8, border: "1px solid var(--line)", color: "#d4556a" }}
                >
                  Decline
                </button>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* ── Students table ── */}
      <section className="dashboard-card">
        <div className="card-heading">
          <h2><Users size={17} /> My Students</h2>
          <span className="muted-copy">{projects.length} total</span>
        </div>

        {projects.length === 0 ? (
          <div className="empty-state" style={{ padding: "40px 20px" }}>
            <div className="metric-icon teal"><Users size={20} /></div>
            <h2>No students assigned yet</h2>
            <p className="muted-copy">Students will appear here once assigned by admin.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--line)" }}>
                  {["Student", "Project", "Progress", "Risk", "Evidence"].map((h) => (
                    <th key={h} style={{ padding: "10px 12px", textAlign: "left", color: "var(--muted)", fontWeight: 600, fontSize: 11, textTransform: "uppercase", letterSpacing: ".06em" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.id} style={{ borderBottom: "1px solid var(--line)" }}>
                    <td style={{ padding: "12px 12px", fontWeight: 600 }}>{p.student_name}</td>
                    <td style={{ padding: "12px 12px" }}>{p.title}</td>
                    <td style={{ padding: "12px 12px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div className="progress-track" style={{ flex: 1, marginTop: 0, minWidth: 70 }}>
                          <span style={{ width: `${p.progress || 0}%` }} />
                        </div>
                        <span style={{ fontSize: 11, color: "var(--muted)", whiteSpace: "nowrap" }}>{p.progress || 0}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "12px 12px" }}>
                      <RiskBadge level={p.risk_level} />
                    </td>
                    <td style={{ padding: "12px 12px" }}>
                      <button
                        type="button"
                        onClick={() => monitorProject(p)}
                        className="primary-link"
                        style={{ background: "none", border: 0, cursor: "pointer", padding: 0 }}
                      >
                        {monitoringProject === p.id ? "Close" : "Monitor evidence"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {monitoringProject !== null && (
        <section className="dashboard-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Evidence review</p>
              <h2>{projects.find((project) => project.id === monitoringProject)?.title}</h2>
            </div>
            <button type="button" className="text-button" onClick={() => monitorProject({ id: monitoringProject })}>Close</button>
          </div>
          {monitorData?.loading ? (
            <p className="muted-copy">Loading repository, proposal, and risk evidence…</p>
          ) : monitorData && (
            <>
              {(monitoringView.githubError || monitoringView.alignmentError || monitoringView.predictionError) && (
                <div className="form-alert error">
                  {[monitoringView.githubError, monitoringView.alignmentError, monitoringView.predictionError]
                    .filter(Boolean).join(" ")}
                </div>
              )}
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <div className="metric-card">
                  <p>Official milestone progress</p>
                  <strong>{monitoringView.milestoneProgress == null
                    ? "—"
                    : `${monitoringView.milestoneProgress}%`}</strong>
                  <span>Recorded milestone status</span>
                </div>
                <div className="metric-card">
                  <p>Evidence estimate</p>
                  <strong>{monitoringView.evidenceEstimate == null
                    ? "—"
                    : `${monitoringView.evidenceEstimate}%`}</strong>
                  <span>Mixed evidence indicator, not verified completion</span>
                </div>
                <div className="metric-card">
                  <p>Proposal text alignment</p>
                  <strong>{monitoringView.alignmentScore == null
                    ? "—"
                    : `${monitoringView.alignmentScore}%`}</strong>
                  <span>Text similarity only; not feature verification</span>
                </div>
                <div className="metric-card">
                  <p>Predicted risk</p>
                  <strong style={{ textTransform: "capitalize" }}>
                    {monitoringView.riskLevel}
                  </strong>
                  <span>{monitoringView.riskModel}</span>
                </div>
              </div>

              <div className="grid gap-5 md:grid-cols-2" style={{ marginTop: 20 }}>
                <div>
                  <h3 style={{ marginBottom: 8 }}>Repository evidence</h3>
                  {!projects.find((project) => project.id === monitoringProject)?.github_url ? (
                    <p className="muted-copy">No repository linked. Add a URL from Projects before reviewing repository evidence.</p>
                  ) : monitoringView.github ? (
                    <>
                      <p className="muted-copy">
                        {monitoringView.github.repositoryName}: {monitoringView.github.commits ?? "—"} commits fetched,
                        {" "}{monitoringView.github.branches ?? "—"} branches,
                        {" "}{monitoringView.github.openPullRequests ?? "—"} open pull requests,
                        {" "}{monitoringView.github.openIssues ?? "—"} open issues.
                      </p>
                      <p className="muted-copy" style={{ marginTop: 6 }}>
                        Activity describes repository changes; it does not prove implementation quality, originality, or completion.
                      </p>
                    </>
                  ) : <p className="muted-copy">Repository data is unavailable or access was denied.</p>}
                </div>
                <div>
                  <h3 style={{ marginBottom: 8 }}>Proposal objective evidence</h3>
                  {monitoringView.alignmentSource && (
                    <p className="muted-copy" style={{ marginBottom: 8 }}>
                      Source: {monitoringView.alignmentSource.replaceAll("_", " ")}.
                    </p>
                  )}
                  {monitoringView.treeError && (
                    <p className="muted-copy" style={{ marginBottom: 8 }}>
                      Repository file-tree evidence unavailable: {monitoringView.treeError}
                    </p>
                  )}
                  {monitoringView.proposalDocumentError && (
                    <p className="muted-copy" style={{ marginBottom: 8 }}>
                      Proposal document note: {monitoringView.proposalDocumentError}
                    </p>
                  )}
                  {monitoringView.requirements.length ? (
                    monitoringView.requirements.map((requirement) => (
                      <div className="list-row" key={requirement.id}>
                        <div className="list-main">
                          <strong>{requirement.objective}</strong>
                          <span>{requirement.status.replaceAll("_", " ")} · {requirement.explanation}</span>
                        </div>
                      </div>
                    ))
                  ) : <p className="muted-copy">No proposal objectives or alignment results are available.</p>}
                </div>
              </div>

              <div style={{ marginTop: 18, borderTop: "1px solid var(--line)", paddingTop: 14 }}>
                <h3 style={{ marginBottom: 8 }}>Suggested evaluation follow-up</h3>
                <ul className="muted-copy" style={{ paddingLeft: 20, listStyle: "disc" }}>
                  {monitoringView.recommendations.map((recommendation) => (
                    <li key={recommendation}>{recommendation}</li>
                  ))}
                </ul>
                <p className="muted-copy" style={{ marginTop: 10 }}>
                  Predictions and repository evidence are advisory. Evaluation and final marks remain with the supervisor.
                </p>
              </div>
            </>
          )}
        </section>
      )}

      {/* ── Quick links ── */}
      <div className="grid gap-4 sm:grid-cols-2">
        <section className="dashboard-card">
          <div className="card-heading">
            <h2><ClipboardCheck size={17} /> Quick Actions</h2>
          </div>
          <div className="space-y-2">
            {[
              { to: "/supervisor/reviews",  label: "Review Submissions" },
              { to: "/projects",            label: "Link / analyze GitHub repository" },
              { to: "/feedback",            label: "Give Feedback"      },
              { to: "/meetings",            label: "Schedule Meeting"   },
              { to: "/milestones",          label: "Manage Milestones"  },
            ].map(({ to, label }) => (
              <Link key={to} to={to} className="list-row" style={{ textDecoration: "none", borderRadius: 8, padding: "10px 12px", background: "transparent" }}>
                <div className="list-icon violet"><ArrowUpRight size={14} /></div>
                <div className="list-main"><strong>{label}</strong></div>
                <ArrowUpRight size={14} className="muted-icon" />
              </Link>
            ))}
          </div>
        </section>

        <section className="dashboard-card">
          <div className="card-heading">
            <h2>Risk Overview</h2>
          </div>
          {["high", "medium", "low"].map((level) => {
            const count = projects.filter((p) => p.risk_level === level).length;
            const max   = projects.length || 1;
            return (
              <div key={level} className="simple-bar-row" style={{ gridTemplateColumns: "80px 1fr 32px" }}>
                <span style={{ textTransform: "capitalize" }}>{level}</span>
                <div>
                  <i style={{
                    width: `${(count / max) * 100}%`,
                    background: level === "high" ? "#de687b" : level === "medium" ? "#e4b45e" : "#42bdc8",
                  }} />
                </div>
                <b>{count}</b>
              </div>
            );
          })}
        </section>
      </div>
    </div>
  );
}

function RiskBadge({ level }) {
  const cls = {
    low:    "status-badge completed",
    medium: "status-badge proposal",
    high:   "status-badge",
  };
  const style = level === "high" ? { color: "#d4556a", background: "#ffebef" } : {};
  return (
    <span className={cls[level] || "status-badge"} style={style}>
      {level || "—"}
    </span>
  );
}
