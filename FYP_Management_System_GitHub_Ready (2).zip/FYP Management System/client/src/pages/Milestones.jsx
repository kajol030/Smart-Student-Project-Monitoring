import { useEffect, useState } from "react";
import { CalendarClock, CheckCircle2, Clock, AlertCircle, XCircle } from "lucide-react";
import { api, getStoredUser } from "../api/api";

const STATUS_META = {
  pending:     { label: "Pending",     icon: Clock,          cls: "status-badge proposal"     },
  in_progress: { label: "In Progress", icon: Clock,          cls: "status-badge in_progress"  },
  completed:   { label: "Completed",   icon: CheckCircle2,   cls: "status-badge completed"    },
  overdue:     { label: "Overdue",     icon: AlertCircle,    cls: "status-badge"               },
};

export default function Milestones() {
  const user    = getStoredUser();
  const role    = user?.role || "student";

  const [project,    setProject]    = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [error,      setError]      = useState("");
  const [loading,    setLoading]    = useState(true);

  const load = async () => {
    try {
      const projects = await api.getProjects();
      if (!projects.length) { setLoading(false); return; }
      setProject(projects[0]);
      const data = await api.getMilestones(projects[0].id);
      setMilestones(data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const projects = await api.getProjects();
        if (ignore || !projects.length) { if (!ignore) setLoading(false); return; }
        const [ms] = await Promise.all([api.getMilestones(projects[0].id)]);
        if (!ignore) { setProject(projects[0]); setMilestones(ms || []); }
      } catch (err) { if (!ignore) setError(err.message); }
      finally      { if (!ignore) setLoading(false); }
    })();
    return () => { ignore = true; };
  }, []);

  /* Only supervisor can change status */
  const updateStatus = async (id, status) => {
    if (role !== "supervisor" && role !== "admin") return;
    try {
      await api.updateMilestoneStatus(id, status);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading milestones…</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="dashboard-card empty-state">
        <div className="metric-icon violet"><CalendarClock size={20} /></div>
        <h2>No project found</h2>
        <p className="muted-copy">Create a project first to view its milestones.</p>
      </div>
    );
  }

  const completed = milestones.filter((m) => m.status === "completed").length;
  const total     = milestones.length;
  const pct       = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div>
        <p className="eyebrow">Project milestones</p>
        <h1 className="page-title">Milestones</h1>
        <p className="page-subtitle">Track your FYP progress step by step.</p>
      </div>

      {error && <div className="form-alert error">{error}</div>}

      {/* ── Progress summary card ── */}
      <div className="dashboard-card">
        <div className="card-heading">
          <div>
            <p className="eyebrow">Current project</p>
            <h2>{project.title}</h2>
          </div>
          <span className={`status-badge ${project.status || "proposal"}`}>
            {(project.status || "proposal").replace("_", " ")}
          </span>
        </div>
        <div className="progress-track">
          <span style={{ width: `${pct}%` }} />
        </div>
        <p className="muted-copy" style={{ marginTop: 8 }}>
          {completed} of {total} milestones completed &mdash; {pct}%
        </p>
      </div>

      {/* ── Milestone list ── */}
      {milestones.length === 0 ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon teal"><CalendarClock size={20} /></div>
          <h2>No milestones yet</h2>
          <p className="muted-copy">Your supervisor will add milestones to your project.</p>
        </div>
      ) : (
        <section className="dashboard-card">
          <h2 style={{ marginBottom: 4 }}>All milestones</h2>
          <p className="muted-copy" style={{ marginBottom: 16 }}>
            {role === "supervisor" || role === "admin"
              ? "You can mark milestones as completed or reset them."
              : "Only your supervisor can mark milestones as completed."}
          </p>

          <div className="space-y-4">
            {milestones.map((m, i) => {
              const meta   = STATUS_META[m.status] || STATUS_META.pending;
              const Icon   = meta.icon;
              const isDone = m.status === "completed";

              return (
                <div key={m.id} className="list-row" style={{ alignItems: "flex-start", padding: "16px 0" }}>
                  {/* Index bubble */}
                  <div className="metric-icon teal" style={{ flex: "none", fontWeight: 700, fontSize: 13 }}>
                    {i + 1}
                  </div>

                  {/* Content */}
                  <div className="list-main" style={{ flex: 1 }}>
                    <strong style={{ fontSize: 14 }}>{m.title}</strong>
                    {m.description && (
                      <span style={{ display: "block", marginTop: 3 }}>{m.description}</span>
                    )}
                    {m.due_date && (
                      <span style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 6 }}>
                        <CalendarClock size={12} />
                        Due {new Date(m.due_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
                      </span>
                    )}
                  </div>

                  {/* Status + action */}
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, flex: "none" }}>
                    <span className={meta.cls} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                      <Icon size={11} /> {meta.label}
                    </span>

                    {/* Only supervisor / admin can act */}
                    {(role === "supervisor" || role === "admin") && (
                      <div style={{ display: "flex", gap: 6 }}>
                        {!isDone && (
                          <button
                            onClick={() => updateStatus(m.id, "completed")}
                            className="auth-submit"
                            style={{ height: "auto", padding: "5px 12px", fontSize: 11, width: "auto", borderRadius: 7 }}
                          >
                            <CheckCircle2 size={12} /> Mark Done
                          </button>
                        )}
                        {isDone && (
                          <button
                            onClick={() => updateStatus(m.id, "pending")}
                            className="icon-button border"
                            style={{ padding: "5px 10px", fontSize: 11, width: "auto", height: "auto", borderRadius: 7, border: "1px solid var(--line)" }}
                            title="Reset to pending"
                          >
                            <XCircle size={12} /> Reset
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
