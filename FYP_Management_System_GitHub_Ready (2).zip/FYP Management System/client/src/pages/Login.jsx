import { useState } from "react";
import { ArrowRight, Eye, EyeOff, GraduationCap, LockKeyhole, Mail, ShieldCheck } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api, getDashboardPath, saveSession } from "../api/api";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "", remember: true });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.email.trim() || !form.password) return setError("Enter your email and password to continue.");
    setLoading(true);
    try {
      const data = await api.login({ email: form.email, password: form.password });
      saveSession(data.user, data.token);
      navigate(getDashboardPath(data.user.role));
    } catch (requestError) { setError(requestError.message); } finally { setLoading(false); }
  };

  return (
    <div className="auth-page login-page">
      <section className="auth-rail">
        <Link to="/login" className="auth-brand"><span className="brand-mark"><GraduationCap size={20} /></span><span>Smart Student</span></Link>
        <div className="auth-rail-copy"><p className="eyebrow">ICT Department / FYP workspace</p><h1>Everything your project needs, in one place.</h1><p>From first topic submission to final viva, keep academic work visible, accountable and on track.</p><div className="login-feature"><ShieldCheck size={18} /><span>Secure role-based access for students, supervisors and admins.</span></div></div>
        <div className="auth-rail-footer"><span className="rail-dot" /> Trusted workspace · BSCS & BSAI</div>
      </section>
      <main className="auth-form-panel login-panel"><div className="auth-form-wrap login-form-wrap">
        <div className="mobile-auth-brand"><span className="brand-mark"><GraduationCap size={19} /></span><strong>Smart Student</strong></div>
        <p className="eyebrow">Welcome back</p><h2>Sign in to your workspace</h2><p className="auth-subtitle">Continue where you left off and keep your FYP moving forward.</p>
        {error && <div className="form-alert error">{error}</div>}
        {location.state?.logoutWarning && (
          <div className="form-alert">{location.state.logoutWarning}</div>
        )}
        <form onSubmit={handleSubmit} noValidate>
          <label className="field"><span>Email or student ID</span><div className="password-wrap"><Mail size={16} /><input type="text" name="email" value={form.email} onChange={handleChange} placeholder="you@university.edu" autoComplete="username" /></div><small className="field-error"> </small></label>
          <label className="field"><span>Password</span><div className="password-wrap"><LockKeyhole size={16} /><input type={showPassword ? "text" : "password"} name="password" value={form.password} onChange={handleChange} placeholder="Enter your password" autoComplete="current-password" /><button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div><small className="field-error"> </small></label>
          <div className="login-options"><label className="terms-row"><input type="checkbox" name="remember" checked={form.remember} onChange={handleChange} /><span>Remember me</span></label><Link className="text-button" to="/forgot-password">Forgot password?</Link></div>
          <button className="auth-submit" disabled={loading}>{loading ? "Signing in..." : "Sign in"}<ArrowRight size={18} /></button>
        </form>
        <p className="auth-switch">New to the workspace? <Link to="/register">Create a student account</Link></p>
      </div></main>
    </div>
  );
}
