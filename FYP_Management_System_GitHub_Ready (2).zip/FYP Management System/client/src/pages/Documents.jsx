
import { useEffect, useState } from "react";
import { api } from "../api/api";

export default function Documents() {
  const [project, setProject] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [form, setForm] = useState({
    type: "proposal",
    title: "",
    notes: "",
  });
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [versions, setVersions] = useState({});
  const [versionFiles, setVersionFiles] = useState({});
  const [uploadingVersion, setUploadingVersion] = useState(null);

  // Load project and submitted documents
  const load = async () => {
    try {
      setError("");

      const projects = await api.getProjects();

      if (!Array.isArray(projects) || projects.length === 0) {
        setProject(null);
        setSubmissions([]);
        return;
      }

      const selectedProject = projects[0];
      const data = await api.getSubmissions(selectedProject.id);

      setProject(selectedProject);
      setSubmissions(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err.message || "Failed to load documents.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let ignore = false;

    async function loadDocuments() {
      try {
        const projects = await api.getProjects();

        if (ignore) return;

        if (!Array.isArray(projects) || projects.length === 0) {
          setProject(null);
          setSubmissions([]);
          return;
        }

        const selectedProject = projects[0];
        const data = await api.getSubmissions(selectedProject.id);

        if (!ignore) {
          setProject(selectedProject);
          setSubmissions(Array.isArray(data) ? data : []);
        }
      } catch (err) {
        if (!ignore) {
          setError(err.message || "Failed to load documents.");
        }
      } finally {
        if (!ignore) setLoading(false);
      }
    }

    loadDocuments();

    return () => {
      ignore = true;
    };
  }, []);

  // Upload a new document
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!project) {
      setError("Create a project first.");
      return;
    }

    if (!file) {
      setError("Please select a file.");
      return;
    }

    const fd = new FormData();
    fd.append("project_id", project.id);
    fd.append("type", form.type);
    fd.append("title", form.title.trim());
    fd.append("notes", form.notes);
    fd.append("file", file);

    try {
      setUploading(true);
      setError("");

      await api.createSubmission(fd);

      setForm({
        type: "proposal",
        title: "",
        notes: "",
      });

      setFile(null);

      // Clear the selected file in the form
      e.target.reset();

      await load();
    } catch (err) {
      setError(err.message || "Document upload failed.");
    } finally {
      setUploading(false);
    }
  };

  // Show document version history
  const showVersions = async (submissionId) => {
    try {
      setError("");

      const data = await api.getDocumentVersions(submissionId);

      setVersions((current) => ({
        ...current,
        [submissionId]: Array.isArray(data) ? data : [],
      }));
    } catch (err) {
      setError(err.message || "Failed to load version history.");
    }
  };

  // Upload a new version of an existing document
  const uploadVersion = async (submissionId) => {
    const selectedFile = versionFiles[submissionId];

    if (!selectedFile) {
      setError("Please select a file for the new version.");
      return;
    }

    const fd = new FormData();
    fd.append("file", selectedFile);

    try {
      setUploadingVersion(submissionId);
      setError("");

      await api.uploadDocumentVersion(submissionId, fd);

      setVersionFiles((current) => ({
        ...current,
        [submissionId]: null,
      }));

      await load();
      await showVersions(submissionId);
    } catch (err) {
      setError(err.message || "Failed to upload new version.");
    } finally {
      setUploadingVersion(null);
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="bg-black text-white border border-gray-700 p-8 rounded-xl text-center">
        Loading documents...
      </div>
    );
  }

  // No project
  if (!project) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Documents
          </h1>

          <p className="text-gray-300 mb-6">
            Submit proposals, reports, and project files
          </p>
        </div>

        {error && (
          <div className="bg-red-950 text-red-200 border border-red-700 p-4 rounded-lg">
            {error}
          </div>
        )}

        <div className="bg-black text-gray-300 border border-gray-700 p-8 rounded-xl shadow text-center">
          Create a project first to upload documents.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">
          Documents
        </h1>

        <p className="text-gray-300">
          Submit proposals, reports, and project files
        </p>
      </div>

      {/* ERROR MESSAGE */}
      {error && (
        <div className="bg-red-950 text-red-200 border border-red-700 p-4 rounded-lg">
          {error}
        </div>
      )}

      {/* DOCUMENT UPLOAD FORM */}
      <form
        onSubmit={handleSubmit}
        className="bg-black text-white border border-gray-700 p-6 rounded-xl shadow grid md:grid-cols-2 gap-4"
      >

        {/* DOCUMENT TYPE */}
        <label className="block">
          <span className="block text-gray-200 text-sm font-medium mb-2">
            Document Type
          </span>

          <select
            className="w-full bg-gray-900 text-white border border-gray-600 rounded-lg px-4 py-3 outline-none focus:border-indigo-400"
            value={form.type}
            onChange={(e) =>
              setForm({
                ...form,
                type: e.target.value,
              })
            }
          >
            <option value="proposal">Proposal</option>
            <option value="report">Report</option>
            <option value="document">Document</option>
            <option value="final">Final Submission</option>
          </select>
        </label>

        {/* DOCUMENT TITLE */}
        <label className="block">
          <span className="block text-gray-200 text-sm font-medium mb-2">
            Document Title
          </span>

          <input
            type="text"
            className="w-full bg-gray-900 text-white placeholder-gray-400 border border-gray-600 rounded-lg px-4 py-3 outline-none focus:border-indigo-400"
            placeholder="Enter document title"
            value={form.title}
            onChange={(e) =>
              setForm({
                ...form,
                title: e.target.value,
              })
            }
            required
          />
        </label>

        {/* FILE UPLOAD */}
        <label className="block md:col-span-2">
          <span className="block text-gray-200 text-sm font-medium mb-2">
            Select File
          </span>

          <input
            type="file"
            className="block w-full bg-gray-900 text-gray-200 border border-gray-600 rounded-lg p-3 file:mr-4 file:rounded-md file:border-0 file:bg-gray-700 file:px-4 file:py-2 file:text-white file:cursor-pointer"
            onChange={(e) =>
              setFile(e.target.files?.[0] || null)
            }
            required
          />
        </label>

        {/* NOTES */}
        <label className="block md:col-span-2">
          <span className="block text-gray-200 text-sm font-medium mb-2">
            Notes (Optional)
          </span>

          <textarea
            className="w-full bg-gray-900 text-white placeholder-gray-400 border border-gray-600 rounded-lg px-4 py-3 outline-none focus:border-indigo-400 resize-y"
            placeholder="Write any notes about this document..."
            value={form.notes}
            onChange={(e) =>
              setForm({
                ...form,
                notes: e.target.value,
              })
            }
            rows={4}
          />
        </label>

        {/* UPLOAD BUTTON */}
        <button
          type="submit"
          disabled={uploading}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-lg md:col-span-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {uploading ? "Uploading..." : "Upload Document"}
        </button>
      </form>

      {/* SUBMITTED DOCUMENTS */}
      <div className="space-y-4">

        <h2 className="text-xl font-bold text-white">
          Submitted Documents
        </h2>

        {submissions.length === 0 ? (
          <div className="bg-black text-gray-300 border border-gray-700 rounded-xl p-6 text-center">
            No documents submitted yet.
          </div>
        ) : (
          submissions.map((s) => (
            <div
              key={s.id}
              className="bg-black text-white border border-gray-700 p-5 rounded-xl shadow"
            >

              {/* DOCUMENT INFORMATION */}
              <div className="flex flex-wrap justify-between items-start gap-4">

                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {s.title}
                  </h3>

                  <p className="text-sm text-gray-300 capitalize mt-1">
                    {s.type}
                    {" • "}
                    {s.submitted_at
                      ? new Date(s.submitted_at).toLocaleDateString()
                      : "Date unavailable"}
                  </p>
                </div>

                {/* STATUS */}
                <span
                  className={`text-sm px-3 py-1 rounded-full capitalize ${statusColor(s.status)}`}
                >
                  {s.status || "pending"}
                </span>
              </div>

              {/* VERSION ACTIONS */}
              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-gray-700 pt-4">

                <button
                  type="button"
                  onClick={() => showVersions(s.id)}
                  className="text-indigo-300 hover:text-indigo-200 text-sm font-medium"
                >
                  {versions[s.id]
                    ? "Refresh History"
                    : "View Version History"}
                </button>

                <input
                  key={`${s.id}-${versionFiles[s.id] ? "selected" : "empty"}`}
                  type="file"
                  onChange={(e) =>
                    setVersionFiles((current) => ({
                      ...current,
                      [s.id]: e.target.files?.[0] || null,
                    }))
                  }
                  className="bg-gray-900 text-gray-200 border border-gray-600 rounded-lg p-2 text-xs max-w-full file:mr-2 file:rounded file:border-0 file:bg-gray-700 file:px-3 file:py-2 file:text-white"
                />

                <button
                  type="button"
                  onClick={() => uploadVersion(s.id)}
                  disabled={
                    !versionFiles[s.id] ||
                    uploadingVersion === s.id
                  }
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploadingVersion === s.id
                    ? "Uploading..."
                    : "Upload New Version"}
                </button>
              </div>

              {/* VERSION HISTORY */}
              {versions[s.id] && (
                <div className="mt-4 rounded-lg bg-gray-900 border border-gray-700 p-4">

                  <h4 className="font-semibold text-white mb-3">
                    Version History
                  </h4>

                  {versions[s.id].length === 0 ? (
                    <p className="text-gray-400 text-sm">
                      No version history available.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {versions[s.id].map((version) => (
                        <div
                          key={version.id}
                          className="flex flex-wrap justify-between gap-2 border-t border-gray-700 py-3 text-sm"
                        >
                          <span className="text-gray-100">
                            Version {version.version}
                            {" • "}
                            {version.uploaded_by_name || "Student"}
                          </span>

                          <span className="text-gray-300">
                            {version.uploaded_at
                              ? new Date(
                                  version.uploaded_at
                                ).toLocaleDateString()
                              : "Date unavailable"}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// DOCUMENT STATUS COLORS
function statusColor(status) {
  const map = {
    pending: "bg-yellow-900 text-yellow-200",
    approved: "bg-green-900 text-green-200",
    rejected: "bg-red-900 text-red-200",
    revision: "bg-orange-900 text-orange-200",
  };

  return map[status] || "bg-gray-800 text-gray-200";
}