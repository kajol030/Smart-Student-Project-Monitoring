
import { useEffect, useState } from "react";
import {
  Award,
  FileCheck2,
  Pencil,
  Plus,
  Save,
  Send,
  Trash2,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";

const emptyCriterion = () => ({
  criterion: "",
  max_marks: 10,
  weight: 0,
});

const GRADE_COLORS = {
  "A+": "#16a34a",
  A: "#16a34a",
  "A-": "#16a34a",
  "B+": "#2563eb",
  B: "#2563eb",
  "B-": "#2563eb",
  "C+": "#d97706",
  C: "#d97706",
  D: "#dc2626",
  F: "#dc2626",
};

export default function Evaluations() {
  const user = getStoredUser();
  const role = user?.role;

  const isAdmin = role === "admin";
  const isSupervisor = role === "supervisor";
  const canEvaluate = isSupervisor;

  /* State */
  const [rubrics, setRubrics] = useState([]);
  const [items, setItems] = useState([]);
  const [projects, setProjects] = useState([]);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  // Projects state is declared before using it.
  const canSelectProject =
    (isAdmin || isSupervisor) && projects.length > 1;

  /* Rubric form */
  const [rubricForm, setRubricForm] = useState({
    name: "",
    total_marks: 100,
    passing_marks: 50,
    stage: "final",
    criteria: [emptyCriterion()],
  });

  /* Evaluation form */
  const [evalForm, setEvalForm] = useState({
    project_id: "",
    rubric_id: "",
    supervisor_marks: "",
    panel_marks: "",
    comments: "",
  });

  const [showEvalForm, setShowEvalForm] = useState(false);
  const [evalMsg, setEvalMsg] = useState("");

  /* Load data */
  const load = async () => {
    setLoading(true);
    setError("");

    try {
      const [rubricData, projectData] = await Promise.all([
        api.getRubrics(),
        api.getProjects(),
      ]);

      const loadedRubrics = rubricData || [];
      const loadedProjects = projectData || [];

      setRubrics(loadedRubrics);
      setProjects(loadedProjects);

      if (loadedProjects.length > 0) {
        const firstProject = loadedProjects[0];

        const evals = await api
          .getEvaluations(firstProject.id)
          .catch(() => []);

        setItems(evals || []);

        setEvalForm((form) => ({
          ...form,
          project_id: String(firstProject.id),
        }));
      } else {
        setItems([]);
      }
    } catch (err) {
      setError(err.message || "Unable to load evaluations.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  /* Change selected project */
  const changeProject = async (pid) => {
    setEvalForm((form) => ({
      ...form,
      project_id: pid,
    }));

    if (!pid) {
      setItems([]);
      return;
    }

    try {
      const evals = await api.getEvaluations(pid);
      setItems(evals || []);
    } catch (err) {
      console.error("Evaluation loading error:", err);
      setItems([]);
      setError(err.message || "Unable to load project evaluations.");
    }
  };

  /* Rubric editing */
  const startEditRubric = async (rubric) => {
    setError("");

    try {
      const selected = await api.getRubric(rubric.id);

      setEditing(rubric.id);

      setRubricForm({
        name: selected.name,
        total_marks: selected.total_marks,
        passing_marks: selected.passing_marks || 50,
        stage: selected.stage || "final",
        criteria: selected.criteria || [emptyCriterion()],
      });
    } catch (err) {
      setError(err.message || "Unable to load rubric.");
    }
  };

  /* Save rubric */
  const saveRubric = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      if (editing) {
        await api.updateRubric(editing, rubricForm);
      } else {
        await api.createRubric(rubricForm);
      }

      setMessage(editing ? "Rubric updated." : "Rubric created.");

      setEditing(null);

      setRubricForm({
        name: "",
        total_marks: 100,
        passing_marks: 50,
        stage: "final",
        criteria: [emptyCriterion()],
      });

      await load();
    } catch (err) {
      setError(err.message || "Unable to save rubric.");
    }
  };

  /* Deactivate rubric */
  const deactivate = async (id) => {
    if (!window.confirm("Deactivate this rubric?")) return;

    setError("");

    try {
      await api.deactivateRubric(id);
      setMessage("Rubric deactivated.");
      await load();
    } catch (err) {
      setError(err.message || "Unable to deactivate rubric.");
    }
  };

  /* Update criterion */
  const updateCriterion = (idx, key, val) => {
    setRubricForm((form) => ({
      ...form,
      criteria: form.criteria.map((criterion, index) =>
        index === idx
          ? { ...criterion, [key]: val }
          : criterion
      ),
    }));
  };

  /* Submit evaluation */
  const submitEvaluation = async (e) => {
    e.preventDefault();

    setError("");
    setEvalMsg("");

    if (!evalForm.project_id) {
      setError("Select a project first.");
      return;
    }

    try {
      const payload = {
        project_id: Number(evalForm.project_id),
        rubric_id: evalForm.rubric_id
          ? Number(evalForm.rubric_id)
          : undefined,
        supervisor_marks:
          evalForm.supervisor_marks !== ""
            ? Number(evalForm.supervisor_marks)
            : undefined,
        panel_marks:
          evalForm.panel_marks !== ""
            ? Number(evalForm.panel_marks)
            : undefined,
        comments: evalForm.comments || undefined,
      };

      const res = await api.createEvaluation(payload);

      setEvalMsg(
        `Evaluation submitted. Grade: ${
          res.grade || "Pending"
        } · Total: ${res.total_marks ?? "—"}`
      );

      setEvalForm((form) => ({
        ...form,
        rubric_id: "",
        supervisor_marks: "",
        panel_marks: "",
        comments: "",
      }));

      await changeProject(evalForm.project_id);
    } catch (err) {
      setError(err.message || "Unable to submit evaluation.");
    }
  };

  /* Loading */
  if (loading) {
    return (
      <div className="loading-state">
        <div />
        <div />
        <div />
        <p>Loading evaluations…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* Header */}
      <div>
        <p className="eyebrow">Academic assessment</p>

        <h1 className="page-title">
          Evaluations &amp; Rubrics
        </h1>

        <p className="page-subtitle">
          {isAdmin
            ? "Configure assessment rubrics and review all evaluated results."
            : isSupervisor
            ? "Submit student evaluations and review grading rubrics."
            : "View your project evaluation results and rubrics."}
        </p>
      </div>

      {error && (
        <div className="form-alert error">
          {error}
        </div>
      )}

      {message && (
        <div
          className="form-alert"
          style={{
            color: "#16a34a",
            background: "#f0fdf4",
            border: "1px solid #bbf7d0",
          }}
        >
          {message}
        </div>
      )}

      {/* Admin: Create / Edit Rubric */}
      {isAdmin && (
        <form onSubmit={saveRubric} className="dashboard-card">

          <div className="card-heading">
            <h2>
              {editing ? (
                <>
                  <Pencil size={15} /> Edit Rubric
                </>
              ) : (
                <>
                  <Plus size={15} /> Create Rubric
                </>
              )}
            </h2>

            {editing && (
              <button
                type="button"
                className="text-button"
                onClick={() => {
                  setEditing(null);
                  setRubricForm({
                    name: "",
                    total_marks: 100,
                    passing_marks: 50,
                    stage: "final",
                    criteria: [emptyCriterion()],
                  });
                }}
              >
                Cancel edit
              </button>
            )}
          </div>

          <div className="grid gap-3 md:grid-cols-4">

            <label className="field">
              <span>Name</span>
              <input
                value={rubricForm.name}
                onChange={(e) =>
                  setRubricForm({
                    ...rubricForm,
                    name: e.target.value,
                  })
                }
                required
              />
            </label>

            <label className="field">
              <span>Total marks</span>
              <input
                type="number"
                min="1"
                value={rubricForm.total_marks}
                onChange={(e) =>
                  setRubricForm({
                    ...rubricForm,
                    total_marks: e.target.value,
                  })
                }
                required
              />
            </label>

            <label className="field">
              <span>Passing marks</span>
              <input
                type="number"
                min="0"
                value={rubricForm.passing_marks}
                onChange={(e) =>
                  setRubricForm({
                    ...rubricForm,
                    passing_marks: e.target.value,
                  })
                }
                required
              />
            </label>

            <label className="field">
              <span>Stage</span>
              <select
                value={rubricForm.stage}
                onChange={(e) =>
                  setRubricForm({
                    ...rubricForm,
                    stage: e.target.value,
                  })
                }
              >
                <option value="proposal">Proposal</option>
                <option value="midterm">Midterm</option>
                <option value="final">Final</option>
                <option value="viva">Viva</option>
              </select>
            </label>

          </div>

          <div style={{ marginTop: 18 }}>

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 10,
              }}
            >
              <span
                style={{
                  color: "#475569",
                  fontSize: 11,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: ".08em",
                }}
              >
                Criteria
              </span>

              <button
                type="button"
                className="text-button"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                }}
                onClick={() =>
                  setRubricForm({
                    ...rubricForm,
                    criteria: [
                      ...rubricForm.criteria,
                      emptyCriterion(),
                    ],
                  })
                }
              >
                <Plus size={13} /> Add criterion
              </button>
            </div>

            {rubricForm.criteria.map((c, idx) => (
              <div
                key={c.id || idx}
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 130px 130px 36px",
                  gap: 8,
                  marginBottom: 8,
                }}
              >

                <label className="field" style={{ margin: 0 }}>
                  <input
                    placeholder="Criterion name"
                    value={c.criterion}
                    onChange={(e) =>
                      updateCriterion(idx, "criterion", e.target.value)
                    }
                    required
                  />
                </label>

                <label className="field" style={{ margin: 0 }}>
                  <input
                    type="number"
                    min="1"
                    placeholder="Max marks"
                    value={c.max_marks}
                    onChange={(e) =>
                      updateCriterion(idx, "max_marks", e.target.value)
                    }
                    required
                  />
                </label>

                <label className="field" style={{ margin: 0 }}>
                  <input
                    type="number"
                    min="0"
                    placeholder="Weight %"
                    value={c.weight}
                    onChange={(e) =>
                      updateCriterion(idx, "weight", e.target.value)
                    }
                  />
                </label>

                <button
                  type="button"
                  className="icon-button"
                  title="Remove criterion"
                  style={{ color: "#dc2626" }}
                  onClick={() =>
                    setRubricForm({
                      ...rubricForm,
                      criteria: rubricForm.criteria.filter(
                        (_, i) => i !== idx
                      ),
                    })
                  }
                >
                  <Trash2 size={15} />
                </button>

              </div>
            ))}

          </div>

          <button
            className="auth-submit"
            style={{
              width: "auto",
              padding: "0 20px",
              marginTop: 12,
            }}
          >
            <Save size={15} />
            {editing ? "Update Rubric" : "Save Rubric"}
          </button>

        </form>
      )}

      {/* Supervisor: Submit Evaluation */}
      {canEvaluate && (
        <section className="dashboard-card">

          <div className="card-heading">
            <h2>
              <Send size={15} /> Submit Evaluation
            </h2>

            <button
              type="button"
              className="text-button"
              onClick={() => setShowEvalForm((value) => !value)}
            >
              {showEvalForm ? "Hide form" : "Open form"}
            </button>
          </div>

          {evalMsg && (
            <div
              className="form-alert"
              style={{
                color: "#16a34a",
                background: "#f0fdf4",
                border: "1px solid #bbf7d0",
                marginBottom: 12,
              }}
            >
              {evalMsg}
            </div>
          )}

          {showEvalForm && (
            <form onSubmit={submitEvaluation} className="grid gap-4">

              <label className="field">
                <span>
                  Project <span style={{ color: "#de687b" }}>*</span>
                </span>

                <select
                  value={evalForm.project_id}
                  onChange={(e) => changeProject(e.target.value)}
                  required
                >
                  <option value="">— Select Project —</option>

                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title}
                      {p.student_name ? ` — ${p.student_name}` : ""}
                    </option>
                  ))}
                </select>
              </label>

              <div className="form-grid">

                <label className="field">
                  <span>
                    Rubric <span style={{ color: "var(--muted)" }}>(optional)</span>
                  </span>

                  <select
                    value={evalForm.rubric_id}
                    onChange={(e) =>
                      setEvalForm({
                        ...evalForm,
                        rubric_id: e.target.value,
                      })
                    }
                  >
                    <option value="">— No rubric —</option>

                    {rubrics.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name} ({r.stage})
                      </option>
                    ))}
                  </select>
                </label>

                <label className="field">
                  <span>Supervisor Marks</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.5"
                    placeholder="0 – 100"
                    value={evalForm.supervisor_marks}
                    onChange={(e) =>
                      setEvalForm({
                        ...evalForm,
                        supervisor_marks: e.target.value,
                      })
                    }
                  />
                </label>

                <label className="field">
                  <span>
                    Panel Marks <span style={{ color: "var(--muted)" }}>(optional)</span>
                  </span>

                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.5"
                    placeholder="0 – 100"
                    value={evalForm.panel_marks}
                    onChange={(e) =>
                      setEvalForm({
                        ...evalForm,
                        panel_marks: e.target.value,
                      })
                    }
                  />
                </label>

              </div>

              <label className="field">
                <span>Comments</span>

                <textarea
                  placeholder="Evaluation remarks, feedback, observations…"
                  value={evalForm.comments}
                  onChange={(e) =>
                    setEvalForm({
                      ...evalForm,
                      comments: e.target.value,
                    })
                  }
                  style={{
                    height: 90,
                    resize: "vertical",
                  }}
                />
              </label>

              {evalForm.supervisor_marks !== "" && (
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                  }}
                >
                  <span className="muted-copy" style={{ fontSize: 12 }}>
                    Estimated grade:
                  </span>

                  <strong
                    style={{
                      color:
                        GRADE_COLORS[
                          calcGrade(
                            Number(evalForm.supervisor_marks),
                            evalForm.panel_marks !== ""
                              ? Number(evalForm.panel_marks)
                              : null
                          )
                        ] || "#475569",
                    }}
                  >
                    {calcGrade(
                      Number(evalForm.supervisor_marks),
                      evalForm.panel_marks !== ""
                        ? Number(evalForm.panel_marks)
                        : null
                    )}
                  </strong>
                </div>
              )}

              <div>
                <button
                  className="auth-submit"
                  style={{
                    width: "auto",
                    padding: "0 24px",
                  }}
                >
                  <Send size={14} /> Submit Evaluation
                </button>
              </div>

            </form>
          )}

        </section>
      )}

      {/* Active Rubrics */}
      <section className="dashboard-card">

        <div className="card-heading">
          <h2>Active Rubrics</h2>
          <span className="muted-copy">
            {rubrics.length} configured
          </span>
        </div>

        {rubrics.length ? (
          rubrics.map((r) => (
            <div className="list-row" key={r.id}>

              <div className="list-icon violet">
                <FileCheck2 size={16} />
              </div>

              <div className="list-main">
                <strong>{r.name}</strong>
                <span>
                  {r.stage || "final"} · {r.criteria_count || 0} criteria ·
                  pass {r.passing_marks || 50}/{r.total_marks}
                </span>
              </div>

              {isAdmin && (
                <>
                  <button
                    className="icon-button"
                    title="Edit rubric"
                    onClick={() => startEditRubric(r)}
                  >
                    <Pencil size={15} />
                  </button>

                  <button
                    className="icon-button"
                    title="Deactivate rubric"
                    style={{ color: "#dc2626" }}
                    onClick={() => deactivate(r.id)}
                  >
                    <Trash2 size={15} />
                  </button>
                </>
              )}

            </div>
          ))
        ) : (
          <p className="muted-copy">
            No active rubrics configured.
          </p>
        )}

      </section>

      {/* Evaluation History */}
      <section className="dashboard-card">

        <div className="card-heading">
          <h2>Evaluation History</h2>

          {canSelectProject && (
            <label
              className="field"
              style={{
                margin: 0,
                minWidth: 220,
              }}
            >
              <select
                value={evalForm.project_id}
                onChange={(e) => changeProject(e.target.value)}
              >
                <option value="">All projects</option>

                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title}
                  </option>
                ))}
              </select>
            </label>
          )}

        </div>

        {items.length ? (
          items.map((item) => (
            <div className="list-row" key={item.id}>

              <div className="list-icon teal">
                <Award size={16} />
              </div>

              <div className="list-main">
                <strong>
                  {item.rubric_name || "Project evaluation"}
                </strong>

                <span>
                  {item.evaluator_name} · {item.comments || "No comments"}
                </span>
              </div>

              <div
                style={{
                  textAlign: "right",
                  flex: "none",
                }}
              >
                <strong
                  style={{
                    display: "block",
                    color:
                      GRADE_COLORS[item.grade] ||
                      "var(--student-text)",
                  }}
                >
                  {item.grade || "—"}
                </strong>

                <span
                  style={{
                    fontSize: 11,
                    color: "var(--muted)",
                  }}
                >
                  {item.total_marks ?? "—"} marks
                </span>
              </div>

            </div>
          ))
        ) : (
          <p className="muted-copy">
            No evaluations recorded yet.
          </p>
        )}

      </section>

    </div>
  );
}

/* Grade helper */
function calcGrade(sm, pm) {
  const total =
    pm != null
      ? Math.round(((sm + pm) / 2) * 100) / 100
      : sm;

  if (total >= 90) return "A+";
  if (total >= 85) return "A";
  if (total >= 80) return "A-";
  if (total >= 75) return "B+";
  if (total >= 70) return "B";
  if (total >= 65) return "B-";
  if (total >= 60) return "C+";
  if (total >= 55) return "C";
  if (total >= 50) return "D";

  return "F";
}
