import { useEffect, useState } from "react";
import {
  Check,
  Pencil,
  Plus,
  Trash2,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";

const EMPTY_FORM = {
  name: "",
  project_title: "",
  supervisor_id: "",
  leader_id: "",
  members: [""],
};
const MAX_GROUP_STUDENTS = 3;

export default function Groups() {
  const currentUser = getStoredUser();
  const role = currentUser?.role;
  const userId = String(currentUser?.id ?? "");

  const isAdmin = role === "admin";
  const isStudent = role === "student";

  const [groups, setGroups] = useState([]);
  const [students, setStudents] = useState([]);
  const [supervisors, setSupervisors] = useState([]);
  const [invites, setInvites] = useState([]);

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState(null);

  const [openCreate, setOpenCreate] = useState(false);
  const [createName, setCreateName] = useState("");

  // Multiple invitation state
  const [invite, setInvite] = useState({
    groupId: "",
    userIds: [],
  });

  // Members of the currently selected group (for filtering)
  const [selectedGroupMembers, setSelectedGroupMembers] = useState([]);
  const [loadingGroupMembers, setLoadingGroupMembers] = useState(false);

  const [sendingInvites, setSendingInvites] = useState(false);
  const [respondingId, setRespondingId] = useState(null);

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const [groupData, studentData, supervisorData, inviteData] =
        await Promise.all([
          api.getGroups(),

          isAdmin || isStudent || role === "supervisor"
            ? api.getStudents().catch(() => [])
            : Promise.resolve([]),

          isAdmin || role === "supervisor"
            ? api.getSupervisors().catch(() => [])
            : Promise.resolve([]),

          isStudent
            ? api.getGroupInvitations().catch(() => [])
            : Promise.resolve([]),
        ]);

      setGroups(Array.isArray(groupData) ? groupData : []);
      setStudents(Array.isArray(studentData) ? studentData : []);
      setSupervisors(Array.isArray(supervisorData) ? supervisorData : []);
      setInvites(Array.isArray(inviteData) ? inviteData : []);
    } catch (e) {
      setError(e.message || "Failed to load groups.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [role]);

  const flash = (msg) => {
    setMessage(msg);
    setTimeout(() => setMessage(""), 4000);
  };

  const err = (msg) => {
    setError(msg);
    setTimeout(() => setError(""), 6000);
  };

  // Groups where current student is the leader
  const leaderGroups = groups.filter((g) => String(g.leader_id) === userId);

  const selectedGroup = leaderGroups.find(
    (g) => String(g.id) === String(invite.groupId)
  );

  const validateForm = () => {
    if (!form.name.trim()) {
      return "Group name is required.";
    }

    if (!form.leader_id) {
      return "Group leader is required.";
    }

    const filledMembers = form.members.filter(Boolean);

    if (filledMembers.includes(form.leader_id)) {
      return "Leader cannot also be a member.";
    }

    if (new Set(filledMembers).size !== filledMembers.length) {
      return "Duplicate members are not allowed.";
    }

    return null;
  };

  // Admin: create or update group
  const submitAdminForm = async (e) => {
    e.preventDefault();

    const validationError = validateForm();

    if (validationError) {
      return err(validationError);
    }

    try {
      setError("");

      const payload = {
        name: form.name.trim(),
        project_title: form.project_title.trim() || undefined,
        supervisor_id: form.supervisor_id || undefined,
        leader_id: form.leader_id || undefined,
        members: form.members.filter(Boolean).map(Number),
      };

      if (editId) {
        await api.updateGroup(editId, payload);
        flash("Group updated successfully.");
      } else {
        await api.createGroup(payload);
        flash("FYP group created successfully.");
      }

      setForm(EMPTY_FORM);
      setEditId(null);
      setShowForm(false);

      await load();
    } catch (e2) {
      err(e2.message || "Failed to save group.");
    }
  };

  // Admin: edit group
  const startEdit = async (g) => {
    try {
      const detail = await api.getGroup(g.id);

      const activeMembers = (detail.members || [])
        .filter((m) => m.status === "active" && m.role === "member")
        .map((m) => String(m.user_id));

      setForm({
        name: g.name || "",
        project_title: g.project_title || "",
        supervisor_id: g.supervisor_id ? String(g.supervisor_id) : "",
        leader_id: g.leader_id ? String(g.leader_id) : "",
        members: activeMembers.length > 0 ? activeMembers : [""],
      });

      setEditId(g.id);
      setShowForm(true);

      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (e2) {
      err(e2.message || "Failed to load group.");
    }
  };

  const addMemberSlot = () => {
    setForm((current) => ({
      ...current,
      members: [...current.members, ""],
    }));
  };

  const removeMemberSlot = (index) => {
    setForm((current) => ({
      ...current,
      members: current.members.filter((_, i) => i !== index),
    }));
  };

  const setMember = (index, value) => {
    setForm((current) => ({
      ...current,
      members: current.members.map((member, i) =>
        i === index ? value : member
      ),
    }));
  };

  // Student: create group
  const createStudentGroup = async (e) => {
    e.preventDefault();

    if (!createName.trim()) {
      return err("Please enter a group name.");
    }

    try {
      setError("");

      await api.createGroup({ name: createName.trim() });

      flash("Project group created successfully.");

      setCreateName("");
      setOpenCreate(false);

      await load();
    } catch (e2) {
      err(e2.message || "Failed to create group.");
    }
  };

  // Students available to invite: exclude self and existing members of selected group
  const remainingInviteSlots = Math.max(
    0,
    MAX_GROUP_STUDENTS - selectedGroupMembers.length
  );
  const availableStudents = students.filter(
    (student) =>
      String(student.id) !== userId &&
      !selectedGroupMembers.includes(String(student.id))
  );

  // Multiple student selection
  const toggleStudent = (studentId) => {
    const id = String(studentId);

    setInvite((current) => {
      const alreadySelected = current.userIds.includes(id);
      if (!alreadySelected && current.userIds.length >= remainingInviteSlots) {
        return current;
      }

      return {
        ...current,
        userIds: alreadySelected
          ? current.userIds.filter((selectedId) => selectedId !== id)
          : [...current.userIds, id],
      };
    });
  };

  const selectAllStudents = () => {
    const availableIds = availableStudents
      .map((student) => String(student.id))
      .slice(0, remainingInviteSlots);

    setInvite((current) => ({
      ...current,
      userIds: availableIds,
    }));
  };

  const clearSelection = () => {
    setInvite((current) => ({
      ...current,
      userIds: [],
    }));
  };

  // Load members of selected group to filter them out from invite list
  const loadGroupMembers = async (groupId) => {
    if (!groupId) {
      setSelectedGroupMembers([]);
      return;
    }
    setLoadingGroupMembers(true);
    try {
      const detail = await api.getGroup(groupId);
      const activeOrInvited = (detail.members || [])
        .filter((m) => m.status === "active" || m.status === "invited")
        .map((m) => String(m.user_id));
      setSelectedGroupMembers(activeOrInvited);
    } catch {
      setSelectedGroupMembers([]);
    } finally {
      setLoadingGroupMembers(false);
    }
  };

  // Student: send multiple invitations
  const sendInvite = async (e) => {
    e.preventDefault();

    if (!invite.groupId) {
      return err("Please select your group.");
    }

    if (!selectedGroup) {
      return err("Only the group leader can send invitations.");
    }

    if (invite.userIds.length === 0) {
      return err("Please select at least one student.");
    }

    if (sendingInvites) return;

    setSendingInvites(true);
    setError("");
    setMessage("");

    try {
      const selectedIds = [...invite.userIds];

      const results = [];
      for (const studentId of selectedIds) {
        try {
          await api.inviteGroupMember(invite.groupId, Number(studentId));
          results.push({ status: "fulfilled" });
        } catch (reason) {
          results.push({ status: "rejected", reason });
        }
      }

      const successful = results.filter((r) => r.status === "fulfilled").length;

      const failedResults = results
        .map((r, i) => ({ result: r, id: selectedIds[i] }))
        .filter((x) => x.result.status === "rejected");

      if (successful > 0) {
        flash(`${successful} invitation(s) sent successfully.`);
      }

      if (failedResults.length > 0) {
        const messages = [
          ...new Set(
            failedResults.map((x) => x.result.reason?.message || "Failed")
          ),
        ];
        // Show error persistently (no auto-clear) so user sees it
        setError(
          `${failedResults.length} invitation(s) failed: ${messages.join(" | ")}`
        );
      }

      // Keep only failed students selected for retry
      const failedIds = failedResults.map((x) => x.id);
      setInvite((current) => ({
        ...current,
        userIds: failedIds,
      }));

      // Reload group members to refresh filter
      await loadGroupMembers(invite.groupId);
      await load();
    } catch (e2) {
      setError(e2.message || "Failed to send invitations.");
    } finally {
      setSendingInvites(false);
    }
  };

  // Student: accept or reject invitation
  const respond = async (item, status) => {
    if (respondingId !== null) return;

    try {
      setRespondingId(item.id);
      setError("");

      await api.respondGroupInvitation(item.id, status);

      setInvites((current) => current.filter((i) => i.id !== item.id));

      await load();

      flash(
        status === "active"
          ? "Invitation accepted. You are now a group member."
          : "Invitation rejected."
      );
    } catch (e2) {
      err(e2.message || "Failed to respond to invitation.");
    } finally {
      setRespondingId(null);
    }
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div />
        <div />
        <div />
        <p>Loading groups...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="eyebrow">Collaboration</p>

          <h1 className="page-title">Project Groups</h1>

          <p className="page-subtitle">
            {isAdmin
              ? "Create and manage FYP groups with leader, members and supervisor."
              : "Build your FYP team and manage group invitations."}
          </p>
        </div>

        {isAdmin && (
          <button
            type="button"
            className="auth-submit"
            style={{ width: "auto", padding: "0 18px" }}
            onClick={() => {
              setShowForm((current) => !current);
              setEditId(null);
              setForm(EMPTY_FORM);
            }}
          >
            {showForm ? (
              <>
                <X size={15} />
                Cancel
              </>
            ) : (
              <>
                <Plus size={15} />
                New FYP Group
              </>
            )}
          </button>
        )}

        {isStudent && (
          <button
            type="button"
            className="auth-submit"
            style={{ width: "auto", padding: "0 16px" }}
            onClick={() => setOpenCreate((current) => !current)}
          >
            <Plus size={16} />
            Create Group
          </button>
        )}
      </div>

      {/* ALERTS */}
      {error && <div className="form-alert error">{error}</div>}

      {message && (
        <div
          className="form-alert"
          style={{
            color: "#16a34a",
            background: "#f0fdf4",
            border: "1px solid #bbf7d0",
          }}
        >
          {message}
        </div>
      )}

      {/* ADMIN GROUP FORM */}
      {isAdmin && showForm && (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2>
              {editId ? (
                <>
                  <Pencil size={15} />
                  Edit FYP Group
                </>
              ) : (
                <>
                  <Plus size={15} />
                  Create FYP Group
                </>
              )}
            </h2>
          </div>

          <form onSubmit={submitAdminForm} className="grid gap-5">
            {/* GROUP NAME AND TITLE */}
            <div className="form-grid">
              <label className="field" htmlFor="groupName">
                <span>Group Name *</span>

                <input
                  id="groupName"
                  name="groupName"
                  placeholder="e.g. Team Alpha"
                  value={form.name}
                  onChange={(e) =>
                    setForm((current) => ({
                      ...current,
                      name: e.target.value,
                    }))
                  }
                  required
                />
              </label>

              <label className="field" htmlFor="projectTitle">
                <span>Project Title</span>

                <input
                  id="projectTitle"
                  name="projectTitle"
                  placeholder="e.g. FYP Management System"
                  value={form.project_title}
                  onChange={(e) =>
                    setForm((current) => ({
                      ...current,
                      project_title: e.target.value,
                    }))
                  }
                />
              </label>
            </div>

            {/* SUPERVISOR AND LEADER */}
            <div className="form-grid">
              <label className="field" htmlFor="adminSupervisor">
                <span>Supervisor</span>

                <select
                  id="adminSupervisor"
                  name="supervisor_id"
                  value={form.supervisor_id}
                  onChange={(e) =>
                    setForm((current) => ({
                      ...current,
                      supervisor_id: e.target.value,
                    }))
                  }
                >
                  <option value="">— Select Supervisor —</option>

                  {supervisors.map((supervisor) => (
                    <option key={supervisor.id} value={supervisor.id}>
                      {supervisor.name}
                      {supervisor.specialization
                        ? ` (${supervisor.specialization})`
                        : ""}
                    </option>
                  ))}
                </select>
              </label>

              <label className="field" htmlFor="adminLeader">
                <span>Group Leader *</span>

                <select
                  id="adminLeader"
                  name="leader_id"
                  value={form.leader_id}
                  onChange={(e) =>
                    setForm((current) => ({
                      ...current,
                      leader_id: e.target.value,
                    }))
                  }
                  required
                >
                  <option value="">— Select Leader —</option>

                  {students.map((student) => (
                    <option
                      key={student.id}
                      value={student.id}
                      disabled={form.members
                        .filter(Boolean)
                        .includes(String(student.id))}
                    >
                      {student.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {/* ADMIN MEMBERS */}
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: 10,
                }}
              >
                <span
                  style={{
                    color: "#475569",
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: ".08em",
                  }}
                >
                  Group Members
                </span>

                <button
                  type="button"
                  className="text-button"
                  style={{ display: "flex", alignItems: "center", gap: 5 }}
                  onClick={addMemberSlot}
                >
                  <Plus size={13} />
                  Add Member
                </button>
              </div>

              {form.members.length === 0 && (
                <p className="muted-copy">No members added yet.</p>
              )}

              <div className="grid gap-3">
                {form.members.map((memberId, index) => (
                  <div
                    key={index}
                    style={{ display: "flex", gap: 10, alignItems: "center" }}
                  >
                    <label
                      className="field"
                      htmlFor={`adminMember-${index}`}
                      style={{ flex: 1, margin: 0 }}
                    >
                      <select
                        id={`adminMember-${index}`}
                        name={`members_${index}`}
                        value={memberId}
                        onChange={(e) => setMember(index, e.target.value)}
                      >
                        <option value="">— Select Student —</option>

                        {students.map((student) => {
                          const sid = String(student.id);

                          const used =
                            sid === form.leader_id ||
                            form.members.some(
                              (m, i) => i !== index && m === sid
                            );

                          return (
                            <option key={student.id} value={sid} disabled={used}>
                              {student.name}
                            </option>
                          );
                        })}
                      </select>
                    </label>

                    <button
                      type="button"
                      className="icon-button"
                      title="Remove member slot"
                      style={{ color: "#dc2626" }}
                      onClick={() => removeMemberSlot(index)}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                ))}
              </div>

              {/* SELECTED MEMBERS PREVIEW */}
              {form.members.filter(Boolean).length > 0 && (
                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 6,
                    marginTop: 12,
                  }}
                >
                  {form.members.filter(Boolean).map((sid) => {
                    const student = students.find((s) => String(s.id) === sid);

                    return student ? (
                      <span key={sid} className="status-badge completed">
                        {student.name}
                      </span>
                    ) : null;
                  })}
                </div>
              )}
            </div>

            {/* GROUP PREVIEW */}
            {(form.leader_id || form.supervisor_id) && (
              <div
                className="dashboard-card"
                style={{
                  background: "#ffffff",
                  borderColor: "#e2e8f0",
                  padding: "14px 18px",
                }}
              >
                <p className="eyebrow">Preview</p>

                <p style={{ color: "var(--student-text)", fontSize: 13 }}>
                  <strong>{form.name || "Group Name"}</strong>

                  {form.project_title && ` — ${form.project_title}`}
                </p>

                {form.supervisor_id && (
                  <p className="muted-copy">
                    Supervisor:{" "}
                    {supervisors.find(
                      (s) => String(s.id) === form.supervisor_id
                    )?.name || "—"}
                  </p>
                )}

                {form.leader_id && (
                  <p className="muted-copy">
                    Leader:{" "}
                    {students.find((s) => String(s.id) === form.leader_id)
                      ?.name || "—"}
                  </p>
                )}

                {form.members.filter(Boolean).length > 0 && (
                  <p className="muted-copy">
                    Members:{" "}
                    {form.members
                      .filter(Boolean)
                      .map(
                        (sid) =>
                          students.find((s) => String(s.id) === sid)?.name
                      )
                      .filter(Boolean)
                      .join(", ")}
                  </p>
                )}
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button
                type="submit"
                className="auth-submit"
                style={{ width: "auto", padding: "0 28px" }}
              >
                {editId ? "Update Group" : "Create FYP Group"}
              </button>

              {editId && (
                <button
                  type="button"
                  className="icon-button"
                  onClick={() => {
                    setEditId(null);
                    setForm(EMPTY_FORM);
                    setShowForm(false);
                  }}
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </section>
      )}

      {/* STUDENT CREATE GROUP */}
      {isStudent && openCreate && (
        <form
          onSubmit={createStudentGroup}
          className="dashboard-card"
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 12,
            alignItems: "flex-end",
          }}
        >
          <label
            className="field"
            htmlFor="createGroupName"
            style={{ flex: 1, minWidth: 180 }}
          >
            <span>Group Name</span>

            <input
              id="createGroupName"
              name="createGroupName"
              value={createName}
              onChange={(e) => setCreateName(e.target.value)}
              placeholder="e.g. Neural North"
              required
            />
          </label>

          <button
            type="submit"
            className="auth-submit"
            style={{ width: "auto", padding: "0 18px" }}
          >
            Create
          </button>
        </form>
      )}

      {/* MULTIPLE INVITATIONS */}
      {isStudent && leaderGroups.length > 0 && (
        <form onSubmit={sendInvite} className="dashboard-card">
          <div className="card-heading">
            <h2>
              <UserPlus size={17} />
              Invite Group Members
            </h2>
          </div>

          <p className="muted-copy" style={{ marginBottom: 18 }}>
            Select multiple students and send invitations together.
            {invite.groupId && selectedGroupMembers.length > 0 && (
              <span className="group-invite-capacity">
                ({selectedGroupMembers.length}/{MAX_GROUP_STUDENTS} group places
                used, including pending invitations)
              </span>
            )}
          </p>

          <div className="grid gap-5">
            {/* GROUP SELECTION */}
            <label className="field" htmlFor="inviteGroup">
              <span>Your Group</span>

              <select
                id="inviteGroup"
                name="group_id"
                value={invite.groupId}
                onChange={(e) => {
                  const gId = e.target.value;
                  setInvite({ groupId: gId, userIds: [] });
                  loadGroupMembers(gId);
                }}
                required
              >
                <option value="">Select your group</option>

                {leaderGroups.map((group) => (
                  <option key={group.id} value={group.id}>
                    {group.name}
                  </option>
                ))}
              </select>
            </label>

            {/* STUDENT SELECTION */}
            <div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: 10,
                  marginBottom: 12,
                }}
              >
                <span className="group-student-selection-label">
                  Select Students
                </span>

                <div style={{ display: "flex", gap: 12 }}>
                  <button
                    type="button"
                    className="text-button"
                    onClick={selectAllStudents}
                  >
                    Select All
                  </button>

                  <button
                    type="button"
                    className="text-button"
                    onClick={clearSelection}
                  >
                    Clear
                  </button>
                </div>
              </div>

              <div
                style={{
                  display: "grid",
                  gap: 10,
                  maxHeight: 280,
                  overflowY: "auto",
                }}
              >
                {loadingGroupMembers ? (
                  <p className="muted-copy" style={{ padding: "12px 0" }}>
                    Loading group members...
                  </p>
                ) : availableStudents.length === 0 ||
                  remainingInviteSlots === 0 ? (
                  <p className="muted-copy" style={{ padding: "12px 0" }}>
                    {invite.groupId && remainingInviteSlots === 0
                      ? `This group has reached its maximum size of ${MAX_GROUP_STUDENTS} students.`
                      : invite.groupId
                      ? "All students are already members or have pending invitations."
                      : "Select a group above to see available students."}
                  </p>
                ) : (
                  availableStudents.map((student) => {
                    const sid = String(student.id);
                    const selected = invite.userIds.includes(sid);

                    return (
                      <label
                        key={student.id}
                        htmlFor={`inviteStudent-${student.id}`}
                        className={`group-student-option${
                          selected ? " selected" : ""
                        }`}
                      >
                        <input
                          id={`inviteStudent-${student.id}`}
                          name="student_ids"
                          type="checkbox"
                          checked={selected}
                          disabled={
                            !selected &&
                            invite.userIds.length >= remainingInviteSlots
                          }
                          onChange={() => toggleStudent(sid)}
                        />

                        <div
                          className="avatar"
                          style={{ width: 32, height: 32, flex: "none" }}
                        >
                          {(student.name || "?").charAt(0).toUpperCase()}
                        </div>

                        <div className="group-student-option-copy">
                          <p>{student.name}</p>

                          {student.email && (
                            <p className="group-student-option-email">
                              {student.email}
                            </p>
                          )}
                        </div>

                        {selected && (
                          <Check
                            size={17}
                            className="group-student-option-check"
                          />
                        )}
                      </label>
                    );
                  })
                )}
              </div>
            </div>

            {/* SELECTED STUDENTS */}
            <div className="group-student-selection-summary">
              <p className="group-student-selection-count">
                {invite.userIds.length} Student(s) Selected
              </p>

              {invite.userIds.length === 0 ? (
                <p className="muted-copy">No students selected yet.</p>
              ) : (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {invite.userIds.map((sid) => {
                    const student = students.find((s) => String(s.id) === sid);

                    return (
                      <span
                        key={sid}
                        className="status-badge completed"
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 6,
                        }}
                      >
                        {student?.name || sid}

                        <button
                          type="button"
                          onClick={() => toggleStudent(sid)}
                          title="Remove selection"
                          style={{ display: "inline-flex", color: "inherit" }}
                        >
                          <X size={12} />
                        </button>
                      </span>
                    );
                  })}
                </div>
              )}
            </div>

            {/* SEND INVITATIONS */}
            <button
              type="submit"
              className="auth-submit"
              disabled={
                sendingInvites ||
                !invite.groupId ||
                invite.userIds.length === 0
              }
              style={{
                width: "auto",
                padding: "0 20px",
                justifySelf: "start",
                opacity: sendingInvites ? 0.6 : 1,
              }}
            >
              <UserPlus size={16} />

              {sendingInvites
                ? "Sending Invitations..."
                : `Send ${invite.userIds.length} Invitation(s)`}
            </button>
          </div>
        </form>
      )}

      {/* PENDING INVITATIONS */}
      {isStudent && invites.length > 0 && (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2>Pending Invitations</h2>

            <span className="muted-copy">{invites.length} pending</span>
          </div>

          {invites.map((item) => (
            <div className="list-row" key={item.id}>
              <div className="list-icon violet">
                <UserPlus size={16} />
              </div>

              <div className="list-main">
                <strong>{item.group_name}</strong>

                <span>Invited by {item.invited_by_name || "Group Leader"}</span>
              </div>

              <button
                type="button"
                className="icon-button"
                title="Accept"
                disabled={respondingId !== null}
                onClick={() => respond(item, "active")}
                style={{ color: "#16a34a" }}
              >
                <Check size={17} />
              </button>

              <button
                type="button"
                className="icon-button"
                title="Reject"
                disabled={respondingId !== null}
                onClick={() => respond(item, "rejected")}
                style={{ color: "#dc2626" }}
              >
                <X size={17} />
              </button>
            </div>
          ))}
        </section>
      )}

      {/* GROUP LIST */}
      <section className="dashboard-card">
        <div className="card-heading">
          <h2>
            {isAdmin
              ? "All FYP Groups"
              : role === "supervisor"
              ? "My Assigned Groups"
              : "My Groups"}
          </h2>

          <span className="muted-copy">{groups.length} total</span>
        </div>

        {groups.length === 0 ? (
          <div className="empty-state" style={{ padding: "40px 20px" }}>
            <div className="metric-icon violet">
              <Users size={20} />
            </div>

            <h2>No groups yet</h2>

            <p className="muted-copy">
              {isAdmin
                ? "Use the form above to create a FYP group."
                : "Create a group or wait for an invitation."}
            </p>
          </div>
        ) : (
          groups.map((group) => (
            <GroupRow
              key={group.id}
              group={group}
              isAdmin={isAdmin}
              onEdit={() => startEdit(group)}
            />
          ))
        )}
      </section>
    </div>
  );
}

// GROUP DETAILS ROW
function GroupRow({ group: g, isAdmin, onEdit }) {
  const [expanded, setExpanded] = useState(false);
  const [members, setMembers] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Are you sure you want to delete "${g.name}"? This action cannot be undone.`
    );

    if (!confirmed) {
      return;
    }

    try {
      await api.deleteGroup(g.id);

      window.location.reload();
    } catch (e) {
      alert(e.message || "Failed to delete group.");
    }
  };

  const toggle = async () => {
    if (!expanded && members === null) {
      setLoading(true);

      try {
        const detail = await api.getGroup(g.id);

        setMembers(detail.members || []);
      } catch (e) {
        alert(e.message || "Failed to load members.");

        return;
      } finally {
        setLoading(false);
      }
    }

    setExpanded((current) => !current);
  };

  return (
    <div
      style={{
        borderTop: "1px solid var(--student-line)",
        paddingTop: 12,
        marginTop: 12,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          flexWrap: "wrap",
        }}
      >
        <div className="list-icon teal">
          <Users size={16} />
        </div>

        <div className="list-main" style={{ flex: 1, minWidth: 180 }}>
          <strong>{g.name}</strong>

          <span>
            Leader: {g.leader_name || "—"}
            {g.supervisor_name ? ` · Supervisor: ${g.supervisor_name}` : ""}
            {g.project_title ? ` · ${g.project_title}` : ""}
            {" · "}
            {g.member_count ?? 0} member(s)
          </span>
        </div>

        <span className="status-badge completed">{g.status || "active"}</span>

        {isAdmin && (
          <>
            <button
              type="button"
              className="icon-button"
              title="Edit group"
              onClick={onEdit}
              style={{ color: "#2563eb" }}
            >
              <Pencil size={14} />
            </button>

            <button
              type="button"
              className="icon-button"
              title="Delete group"
              onClick={handleDelete}
              style={{ color: "#dc2626" }}
            >
              <Trash2 size={14} />
            </button>
          </>
        )}

        <button
          type="button"
          className="icon-button"
          title={expanded ? "Collapse" : "View members"}
          onClick={toggle}
          style={{
            fontSize: 11,
            width: "auto",
            padding: "4px 10px",
            color: "var(--student-muted)",
          }}
        >
          {expanded ? "Hide" : "Details"}
        </button>
      </div>

      {/* EXPANDED MEMBERS */}
      {expanded && (
        <div
          style={{
            marginLeft: 40,
            marginTop: 10,
            padding: "12px 14px",
            background:  "var(--student-card, #ffffff)",
            borderRadius: 10,
             border: "1px solid var(--student-line, #e2e8f0)",
            boxShadow: "0 2px 8px rgba(15, 23, 42, 0.04)",
          }}
        >
          {loading ? (
            <p className="muted-copy">Loading members...</p>
          ) : members && members.length > 0 ? (
            <>
              <p className="eyebrow" style={{ marginBottom: 8 }}>
                Members
              </p>

              {members
                .filter((member) => member.status === "active")
                .map((member) => (
                  <div
                    key={member.user_id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      padding: "5px 0",
                      borderBottom: "1px solid #e2e8f0",
                    }}
                  >
                    <div
                      className="avatar"
                      style={{
                        width: 26,
                        height: 26,
                        fontSize: 11,
                        flex: "none",
                      }}
                    >
                      {(member.name || "?").charAt(0).toUpperCase()}
                    </div>

                    <span
                      style={{
                        flex: 1,
                        fontSize: 13,
                        color: "var(--student-text)",
                      }}
                    >
                      {member.name}
                    </span>

                    <span
                      className={`status-badge ${
                        member.role === "leader" ? "review" : "completed"
                      }`}
                      style={{ fontSize: 10 }}
                    >
                      {member.role}
                    </span>
                  </div>
                ))}
            </>
          ) : (
            <p className="muted-copy">No active members.</p>
          )}
        </div>
      )}
    </div>
  );
}
