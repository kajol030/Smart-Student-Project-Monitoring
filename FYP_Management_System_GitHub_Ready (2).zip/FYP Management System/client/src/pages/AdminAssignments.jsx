
import { useEffect, useState } from "react";
import { api } from "../api/api";

export default function AdminAssignments() {
  const [projects, setProjects] = useState([]);
  const [supervisors, setSupervisors] = useState([]);
  const [assignments, setAssignments] = useState({});
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const [p, s] = await Promise.all([
          api.getProjects(),
          api.getSupervisors(),
        ]);

        setProjects(Array.isArray(p) ? p : p.projects || []);
        setSupervisors(Array.isArray(s) ? s : s.supervisors || []);
      } catch (err) {
        setError(err.message);
      }
    }

    load();
  }, []);

  const handleAssign = async (projectId) => {
    const project = projects.find(
      (p) => String(p.id) === String(projectId)
    );

    const supervisor_id =
      assignments[projectId] !== undefined
        ? assignments[projectId]
        : String(
            project?.supervisor_id ||
            project?.preferred_supervisor_id ||
            ""
          );

    if (!supervisor_id) {
      setError("Please select a supervisor first.");
      return;
    }

    try {
      setError("");
      setSuccess("");

      await api.assignSupervisor(projectId, supervisor_id);

      setSuccess("Supervisor assigned successfully.");

      const p = await api.getProjects();
      setProjects(Array.isArray(p) ? p : p.projects || []);

      setAssignments((prev) => ({
        ...prev,
        [projectId]: "",
      }));
    } catch (err) {
      setError(err.message);
    }
  };

  const unassigned = projects.filter(
    (p) => !p.supervisor_id
  ).length;

  const studentPicked = projects.filter(
    (p) => p.preferred_supervisor_id
  ).length;

  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-2">
        Supervisor Assignments
      </h1>

      <p className="text-white-500 mb-6">
        Students choose their preferred supervisor when submitting
        the project. You can override or assign supervisors below.
      </p>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="bg-black p-4 rounded-xl shadow">
          <p className="text-sm text-white-500">Total Projects</p>
          <p className="text-2xl font-bold text-indigo-600">
            {projects.length}
          </p>
        </div>

        <div className="bg-black p-4 rounded-xl shadow">
          <p className="text-sm text-white-500">
            Supervisor Chosen by Student
          </p>
          <p className="text-2xl font-bold text-green-600">
            {studentPicked}
          </p>
        </div>

        <div className="bg-black p-4 rounded-xl shadow">
          <p className="text-sm text-white-500">
            Pending Assignment
          </p>
          <p className="text-2xl font-bold text-orange-600">
            {unassigned}
          </p>
        </div>
      </div>

      {error && (
        <div className="bg-red-100 text-red-600 p-3 rounded-lg mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 text-green-700 p-3 rounded-lg mb-4">
          {success}
        </div>
      )}

      <div className="space-y-4">
        {projects.map((p) => {
          const preferredId = p.preferred_supervisor_id
            ? String(p.preferred_supervisor_id)
            : "";

          const assignedId = p.supervisor_id
            ? String(p.supervisor_id)
            : "";

          return (
            <div
              key={p.id}
              className={`bg-black p-5 rounded-xl shadow flex flex-wrap items-center justify-between gap-4 border-l-4 ${
                assignedId
                  ? "border-green-500"
                  : "border-orange-400"
              }`}
            >
              <div className="flex-1 min-w-[250px]">
                <p className="font-semibold text-white">
                  {p.title}
                </p>

                <p className="text-sm text-white-500 mt-1">
                  Student: {p.student_name}
                </p>

                {preferredId ? (
                  <div className="mt-2 inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                    Student's Choice: {p.preferred_supervisor_name}
                  </div>
                ) : (
                  <div className="mt-2 inline-flex items-center gap-2 bg-orange-50 text-orange-700 px-3 py-1 rounded-full text-xs font-medium">
                    No supervisor preference selected
                  </div>
                )}

                <div className="mt-2">
                  {assignedId ? (
                    <span className="text-sm text-green-400">
                      Admin Assigned: {p.supervisor_name}
                    </span>
                  ) : (
                    <span className="text-sm text-orange-400">
                      Admin Assigned: Not assigned yet
                    </span>
                  )}
                </div>

                {(p.category || p.domain) && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {p.category && (
                      <span className="bg-indigo-50 text-indigo-700 text-xs px-2 py-0.5 rounded-full">
                        {p.category}
                      </span>
                    )}

                    {p.domain && (
                      <span className="bg-purple-50 text-purple-700 text-xs px-2 py-0.5 rounded-full">
                        {p.domain}
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <select
                  className="border rounded-lg px-3 py-2 bg-black text-white"
                  value={
                    assignments[p.id] !== undefined
                      ? assignments[p.id]
                      : assignedId || preferredId
                  }
                  onChange={(e) =>
                    setAssignments((prev) => ({
                      ...prev,
                      [p.id]: e.target.value,
                    }))
                  }
                >
                  <option value="">Select Supervisor</option>

                  {supervisors.map((s) => (
                    <option key={s.id} value={String(s.id)}>
                      {s.name} ({s.assigned_count}/{s.max_students})
                      {preferredId === String(s.id)
                        ? " (Student's Choice)"
                        : ""}
                    </option>
                  ))}
                </select>

                <button
                  onClick={() => handleAssign(p.id)}
                  className={`px-4 py-2 rounded-lg font-medium ${
                    assignedId
                      ? "bg-white border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50"
                      : "bg-indigo-600 text-white hover:bg-indigo-700"
                  }`}
                >
                  {assignedId ? "Reassign" : "Assign"}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
