import { useEffect, useState } from "react";
import {
  AlertTriangle, ArrowUpRight, CheckCircle2,
  CircleGauge, GitBranch, RefreshCw, Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";
import { api } from "../api/api";
import { probabilityToPercent } from "../utils/probability";

export default function AiInsights() {
  const [project,    setProject]    = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [modelHealth, setModelHealth] = useState(null);
  const [error,      setError]      = useState("");
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const projects = await api.getProjects();
        if (ignore || !projects[0]) { if (!ignore) setLoading(false); return; }
        if (!ignore) setProject(projects[0]);
        const [predictionResult, healthResult] = await Promise.allSettled([
          api.getPrediction(projects[0].id),
          api.getSyntheticRiskHealth(),
        ]);
        if (ignore) return;
        if (predictionResult.status === "fulfilled") {
          setPrediction(predictionResult.value);
        } else {
          setError(predictionResult.reason.message);
        }
        if (healthResult.status === "fulfilled") {
          setModelHealth(healthResult.value);
        } else if (predictionResult.status === "fulfilled") {
          setError(healthResult.reason.message);
        }
      } catch (err) {
        if (!ignore) setError(err.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => { ignore = true; };
  }, []);

  const handleRefresh = async () => {
    if (!project) return;
    setRefreshing(true);
    setError("");
    try {
      const [predictionResult, healthResult] = await Promise.allSettled([
        api.getPrediction(project.id),
        api.getSyntheticRiskHealth(),
      ]);
      if (predictionResult.status === "fulfilled") {
        setPrediction(predictionResult.value);
      } else {
        throw predictionResult.reason;
      }
      if (healthResult.status === "fulfilled") {
        setModelHealth(healthResult.value);
      } else {
        throw healthResult.reason;
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setRefreshing(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Analysing project signals…</p>
      </div>
    );
  }

  const predictionAvailable = prediction?.prediction_available === true;
  const risk = predictionAvailable ? prediction.risk_level : "Unavailable";
  const f = prediction?.features || {};
  const modelInfo = {
    ...(modelHealth?.active_risk_model || {}),
    ...(prediction?.model_info || {}),
  };
  const evaluationMetrics = modelInfo?.evaluation_metrics;
  const metricSummary = evaluationMetrics
    ? ["accuracy", "macro_f1", "macro_precision", "macro_recall"]
      .filter((name) => Number.isFinite(evaluationMetrics[name]))
      .map((name) => `${name}: ${evaluationMetrics[name].toFixed(3)}`)
      .join(" · ")
    : "";

  /* Has GitHub data (at least one GitHub feature > 0) */
  const hasGithub = (f.total_commits > 0) || (f.recent_commits > 0) ||
    (f.active_days > 0) || (f.open_issues > 0) || (f.merged_prs > 0);

  return (
    <div className="space-y-6">

      {/* ── Header ── */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16 }}>
        <div>
          <p className="eyebrow">Performance intelligence</p>
          <h1 className="page-title">AI Insights</h1>
          <p className="eyebrow" style={{ marginTop: 6 }}>
            Synthetic Risk Model — Demonstration Only
          </p>
          <p className="page-subtitle">
            Low, Medium, and High project-risk classification from Logistic Regression using project and GitHub activity signals.
          </p>
        </div>
        {project && (
          <button
            className="icon-button"
            title="Refresh prediction"
            onClick={handleRefresh}
            disabled={refreshing}
            style={{ width: 38, height: 38, border: "1px solid var(--line)", borderRadius: 9 }}
          >
            <RefreshCw size={16} style={refreshing ? { animation: "spin 1s linear infinite" } : {}} />
          </button>
        )}
      </div>

      {error && <div className="form-alert error">{error}</div>}

      {!project ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon violet"><CircleGauge size={20} /></div>
          <h2>Create a project to see insights</h2>
          <p className="muted-copy">Submit your FYP topic to unlock AI risk prediction and activity analysis.</p>
          <Link className="primary-link" to="/projects">Open project workspace <ArrowUpRight size={14} /></Link>
        </div>
      ) : (
        <>
          {/* ── Logistic Regression risk classification ── */}
          <div className="grid gap-4 md:grid-cols-3">
            <Insight
              icon={CircleGauge}
              label="Synthetic risk category"
              value={risk}
              tone={!predictionAvailable ? "blue" : risk === "high" ? "rose" : risk === "medium" ? "amber" : "teal"}
              detail={predictionAvailable ? "Low / Medium / High classification" : "No model prediction"}
            />
            <Insight
              icon={AlertTriangle}
              label="Classifier confidence"
              value={predictionAvailable
                ? `${probabilityToPercent(Math.max(...Object.values(prediction.risk_probabilities || {})))}%`
                : "Unavailable"}
              tone={predictionAvailable ? "violet" : "blue"}
              detail="Maximum synthetic class probability"
            />
            <Insight
              icon={CheckCircle2}
              label="Training data"
              value={modelInfo?.dataset?.record_count ?? "Unavailable"}
              tone="blue"
              detail="Synthetic records; not real-world validation"
            />
          </div>

          {/* ── AI explanation card ── */}
          <section className="dashboard-card ai-card">
            <div className="ai-heading">
              <span className="ai-icon"><Sparkles size={17} /></span>
              <div>
                <p className="eyebrow">Why this prediction</p>
                <h2>{project.title}</h2>
              </div>
            </div>

            <p className="muted-copy" style={{ marginTop: 18 }}>
              A Logistic Regression classifies Low, Medium, and High risk using a newly generated
              synthetic dataset and current project/GitHub signals. Historical reported metrics
              were not reproducible from the available original data or code.
            </p>

            <div role="status" className="form-alert" style={{ marginTop: 16 }}>
              <strong>{modelInfo?.model_name || "Logistic Regression not available"}</strong>
              <p style={{ marginTop: 6 }}>
                Synthetic Dataset Evaluation — Not Real-world Validation. {modelInfo?.message || error || "The synthetic classifier is unavailable."}
              </p>
              <p style={{ marginTop: 6 }}>
                {metricSummary
                  ? `Held-out synthetic test metrics: ${metricSummary}`
                  : "Synthetic evaluation metrics are unavailable."}
              </p>
              {modelInfo?.historical_claims && (
                <p style={{ marginTop: 6 }}>
                  Historical 85% accuracy and 82% Macro F1 remain unverified and were not reproduced.
                </p>
              )}
            </div>

            {/* ── Core project features ── */}
            <p className="eyebrow" style={{ margin: "18px 0 8px" }}>Project signals</p>
            <div className="mini-grid">
              <Info label="Progress"           value={`${f.progress ?? project.progress ?? 0}%`} />
              <Info label="Model" value={modelInfo?.model_name || prediction?.model_used || "Logistic Regression (not trained)"} />
              <Info label="Risk class" value={predictionAvailable ? prediction.risk_class : "Unavailable"} />
              <Info label="Synthetic training records" value={modelInfo?.dataset?.record_count ?? "—"} />
              <Info label="Held-out test records" value={modelInfo?.evaluation_metrics?.test_class_counts
                ? Object.values(modelInfo.evaluation_metrics.test_class_counts).reduce((sum, count) => sum + count, 0)
                : "—"} />
              {predictionAvailable && Object.entries(prediction.risk_probabilities || {}).map(([label, probability]) => (
                <Info key={label} label={`${label} class probability`} value={`${probabilityToPercent(probability)}%`} />
              ))}
              <Info label="Completed milestones" value={f.completed_milestones ?? "—"} />
              <Info label="Overdue milestones"   value={f.overdue_milestones ?? "—"} />
              <Info label="Pending submissions"  value={f.pending_submissions ?? "—"} />
              <Info label="Feedback count"       value={f.feedback_count ?? "—"} />
            </div>

            {/* ── GitHub signals (shown only if available) ── */}
            {hasGithub && (
              <>
                <p className="eyebrow" style={{ margin: "18px 0 8px" }}>
                  <GitBranch size={11} style={{ display: "inline", marginRight: 5 }} />
                  GitHub signals
                </p>
                <div className="mini-grid">
                  <Info label="Total commits"      value={f.total_commits ?? 0} />
                  <Info label="Recent commits"     value={f.recent_commits ?? 0} />
                  <Info label="Active days"        value={f.active_days ?? 0} />
                  <Info label="Commit frequency"   value={f.commit_frequency ?? 0} />
                  <Info label="Open PRs"           value={f.pull_requests ?? 0} />
                  <Info label="Merged PRs"         value={f.merged_prs ?? 0} />
                  <Info label="Open issues"        value={f.open_issues ?? 0} />
                  <Info label="Closed issues"      value={f.closed_issues ?? 0} />
                </div>
              </>
            )}

            {!hasGithub && (
              <div style={{ marginTop: 16, padding: "12px 14px", borderRadius: 10, background: "rgba(0,0,0,.04)", border: "1px solid var(--line)" }}>
                <p className="muted-copy" style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <GitBranch size={13} />
                  No GitHub repository linked. Link one on your{" "}
                  <Link to="/projects" className="primary-link">Projects page</Link>{" "}
                  to include development signals in the prediction.
                </p>
              </div>
            )}

            {/* ── Recommendations ── */}
            {Array.isArray(prediction?.recommendations) && prediction.recommendations.length > 0 && (
              <>
                <p className="eyebrow" style={{ margin: "18px 0 8px" }}>Recommendations</p>
                <div className="recommendation-list">
                  {prediction.recommendations.map((item) => (
                    <div className="recommendation" key={item.message}>
                      <CheckCircle2 size={15} />
                      <span>{item.message}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </section>
        </>
      )}

    </div>
  );
}

function Insight({ icon: Icon, label, value, tone, detail }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}><Icon size={18} /></div>
      <p>{label}</p>
      <strong className="capitalize">{value}</strong>
      <span>{detail || "Current model output"}</span>
    </div>
  );
}

function Info({ label, value }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
