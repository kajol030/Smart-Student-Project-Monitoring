import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowRight, Check, CheckCircle2,
  Eye, EyeOff, GraduationCap, LockKeyhole, Mail, RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";
import { api } from "../api/api";

/* ── password requirements (same as Register) ── */
const CHECKS = [
  ["length",  "At least 8 characters",   (v) => v.length >= 8],
  ["upper",   "One uppercase letter",     (v) => /[A-Z]/.test(v)],
  ["lower",   "One lowercase letter",     (v) => /[a-z]/.test(v)],
  ["number",  "One number",               (v) => /\d/.test(v)],
  ["special", "One special character",    (v) => /[^A-Za-z0-9]/.test(v)],
];

export default function ForgotPassword() {
  const [step, setStep]       = useState("email");
  const [email, setEmail]     = useState("");
  const [token, setToken]     = useState("");
  const [password, setPwd]    = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError]     = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  /* ── password strength ── */
  const pwdChecks = useMemo(() => CHECKS.map(([, , test]) => test(password)), [password]);
  const strength  = pwdChecks.filter(Boolean).length;
  const strengthClass = strength < 3 ? "weak" : strength < 5 ? "fair" : "strong";
  const strengthLabel = strength === 0 ? "Add a password" : strength < 3 ? "Weak" : strength < 5 ? "Getting stronger" : "Strong password";

  /* ── step 1: send email ── */
  const submitEmail = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const res = await api.forgotPassword(email);
      setMessage(res.message);
      setStep("token");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  /* ── resend (back to step 1 logic, reuse same email) ── */
  const resend = async () => {
    if (resendCooldown > 0) return;
    setLoading(true); setError("");
    try {
      const res = await api.forgotPassword(email);
      setMessage(res.message);
      // 60-second cooldown
      setResendCooldown(60);
      const timer = setInterval(() => {
        setResendCooldown((prev) => {
          if (prev <= 1) { clearInterval(timer); return 0; }
          return prev - 1;
        });
      }, 1000);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  /* ── step 2: reset password ── */
  const submitReset = async (e) => {
    e.preventDefault();
    if (strength < CHECKS.length) return setError("Your new password doesn't meet all requirements.");
    if (password !== confirm)     return setError("Passwords do not match.");
    setLoading(true); setError("");
    try {
      const res = await api.resetPassword({ token: token.trim(), password });
      setMessage(res.message);
      setStep("success");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      {/* ── Left rail ── */}
      <section className="auth-rail">
        <Link to="/login" className="auth-brand">
          <span className="brand-mark"><GraduationCap size={20} /></span>
          <span>Smart Student</span>
        </Link>
        <div className="auth-rail-copy">
          <p className="eyebrow">Account recovery</p>
          <h1>Get back to the work that matters.</h1>
          <p>Reset your password securely and return to your ICT Department FYP workspace.</p>
        </div>
        <div className="auth-rail-footer">
          <span className="rail-dot" /> BSCS &amp; BSAI · FYP cycle 2025 / 26
        </div>
      </section>

      {/* ── Right panel ── */}
      <main className="auth-form-panel">
        <div className="auth-form-wrap login-form-wrap">
          <div className="mobile-auth-brand">
            <span className="brand-mark"><GraduationCap size={19} /></span>
            <strong>Smart Student</strong>
          </div>

          {/* ── SUCCESS ── */}
          {step === "success" && (
            <div className="empty-state">
              <div className="metric-icon teal"><CheckCircle2 size={28} /></div>
              <p className="eyebrow">All done</p>
              <h2>Password updated</h2>
              <p className="muted-copy" style={{ marginBottom: 28 }}>{message}</p>
              <Link className="auth-submit" to="/login" style={{ textDecoration: "none", display: "inline-flex" }}>
                Sign in now <ArrowRight size={18} />
              </Link>
            </div>
          )}

          {/* ── STEP 1 or STEP 2 ── */}
          {step !== "success" && (
            <>
              <p className="eyebrow">{step === "email" ? "Step 1 of 2" : "Step 2 of 2"}</p>
              <h2>{step === "email" ? "Forgot your password?" : "Create a new password"}</h2>
              <p className="auth-subtitle">
                {step === "email"
                  ? "Enter your university email and we will send a secure one-time verification token."
                  : `Check your inbox for ${email} — paste the token below, then choose a strong new password.`}
              </p>

              {error   && <div className="form-alert error">{error}</div>}
              {message && <div className="form-alert" style={{ color: "#16a34a", background: "#f0fdf4", border: "1px solid #bbf7d0" }}>{message}</div>}

              {/* ── STEP 1 form ── */}
              {step === "email" && (
                <form onSubmit={submitEmail}>
                  <label className="field">
                    <span>University email</span>
                    <div className="password-wrap">
                      <Mail size={16} />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@university.edu.pk"
                        required
                        autoComplete="email"
                      />
                    </div>
                    <small className="field-error"> </small>
                  </label>
                  <button className="auth-submit" disabled={loading}>
                    {loading ? "Sending…" : "Send verification token"}
                    <ArrowRight size={18} />
                  </button>
                </form>
              )}

              {/* ── STEP 2 form ── */}
              {step === "token" && (
                <form onSubmit={submitReset}>
                  {/* Token input */}
                  <label className="field">
                    <span>Verification token</span>
                    <input
                      value={token}
                      onChange={(e) => setToken(e.target.value)}
                      placeholder="Paste the 64-character token from your email"
                      required
                      autoComplete="off"
                      spellCheck={false}
                      style={{ fontFamily: "monospace", fontSize: 12, letterSpacing: "0.03em" }}
                    />
                    <small className="field-error"> </small>
                  </label>

                  {/* Resend button */}
                  <div style={{ marginTop: -8, marginBottom: 18 }}>
                    <button
                      type="button"
                      className="text-button"
                      onClick={resend}
                      disabled={resendCooldown > 0 || loading}
                      style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 11 }}
                    >
                      <RefreshCw size={12} />
                      {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend token"}
                    </button>
                  </div>

                  {/* New password */}
                  <label className="field">
                    <span>New password</span>
                    <div className="password-wrap">
                      <LockKeyhole size={16} />
                      <input
                        type={showPwd ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPwd(e.target.value)}
                        placeholder="Create a strong password"
                        autoComplete="new-password"
                        required
                      />
                      <button type="button" onClick={() => setShowPwd((v) => !v)} aria-label={showPwd ? "Hide password" : "Show password"}>
                        {showPwd ? <EyeOff size={17} /> : <Eye size={17} />}
                      </button>
                    </div>
                    <small className="field-error"> </small>
                  </label>

                  {/* Strength bar + requirements — only when typing */}
                  {password.length > 0 && (
                    <>
                      <div className="strength-meter">
                        <div className="strength-bars">
                          {CHECKS.map(([id], i) => (
                            <span key={id} className={i < strength ? strengthClass : ""} />
                          ))}
                        </div>
                        <span className="strength-label">{strengthLabel}</span>
                      </div>
                      <div className="password-requirements" style={{ marginBottom: 14 }}>
                        {CHECKS.map(([id, label], i) => (
                          <span key={id} className={pwdChecks[i] ? "valid" : ""}>
                            {pwdChecks[i] ? <Check size={12} /> : <span className="requirement-dot" />}
                            {label}
                          </span>
                        ))}
                      </div>
                    </>
                  )}

                  {/* Confirm password */}
                  <label className="field">
                    <span>Confirm password</span>
                    <div className="password-wrap">
                      <LockKeyhole size={16} />
                      <input
                        type={showPwd ? "text" : "password"}
                        value={confirm}
                        onChange={(e) => setConfirm(e.target.value)}
                        placeholder="Re-enter your password"
                        autoComplete="new-password"
                        required
                      />
                    </div>
                    <small className="field-error">
                      {confirm && confirm !== password ? "Passwords do not match." : " "}
                    </small>
                  </label>

                  <button className="auth-submit" disabled={loading}>
                    {loading ? "Updating…" : "Reset password"}
                    <ArrowRight size={18} />
                  </button>
                </form>
              )}

              <p className="auth-switch" style={{ marginTop: 20 }}>
                <Link to="/login"><ArrowLeft size={13} /> Back to sign in</Link>
              </p>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
