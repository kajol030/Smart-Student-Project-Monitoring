import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Activity,
  ArrowUpRight,
  BookOpen,
  CalendarDays,
  CircleAlert,
  Clock3,
  GraduationCap,
  LayoutDashboard,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";
import { getGreeting } from "../utils/greeting";

const STATUS_COLORS = ["#1D4ED8", "#2563EB", "#93C5FD", "#D97706", "#16A34A"];
const RISK_COLORS = { low: "#16A34A", medium: "#D97706", high: "#DC2626" };

/* ── CSS bar chart (same pattern as AdminAnalytics) ─────────── */
function Bars({ data = [], labelKey, colorKey }) {
  const max = Math.max(...data.map((d) => Number(d.count) || 0), 1);
  if (!data.length) return <EmptyChart />;
  return (
    <div className="simple-bars">
      {data.map((item, i) => (
        <div className="simple-bar-row" key={item[labelKey]}>
          <span>{String(item[labelKey]).replaceAll("_", " ")}</span>
          <div>
            <i style={{
              width: `${(Number(item.count) / max) * 100}%`,
              background: colorKey && RISK_COLORS[item[colorKey]]
                ? RISK_COLORS[item[colorKey]]
                : STATUS_COLORS[i % STATUS_COLORS.length],
            }} />
          </div>
          <b>{item.count}</b>
        </div>
      ))}
    </div>
  );
}

/* ── CSS conic-gradient donut (same pattern as AdminAnalytics) ─ */
function Donut({ data = [], labelKey = "risk_level" }) {
  const total = data.reduce((s, d) => s + Number(d.count || 0), 0);
  if (!data.length || !total) return <EmptyChart />;

  const { stops } = data.reduce(
    (acc, item, i) => {
      const start = acc.offset;
      const end   = start + (Number(item.count) / total) * 360;
      return {
        offset: end,
        stops: [...acc.stops, `${STATUS_COLORS[i % STATUS_COLORS.length]} ${start}deg ${end}deg`],
      };
    },
    { offset: 0, stops: [] },
  );

  return (
    <div className="donut-layout">
      <div className="donut" style={{ background: `conic-gradient(${stops.join(", ")})` }}>
        <span>{total}<small>projects</small></span>
      </div>
      <div className="donut-legend">
        {data.map((item, i) => (
          <span key={item[labelKey]}>
            <i style={{ background: STATUS_COLORS[i % STATUS_COLORS.length] }} />
            {String(item[labelKey]).replaceAll("_", " ")} <b>{item.count}</b>
          </span>
        ))}
      </div>
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="empty-state" style={{ padding: "32px 16px" }}>
      <p className="muted-copy">No data available yet.</p>
    </div>
  );
}

/* ── Main component ──────────────────────────────────────────── */
export default function AdminDashboard() {
  const user = getStoredUser();
  const location = useLocation();
  const [analytics, setAnalytics] = useState(null);
  const [users,     setUsers]     = useState([]);
  const [activity, setActivity] = useState([]);
  const [error,     setError]     = useState("");
  const [activityError, setActivityError] = useState("");
  const [activityLoading, setActivityLoading] = useState(true);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const [a, u] = await Promise.all([api.getAnalytics(), api.getUsers()]);
        if (!ignore) { setAnalytics(a); setUsers(u); }
      } catch (err) { if (!ignore) setError(err.message); }
      finally       { if (!ignore) setLoading(false); }
    })();
    return () => { ignore = true; };
  }, []);

  useEffect(() => {
    if (!loading && location.hash === "#projects-overview") {
      document.getElementById("projects-overview")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [loading, location.hash]);

  useEffect(() => {
    let ignore = false;
    api.getAuditLogs("limit=5")
      .then((result) => {
        if (!ignore) setActivity(Array.isArray(result.logs) ? result.logs : []);
      })
      .catch((requestError) => {
        if (!ignore) setActivityError(requestError.message || "Recent activity could not be loaded.");
      })
      .finally(() => {
        if (!ignore) setActivityLoading(false);
      });
    return () => { ignore = true; };
  }, []);

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading admin workspace…</p>
      </div>
    );
  }

  const stats   = analytics?.stats || {};
  const statusD = analytics?.statusDistribution || [];
  const riskD   = analytics?.riskDistribution   || [];

  return (
    <div className="space-y-6 admin-dashboard">
      <section className="admin-welcome">
        <div className="admin-welcome-copy">
          <p className="eyebrow">Admin workspace</p>
          <h1>{getGreeting()}, {user?.name?.split(" ")[0] || "Admin"}!</h1>
          <p>Here’s what’s happening across your FYP workspace today.</p>
        </div>
        <div className="welcome-illustration" aria-hidden="true">
          <div className="illustration-orbit illustration-orbit-one" />
          <div className="illustration-orbit illustration-orbit-two" />
          <div className="illustration-book"><BookOpen size={42} /></div>
          <span className="illustration-cap"><GraduationCap size={24} /></span>
          <span className="illustration-sparkle"><Sparkles size={18} /></span>
        </div>
        <div className="welcome-caption"><span><Activity size={14} /> Workspace overview</span></div>
      </section>

      <div className="admin-dashboard-heading">
        <div>
          <h2>System overview</h2>
          <p>Project health and activity at a glance.</p>
        </div>
        <span className="dashboard-updated"><Clock3 size={14} /> Current snapshot</span>
      </div>

      {error && <div className="form-alert error">{error}</div>}

      {/* ── Stat cards ── */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="metric-card admin-stat-card users-stat">
          <div className="metric-icon violet"><Users size={18} /></div>
          <p>Total Users</p>
          <strong>{users.length}</strong>
          <span>Registered accounts</span>
          <StatSparkline />
        </div>
        <div className="metric-card admin-stat-card projects-stat">
          <div className="metric-icon teal"><LayoutDashboard size={18} /></div>
          <p>Total Projects</p>
          <strong>{stats.total_projects || 0}</strong>
          <span>Across all batches</span>
          <StatSparkline />
        </div>
        <div className="metric-card admin-stat-card progress-stat">
          <div className="metric-icon blue"><BookOpen size={18} /></div>
          <p>In Progress</p>
          <strong>{stats.in_progress || 0}</strong>
          <span>Active right now</span>
          <StatSparkline />
        </div>
        <div className="metric-card admin-stat-card risk-stat">
          <div className="metric-icon rose"><CircleAlert size={18} /></div>
          <p>High Risk</p>
          <strong>{stats.high_risk || 0}</strong>
          <span>Need intervention</span>
          <StatSparkline />
        </div>
      </div>

      <div className="admin-dashboard-section-heading">
        <div>
          <h2>Analytics</h2>
          <p>Evidence-based insights from current project data.</p>
        </div>
        <Link to="/admin/analytics" className="card-link">Full analytics <ArrowUpRight size={14} /></Link>
      </div>

      <div className="grid gap-5 xl:grid-cols-2 admin-chart-grid">
        <section className="dashboard-card chart-card" id="projects-overview">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Project portfolio</p>
              <h2>Projects Overview</h2>
            </div>
            <span className="chart-period">All projects</span>
          </div>
          <Donut data={statusD} labelKey="status" />
        </section>

        <section className="dashboard-card chart-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Predictive analytics</p>
              <h2>AI Risk Distribution</h2>
            </div>
            <span className="chart-period">Current</span>
          </div>
          <Bars data={riskD} labelKey="risk_level" colorKey="risk_level" />
        </section>
      </div>

      <div className="admin-dashboard-section-heading">
        <div>
          <h2>Workspace activity</h2>
          <p>Recent changes and common admin tasks.</p>
        </div>
      </div>
      <div className="grid gap-5 lg:grid-cols-2 2xl:grid-cols-3 admin-workspace-grid">
        <section className="dashboard-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Shortcuts</p>
              <h2>Quick Actions</h2>
            </div>
          </div>
          {[
            { to: "/admin/users",       label: "Manage Users",       icon: Users        },
            { to: "/admin/assignments", label: "Assign Supervisors", icon: ShieldCheck  },
            { to: "/admin/deadlines",   label: "Set Deadlines",      icon: CalendarDays },
            { to: "/admin/analytics",   label: "View Analytics",     icon: BookOpen     },
          ].map(({ to, label, icon: Icon }) => (
            <Link key={to} to={to} className="list-row" style={{ textDecoration: "none" }}>
              <div className="list-icon violet"><Icon size={15} /></div>
              <div className="list-main"><strong>{label}</strong></div>
              <ArrowUpRight size={14} className="muted-icon" />
            </Link>
          ))}
        </section>

        <section className="dashboard-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Audit trail</p>
              <h2>Recent Activity</h2>
            </div>
            <Activity size={17} className="activity-heading-icon" />
          </div>
          {activityError && <p className="muted-copy">{activityError}</p>}
          {activityLoading ? (
            <p className="muted-copy">Loading recent activity…</p>
          ) : activity.length === 0 ? (
            <p className="muted-copy">No recent activity has been recorded.</p>
          ) : (
            <div className="activity-timeline">
              {activity.map((item) => (
                <div className="activity-timeline-item" key={item.id}>
                  <span className="activity-timeline-marker"><Activity size={13} /></span>
                  <div className="activity-timeline-copy">
                    <strong>{String(item.action || "Activity recorded").replaceAll("_", " ").toLowerCase()}</strong>
                    <span>{item.user_name || "System user"}{item.entity ? ` · ${item.entity.replaceAll("_", " ")}` : ""}</span>
                    <time>{formatActivityDate(item.created_at)}</time>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="dashboard-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">Accounts</p>
              <h2>Recent Users</h2>
            </div>
            <Link to="/admin/users" className="card-link">
              View all <ArrowUpRight size={13} />
            </Link>
          </div>
          {users.length === 0 ? (
            <p className="muted-copy">No users found.</p>
          ) : (
            users.slice(0, 5).map((u) => (
              <div className="list-row" key={u.id}>
                <div
                  className="avatar"
                  style={{ width: 30, height: 30, fontSize: 12, flex: "none" }}
                >
                  {(u.name || "U").charAt(0).toUpperCase()}
                </div>
                <div className="list-main">
                  <strong>{u.name}</strong>
                  <span>{u.email}</span>
                </div>
                <span
                  className={`status-badge ${
                    u.role === "admin"
                      ? "review"
                      : u.role === "supervisor"
                        ? "in_progress"
                        : "completed"
                  }`}
                >
                  {u.role}
                </span>
              </div>
            ))
          )}
        </section>
      </div>
    </div>
  );
}

function StatSparkline() {
  return (
    <svg className="stat-sparkline" viewBox="0 0 96 34" preserveAspectRatio="none" aria-hidden="true">
      <path d="M1 27 C12 26 15 18 26 21 S42 28 51 18 S66 17 74 11 S86 14 95 4" />
    </svg>
  );
}

function formatActivityDate(value) {
  if (!value) return "Time unavailable";
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Time unavailable"
    : date.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
