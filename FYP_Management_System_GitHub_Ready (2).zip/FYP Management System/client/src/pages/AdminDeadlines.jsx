import { useEffect, useState } from "react";
import { CalendarDays, Plus } from "lucide-react";
import { api } from "../api/api";

export default function AdminDeadlines() {
  const [deadlines, setDeadlines] = useState([]);
  const [form, setForm]           = useState({ title: "", description: "", due_date: "" });
  const [error, setError]         = useState("");
  const [loading, setLoading]     = useState(true);

  const load = async () => {
    try {
      const data = await api.getDeadlines();
      setDeadlines(data || []);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.createDeadline(form);
      setForm({ title: "", description: "", due_date: "" });
      load();
    } catch (err) { setError(err.message); }
  };

  if (loading) return <div className="loading-state"><div /><div /><div /><p>Loading…</p></div>;

  return (
    <div className="space-y-6">

      {/* ── Header ── */}
      <div>
        <p className="eyebrow">Admin · FYP Schedule</p>
        <h1 className="page-title">Set Deadlines</h1>
        <p className="page-subtitle">Create and manage submission deadlines for all students.</p>
      </div>

      {error && <div className="form-alert error">{error}</div>}

      {/* ── Add deadline form ── */}
      <section className="dashboard-card">
        <div className="card-heading">
          <h2><Plus size={16} /> Add New Deadline</h2>
        </div>
        <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-3">
          <label className="field">
            <span>Deadline Title</span>
            <input
              placeholder="e.g. Final Report Submission"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </label>

          <label className="field">
            <span>Due Date</span>
            <input
              type="date"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
              required
            />
          </label>

          <div style={{ alignSelf: "flex-end" }}>
            <button
              className="auth-submit"
              style={{ width: "100%", height: 43 }}
            >
              Add Deadline
            </button>
          </div>

          <label className="field" style={{ gridColumn: "1 / -1" }}>
            <span>Description (optional)</span>
            <textarea
              placeholder="Brief instructions or notes for students…"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              style={{ height: 80, resize: "vertical" }}
            />
          </label>
        </form>
      </section>

      {/* ── Deadline list ── */}
      <section className="dashboard-card">
        <div className="card-heading">
          <h2>All Deadlines</h2>
          <span className="muted-copy">{deadlines.length} total</span>
        </div>

        {deadlines.length === 0 ? (
          <div className="empty-state" style={{ padding: "36px 20px" }}>
            <div className="metric-icon amber"><CalendarDays size={20} /></div>
            <h2>No deadlines yet</h2>
            <p className="muted-copy">Add your first deadline using the form above.</p>
          </div>
        ) : (
          deadlines.map((d) => (
            <div className="list-row" key={d.id}>
              <div className="list-icon amber"><CalendarDays size={15} /></div>
              <div className="list-main">
                <strong>{d.title}</strong>
                {d.description && <span>{d.description}</span>}
              </div>
              <time style={{ color: "var(--muted)", fontSize: 12, whiteSpace: "nowrap" }}>
                {new Date(d.due_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
              </time>
            </div>
          ))
        )}
      </section>
    </div>
  );
}
