import { useEffect, useRef, useState } from "react";
import { api, getStoredUser } from "../api/api";

const ACCEPTED_FILES = ".pdf,.docx,.txt";

export default function Plagiarism() {
  const user = getStoredUser();
  const isStudent = user?.role === "student";
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState("");
  const [checks, setChecks] = useState([]);
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const fileInput = useRef(null);

  useEffect(() => {
    let active = true;
    api.getProjects()
      .then((rows) => {
        if (!active) return;
        const availableProjects = Array.isArray(rows) ? rows : [];
        setProjects(availableProjects);
        setProjectId((current) => current || String(availableProjects[0]?.id || ""));
      })
      .catch((requestError) => {
        if (active) setError(requestError.message || "Projects could not be loaded.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!projectId) {
      setChecks([]);
      return undefined;
    }
    let active = true;
    setError("");
    api.getPlagiarismChecks(projectId)
      .then((result) => {
        if (active) setChecks(Array.isArray(result.checks) ? result.checks : []);
      })
      .catch((requestError) => {
        if (active) setError(requestError.message || "Similarity history could not be loaded.");
      });
    return () => { active = false; };
  }, [projectId]);

  const submitCheck = async (event) => {
    event.preventDefault();
    if (!projectId || !file) {
      setError("Choose a project and a PDF, DOCX, or text file.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("The selected file exceeds the 10 MB limit.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    setUploading(true);
    setError("");
    setNotice("");
    try {
      const result = await api.createPlagiarismCheck(projectId, formData);
      setChecks((current) => [result.check, ...current]);
      setNotice(result.advisory || "Similarity review completed.");
      setFile(null);
      if (fileInput.current) fileInput.current.value = "";
    } catch (requestError) {
      setError(requestError.message || "Similarity review could not be completed.");
    } finally {
      setUploading(false);
    }
  };

  const selectedProject = projects.find((project) => String(project.id) === projectId);

  if (loading) {
    return <div className="rounded-xl border border-slate-700 bg-slate-900 p-6 text-slate-200">Loading project data...</div>;
  }

  return (
    <section className="space-y-6">
      <header>
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-700">Document review</p>
        <h1 className="mt-1 text-3xl font-bold text-slate-900">Text similarity review</h1>
        <p className="mt-2 max-w-3xl text-slate-600">
          Compare uploaded proposal text with earlier platform checks. Similarity is an advisory signal only;
          supervisors review the evidence and retain control of all marks.
        </p>
      </header>

      {error && <div role="alert" className="rounded-lg border border-red-700 bg-red-950 p-3 text-red-100">{error}</div>}
      {notice && <div role="status" className="rounded-lg border border-emerald-700 bg-emerald-950 p-3 text-emerald-100">{notice}</div>}

      {projects.length === 0 ? (
        <div className="rounded-xl border border-slate-700 bg-slate-900 p-6 text-slate-200">
          There are no projects available for your account.
        </div>
      ) : (
        <>
          <div className="rounded-xl border border-slate-700 bg-slate-900 p-5">
            <label htmlFor="similarity-project" className="mb-2 block font-medium text-white">Project</label>
            <select
              id="similarity-project"
              value={projectId}
              onChange={(event) => setProjectId(event.target.value)}
              className="w-full max-w-2xl rounded-lg border border-slate-300 bg-white p-3 text-slate-900"
            >
              {projects.map((project) => (
                <option key={project.id} value={project.id}>{project.title}</option>
              ))}
            </select>
            {selectedProject && <p className="mt-2 text-sm text-slate-400">Project #{selectedProject.id}</p>}
          </div>

          {isStudent && (
            <form onSubmit={submitCheck} className="space-y-4 rounded-xl border border-slate-700 bg-slate-900 p-5">
              <div>
                <label htmlFor="similarity-file" className="mb-2 block font-medium text-white">
                  Upload document for review
                </label>
                <input
                  ref={fileInput}
                  id="similarity-file"
                  type="file"
                  accept={ACCEPTED_FILES}
                  onChange={(event) => setFile(event.target.files?.[0] || null)}
                  className="block w-full text-sm text-slate-700 file:mr-4 file:rounded-md file:border-0 file:bg-blue-600 file:px-4 file:py-2 file:font-semibold file:text-white"
                />
                <p className="mt-2 text-sm text-slate-400">PDF, DOCX, or UTF-8 TXT; maximum 10 MB. Uploaded bytes are processed in memory and are not saved as files.</p>
              </div>
              <button
                type="submit"
                disabled={uploading || !file}
                className="rounded-lg bg-blue-600 px-5 py-2.5 font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {uploading ? "Checking document..." : "Check text similarity"}
              </button>
            </form>
          )}

          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-white">Saved review history</h2>
            {checks.length === 0 ? (
              <p className="rounded-xl border border-slate-700 bg-slate-900 p-5 text-slate-300">
                No similarity checks have been saved for this project.
              </p>
            ) : checks.map((check) => (
              <article key={check.id} className="space-y-4 rounded-xl border border-slate-700 bg-slate-900 p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-white">{check.original_filename}</h3>
                    <p className="text-sm text-slate-400">
                      {check.word_count} words · {check.created_at ? new Date(check.created_at).toLocaleString() : "Saved review"}
                    </p>
                  </div>
                  <div className="min-w-36 text-right">
                    <strong className="text-2xl text-blue-800">{check.similarity_percent}%</strong>
                    <p className="text-xs text-slate-400">highest text similarity</p>
                  </div>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-200" aria-label={`${check.similarity_percent}% text similarity`}>
                  <div className="h-full rounded-full bg-blue-500" style={{ width: `${Math.min(100, Math.max(0, Number(check.similarity_percent) || 0))}%` }} />
                </div>
                {check.matched_text?.length > 0 ? (
                  <div className="space-y-3">
                    <h4 className="font-medium text-slate-100">Matched text excerpts</h4>
                    {check.matched_text.map((match, index) => (
                      <div key={`${check.id}-${index}`} className="rounded-lg border border-slate-700 bg-slate-950 p-4 text-sm">
                        {match.source_project_title && <p className="mb-2 text-slate-400">Reference project: {match.source_project_title}</p>}
                        {match.matched_phrase && <p className="mb-2 font-medium text-blue-800">Exact overlapping phrase: “{match.matched_phrase}”</p>}
                        {match.submitted_excerpt && <p className="text-slate-200">Uploaded text: “{match.submitted_excerpt}”</p>}
                        {match.source_excerpt && <p className="mt-2 text-slate-300">Reference text: “{match.source_excerpt}”</p>}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-400">No exact matching text passage was found in the checked documents.</p>
                )}
              </article>
            ))}
          </div>
        </>
      )}
      {!isStudent && <p className="text-sm text-slate-400">Supervisor and admin accounts can review saved results; only students can submit a new check.</p>}
    </section>
  );
}
