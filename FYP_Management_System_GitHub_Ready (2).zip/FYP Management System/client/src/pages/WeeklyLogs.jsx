import { useEffect, useState } from "react";
import {
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock3,
  Plus,
  Send,
  XCircle,
} from "lucide-react";
import { api, getStoredUser } from "../api/api";

/* ─── Initial form state ─────────────────────────────────── */
const EMPTY_FORM = {
  week_number: "",
  work_done: "",
  plan_next_week: "",
  blockers: "",
  hours_worked: "",
};

export default function WeeklyLogs() {
  const user = getStoredUser();
  const role = user?.role;

  /* ── state ── */
  const [project, setProject] = useState(null);
  const [logs, setLogs] = useState([]);
  const [summary, setSummary] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showForm, setShowForm] = useState(false);
  const [expandedLog, setExpandedLog] = useState(null);
  const [reviewComment, setReviewComment] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [reviewingId, setReviewingId] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  /* ── load data ── */
  const load = async (selectedProject) => {
    const proj = selectedProject || project;
    if (!proj) return;
    try {
      const data = await api.getWeeklyLogs(proj.id, "limit=20");
      setLogs(data.logs || []);
      setSummary(data.summary || null);
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const projects = await api.getProjects();
        if (cancelled) return;
        if (!projects || projects.length === 0) {
          setLoading(false);
          return;
        }
        const proj = projects[0];
        setProject(proj);
        const data = await api.getWeeklyLogs(proj.id, "limit=20");
        if (!cancelled) {
          setLogs(data.logs || []);
          setSummary(data.summary || null);
        }
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  /* ── submit new weekly log ── */
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!project) return;
    setError("");
    setSuccess("");
    setSubmitting(true);
    try {
      await api.submitWeeklyLog({
        project_id: project.id,
        week_number: Number(form.week_number),
        work_done: form.work_done.trim(),
        plan_next_week: form.plan_next_week.trim() || null,
        blockers: form.blockers.trim() || null,
        hours_worked: form.hours_worked ? Number(form.hours_worked) : 0,
      });
      setSuccess(`Week ${form.week_number} log submitted successfully.`);
      setForm(EMPTY_FORM);
      setShowForm(false);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  /* ── supervisor: review a log ── */
  const handleReview = async (logId) => {
    setError("");
    setSuccess("");
    setReviewingId(logId);
    try {
      await api.reviewWeeklyLog(logId, {
        supervisor_comment: reviewComment[logId] || "",
      });
      setSuccess("Log marked as reviewed.");
      setReviewComment((prev) => ({ ...prev, [logId]: "" }));
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setReviewingId(null);
    }
  };

  /* ── helpers ── */
  const toggleExpand = (id) =>
    setExpandedLog((prev) => (prev === id ? null : id));

  const fieldChange = (key, value) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const nextWeekNumber = () => {
    if (!logs.length) return 1;
    const submitted = logs.map((l) => l.week_number);
    let w = 1;
    while (submitted.includes(w)) w++;
    return w;
  };

  const openForm = () => {
    setForm({ ...EMPTY_FORM, week_number: String(nextWeekNumber()) });
    setShowForm(true);
    setError("");
    setSuccess("");
  };

  if (loading)
    return (
      <div className="loading-state">
        <div />
        <div />
        <div />
        <p>Loading weekly progress...</p>
      </div>
    );

  return (
    <div className="space-y-6">

      {/* ── Page header ── */}
      <div className="flex items-start justify-between gap-4" style={{ flexWrap: "wrap" }}>
        <div>
          <p className="eyebrow">
            {role === "supervisor" ? "Supervisor workspace" : "Student workspace"}
          </p>
          <h1 className="page-title">Weekly Progress</h1>
          <p className="page-subtitle">
            {role === "student"
              ? "Submit your weekly work log and track progress over the semester."
              : "Review your students' weekly progress reports."}
          </p>
        </div>

        {role === "student" && project && (
          <button
            className="auth-submit"
            style={{ width: "auto", padding: "0 18px", gap: 8 }}
            onClick={openForm}
          >
            <Plus size={16} />
            Submit Weekly Log
          </button>
        )}
      </div>

      {/* ── Alerts ── */}
      {error && <div className="form-alert error">{error}</div>}
      {success && (
        <div className="form-alert" style={{ color: "#16a34a", background: "#f0fdf4", border: "1px solid #bbf7d0" }}>
          {success}
        </div>
      )}

      {/* ── No project ── */}
      {!project ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon violet">
            <BookOpen size={20} />
          </div>
          <h2>No project found</h2>
          <p className="muted-copy">
            Weekly progress logs will appear here once you have an active project.
          </p>
        </div>
      ) : (
        <>
          {/* ── Summary cards ── */}
          {summary && (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <SummaryCard
                label="Total Reports"
                value={summary.total_reports}
                sub="Logs submitted"
                tone="teal"
              />
              <SummaryCard
                label="Weeks Reported"
                value={summary.reported_weeks}
                sub="Distinct weeks covered"
                tone="violet"
              />
              <SummaryCard
                label="Total Hours"
                value={`${Number(summary.total_hours).toFixed(1)}h`}
                sub="Logged across all weeks"
                tone="blue"
              />
              <SummaryCard
                label="Reviewed"
                value={summary.reviewed_reports}
                sub={`of ${summary.total_reports} reports`}
                tone="amber"
              />
            </div>
          )}

          {/* ── Submit form (students only) ── */}
          {role === "student" && showForm && (
            <section className="dashboard-card">
              <div className="card-heading">
                <h2>
                  <Send size={16} /> Submit Week {form.week_number} Report
                </h2>
                <button
                  className="icon-button"
                  onClick={() => setShowForm(false)}
                  aria-label="Cancel"
                >
                  <XCircle size={18} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="grid gap-4">
                {/* Week number + hours row */}
                <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1fr" }}>
                  <label className="field">
                    <span>Week Number</span>
                    <input
                      type="number"
                      min="1"
                      max="52"
                      required
                      value={form.week_number}
                      onChange={(e) => fieldChange("week_number", e.target.value)}
                      placeholder="e.g. 1"
                    />
                  </label>
                  <label className="field">
                    <span>Hours Worked (optional)</span>
                    <input
                      type="number"
                      min="0"
                      max="168"
                      step="0.5"
                      value={form.hours_worked}
                      onChange={(e) => fieldChange("hours_worked", e.target.value)}
                      placeholder="e.g. 12"
                    />
                  </label>
                </div>

                {/* Work done */}
                <label className="field">
                  <span>Work Done This Week *</span>
                  <textarea
                    rows={4}
                    required
                    placeholder="Describe the tasks you completed this week..."
                    value={form.work_done}
                    onChange={(e) => fieldChange("work_done", e.target.value)}
                  />
                </label>

                {/* Plan */}
                <label className="field">
                  <span>Plan for Next Week</span>
                  <textarea
                    rows={3}
                    placeholder="What do you plan to work on next week?"
                    value={form.plan_next_week}
                    onChange={(e) => fieldChange("plan_next_week", e.target.value)}
                  />
                </label>

                {/* Blockers */}
                <label className="field">
                  <span>Blockers / Issues</span>
                  <textarea
                    rows={2}
                    placeholder="Any problems or dependencies blocking progress?"
                    value={form.blockers}
                    onChange={(e) => fieldChange("blockers", e.target.value)}
                  />
                </label>

                <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
                  <button
                    type="button"
                    className="icon-button"
                    style={{
                      width: "auto",
                      padding: "0 16px",
                      border: "1px solid var(--line)",
                      borderRadius: 8,
                      fontSize: 12,
                      color: "var(--muted)",
                    }}
                    onClick={() => setShowForm(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="auth-submit"
                    disabled={submitting}
                    style={{ width: "auto", padding: "0 22px" }}
                  >
                    {submitting ? "Submitting..." : "Submit Log"}
                  </button>
                </div>
              </form>
            </section>
          )}

          {/* ── Log list ── */}
          <section className="dashboard-card" style={{ padding: 0, overflow: "hidden" }}>
            <div className="card-heading" style={{ padding: "20px 22px 14px" }}>
              <h2>
                <BookOpen size={16} /> Weekly Reports
              </h2>
              <span className="muted-copy">{logs.length} report{logs.length !== 1 ? "s" : ""}</span>
            </div>

            {logs.length === 0 ? (
              <div className="empty-state" style={{ padding: "45px 24px" }}>
                <div className="metric-icon violet">
                  <BookOpen size={20} />
                </div>
                <h2>No weekly logs yet</h2>
                <p className="muted-copy">
                  {role === "student"
                    ? 'Submit your first log using the "Submit Weekly Log" button above.'
                    : "No weekly progress reports have been submitted yet."}
                </p>
              </div>
            ) : (
              <div>
                {logs.map((log) => (
                  <LogCard
                    key={log.id}
                    log={log}
                    role={role}
                    expanded={expandedLog === log.id}
                    onToggle={() => toggleExpand(log.id)}
                    reviewComment={reviewComment[log.id] || ""}
                    onReviewCommentChange={(val) =>
                      setReviewComment((prev) => ({ ...prev, [log.id]: val }))
                    }
                    onReview={() => handleReview(log.id)}
                    reviewing={reviewingId === log.id}
                  />
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}

/* ─── Summary card ───────────────────────────────────────── */
function SummaryCard({ label, value, sub, tone }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}>
        <BookOpen size={17} />
      </div>
      <p>{label}</p>
      <strong>{value}</strong>
      <span>{sub}</span>
    </div>
  );
}

/* ─── Individual log card ────────────────────────────────── */
function LogCard({
  log,
  role,
  expanded,
  onToggle,
  reviewComment,
  onReviewCommentChange,
  onReview,
  reviewing,
}) {
  const isReviewed = log.status === "reviewed";

  return (
    <div
      style={{
        borderBottom: "1px solid var(--line, #29332d)",
      }}
    >
      {/* ── Collapsed header row ── */}
      <button
        onClick={onToggle}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "14px 22px",
          background: "transparent",
          border: 0,
          cursor: "pointer",
          textAlign: "left",
        }}
      >
        {/* Week badge */}
        <div
          className="metric-icon violet"
          style={{ width: 36, height: 36, flexShrink: 0, marginBottom: 0 }}
        >
          <span style={{ fontSize: 11, fontWeight: 700 }}>W{log.week_number}</span>
        </div>

        {/* Main info */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <strong
            style={{
              display: "block",
              fontSize: 13,
              color: "var(--ink, #f4f7f4)",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            Week {log.week_number}
            {log.student_name && (
              <span
                style={{
                  color: "var(--muted, #9ca99f)",
                  fontWeight: 400,
                  fontSize: 11,
                  marginLeft: 8,
                }}
              >
                · {log.student_name}
              </span>
            )}
          </strong>
          <span
            style={{
              color: "var(--muted, #9ca99f)",
              fontSize: 11,
              marginTop: 3,
              display: "block",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {log.work_done?.slice(0, 80)}
            {log.work_done?.length > 80 ? "…" : ""}
          </span>
        </div>

        {/* Meta right side */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            flexShrink: 0,
          }}
        >
          {log.hours_worked > 0 && (
            <span
              style={{
                display: "flex",
                alignItems: "center",
                gap: 4,
                color: "var(--muted, #9ca99f)",
                fontSize: 11,
              }}
            >
              <Clock3 size={12} />
              {Number(log.hours_worked).toFixed(1)}h
            </span>
          )}

          <StatusPill reviewed={isReviewed} />

          <span style={{ color: "var(--muted, #9ca99f)" }}>
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </span>
        </div>
      </button>

      {/* ── Expanded detail ── */}
      {expanded && (
        <div
          style={{
            padding: "0 22px 20px",
            borderTop: "1px solid var(--line, #29332d)",
          }}
        >
          {/* Submitted date */}
          <p
            style={{
              color: "var(--muted, #9ca99f)",
              fontSize: 11,
              margin: "12px 0 16px",
            }}
          >
            Submitted:{" "}
            {log.submitted_at
              ? new Date(log.submitted_at).toLocaleDateString(undefined, {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })
              : "—"}
          </p>

          <DetailBlock label="Work Done" text={log.work_done} />
          {log.plan_next_week && (
            <DetailBlock label="Plan for Next Week" text={log.plan_next_week} />
          )}
          {log.blockers && (
            <DetailBlock label="Blockers / Issues" text={log.blockers} />
          )}

          {/* Supervisor comment (if reviewed) */}
          {isReviewed && log.supervisor_comment && (
            <div
              style={{
                marginTop: 16,
                padding: "12px 14px",
                borderRadius: 9,
                background: "rgba(99,244,119,.06)",
                border: "1px solid rgba(99,244,119,.18)",
              }}
            >
              <p
                style={{
                  color: "#16a34a",
                  fontSize: 10,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: ".08em",
                  margin: "0 0 6px",
                }}
              >
                Supervisor Comment
              </p>
              <p
                style={{
                  color: "var(--ink, #f4f7f4)",
                  fontSize: 12,
                  margin: 0,
                  lineHeight: 1.6,
                }}
              >
                {log.supervisor_comment}
              </p>
            </div>
          )}

          {/* Supervisor review form */}
          {role === "supervisor" && !isReviewed && (
            <div style={{ marginTop: 18, display: "grid", gap: 10 }}>
              <label className="field">
                <span>Review Comment (optional)</span>
                <textarea
                  rows={2}
                  placeholder="Leave a comment for the student..."
                  value={reviewComment}
                  onChange={(e) => onReviewCommentChange(e.target.value)}
                />
              </label>
              <button
                className="auth-submit"
                style={{ width: "auto", padding: "0 20px", alignSelf: "flex-start" }}
                onClick={onReview}
                disabled={reviewing}
              >
                <CheckCircle2 size={15} />
                {reviewing ? "Saving..." : "Mark as Reviewed"}
              </button>
            </div>
          )}

          {/* Already reviewed badge */}
          {role === "supervisor" && isReviewed && (
            <div
              style={{
                marginTop: 14,
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                color: "#16a34a",
                fontSize: 11,
              }}
            >
              <CheckCircle2 size={14} />
              Already reviewed
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Small helpers ──────────────────────────────────────── */
function StatusPill({ reviewed }) {
  return (
    <span
      style={{
        padding: "3px 9px",
        borderRadius: 999,
        fontSize: 10,
        fontWeight: 700,
        color: reviewed ? "#16a34a" : "#d97706",
        background: reviewed ? "#f0fdf4" : "#fffbeb",
      }}
    >
      {reviewed ? "Reviewed" : "Pending"}
    </span>
  );
}

function DetailBlock({ label, text }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <p
        style={{
          color: "var(--muted, #9ca99f)",
          fontSize: 10,
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: ".08em",
          margin: "0 0 5px",
        }}
      >
        {label}
      </p>
      <p
        style={{
          color: "var(--ink, #f4f7f4)",
          fontSize: 12,
          margin: 0,
          lineHeight: 1.65,
          whiteSpace: "pre-wrap",
        }}
      >
        {text}
      </p>
    </div>
  );
}
