
import { useEffect, useState } from "react";
import { api } from "../api/api";

const API_BASE = "http://localhost:5000";

function getFileUrl(filePath) {
  if (!filePath) return null;

  if (/^https?:\/\//i.test(filePath)) {
    return filePath;
  }

  return `${API_BASE}/${String(filePath).replace(/^\/+/, "")}`;
}

function statusColor(status) {
  const colors = {
    pending: "bg-yellow-900 text-yellow-200",
    approved: "bg-green-900 text-green-200",
    revision: "bg-orange-900 text-orange-200",
    rejected: "bg-red-900 text-red-200",
  };

  return colors[status] || "bg-gray-800 text-gray-200";
}

export default function SupervisorReviews() {
  const [projects, setProjects] = useState([]);
  const [selected, setSelected] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [error, setError] = useState("");
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [loadingSubmissions, setLoadingSubmissions] = useState(false);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    let ignore = false;

    async function loadProjects() {
      try {
        const data = await api.getProjects();

        if (!ignore) {
          setProjects(Array.isArray(data) ? data : []);
        }
      } catch (err) {
        if (!ignore) {
          setError(err.message || "Failed to load projects.");
        }
      } finally {
        if (!ignore) {
          setLoadingProjects(false);
        }
      }
    }

    loadProjects();

    return () => {
      ignore = true;
    };
  }, []);

  const loadSubmissions = async (projectId) => {
    setSelected(projectId);
    setSubmissions([]);
    setLoadingSubmissions(true);
    setError("");

    try {
      const data = await api.getSubmissions(projectId);

      setSubmissions(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err.message || "Failed to load submissions.");
    } finally {
      setLoadingSubmissions(false);
    }
  };

  const updateStatus = async (id, status) => {
    try {
      setUpdatingId(id);
      setError("");

      await api.updateSubmissionStatus(id, status);

      if (selected !== null) {
        await loadSubmissions(selected);
      }
    } catch (err) {
      setError(err.message || "Failed to update submission.");
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6 text-white">
      <h1 className="text-3xl font-bold text-white">
        Review Submissions
      </h1>

      {error && (
        <div className="bg-red-950 border border-red-700 text-red-200 p-3 rounded-lg">
          {error}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">

        {/* PROJECTS */}
        <section className="bg-black border border-gray-800 rounded-xl shadow p-4">
          <h2 className="font-semibold text-white mb-4">
            Projects
          </h2>

          {loadingProjects ? (
            <p className="text-gray-300">
              Loading projects...
            </p>
          ) : projects.length === 0 ? (
            <p className="text-gray-300">
              No projects assigned.
            </p>
          ) : (
            projects.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => loadSubmissions(p.id)}
                className={`w-full text-left p-3 rounded-lg mb-2 border transition-colors ${
                  selected === p.id
                    ? "bg-gray-900 border-green-500 text-white"
                    : "bg-black border-gray-800 text-white hover:bg-gray-900 hover:border-gray-600"
                }`}
              >
                <p className="font-semibold text-white">
                  {p.title}
                </p>

                <p className="text-sm text-gray-300 mt-1">
                  {p.student_name || "Student"}
                </p>

                {selected === p.id && (
                  <span className="inline-block mt-2 text-xs font-medium text-green-400">
                    Selected
                  </span>
                )}
              </button>
            ))
          )}
        </section>

        {/* SUBMISSIONS */}
        <section className="lg:col-span-2 bg-black border border-gray-800 rounded-xl shadow p-4">
          <h2 className="font-semibold text-white mb-4">
            Submissions
          </h2>

          {selected === null ? (
            <p className="text-gray-300">
              Select a project to review submissions.
            </p>
          ) : loadingSubmissions ? (
            <p className="text-gray-300">
              Loading submissions...
            </p>
          ) : submissions.length === 0 ? (
            <p className="text-gray-300">
              No submissions found for this project.
            </p>
          ) : (
            submissions.map((s) => {
              const fileUrl = getFileUrl(s.file_path);
              const isUpdating = updatingId === s.id;

              return (
                <div
                  key={s.id}
                  className="bg-gray-950 border border-gray-700 rounded-lg p-4 mb-4"
                >
                  {/* DOCUMENT DETAILS */}
                  <div className="flex flex-wrap justify-between items-start gap-3">
                    <div>
                      <h3 className="font-semibold text-white text-lg">
                        {s.title}
                      </h3>

                      <p className="text-sm text-gray-300 capitalize mt-1">
                        {s.type}
                      </p>

                      {s.submitted_at && (
                        <p className="text-xs text-gray-400 mt-1">
                          Submitted:{" "}
                          {new Date(
                            s.submitted_at
                          ).toLocaleDateString()}
                        </p>
                      )}
                    </div>

                    <span
                      className={`text-sm px-3 py-1 rounded-full capitalize ${statusColor(
                        s.status
                      )}`}
                    >
                      {s.status || "pending"}
                    </span>
                  </div>

                  {/* PDF ACTIONS */}
                  <div className="flex flex-wrap gap-3 mt-4 border-t border-gray-700 pt-4">
                    {fileUrl ? (
                      <>
                        {/* VIEW PDF */}
                    <a
                       href={fileUrl}
                       target="_blank"
                       rel="noopener noreferrer"
                        className="bg-blue-700 hover:bg-blue-600 !text-white px-4 py-2 rounded-lg text-sm font-medium"
>
                        <span className="!text-white">View PDF</span>
                            </a>

            {/* DOWNLOAD PDF */}
                  <a
              href={fileUrl}
                    download
                  className="bg-slate-700 hover:bg-slate-600 !text-white px-4 py-2 rounded-lg text-sm font-medium"
>
                    <span className="!text-white">Download PDF</span>
                  </a>
                      </>
                    ) : (
                      <div className="bg-yellow-950 border border-yellow-800 text-yellow-200 p-3 rounded-lg text-sm w-full">
                        File path is missing from this submission.
                        Check the submissions API response.
                      </div>
                    )}
                  </div>

                  {/* REVIEW ACTIONS */}
                  <div className="flex flex-wrap gap-3 mt-4">
                    <button
                      type="button"
                      onClick={() =>
                        updateStatus(s.id, "approved")
                      }
                      disabled={isUpdating}
                      className="bg-green-700 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-50"
                    >
                      {isUpdating ? "Updating..." : "Approve"}
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        updateStatus(s.id, "revision")
                      }
                      disabled={isUpdating}
                      className="bg-yellow-700 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-50"
                    >
                      Request Revision
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        updateStatus(s.id, "rejected")
                      }
                      disabled={isUpdating}
                      className="bg-red-700 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-50"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </section>
      </div>
    </div>
  );
}

