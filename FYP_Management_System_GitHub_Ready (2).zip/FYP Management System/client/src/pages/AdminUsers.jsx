import { useEffect, useState } from "react";
import { api } from "../api/api";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.getUsers()
      .then(setUsers)
      .catch((err) => setError(err.message));
  }, []);

  async function handleDelete(id) {
    if (!window.confirm("Delete this user? This will remove their related data.")) return;
    try {
      await api.deleteUser(id);
      setUsers((prev) => prev.filter((u) => u.id !== id));
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-white-800 mb-6">Manage Users</h1>
      {error && <div className="bg-red-100 text-red-600 p-3 rounded-lg mb-4 ">{error}</div>}

      <div className="bg-black rounded-xl shadow overflow-hidden ">
        <table className="w-full text-sm ">
          <thead className="bg-gray-50 ">
            <tr>
              <th className="text-left p-4">Name</th>
              <th className="text-left p-4">Email</th>
              <th className="text-left p-4">Role</th>
              <th className="text-left p-4">Joined</th>
              <th className="text-left p-4">Actions</th>
            </tr>
          </thead>
          <tbody className="text-black">
            {users.map((u) => (
              <tr key={u.id} className="border-t">
                <td className="p-4 text-black">{u.name}</td>
                <td className="p-4 text-black ">{u.email}</td>
                <td className="p-4 capitalize text-black">{u.role}</td>
                <td className="p-4 text-black">{new Date(u.created_at).toLocaleDateString()}</td>
                <td className="p-4  text-black ">
                  <button
                    onClick={() => handleDelete(u.id)}
                    className="bg-red-500 hover:bg-red-600 text-black px-3 py-1 rounded"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
