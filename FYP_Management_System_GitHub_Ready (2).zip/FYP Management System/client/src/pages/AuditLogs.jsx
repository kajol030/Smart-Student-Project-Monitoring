import { useEffect, useState } from "react";
import { Activity, Search } from "lucide-react";
import { api } from "../api/api";

export default function AuditLogs() {
  const [logs, setLogs] = useState([]); const [query, setQuery] = useState(""); const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  useEffect(() => { let ignore = false; api.getAuditLogs().then((data) => { if (!ignore) setLogs(data?.logs || []); }).catch((err) => { if (!ignore) setError(err.message); }).finally(() => { if (!ignore) setLoading(false); }); return () => { ignore = true; }; }, []);
  const filtered = logs.filter((log) => `${log.action} ${log.user_name || ""} ${log.entity || ""}`.toLowerCase().includes(query.toLowerCase()));
  if (loading) return <div className="loading-state"><div /><div /><p>Loading audit logs...</p></div>;
  return <div className="space-y-6"><div><p className="eyebrow">Governance</p><h1 className="page-title">Audit logs</h1><p className="page-subtitle">A traceable record of important system actions.</p></div>{error && <div className="form-alert error">{error}</div>}<section className="dashboard-card"><label className="global-search" style={{ width: "100%", marginBottom: 12 }}><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search actions, users or entities" /></label>{filtered.length ? filtered.map((log) => <article className="list-row" key={log.id}><div className="list-icon violet"><Activity size={16} /></div><div className="list-main"><strong>{log.action}</strong><span>{log.user_name || "System"} · {log.entity || "General"}{log.entity_id ? ` #${log.entity_id}` : ""}</span></div><time>{log.created_at ? new Date(log.created_at).toLocaleString() : ""}</time></article>) : <div className="empty-state"><h2>No audit entries found</h2><p className="muted-copy">Try a different search term.</p></div>}</section></div>;
}
