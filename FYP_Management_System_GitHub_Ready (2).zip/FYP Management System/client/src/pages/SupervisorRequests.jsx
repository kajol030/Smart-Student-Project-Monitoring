import { useEffect, useState } from "react";
import { ClipboardCheck } from "lucide-react";
import { api } from "../api/api";

export default function SupervisorRequests() {
  const [requests, setRequests] = useState([]);
  const [rejectionReasons, setRejectionReasons] = useState({});
  const [processingId, setProcessingId] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const data = await api.getSupervisorRequests();
        if (!Array.isArray(data)) {
          throw new Error("Supervisor requests could not be loaded.");
        }
        if (!ignore) setRequests(data);
      } catch (requestError) {
        if (!ignore) setError(requestError.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => { ignore = true; };
  }, []);

  const refreshRequests = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await api.getSupervisorRequests();
      if (!Array.isArray(data)) {
        throw new Error("Supervisor requests could not be refreshed.");
      }
      setRequests(data);
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setLoading(false);
    }
  };

  const respond = async (request, status) => {
    setProcessingId(request.id);
    setError("");
    setSuccess("");
    try {
      const reason = (rejectionReasons[request.id] || "").trim();
      if (status === "rejected") {
        await api.respondToSupervisorRequest(request.id, status, reason);
      } else {
        await api.respondToSupervisorRequest(request.id, status);
      }
      setSuccess(`Request #${request.id} ${status}.`);
      await refreshRequests();
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div /><div /><div />
        <p>Loading supervisor requests…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="eyebrow">Supervisor workspace</p>
        <h1 className="page-title">Supervisor Requests</h1>
        <p className="page-subtitle">Review student requests to supervise their projects.</p>
      </div>

      {error && <div className="form-alert error" role="alert">{error}</div>}
      {success && (
        <div className="form-alert" role="status" style={{ color: "#2c8d7b", background: "#eaf8f4" }}>
          {success}
        </div>
      )}

      <section className="dashboard-card">
        <div className="card-heading">
          <h2><ClipboardCheck size={17} /> All Requests</h2>
          <span className="muted-copy">{requests.length} total</span>
        </div>

        {requests.length === 0 ? (
          !error && (
            <div className="empty-state" style={{ padding: "40px 20px" }}>
              <div className="metric-icon violet"><ClipboardCheck size={20} /></div>
              <h2>No supervisor requests</h2>
              <p className="muted-copy">New student requests will appear here.</p>
            </div>
          )
        ) : (
          requests.map((request) => (
            <article
              className="list-row"
              key={request.id}
              style={{ alignItems: "flex-start", flexWrap: "wrap" }}
            >
              <div className="list-icon violet"><ClipboardCheck size={15} /></div>
              <div className="list-main">
                <strong>{request.title || "Untitled project"}</strong>
                <span>
                  Student: {request.student_name || "Unknown"} · Request #{request.id} ·
                  {" "}Preference #{request.preference_order ?? "—"}
                </span>
                <span style={{ marginTop: 6 }}>
                  Status: <span className={`status-badge ${request.status === "accepted" ? "completed" : request.status === "pending" ? "proposal" : ""}`}>
                    {request.status || "unknown"}
                  </span>
                </span>
              </div>

              {request.status === "pending" && (
                <div style={{ display: "grid", gap: 8, width: "min(100%, 300px)", flex: "none" }}>
                  <label className="field">
                    <span>Rejection reason (optional)</span>
                    <textarea
                      rows={2}
                      placeholder="Add a reason for rejecting this request"
                      value={rejectionReasons[request.id] || ""}
                      onChange={(event) => setRejectionReasons((current) => ({
                        ...current,
                        [request.id]: event.target.value,
                      }))}
                      disabled={processingId === request.id}
                    />
                  </label>
                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                    <button
                      type="button"
                      className="icon-button"
                      style={{ width: "auto", padding: "5px 12px", fontSize: 12, height: "auto", borderRadius: 8, border: "1px solid var(--line)", color: "#d4556a" }}
                      onClick={() => respond(request, "rejected")}
                      disabled={processingId === request.id}
                    >
                      {processingId === request.id ? "Saving…" : "Reject"}
                    </button>
                    <button
                      type="button"
                      className="auth-submit"
                      style={{ width: "auto", padding: "5px 14px", fontSize: 12, height: "auto", borderRadius: 8 }}
                      onClick={() => respond(request, "accepted")}
                      disabled={processingId === request.id}
                    >
                      {processingId === request.id ? "Saving…" : "Accept"}
                    </button>
                  </div>
                </div>
              )}
            </article>
          ))
        )}
      </section>
    </div>
  );
}
