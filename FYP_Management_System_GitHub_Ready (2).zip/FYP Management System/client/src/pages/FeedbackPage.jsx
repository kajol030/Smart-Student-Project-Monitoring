import { useEffect, useState } from "react";
import { MessageSquare, Star } from "lucide-react";
import { api, getStoredUser } from "../api/api";

export default function FeedbackPage() {
  const user = getStoredUser();
  const role = user?.role;

  const [project,  setProject]  = useState(null);
  const [feedback, setFeedback] = useState([]);
  const [message,  setMessage]  = useState("");
  const [rating,   setRating]   = useState(5);
  const [error,    setError]    = useState("");
  const [success,  setSuccess]  = useState("");
  const [loading,  setLoading]  = useState(true);

  const load = async () => {
    try {
      const projects = await api.getProjects();
      if (!projects.length) { setLoading(false); return; }
      setProject(projects[0]);
      const data = await api.getFeedback(projects[0].id);
      setFeedback(data || []);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const projects = await api.getProjects();
        if (ignore || !projects.length) { if (!ignore) setLoading(false); return; }
        const data = await api.getFeedback(projects[0].id);
        if (!ignore) { setProject(projects[0]); setFeedback(data || []); }
      } catch (err) { if (!ignore) setError(err.message); }
      finally      { if (!ignore) setLoading(false); }
    })();
    return () => { ignore = true; };
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!project) return;
    try {
      await api.createFeedback({ project_id: project.id, message, rating: Number(rating) });
      setMessage("");
      setSuccess("Feedback sent successfully.");
      load();
    } catch (err) { setError(err.message); }
  };

  if (loading) return <div className="loading-state"><div /><div /><div /><p>Loading feedback…</p></div>;

  return (
    <div className="space-y-6">

      {/* ── Header ── */}
      <div>
        <p className="eyebrow">
          {role === "supervisor" ? "Supervisor workspace" : "Student workspace"}
        </p>
        <h1 className="page-title">Feedback</h1>
        <p className="page-subtitle">
          {role === "supervisor"
            ? "Give feedback and ratings to your assigned students."
            : "View feedback and ratings from your supervisor."}
        </p>
      </div>

      {error   && <div className="form-alert error">{error}</div>}
      {success && <div className="form-alert" style={{ color: "#16a34a", background: "#f0fdf4", border: "1px solid #bbf7d0" }}>{success}</div>}

      {/* ── Supervisor: write feedback ── */}
      {role === "supervisor" && project && (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2><MessageSquare size={16} /> Write Feedback</h2>
            <span className="muted-copy">Project: {project.title}</span>
          </div>
          <form onSubmit={handleSubmit} className="grid gap-4">
            <label className="field">
              <span>Feedback message</span>
              <textarea
                placeholder="Write detailed feedback for the student…"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                style={{ height: 100, resize: "vertical" }}
              />
            </label>

            <div style={{ display: "flex", alignItems: "flex-end", gap: 12, flexWrap: "wrap" }}>
              <label className="field" style={{ minWidth: 120 }}>
                <span>Rating (1–5)</span>
                <select value={rating} onChange={(e) => setRating(e.target.value)}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <option key={n} value={n}>{n} — {["Poor","Below Average","Average","Good","Excellent"][n-1]}</option>
                  ))}
                </select>
              </label>
              <button
                className="auth-submit"
                style={{ width: "auto", padding: "0 24px", alignSelf: "flex-end" }}
              >
                Send Feedback
              </button>
            </div>
          </form>
        </section>
      )}

      {/* ── No project state ── */}
      {!project ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon violet"><MessageSquare size={20} /></div>
          <h2>No project available</h2>
          <p className="muted-copy">Feedback will appear once a project is assigned.</p>
        </div>
      ) : feedback.length === 0 ? (
        <div className="dashboard-card empty-state">
          <div className="metric-icon violet"><MessageSquare size={20} /></div>
          <h2>No feedback yet</h2>
          <p className="muted-copy">
            {role === "supervisor"
              ? "Use the form above to submit your first feedback."
              : "Your supervisor hasn't provided feedback yet."}
          </p>
        </div>
      ) : (
        <section className="dashboard-card">
          <div className="card-heading">
            <h2>Feedback History</h2>
            <span className="muted-copy">{feedback.length} entries</span>
          </div>

          {feedback.map((f) => (
            <div key={f.id} className="list-row" style={{ alignItems: "flex-start", padding: "16px 0" }}>
              <div className="list-icon violet"><MessageSquare size={15} /></div>
              <div className="list-main" style={{ flex: 1 }}>
                <strong>{f.supervisor_name || "Supervisor"}</strong>
                <span style={{ marginTop: 5, display: "block", lineHeight: 1.55 }}>{f.message}</span>
                {f.rating > 0 && (
                  <span style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 6, color: "#d97706", fontSize: 12 }}>
                    <Star size={12} fill="#d97706" />
                    {f.rating}/5
                  </span>
                )}
              </div>
              <time style={{ color: "var(--muted)", fontSize: 11, whiteSpace: "nowrap", flex: "none" }}>
                {new Date(f.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
              </time>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
