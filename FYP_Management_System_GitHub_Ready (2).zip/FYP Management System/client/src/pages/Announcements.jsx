import { useEffect, useState } from "react";
import { Bell, Megaphone, Plus, Send } from "lucide-react";
import { api, getStoredUser } from "../api/api";

export default function Announcements() {
  const user = getStoredUser(); const isAdmin = user?.role === "admin"; const [items, setItems] = useState([]); const [form, setForm] = useState({ title: "", body: "", target_role: "all" }); const [open, setOpen] = useState(false); const [error, setError] = useState(""); const [message, setMessage] = useState(""); const [loading, setLoading] = useState(true);
  const load = async () => { try { const data = await api.getAnnouncements(); setItems(data?.announcements || data || []); } catch (err) { setError(err.message); } finally { setLoading(false); } };
  useEffect(() => {
    let ignore = false;
    async function loadAnnouncements() {
      try { const data = await api.getAnnouncements(); if (!ignore) setItems(data?.announcements || data || []); }
      catch (err) { if (!ignore) setError(err.message); }
      finally { if (!ignore) setLoading(false); }
    }
    loadAnnouncements();
    return () => { ignore = true; };
  }, []);
  const submit = async (event) => { event.preventDefault(); try { await api.createAnnouncement(form); setMessage("Announcement published."); setForm({ title: "", body: "", target_role: "all" }); setOpen(false); load(); } catch (err) { setError(err.message); } };
  if (loading) return <div className="loading-state"><div /><div /><p>Loading announcements...</p></div>;
  return <div className="space-y-6"><div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Department updates</p><h1 className="page-title">Announcements</h1><p className="page-subtitle">Important notices from the ICT Department.</p></div>{isAdmin && <button className="auth-submit" style={{ width: "auto", padding: "0 16px" }} onClick={() => setOpen((value) => !value)}><Plus size={16} /> New announcement</button>}</div>{error && <div className="form-alert error">{error}</div>}{message && <div className="form-alert" style={{ color: "#2c8d7b", background: "#eaf8f4" }}>{message}</div>}{open && <form onSubmit={submit} className="dashboard-card grid gap-3"><label className="field"><span>Title</span><input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} required /></label><label className="field"><span>Audience</span><select value={form.target_role} onChange={(event) => setForm({ ...form, target_role: event.target.value })}><option value="all">Everyone</option><option value="student">Students</option><option value="supervisor">Supervisors</option></select></label><label className="field"><span>Announcement</span><textarea value={form.body} onChange={(event) => setForm({ ...form, body: event.target.value })} required /></label><button className="auth-submit"><Send size={16} /> Publish announcement</button></form>}<section className="dashboard-card">{items.length ? items.map((item) => <article className="announcement-item" key={item.id}><div className="list-icon amber"><Megaphone size={17} /></div><div><div className="flex items-center gap-2"><strong>{item.title}</strong><span className="status-badge proposal">{item.target_role === "all" ? "Everyone" : item.target_role}</span></div><p>{item.body}</p><time>{item.created_at ? new Date(item.created_at).toLocaleDateString() : ""} · {item.created_by_name || "ICT Department"}</time></div></article>) : <div className="empty-state"><div className="metric-icon amber"><Bell size={20} /></div><h2>No announcements</h2><p className="muted-copy">Department updates will appear here.</p></div>}</section></div>;
}
