import { useEffect, useState } from "react"; 
import { CalendarDays, CheckCircle2, Clock3, MapPin, Plus, Video, XCircle } from "lucide-react"; 
import { api } from "../api/api"; 
 
const initialForm = { project_id: "", agenda: "", scheduled_at: "", location: "", meeting_type: "in_person" }; 
export default function Meetings() { 
  const [meetings, setMeetings] = useState([]); const [projects, setProjects] = useState([]); const [form, setForm] = useState(initialForm); const [open, setOpen] = useState(false); const [loading, setLoading] = useState(true); const [error, setError] = useState(""); const [message, setMessage] = useState(""); 
  const load = async () => { try { const [meetingData, projectData] = await Promise.all([api.getMeetings(), api.getProjects()]); setMeetings(meetingData || []); setProjects(projectData || []); setForm((current) => ({ ...current, project_id: current.project_id || projectData?.[0]?.id || "" })); } catch (err) { setError(err.message); } finally { setLoading(false); } }; 
  useEffect(() => { 
    let ignore = false; 
    async function loadMeetings() { 
      try { const [meetingData, projectData] = await Promise.all([api.getMeetings(), api.getProjects()]); if (!ignore) { setMeetings(meetingData || []); setProjects(projectData || []); setForm((current) => ({ ...current, project_id: current.project_id || projectData?.[0]?.id || "" })); } } 
      catch (err) { if (!ignore) setError(err.message); } 
      finally { if (!ignore) setLoading(false); } 
    } 
    loadMeetings(); 
    return () => { ignore = true; }; 
  }, []); 
  const submit = async (event) => { event.preventDefault(); try { await api.createMeeting({ ...form, project_id: Number(form.project_id) }); setMessage("Meeting request created."); setOpen(false); setForm((current) => ({ ...initialForm, project_id: current.project_id })); load(); } catch (err) { setError(err.message); } }; 
  const update = async (id, status) => { try { await api.updateMeeting(id, { status }); setMessage(`Meeting ${status}.`); load(); } catch (err) { setError(err.message); } }; 

  const getStatusLabel = (status) => {
    if (status === "completed") return "Completed";
    if (status === "cancelled") return "Cancelled";
    return "Pending";
  };

  const getStatusStyle = (status) => {
    if (status === "completed") {
      return { color: "#16a34a", background: "#f0fdf4" };
    }

    if (status === "cancelled") {
      return { color: "#dc2626", background: "#fef2f2" };
    }

    return { color: "#d97706", background: "#fffbeb" };
  };

  if (loading) return <div className="loading-state"><div /><div /><p>Loading meetings...</p></div>; 
  return <div className="space-y-6"><div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Consultation log</p><h1 className="page-title">Meetings</h1><p className="page-subtitle">Plan consultations, record decisions and keep the next action visible.</p></div><button className="auth-submit" style={{ width: "auto", padding: "0 16px" }} onClick={() => setOpen((value) => !value)}><Plus size={16} /> Request meeting</button></div>{error && <div className="form-alert error">{error}</div>}{message && <div className="form-alert" style={{ color: "#2c8d7b", background: "#eaf8f4" }}>{message}</div>}{open && <form onSubmit={submit} className="dashboard-card grid gap-3 md:grid-cols-2"><label className="field"><span>Project</span><select value={form.project_id} onChange={(event) => setForm({ ...form, project_id: event.target.value })} required>{projects.map((project) => <option key={project.id} value={project.id}>{project.title}</option>)}</select></label><label className="field"><span>Meeting date and time</span><input type="datetime-local" value={form.scheduled_at} onChange={(event) => setForm({ ...form, scheduled_at: event.target.value })} required /></label><label className="field md:col-span-2"><span>Agenda</span> <textarea 
  value={form.agenda} 
  onChange={(event) => setForm({ ...form, agenda: event.target.value })} 
  placeholder="What should this consultation cover?" 
  required 
  style={{ color: "#0f172a", backgroundColor: "#ffffff" }} 
/></label><label className="field"><span>Meeting type</span><select value={form.meeting_type} onChange={(event) => setForm({ ...form, meeting_type: event.target.value })}><option value="in_person">In person</option><option value="online">Online</option></select></label><label className="field"><span>Location or link</span><input value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })} placeholder="Room or meeting link" /></label><button className="auth-submit md:col-span-2">Send meeting request</button></form>}<section className="dashboard-card">{meetings.length ? meetings.map((meeting) => <article className="list-row" key={meeting.id}><div className="list-icon violet">{meeting.meeting_type === "online" ? <Video size={16} /> : <MapPin size={16} />}</div><div className="list-main"><strong>{meeting.project_title || "Project consultation"}</strong><span>{meeting.agenda || "No agenda recorded"} · Requested by {meeting.requested_by_name}</span></div><div className="text-right"><strong style={{ ...getStatusStyle(meeting.status), display: "inline-block", padding: "4px 9px", borderRadius: "999px", fontSize: "12px", fontWeight: 600 }}>{getStatusLabel(meeting.status)}</strong><time className="block">{meeting.scheduled_at ? new Date(meeting.scheduled_at).toLocaleString() : "Schedule pending"}</time></div>{meeting.status === "pending" && <div className="flex gap-1"><button className="icon-button" title="Mark as completed" onClick={() => update(meeting.id, "completed")} style={{ color: "#16a34a" }}><CheckCircle2 size={16} /></button><button className="icon-button" title="Cancel meeting" onClick={() => update(meeting.id, "cancelled")} style={{ color: "#de687b" }}><XCircle size={16} /></button></div>}</article>) : <div className="empty-state"><div className="metric-icon violet"><CalendarDays size={20} /></div><h2>No meetings recorded</h2><p className="muted-copy">Your consultation history will appear here.</p></div>}</section></div>;
}