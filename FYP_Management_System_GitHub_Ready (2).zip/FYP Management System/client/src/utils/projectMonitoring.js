export function buildProjectMonitoringView({
  github,
  alignment,
  prediction,
  githubError = null,
  alignmentError = null,
  predictionError = null,
}) {
  const githubData = github?.data || null;
  const requirements = alignment?.requirements || [];
  const recommendations = requirements
    .filter((requirement) => requirement.status !== "strong_textual_match")
    .slice(0, 5)
    .map((requirement) =>
      `Demonstrate and test "${requirement.objective}"; current text evidence is ${requirement.status.replaceAll("_", " ")}.`
    );

  if ((githubData?.issues?.open_count || 0) > 0) {
    recommendations.push(
      "Discuss open repository issues and identify which, if any, are blockers."
    );
  }
  recommendations.push(
    "Verify a working demonstration and milestone deliverables directly before evaluating."
  );

  return {
    milestoneProgress: alignment?.implementation_progress?.milestone_progress ?? null,
    evidenceEstimate: alignment?.implementation_progress?.evidence_estimate ?? null,
    alignmentScore: alignment?.alignment_score ?? null,
    alignmentSource: alignment?.alignment_source || null,
    requirements,
    riskLevel: prediction?.risk_level || "Unavailable",
    riskModel: prediction?.model_used || "Prediction service status",
    github: githubData
      ? {
          repositoryName: githubData.repository?.full_name || null,
          commits: githubData.commits?.total_fetched ?? null,
          branches: githubData.branches?.total_fetched ?? null,
          openPullRequests: githubData.pull_requests?.open_count ?? null,
          mergedPullRequests: githubData.pull_requests?.merged_count ?? null,
          openIssues: githubData.issues?.open_count ?? null,
          closedIssues: githubData.issues?.recent_closed_count ?? null,
        }
      : null,
    githubError,
    alignmentError,
    predictionError,
    treeError: alignment?.github_tree_error || null,
    proposalDocumentError: alignment?.proposal_document_error || null,
    recommendations,
  };
}

export function getPredictionDisplay(prediction) {
  const riskLevel = ["low", "medium", "high"].includes(
    String(prediction?.risk_level || "").toLowerCase()
  )
    ? String(prediction.risk_level).toLowerCase()
    : null;
  const probability = (value) => {
    if (value === null || value === undefined || value === "") return null;
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  };

  return {
    riskLevel,
    delayProbability: probability(prediction?.delay_probability),
    completionChance: probability(
      prediction?.completion_chance ?? prediction?.completion_probability
    ),
  };
}
