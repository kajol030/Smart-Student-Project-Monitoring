export function probabilityToPercent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 0;

  const percentage = numeric > 1 ? numeric : numeric * 100;
  return Math.round(Math.min(Math.max(percentage, 0), 100));
}
