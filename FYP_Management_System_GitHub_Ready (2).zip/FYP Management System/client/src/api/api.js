const API_URL = import.meta.env.VITE_API_URL || "/api";

export function getToken() {
  return localStorage.getItem("token");
}

async function request(endpoint, options = {}, { includeValidationDetails = false } = {}) {
  const headers = { ...options.headers };

  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const token = getToken();
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  let res;
  try {
    res = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    });
  } catch {
    throw new Error(
      "Cannot connect to server. Start the backend: cd server → npm run dev"
    );
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    if (res.status === 401 && [
      "Invalid or expired token.",
      "Token revoked. Please log in again.",
    ].includes(data.message)) {
      clearSession();
      window.location.href = "/login";
    }

    if (!data.message && !data.error && [502, 503, 504].includes(res.status)) {
      throw new Error(
        "Backend server is not running. Open a terminal and run: cd server → npm run dev"
      );
    }
    const validationMessage = includeValidationDetails && Array.isArray(data.errors)
      ? [...new Set(data.errors.flatMap((item) => Object.values(item)))]
          .filter((message) => typeof message === "string")
          .join(" ")
      : "";
    throw new Error(validationMessage || data.message || data.error || "Request failed");
  }

  return data;
}

export const api = {
  register: (body) => request("/auth/register", { method: "POST", body: JSON.stringify(body) }),
  login: (body) => request("/auth/login", { method: "POST", body: JSON.stringify(body) }),
  logout: () => request("/auth/logout", { method: "POST" }),
  forgotPassword: (email) => request("/auth/forgot-password", { method: "POST", body: JSON.stringify({ email }) }),
  resetPassword: (body) => request("/auth/reset-password", { method: "POST", body: JSON.stringify(body) }),
  getMe: () => request("/auth/me"),
  changePassword: (body) => request("/auth/change-password", { method: "POST", body: JSON.stringify(body) }),
  getProfile: () => request("/profiles/me"),
  updateProfile: (body) => request("/profiles/me", { method: "PUT", body: JSON.stringify(body) }),

  getUsers: () => request("/users"),
  getSupervisors: () => request("/users/supervisors"),
  getSupervisorRequests: () => request("/supervisor-requests"),
  respondToSupervisorRequest: (id, status, reason = "") =>
    request(`/supervisor-requests/${id}/respond`, { method: "PUT", body: JSON.stringify({ status, reason }) }),
  getStudents: () => request("/users/students"),
  getStudentPeers: () => request("/users/peers"),
  deleteUser: (id) => request(`/users/${id}`, { method: "DELETE" }),

  getProjects: async (params = "") => {
    const data = await request(`/projects${params ? `?${params}` : ""}`);
    return Array.isArray(data) ? data : (data.projects || []);
  },
  getProject: (id) => request(`/projects/${id}`),
  createProject: (body) => request(
    "/projects",
    { method: "POST", body: JSON.stringify(body) },
    { includeValidationDetails: true },
  ),
  assignSupervisor: (id, supervisor_id) =>
    request(`/projects/${id}/assign-supervisor`, {
      method: "PUT",
      body: JSON.stringify({ supervisor_id }),
    }),
  saveProjectOutcome: (projectId, body) =>
    request(`/project-outcomes/${projectId}`, {
      method: "PUT",
      body: JSON.stringify(body),
    }),
  verifyProjectOutcome: (projectId) =>
    request(`/project-outcomes/${projectId}/verify`, { method: "POST" }),
  getProjectOutcome: (projectId) => request(`/project-outcomes/${projectId}`),
  getProjectStats: (id) => request(`/projects/${id}/stats`),

  getMilestones: (projectId) => request(`/milestones/project/${projectId}`),
  updateMilestoneStatus: (id, status) =>
    request(`/milestones/${id}/status`, { method: "PUT", body: JSON.stringify({ status }) }),

  getSubmissions: async (projectId) => {
    const data = await request(`/submissions/project/${projectId}`);
    return Array.isArray(data) ? data : (data.submissions || []);
  },
  createSubmission: (formData) =>
    request("/submissions", { method: "POST", body: formData }),
  updateSubmissionStatus: (id, status) =>
    request(`/submissions/${id}/status`, { method: "PUT", body: JSON.stringify({ status }) }),

  getFeedback: (projectId) => request(`/feedback/project/${projectId}`),
  createFeedback: (body) =>
    request("/feedback", { method: "POST", body: JSON.stringify(body) }),

  getDeadlines: () => request("/deadlines"),
  createDeadline: (body) =>
    request("/deadlines", { method: "POST", body: JSON.stringify(body) }),

  getPrediction: (projectId) => request(`/predictions/project/${projectId}`),
  getSyntheticRiskHealth: () => request("/predictions/synthetic-demo/health"),
  getSyntheticRiskEvaluation: () => request("/predictions/synthetic-demo/evaluation"),
  predictSyntheticRisk: (features) => request("/predictions/synthetic-demo/predict", {
    method: "POST",
    body: JSON.stringify(features),
  }),
  getGithubData: (projectId) => request(`/github/project/${projectId}`),
  getProposalAlignment: (projectId) => request(`/alignment/project/${projectId}`),
  getPlagiarismChecks: (projectId) => request(`/plagiarism/project/${projectId}`),
  createPlagiarismCheck: (projectId, formData) =>
    request(`/plagiarism/project/${projectId}/check`, { method: "POST", body: formData }),
  updateGithubUrl: (projectId, github_url) =>
    request(`/projects/${projectId}/github-url`, { method: "PUT", body: JSON.stringify({ github_url }) }),
  getAnalytics: (params = "") => request(`/predictions/analytics${params ? `?${params}` : ""}`),
  getNotifications: () => request("/notifications"),
  markAllNotificationsRead: () => request("/notifications/read-all", { method: "PUT" }),
  markNotificationRead: (id) => request(`/notifications/${id}/read`, { method: "PUT" }),
  deleteNotification: (id) => request(`/notifications/${id}`, { method: "DELETE" }),
  getUnreadCount: () => request("/notifications/unread-count"),
  getDocumentVersions: (submissionId) => request(`/submissions/${submissionId}/versions`),
  uploadDocumentVersion: (submissionId, formData) => request(`/submissions/${submissionId}/new-version`, { method: "POST", body: formData }),
  getMeetings: () => request("/meetings/my"),
  createMeeting: (body) => request("/meetings", { method: "POST", body: JSON.stringify(body) }),
  updateMeeting: (id, body) => request(`/meetings/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  getEvaluations: (projectId) => request(`/evaluations/project/${projectId}`),
  createEvaluation: (body) => request("/evaluations", { method: "POST", body: JSON.stringify(body) }),
  getRubrics: () => request("/evaluations/rubrics"),
  getRubric: (id) => request(`/evaluations/rubrics/${id}`),
  createRubric: (body) => request("/evaluations/rubrics", { method: "POST", body: JSON.stringify(body) }),
  updateRubric: (id, body) => request(`/evaluations/rubrics/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  deactivateRubric: (id) => request(`/evaluations/rubrics/${id}`, { method: "DELETE" }),
  getProjectEvaluations: async () => { const projects = await api.getProjects(); return projects[0] ? api.getEvaluations(projects[0].id) : []; },
  getAnnouncements: (params = "") => request(`/announcements${params ? `?${params}` : ""}`),
  createAnnouncement: (body) => request("/announcements", { method: "POST", body: JSON.stringify(body) }),
  getAuditLogs: (params = "") => request(`/audit-logs${params ? `?${params}` : ""}`),
  getAcademicHierarchy: () => request("/academic/hierarchy"),
  getAcademic: (resource) => request(`/academic/${resource}`),
  createAcademic: (resource, body) => request(`/academic/${resource}`, { method: "POST", body: JSON.stringify(body) }),
  updateAcademic: (resource, id, body) => request(`/academic/${resource}/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  deactivateAcademic: (resource, id) => request(`/academic/${resource}/${id}`, { method: "DELETE" }),
  getGroups: () => request("/project-groups"),
  getGroup: (id) => request(`/project-groups/${id}`),
  createGroup: (body) => request("/project-groups", { method: "POST", body: JSON.stringify(body) }),
  updateGroup: (id, body) => request(`/project-groups/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  deleteGroup: (id) => request(`/project-groups/${id}`, { method: "DELETE" }),
  addGroupMember: (id, user_id) => request(`/project-groups/${id}/members`, { method: "POST", body: JSON.stringify({ user_id }) }),
  inviteGroupMember: (id, user_id) => request(`/project-groups/${id}/invite`, { method: "POST", body: JSON.stringify({ user_id }) }),
  getGroupInvitations: () => request("/project-groups/invitations/mine"),
  respondGroupInvitation: (invitationId, status) => request(`/project-groups/${invitationId}/invitation`, { method: "PUT", body: JSON.stringify({ status }) }),
  getTopicReviews: (id) => request(`/projects/${id}/topic-reviews`),
  reviewTopic: (id, body) => request(`/projects/${id}/topic-reviews`, { method: "POST", body: JSON.stringify(body) }),
  resubmitTopic: (id, body) => request(`/projects/${id}/resubmit-topic`, { method: "PUT", body: JSON.stringify(body) }),
  search: (query) => request(`/search?q=${encodeURIComponent(query)}`),
  getPreferences: () => request("/preferences"),
  updatePreference: (body) => request("/preferences", { method: "PUT", body: JSON.stringify(body) }),
  getProjectReport: () => request("/reports/projects"),
  getProjectReportCsvUrl: () => `${API_URL}/reports/projects.csv`,
  getSupervisorWorkloadReport: () => request("/reports/supervisor-workload"),
  getEvaluationReport: () => request("/reports/evaluations"),
  downloadProjectReportPdf: async () => { const response = await fetch(`${API_URL}/reports/projects.pdf`, { headers: { Authorization: `Bearer ${getToken()}` } }); if (!response.ok) throw new Error("Unable to download PDF report."); return response.blob(); },
  downloadProjectReportCsv: async () => {
    const response = await fetch(`${API_URL}/reports/projects.csv`, { headers: { Authorization: `Bearer ${getToken()}` } });
    if (!response.ok) throw new Error("Unable to download report.");
    return response.blob();
  },

  // ── Weekly Logs ──────────────────────────────────────────────────────────
  getWeeklyLogs: (projectId, params = "") =>
    request(`/weekly-logs/project/${projectId}${params ? `?${params}` : ""}`),
  submitWeeklyLog: (body) =>
    request("/weekly-logs", { method: "POST", body: JSON.stringify(body) }),
  reviewWeeklyLog: (id, body) =>
    request(`/weekly-logs/${id}/review`, { method: "PUT", body: JSON.stringify(body) }),
};

export function saveSession(user, token) {
  localStorage.setItem("token", token);
  localStorage.setItem("user", JSON.stringify(user));
  localStorage.setItem("username", user.name);
  localStorage.setItem("role", user.role);
  localStorage.setItem("isLoggedIn", "true");
}

export function clearSession() {
  for (const key of ["token", "user", "username", "role", "isLoggedIn"]) {
    localStorage.removeItem(key);
  }
}

export function getStoredUser() {
  const raw = localStorage.getItem("user");
  return raw ? JSON.parse(raw) : null;
}

export function getDashboardPath(role) {
  if (role === "admin") return "/admin";
  if (role === "supervisor") return "/supervisor";
  return "/student";
}
