import { Routes, Route, Navigate } from "react-router-dom";
import "./App.css";

import MainLayout from "./Layout/MainLayout";
import ProtectedRoute from "./components/ProtectedRoute";

import Login from "./pages/Login";
import Register from "./pages/Register";
import StudentDashboard from "./pages/StudentDashboard";
import SupervisorDashboard from "./pages/SupervisorDashboard";
import SupervisorReviews from "./pages/SupervisorReviews";
import SupervisorRequests from "./pages/SupervisorRequests";
import AdminDashboard from "./pages/AdminDashboard";
import AdminRequests from "./pages/AdminRequests";
import AdminUsers from "./pages/AdminUsers";
import AdminAssignments from "./pages/AdminAssignments";
import AdminDeadlines from "./pages/AdminDeadlines";
import AdminAnalytics from "./pages/AdminAnalytics";
import Projects from "./pages/Projects";
import Milestones from "./pages/Milestones";
import Documents from "./pages/Documents";
import FeedbackPage from "./pages/FeedbackPage";
import Notifications from "./pages/Notifications";
import ForgotPassword from "./pages/ForgotPassword";
import Meetings from "./pages/Meetings";
import Announcements from "./pages/Announcements";
import AuditLogs from "./pages/AuditLogs";
import Evaluations from "./pages/Evaluations";
import AiInsights from "./pages/AiInsights";
import Groups from "./pages/Groups";
import AcademicManagement from "./pages/AcademicManagement";
import SearchResults from "./pages/SearchResults";
import Preferences from "./pages/Preferences";
import Reports from "./pages/Reports";
import TopicReview from "./pages/TopicReview";
import WeeklyLogs from "./pages/WeeklyLogs";
import Plagiarism from "./pages/Plagiarism";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/student" replace />} />

        <Route
          path="student"
          element={
            <ProtectedRoute allowedRoles={["student"]}>
              <StudentDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="projects"
          element={
            <ProtectedRoute allowedRoles={["student"]}>
              <Projects />
            </ProtectedRoute>
          }
        />
        <Route
          path="milestones"
          element={
            <ProtectedRoute allowedRoles={["student", "supervisor", "admin"]}>
              <Milestones />
            </ProtectedRoute>
          }
        />
        <Route
          path="documents"
          element={
            <ProtectedRoute allowedRoles={["student"]}>
              <Documents />
            </ProtectedRoute>
          }
        />

        <Route
          path="supervisor"
          element={
            <ProtectedRoute allowedRoles={["supervisor"]}>
              <SupervisorDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="supervisor/students"
          element={
            <ProtectedRoute allowedRoles={["supervisor"]}>
              <SupervisorDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="supervisor/reviews"
          element={
            <ProtectedRoute allowedRoles={["supervisor"]}>
              <SupervisorReviews />
            </ProtectedRoute>
          }
        />
        <Route
          path="supervisor/requests"
          element={
            <ProtectedRoute allowedRoles={["supervisor"]}>
              <SupervisorRequests />
            </ProtectedRoute>
          }
        />

        <Route
          path="admin"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin/users"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminUsers />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin/requests"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminRequests />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin/assignments"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminAssignments />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin/deadlines"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminDeadlines />
            </ProtectedRoute>
          }
        />
        <Route
          path="admin/analytics"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminAnalytics />
            </ProtectedRoute>
          }
        />

        <Route
          path="feedback"
          element={
            <ProtectedRoute allowedRoles={["student", "supervisor"]}>
              <FeedbackPage />
            </ProtectedRoute>
          }
        />
        <Route path="notifications" element={<Notifications />} />
        <Route path="meetings" element={<Meetings />} />
        <Route path="announcements" element={<Announcements />} />
        <Route path="audit-logs" element={<ProtectedRoute allowedRoles={["admin"]}><AuditLogs /></ProtectedRoute>} />
        <Route path="evaluations" element={<Evaluations />} />
        <Route path="ai-insights" element={<AiInsights />} />
        <Route path="groups" element={<Groups />} />
        <Route path="search" element={<SearchResults />} />
        <Route path="settings" element={<Preferences />} />
        <Route path="preferences" element={<Preferences />} />
        <Route path="reports" element={<ProtectedRoute allowedRoles={["admin"]}><Reports /></ProtectedRoute>} />
        <Route path="topic-review" element={<ProtectedRoute allowedRoles={["supervisor", "admin"]}><TopicReview /></ProtectedRoute>} />
        <Route path="academic" element={<ProtectedRoute allowedRoles={["admin"]}><AcademicManagement /></ProtectedRoute>} />
        <Route
          path="weekly-logs"
          element={
            <ProtectedRoute allowedRoles={["student", "supervisor", "admin"]}>
              <WeeklyLogs />
            </ProtectedRoute>
          }
        />
        <Route
          path="plagiarism"
          element={
            <ProtectedRoute allowedRoles={["student", "supervisor", "admin"]}>
              <Plagiarism />
            </ProtectedRoute>
          }
        />
      </Route>
    </Routes>
  );
}
