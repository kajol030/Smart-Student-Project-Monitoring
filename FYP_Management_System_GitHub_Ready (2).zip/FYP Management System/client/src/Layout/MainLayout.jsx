import { useState, useEffect } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  Bell,
  BookOpen,
  CalendarDays,
  ChevronRight,
  ClipboardCheck,
  ClipboardList,
  FileText,
  FolderKanban,
  GraduationCap,
  ChevronDown,
  LayoutDashboard,
  LogOut,
  Menu,
  Search,
  Settings,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import { getStoredUser, clearSession, api } from "../api/api";

const NAV_BY_ROLE = {
  student: [
    { to: "/student",      label: "Dashboard",     icon: LayoutDashboard },
    { to: "/projects",     label: "My Projects",   icon: FolderKanban },
    { to: "/milestones",   label: "Milestones",    icon: CalendarDays },
    { to: "/weekly-logs",  label: "Weekly Logs",   icon: ClipboardList },
    { to: "/documents",    label: "Submissions",   icon: FileText },
    { to: "/plagiarism",   label: "Text Similarity", icon: ShieldCheck },
    { to: "/feedback",     label: "Feedback",      icon: ClipboardCheck },
    { to: "/meetings",     label: "Meetings",      icon: CalendarDays },
    { to: "/announcements",label: "Announcements", icon: Bell },
    { to: "/evaluations",  label: "Evaluations",   icon: ClipboardCheck },
    { to: "/ai-insights",  label: "AI Predictions",icon: BookOpen },
    { to: "/groups",       label: "Project Group", icon: Users },
    { to: "/notifications",label: "Notifications", icon: Bell },
  ],
  supervisor: [
    { to: "/supervisor",         label: "Dashboard",    icon: LayoutDashboard },
    { to: "/supervisor/students",label: "My Students",  icon: Users },
    { to: "/supervisor/reviews", label: "Reviews",      icon: ClipboardCheck },
    { to: "/milestones",         label: "Milestones",   icon: CalendarDays },
    { to: "/weekly-logs",        label: "Weekly Logs",  icon: ClipboardList },
    { to: "/feedback",           label: "Feedback",     icon: FileText },
    { to: "/meetings",           label: "Meetings",     icon: CalendarDays },
    { to: "/announcements",      label: "Announcements",icon: Bell },
    { to: "/evaluations",        label: "Evaluations",  icon: ClipboardCheck },
    { to: "/ai-insights",        label: "AI Insights",  icon: BookOpen },
    { to: "/plagiarism",         label: "Similarity Reviews", icon: ShieldCheck },
    { to: "/groups",             label: "Project Groups",icon: Users },
    { to: "/notifications",      label: "Notifications",icon: Bell },
  ],
  admin: [
    { to: "/admin",          label: "Dashboard",          icon: LayoutDashboard },
    { sectionId: "projects-overview", label: "Projects", icon: FolderKanban },
    { to: "/admin/users",    label: "Users",              icon: Users },
    { to: "/admin/assignments",label: "Assignments",      icon: ShieldCheck },
    { to: "/admin/deadlines",label: "FYP Schedule",       icon: CalendarDays },
    { to: "/admin/analytics",label: "AI Analytics",       icon: BookOpen },
    { to: "/academic",       label: "Academic Management",icon: BookOpen },
    { to: "/groups",         label: "Project Groups",     icon: Users },
    { to: "/evaluations",    label: "Rubrics & Results",  icon: ClipboardCheck },
    { to: "/plagiarism",     label: "Similarity Reviews", icon: ShieldCheck },
    { to: "/audit-logs",     label: "Audit Logs",         icon: ShieldCheck },
    { to: "/announcements",  label: "Announcements",      icon: Bell },
    { to: "/notifications",  label: "Notifications",      icon: Bell },
  ],
};

export default function MainLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const reduceMotion = useReducedMotion();
  const [user, setUser] = useState(getStoredUser);
  const role = user?.role || "student";
  const navItems = NAV_BY_ROLE[role] || NAV_BY_ROLE.student;
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [unreadCount, setUnreadCount] = useState(0);
  const [profileOpen, setProfileOpen] = useState(false);
  const currentPage = location.pathname === "/settings" || location.pathname === "/preferences"
    ? "Settings"
    : navItems.find((item) => location.pathname === item.to)?.label || "Workspace";

  useEffect(() => {
    const handleProfileUpdate = (event) => setUser(event.detail);
    window.addEventListener("projectflow:profile-updated", handleProfileUpdate);
    return () => window.removeEventListener("projectflow:profile-updated", handleProfileUpdate);
  }, []);

  /* ── Fetch unread count on mount, refresh every 60 s ── */
  useEffect(() => {
    let cancelled = false;
    const fetchCount = async () => {
      try {
        const data = await api.getUnreadCount();
        if (!cancelled) setUnreadCount(data.count || 0);
      } catch { /* silently ignore — user may not be logged in yet */ }
    };
    fetchCount();
    const interval = setInterval(fetchCount, 60_000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  const handleLogout = async () => {
    let logoutWarning = "";
    try {
      await api.logout();
    } catch {
      logoutWarning = "Your browser session was cleared, but the server could not confirm sign-out.";
    } finally {
      clearSession();
      navigate("/login", logoutWarning ? { state: { logoutWarning } } : undefined);
    }
  };

  return (
    <div className="app-shell min-h-screen student-theme">
      <div className={`sidebar-backdrop ${sidebarOpen ? "is-visible" : ""}`} onClick={() => setSidebarOpen(false)} />
      <aside className={`app-sidebar ${sidebarOpen ? "is-open" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-mark"><GraduationCap size={21} /></div>
          <div><p className="brand-name">Smart Student</p><p className="brand-caption">Project Monitoring Platform<br />Using Predictive Analytics</p></div>
          <button className="icon-button mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="workspace-switcher">
          <div className="workspace-icon"><ShieldCheck size={16} /></div>
          <div><span>Current workspace</span><strong>FYP 2025 / 26</strong></div>
          <ChevronRight size={15} className="muted-icon" />
        </div>
        <p className="nav-label">Workspace</p>
        <nav className="sidebar-nav" aria-label="Primary navigation">
          {navItems.map((item) => <SideItem
            key={`${item.to || item.sectionId}-${item.label}`}
            {...item}
            onNavigate={() => {
              setSidebarOpen(false);
              setProfileOpen(false);
            }}
            onSectionNavigate={(sectionId) => {
              setSidebarOpen(false);
              setProfileOpen(false);
              if (location.pathname === "/admin") {
                document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
              } else {
                navigate(`/admin#${sectionId}`);
              }
            }}
          />)}
        </nav>
        <div className="sidebar-bottom">
          <button className="sidebar-utility" onClick={() => navigate("/settings")}><Settings size={17} /> Settings</button>
          <div className="profile-row">
            <div className="avatar">{(user?.name || "U").charAt(0).toUpperCase()}</div>
            <div className="profile-copy"><strong>{user?.name || "User"}</strong><span>{role}</span></div>
            <button className="logout-button" onClick={handleLogout} aria-label="Log out" title="Log out"><LogOut size={17} /></button>
          </div>
        </div>
      </aside>
      <main
        className="app-main"
        onClick={(event) => {
          if (!event.target.closest(".profile-menu-wrap")) setProfileOpen(false);
        }}
      >
        <header className="topbar">
          <div className="topbar-leading">
            <button className="icon-button mobile-menu" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu size={21} /></button>
            <div className="breadcrumbs"><span>Smart Student</span><ChevronRight size={14} /><strong>{currentPage}</strong></div>
          </div>
          <div className="topbar-actions">
            <form
              className="global-search"
              onSubmit={(event) => {
                event.preventDefault();
                if (search.trim()) {
                  navigate(`/search?q=${encodeURIComponent(search.trim())}`);
                }
              }}
            >
              <Search size={17} />
              <input
                id="searchWorkspace"
                name="searchWorkspace"
                aria-label="Search workspace"
                placeholder="Search workspace"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </form>

            <button
              className="icon-button notification-button"
              aria-label={`Notifications${unreadCount > 0 ? ` — ${unreadCount} unread` : ""}`}
              title="Notifications"
              onClick={() => navigate("/notifications")}
            >
              <Bell size={18} />
              {unreadCount > 0 && (
                <span className="notif-topbar-badge">
                  {unreadCount > 99 ? "99+" : unreadCount}
                </span>
              )}
            </button>
            {role === "admin" ? (
              <div className="profile-menu-wrap">
                <button
                  type="button"
                  className="profile-menu-trigger"
                  aria-expanded={profileOpen}
                  aria-haspopup="menu"
                  onClick={() => setProfileOpen((open) => !open)}
                >
                  <span className="topbar-avatar">{(user?.name || "U").charAt(0).toUpperCase()}</span>
                  <span className="profile-menu-label">{user?.name || "Admin"}</span>
                  <ChevronDown size={15} />
                </button>
                {profileOpen && (
                  <div className="profile-menu" role="menu">
                    <div className="profile-menu-summary">
                      <strong>{user?.name || "Admin"}</strong>
                      <span>{user?.email || "Administrator"}</span>
                    </div>
                    <button type="button" role="menuitem" onClick={() => { setProfileOpen(false); navigate("/settings"); }}>
                      <Settings size={15} /> Settings
                    </button>
                    <button type="button" role="menuitem" onClick={() => { setProfileOpen(false); handleLogout(); }}>
                      <LogOut size={15} /> Sign out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="topbar-avatar">{(user?.name || "U").charAt(0).toUpperCase()}</div>
            )}
          </div>
        </header>

        <div className="page-content">
          <motion.div
            key={location.pathname}
            initial={reduceMotion ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            <Outlet />
          </motion.div>
        </div>
      </main>
    </div>
  );
}

function SideItem({ to, sectionId, label, icon: Icon, onNavigate, onSectionNavigate }) {
  if (sectionId) {
    return (
      <button
        type="button"
        className="side-item side-item-button"
        onClick={() => onSectionNavigate(sectionId)}
      >
        <Icon size={18} /><span>{label}</span>
      </button>
    );
  }
  return <NavLink to={to} end onClick={onNavigate} className={({ isActive }) => `side-item ${isActive ? "active" : ""}`}>
    <Icon size={18} /><span>{label}</span>{label === "AI Analytics" && <span className="nav-chip">AI</span>}
  </NavLink>;
}
