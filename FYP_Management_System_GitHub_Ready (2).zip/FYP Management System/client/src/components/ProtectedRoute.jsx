import { Navigate } from "react-router-dom";
import { getStoredUser, getToken, getDashboardPath } from "../api/api";

export default function ProtectedRoute({ children, allowedRoles }) {
  const user = getStoredUser();
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true" && Boolean(getToken());

  if (!isLoggedIn || !user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to={getDashboardPath(user.role)} replace />;
  }

  return children;
}
