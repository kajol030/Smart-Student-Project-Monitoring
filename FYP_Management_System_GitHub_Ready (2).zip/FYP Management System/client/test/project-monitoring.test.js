import assert from "node:assert/strict";
import test from "node:test";
import {
  buildProjectMonitoringView,
  getPredictionDisplay,
} from "../src/utils/projectMonitoring.js";
import { getGreeting } from "../src/utils/greeting.js";

test("supervisor view maps GitHub, alignment, and prediction API responses", () => {
  const view = buildProjectMonitoringView({
    github: {
      data: {
        repository: { full_name: "student/fyp" },
        commits: { total_fetched: 18 },
        branches: { total_fetched: 3 },
        pull_requests: { open_count: 2, merged_count: 4 },
        issues: { open_count: 1, recent_closed_count: 5 },
      },
    },
    alignment: {
      alignment_score: 55,
      alignment_source: "approved_proposal_notes",
      requirements: [
        { id: 1, objective: "Predict delays", status: "possible_match" },
        { id: 2, objective: "Track milestones", status: "strong_textual_match" },
      ],
      implementation_progress: {
        milestone_progress: 50,
        evidence_estimate: 62,
      },
      github_tree_error: null,
    },
    prediction: { risk_level: "medium", model_used: "ml_service" },
  });

  assert.equal(view.milestoneProgress, 50);
  assert.equal(view.evidenceEstimate, 62);
  assert.equal(view.alignmentScore, 55);
  assert.equal(view.alignmentSource, "approved_proposal_notes");
  assert.equal(view.riskLevel, "medium");
  assert.equal(view.riskModel, "ml_service");
  assert.deepEqual(view.github, {
    repositoryName: "student/fyp",
    commits: 18,
    branches: 3,
    openPullRequests: 2,
    mergedPullRequests: 4,
    openIssues: 1,
    closedIssues: 5,
  });
  assert.match(view.recommendations[0], /Predict delays/);
  assert.match(view.recommendations[1], /open repository issues/);
});

test("supervisor view does not invent unavailable progress or risk", () => {
  const view = buildProjectMonitoringView({
    github: null,
    alignment: { implementation_progress: { milestone_progress: null, evidence_estimate: null } },
    prediction: null,
  });
  assert.equal(view.milestoneProgress, null);
  assert.equal(view.evidenceEstimate, null);
  assert.equal(view.alignmentScore, null);
  assert.equal(view.riskLevel, "Unavailable");
  assert.equal(view.github, null);
});

test("prediction display never treats missing or invalid risk data as low risk", () => {
  assert.deepEqual(getPredictionDisplay(null), {
    riskLevel: null,
    delayProbability: null,
    completionChance: null,
  });
  assert.equal(getPredictionDisplay({ risk_level: "unknown" }).riskLevel, null);
  assert.deepEqual(getPredictionDisplay({
    risk_level: "HIGH",
    delay_probability: 0.72,
    completion_chance: 0.28,
  }), {
    riskLevel: "high",
    delayProbability: 0.72,
    completionChance: 0.28,
  });
});

test("dashboard greeting follows local-time boundaries", () => {
  for (const [hour, expected] of [
    [0, "Good Night"],
    [4, "Good Night"],
    [5, "Good Morning"],
    [11, "Good Morning"],
    [12, "Good Afternoon"],
    [16, "Good Afternoon"],
    [17, "Good Evening"],
    [20, "Good Evening"],
    [21, "Good Night"],
    [23, "Good Night"],
  ]) {
    assert.equal(getGreeting(new Date(2026, 0, 1, hour)), expected);
  }
});
