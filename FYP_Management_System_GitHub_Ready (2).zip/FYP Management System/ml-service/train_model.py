"""Train a Random Forest only from verified outcomes in the SQLite database."""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)
from sklearn.model_selection import train_test_split

from dataset import FEATURES, OUTCOME_LABELS, prepare_dataset

MODEL_PATH = Path(
    os.environ.get(
        "ML_MODEL_PATH",
        Path(__file__).resolve().parent / "models" / "project_outcome_rf.joblib",
    )
).expanduser().resolve()
TEST_SIZE = 0.25
RANDOM_STATE = 42


def train_model(records, report):
    if report["training_status"] != "ready":
        raise ValueError(report["message"])

    labels = [record["label"] for record in records]
    label_counts = {status: labels.count(status) for status in OUTCOME_LABELS}
    if (
        len(records) < report["minimum_rows"]
        or any(count < report["minimum_per_class"] for count in label_counts.values())
    ):
        raise ValueError("Verified outcome dataset no longer meets the training minimum.")

    features = np.asarray(
        [[record["features"][name] for name in FEATURES] for record in records],
        dtype=float,
    )
    targets = np.asarray(labels, dtype=str)
    train_features, test_features, train_targets, test_targets = train_test_split(
        features,
        targets,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=targets,
    )

    model = RandomForestClassifier(
        n_estimators=300,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(train_features, train_targets)
    predicted = model.predict(test_features)
    labels_order = list(OUTCOME_LABELS)
    metrics = {
        "accuracy": float(accuracy_score(test_targets, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(test_targets, predicted)),
        "macro_f1": float(f1_score(test_targets, predicted, average="macro", zero_division=0)),
        "confusion_matrix_labels": labels_order,
        "confusion_matrix": confusion_matrix(
            test_targets, predicted, labels=labels_order
        ).tolist(),
        "per_class": classification_report(
            test_targets,
            predicted,
            labels=labels_order,
            target_names=[OUTCOME_LABELS[label] for label in labels_order],
            output_dict=True,
            zero_division=0,
        ),
    }
    metadata = {
        "model_name": "Random Forest Classifier",
        "model_type": "random_forest",
        "training_status": "trained",
        "features": FEATURES,
        "outcome_labels": OUTCOME_LABELS,
        "evaluation_metrics": metrics,
        "training_rows": len(train_targets),
        "test_rows": len(test_targets),
        "verified_project_count": len(records),
        "class_counts": label_counts,
        "test_size": TEST_SIZE,
        "random_state": RANDOM_STATE,
        "data_fingerprint": report["fingerprint"],
        "trained_at": datetime.now(timezone.utc).isoformat(),
    }
    return {"model": model, "metadata": metadata}


def main():
    records, report = prepare_dataset()
    print(json.dumps(report, indent=2))
    if report["training_status"] != "ready":
        print("No model trained: verified historical outcomes are insufficient.")
        return 2

    trained = train_model(records, report)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            dir=MODEL_PATH.parent, suffix=".tmp", delete=False
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)
        joblib.dump(trained, temporary_path)
        validated = joblib.load(temporary_path)
        if (
            validated["metadata"]["data_fingerprint"] != report["fingerprint"]
            or list(validated["metadata"]["features"]) != FEATURES
        ):
            raise RuntimeError("Saved model metadata failed validation.")
        os.replace(temporary_path, MODEL_PATH)
    finally:
        if temporary_path and temporary_path.exists():
            temporary_path.unlink()

    print(f"Trained model saved to {MODEL_PATH}")
    print(json.dumps(trained["metadata"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
