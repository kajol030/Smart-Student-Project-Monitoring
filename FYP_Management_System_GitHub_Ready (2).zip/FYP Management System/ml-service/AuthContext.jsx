import React, { createContext, useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { mockLogin } from '../services/api'; // We will use a mock API for now

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const login = async (email, password, role) => {
    try {
      // In a real app, you'd get the user and token from the API
      const loggedInUser = await mockLogin(email, password, role);
      if (loggedInUser) {
        setUser(loggedInUser);
        // In a real app, you'd store the token: localStorage.setItem('token', loggedInUser.token);
        navigate(`/${loggedInUser.role}/dashboard`);
      } else {
        throw new Error("Invalid credentials or role");
      }
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
    // In a real app, you'd remove the token: localStorage.removeItem('token');
    navigate('/login');
  };

  const value = { user, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  return useContext(AuthContext);
};