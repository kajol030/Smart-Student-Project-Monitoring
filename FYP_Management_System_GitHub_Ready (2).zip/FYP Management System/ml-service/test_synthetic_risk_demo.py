import json
import tempfile
import unittest
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split

import synthetic_risk_demo as demo


class SyntheticRiskDemoTests(unittest.TestCase):
    def test_dataset_is_reproducible_and_has_documented_schema(self):
        first = demo.generate_dataset()
        second = demo.generate_dataset()
        self.assertEqual(len(first), 1500)
        self.assertEqual(list(first.columns), demo.FEATURES + ["risk_class"])
        self.assertTrue(first.equals(second))
        self.assertEqual(set(first["risk_class"].unique()), set(demo.RISK_CLASSES))

    def test_training_evaluation_and_artifacts_are_real_and_separate(self):
        frame = demo.generate_dataset()
        with tempfile.TemporaryDirectory(prefix="fyp-synthetic-demo-tests-") as directory:
            model, scaler, evaluation = demo.train_and_evaluate(frame, directory)
            saved_dataset = Path(directory) / "synthetic_risk_17_dataset.csv"
            model_path = Path(directory) / "synthetic_risk_17_logistic_regression.joblib"
            scaler_path = Path(directory) / "synthetic_risk_17_scaler.joblib"
            evaluation_path = Path(directory) / "synthetic_risk_17_evaluation.json"
            self.assertTrue(all(path.is_file() for path in (
                saved_dataset, model_path, scaler_path, evaluation_path
            )))
            self.assertEqual(len(frame), len(pd.read_csv(saved_dataset)))
            self.assertIsNot(model, scaler)
            self.assertEqual(evaluation["record_count"], 1500)
            self.assertEqual(evaluation["model_name"], "Logistic Regression")
            self.assertEqual(evaluation["historical_claims"]["reproduced"], False)
            self.assertIn("Not Real-world Validation", evaluation["disclaimer"])

            features = frame[demo.FEATURES].to_numpy(dtype=float)
            targets = frame["risk_class"].to_numpy(dtype=str)
            train_features, test_features, _, test_targets = train_test_split(
                features,
                targets,
                test_size=demo.TEST_SIZE,
                random_state=demo.RANDOM_STATE,
                stratify=targets,
            )
            predicted = model.predict(scaler.transform(test_features))
            self.assertAlmostEqual(
                evaluation["metrics"]["accuracy"],
                accuracy_score(test_targets, predicted),
            )
            self.assertAlmostEqual(
                evaluation["metrics"]["macro_f1"],
                f1_score(
                    test_targets,
                    predicted,
                    labels=demo.RISK_CLASSES,
                    average="macro",
                    zero_division=0,
                ),
            )
            self.assertEqual(len(train_features), 1200)
            self.assertEqual(len(test_targets), 300)
            self.assertEqual(
                json.loads(evaluation_path.read_text(encoding="utf-8"))["metrics"],
                evaluation["metrics"],
            )

    def test_training_rejects_non_demo_rows(self):
        frame = demo.generate_dataset().iloc[:-1]
        with self.assertRaisesRegex(ValueError, "exactly 1500"):
            demo.train_and_evaluate(frame, tempfile.gettempdir())


if __name__ == "__main__":
    unittest.main()
