import logging
import os
from pathlib import Path

import joblib
import numpy as np
from flask import Flask, jsonify, request
from flask_cors import CORS

from dataset import FEATURES, OUTCOME_LABELS, prepare_dataset
from synthetic_risk_demo import (
    FEATURES as SYNTHETIC_RISK_FEATURES,
    load_demo_artifacts,
)

app = Flask(__name__)
CORS(app)
logger = logging.getLogger(__name__)

MODEL_PATH = Path(
    os.environ.get(
        "ML_MODEL_PATH",
        Path(__file__).resolve().parent / "models" / "project_outcome_rf.joblib",
    )
).expanduser().resolve()


def _model_status():
    _, report = prepare_dataset()
    model_info = {
        "model_name": None,
        "model_type": None,
        "training_status": report["training_status"],
        "evaluation_metrics": None,
        "message": report["message"],
        "dataset": report,
    }
    if report["training_status"] != "ready":
        return None, model_info
    if not MODEL_PATH.is_file():
        model_info["training_status"] = "training_required"
        model_info["message"] = (
            "There is enough verified data to train, but no model artifact exists. "
            "Run python train_model.py from the ml-service directory."
        )
        return None, model_info
    try:
        artifact = joblib.load(MODEL_PATH)
    except (OSError, ValueError, EOFError) as error:
        logger.exception("Could not load Random Forest model artifact.")
        model_info["training_status"] = "model_load_error"
        model_info["message"] = f"The trained model could not be loaded: {error}"
        return None, model_info

    metadata = artifact.get("metadata", {})
    if metadata.get("data_fingerprint") != report["fingerprint"]:
        model_info["training_status"] = "retraining_required"
        model_info["message"] = (
            "Verified project outcomes or eligible feature snapshots changed since "
            "training. Retrain the model before requesting predictions."
        )
        return None, model_info
    if metadata.get("features") != FEATURES or not artifact.get("model"):
        model_info["training_status"] = "model_load_error"
        model_info["message"] = "The model artifact does not match the current feature schema."
        return None, model_info

    return artifact["model"], metadata


def _unavailable_response(model_info):
    return jsonify({
        "error": model_info["message"],
        "model_info": model_info,
    }), 503


def _synthetic_risk_model_status():
    try:
        model, scaler, evaluation = load_demo_artifacts()
    except FileNotFoundError as error:
        return {
            "model_loaded": False,
            "model_name": None,
            "model_type": "logistic_regression",
            "training_status": "artifact_missing",
            "feature_count": len(SYNTHETIC_RISK_FEATURES),
            "class_labels": ["Low", "Medium", "High"],
            "evaluation_metrics": None,
            "message": str(error),
        }
    except (OSError, ValueError, EOFError, KeyError, TypeError) as error:
        logger.exception("Could not load active synthetic Logistic Regression artifacts.")
        return {
            "model_loaded": False,
            "model_name": None,
            "model_type": "logistic_regression",
            "training_status": "model_load_error",
            "feature_count": len(SYNTHETIC_RISK_FEATURES),
            "class_labels": ["Low", "Medium", "High"],
            "evaluation_metrics": None,
            "message": f"Synthetic Logistic Regression artifacts could not be loaded: {error}",
        }

    return {
        "model_loaded": True,
        "model_name": evaluation["model_name"],
        "model_type": "logistic_regression",
        "training_status": "trained",
        "feature_count": len(SYNTHETIC_RISK_FEATURES),
        "feature_names": SYNTHETIC_RISK_FEATURES,
        "class_labels": evaluation["metrics"]["class_labels"],
        "evaluation_metrics": evaluation["metrics"],
        "dataset_type": evaluation["dataset_type"],
        "record_count": evaluation["record_count"],
        "disclaimer": evaluation["disclaimer"],
        "message": "Synthetic risk model and scaler loaded successfully.",
    }


@app.get("/health")
def health():
    synthetic_model_info = _synthetic_risk_model_status()
    verified_model, verified_model_info = _model_status()
    return jsonify({
        "status": "ok",
        "model_loaded": synthetic_model_info["model_loaded"],
        "model_info": synthetic_model_info,
        "active_risk_model": synthetic_model_info,
        "verified_outcome_model": {
            "model_loaded": verified_model is not None,
            "model_info": verified_model_info,
        },
    })


@app.post("/predict")
def predict():
    model, model_info = _model_status()
    if model is None:
        return _unavailable_response(model_info)

    data = request.get_json(silent=True) or {}
    missing = [name for name in FEATURES if name not in data]
    if missing:
        return jsonify({"error": f"Missing field(s): {', '.join(missing)}"}), 400
    try:
        features = np.asarray([[float(data[name]) for name in FEATURES]], dtype=float)
        if not np.isfinite(features).all():
            raise ValueError("Feature values must be finite numbers.")
    except (TypeError, ValueError):
        return jsonify({"error": "All project features must be finite numbers."}), 400

    predicted_label = str(model.predict(features)[0])
    class_probabilities = {
        str(label): float(probability)
        for label, probability in zip(model.classes_, model.predict_proba(features)[0])
    }
    probabilities = {
        status: class_probabilities.get(status, 0.0)
        for status in OUTCOME_LABELS
    }
    risk_level = {
        "completed_on_time": "low",
        "delayed": "medium",
        "failed": "high",
    }[predicted_label]
    return jsonify({
        "predicted_outcome": predicted_label,
        "risk_level": risk_level,
        "risk_score": probabilities["delayed"] + probabilities["failed"],
        "delay_probability": probabilities["delayed"],
        "failure_probability": probabilities["failed"],
        "completion_chance": probabilities["completed_on_time"] + probabilities["delayed"],
        "outcome_probabilities": probabilities,
        "model_used": model_info["model_name"],
        "model_info": model_info,
    })


@app.post("/explain")
def explain():
    model, model_info = _model_status()
    if model is None:
        return _unavailable_response(model_info)
    data = request.get_json(silent=True) or {}
    missing = [name for name in FEATURES if name not in data]
    if missing:
        return jsonify({"error": f"Missing field(s): {', '.join(missing)}"}), 400
    try:
        features = np.asarray([[float(data[name]) for name in FEATURES]], dtype=float)
        if not np.isfinite(features).all():
            raise ValueError("Feature values must be finite numbers.")
    except (TypeError, ValueError):
        return jsonify({"error": "All project features must be finite numbers."}), 400

    importance = getattr(model, "feature_importances_", None)
    if importance is None:
        return jsonify({"error": "The trained model does not expose feature importance."}), 422
    contributions = [
        {
            "feature": name,
            "importance": float(importance[index]),
            "value": float(features[0, index]),
        }
        for index, name in enumerate(FEATURES)
    ]
    return jsonify({
        "contributions": sorted(
            contributions, key=lambda item: item["importance"], reverse=True
        ),
        "method": "random_forest_feature_importance",
        "model_info": model_info,
    })


@app.get("/demo/synthetic-risk/evaluation")
def synthetic_risk_evaluation():
    try:
        _, _, evaluation = load_demo_artifacts()
    except FileNotFoundError as error:
        return jsonify({"error": str(error)}), 503
    except (OSError, ValueError, EOFError, KeyError) as error:
        logger.exception("Could not load synthetic risk demonstration artifacts.")
        return jsonify({"error": f"Synthetic demo artifacts could not be loaded: {error}"}), 503
    return jsonify(evaluation)


@app.post("/demo/synthetic-risk/predict")
def synthetic_risk_predict():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "A JSON object of synthetic demo features is required."}), 400
    missing = [name for name in SYNTHETIC_RISK_FEATURES if name not in data]
    if missing:
        return jsonify({"error": f"Missing field(s): {', '.join(missing)}"}), 400
    extra = sorted(set(data) - set(SYNTHETIC_RISK_FEATURES))
    if extra:
        return jsonify({"error": f"Unexpected field(s): {', '.join(extra)}"}), 400
    try:
        values = np.asarray([[float(data[name]) for name in SYNTHETIC_RISK_FEATURES]], dtype=float)
        if not np.isfinite(values).all():
            raise ValueError("Feature values must be finite numbers.")
        limits = {
            "progress": (0, 100),
            "completed_milestones": (0, 100),
            "overdue_milestones": (0, 100),
            "pending_submissions": (0, 100),
            "rejected_submissions": (0, 100),
            "feedback_count": (0, 100),
            "days_since_activity": (0, 3650),
            "total_commits": (0, 100000),
            "recent_commits": (0, 100000),
            "commit_frequency": (0, 100000),
            "active_days": (0, 3650),
            "recent_activity_days": (0, 3650),
            "pull_requests": (0, 10000),
            "merged_prs": (0, 10000),
            "open_issues": (0, 10000),
            "closed_issues": (0, 10000),
            "github_evidence_available": (0, 1),
        }
        for index, name in enumerate(SYNTHETIC_RISK_FEATURES):
            low, high = limits[name]
            if not low <= values[0, index] <= high:
                raise ValueError(f"{name} must be between {low} and {high}.")
    except (TypeError, ValueError) as error:
        return jsonify({"error": str(error)}), 400

    try:
        model, scaler, evaluation = load_demo_artifacts()
    except FileNotFoundError as error:
        return jsonify({"error": str(error)}), 503
    except (OSError, ValueError, EOFError, KeyError) as error:
        logger.exception("Could not load synthetic risk demonstration artifacts.")
        return jsonify({"error": f"Synthetic demo artifacts could not be loaded: {error}"}), 503

    scaled = scaler.transform(values)
    predicted = str(model.predict(scaled)[0])
    probabilities = {
        str(label): float(probability)
        for label, probability in zip(model.classes_, model.predict_proba(scaled)[0])
    }
    risk_level = predicted.lower()
    return jsonify({
        "risk_class": predicted,
        "risk_level": risk_level,
        "predicted_outcome": risk_level,
        "risk_score": probabilities.get("Medium", 0.0) + probabilities.get("High", 0.0),
        "risk_probabilities": {
            label: probabilities.get(label, 0.0)
            for label in evaluation["metrics"]["class_labels"]
        },
        "model_name": evaluation["model_name"],
        "model_used": evaluation["model_name"],
        "evaluation_metrics": evaluation["metrics"],
        "dataset": {
            "record_count": evaluation["record_count"],
            "class_distribution": evaluation["class_distribution"],
        },
        "historical_claims": evaluation["historical_claims"],
        "model_info": {
            "model_name": evaluation["model_name"],
            "model_type": "logistic_regression",
            "training_status": "trained",
            "evaluation_metrics": evaluation["metrics"],
            "dataset_type": "synthetic",
            "dataset": {
                "record_count": evaluation["record_count"],
                "class_distribution": evaluation["class_distribution"],
            },
            "historical_claims": evaluation["historical_claims"],
            "message": evaluation["disclaimer"],
        },
        "disclaimer": "Synthetic Dataset Evaluation — Not Real-world Validation",
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
