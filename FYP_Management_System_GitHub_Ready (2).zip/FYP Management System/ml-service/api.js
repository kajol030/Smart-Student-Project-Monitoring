import axios from 'axios';

// In a real app, this would be in a .env file
const API_BASE_URL = 'http://localhost:5000/api'; // Your backend server
const ML_API_BASE_URL = 'http://127.0.0.1:5001';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    // 'Authorization': `Bearer ${localStorage.getItem('token')}` // Example for auth
  },
});

const mlApiClient = axios.create({
  baseURL: ML_API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});


/**
 * MOCK DATA AND FUNCTIONS
 * Replace these with actual API calls to your backend
 */

const mockUsers = {
  'student@test.com': { id: 1, name: 'Ali Khan', email: 'student@test.com', role: 'student', program: 'BSCS' },
  'supervisor@test.com': { id: 101, name: 'Dr. Ahmed', email: 'supervisor@test.com', role: 'supervisor' },
  'admin@test.com': { id: 201, name: 'Admin User', email: 'admin@test.com', role: 'admin' },
};

const mockProject = {
  id: 1,
  title: 'AI-Based Healthcare Assistant',
  description: 'A project to assist healthcare professionals.',
  program: 'BSCS',
  student_id: 1,
  supervisor_id: null,
  supervisor: null,
  supervisor_request_status: 'pending', // 'pending', 'accepted', 'rejected'
  status: 'Supervisor Requested',
  progress: 42,
};

const mockSupervisors = [
    { id: 101, name: 'Dr. Ahmed', specialization: 'AI', program: 'BSAI', status: 'Available', students: 8 },
    { id: 102, name: 'Dr. Sara', specialization: 'Web Development', program: 'BSCS', status: 'Available', students: 5 },
    { id: 103, name: 'Dr. Ali', specialization: 'Machine Learning', program: 'BSAI', status: 'Full', students: 12 },
    { id: 104, name: 'Dr. Fatima', specialization: 'Cyber Security', program: 'BSCS', status: 'Available', students: 7 },
];


// Mock Login
export const mockLogin = (email, password, role) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = mockUsers[email];
      if (user && user.role === role) {
        resolve(user);
      } else {
        reject('Invalid credentials');
      }
    }, 500);
  });
};

// Mock get student project
export const getStudentProject = (studentId) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            // If supervisor request is accepted, attach supervisor info
            if (mockProject.supervisor_request_status === 'accepted') {
                mockProject.supervisor_id = 101;
                mockProject.supervisor = mockSupervisors.find(s => s.id === 101);
            }
            resolve(mockProject);
        }, 500);
    });
};

// Mock get available supervisors
export const getAvailableSupervisors = () => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(mockSupervisors.filter(s => s.status === 'Available'));
        }, 500);
    });
};

// Mock send supervisor request
export const sendSupervisorRequest = (studentId, supervisorId) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            mockProject.supervisor_request_status = 'pending';
            console.log(`Request sent from student ${studentId} to supervisor ${supervisorId}`);
            resolve({ success: true, message: 'Request sent successfully!' });
        }, 500);
    });
};

/**
 * REAL AI/ML SERVICE API CALL
 */
export const getAiPrediction = async (params) => {
  try {
    const response = await mlApiClient.post('/predict', params);
    return response.data;
  } catch (error) {
    console.error('AI Prediction API failed:', error);
    // Return a default/error state so the UI doesn't break
    return { risk_level: 'unavailable', delay_probability: 'N/A', completion_chance: 'N/A', model_used: 'error' };
  }
};