import React, { useState, useEffect } from 'react';
import { Grid, Paper, Typography, Box, LinearProgress, Chip } from '@mui/material';
import { getStudentProject, getAiPrediction } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import AiPredictionCard from '../../components/AiPredictionCard';

const getRiskColor = (risk) => {
  if (risk === 'high') return 'error';
  if (risk === 'medium') return 'warning';
  return 'success';
};

const Overview = () => {
  const { user } = useAuth();
  const [project, setProject] = useState(null);
  const [aiData, setAiData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const projectData = await getStudentProject(user.id);
        setProject(projectData);

        if (projectData) {
          // These values would come from the project data in a real app
          const mockAiParams = {
            progress: projectData.progress,
            completed_milestones: 5,
            overdue_milestones: 1,
            pending_submissions: 2,
            rejected_submissions: 1,
            feedback_count: 3,
            days_since_activity: 4,
          };
          const prediction = await getAiPrediction(mockAiParams);
          setAiData(prediction);
        }
      } catch (error) {
        console.error("Failed to fetch student data", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user.id]);

  if (loading) return <Typography>Loading...</Typography>;

  if (!project) {
    return (
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">No Project Found</Typography>
        <Typography>You have not created or been assigned to a project yet.</Typography>
      </Paper>
    );
  }

  return (
    <Grid container spacing={3}>
      {/* Project Info */}
      <Grid item xs={12} md={8} lg={9}>
        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Typography component="h2" variant="h6" color="primary" gutterBottom>
            My Final Year Project
          </Typography>
          <Typography component="p" variant="h4">
            {project.title}
          </Typography>
          <Typography color="text.secondary" sx={{ flex: 1, mt: 1 }}>
            Supervisor: {project.supervisor?.name || 'Not Assigned'}
          </Typography>
          <Box sx={{ mt: 3 }}>
            <Typography variant="body2">Overall Progress: {project.progress}%</Typography>
            <LinearProgress variant="determinate" value={project.progress} sx={{ height: 10, borderRadius: 5 }} />
          </Box>
        </Paper>
      </Grid>

      {/* AI Prediction Card */}
      <Grid item xs={12} md={4} lg={3}>
        <AiPredictionCard aiData={aiData} />
      </Grid>

      {/* Quick Stats */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>Quick Stats</Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Chip label={`Program: ${user.program}`} color="primary" />
            <Chip label={`Project Status: ${project.status}`} color="info" />
            <Chip label={`Supervisor Status: ${project.supervisor_request_status}`} color={project.supervisor_request_status === 'accepted' ? 'success' : 'warning'} />
            <Chip label="Next Deadline: 15 Days" />
          </Box>
        </Paper>
      </Grid>

      {/* Placeholder for more components */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 240 }}>
          <Typography>Recent Feedback / Announcements</Typography>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default Overview;