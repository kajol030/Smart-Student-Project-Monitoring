import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Overview from './Overview';
import MyProject from './MyProject';
import SupervisorSelection from './SupervisorSelection';
import Submissions from './Submissions';
import Milestones from './Milestones';

const StudentDashboard = () => {
  return (
    <Routes>
      <Route path="dashboard" element={<Overview />} />
      <Route path="my-project" element={<MyProject />} />
      <Route path="supervisors" element={<SupervisorSelection />} />
      <Route path="submissions" element={<Submissions />} />
      <Route path="milestones" element={<Milestones />} />
      {/* Default route for student */}
      <Route index element={<Overview />} />
    </Routes>
  );
};

export default StudentDashboard;