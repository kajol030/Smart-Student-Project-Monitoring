"""Read-only, leakage-safe dataset preparation from verified SQLite outcomes."""

import hashlib
import json
import os
import sqlite3
from datetime import date
from pathlib import Path
from urllib.parse import quote

FEATURES = [
    "progress",
    "completed_milestones",
    "overdue_milestones",
    "pending_submissions",
    "rejected_submissions",
    "feedback_count",
    "days_since_activity",
    "total_commits",
    "recent_commits",
    "commit_frequency",
    "active_days",
    "recent_activity_days",
    "pull_requests",
    "merged_prs",
    "open_issues",
    "closed_issues",
    "github_evidence_available",
]

OUTCOME_LABELS = {
    "completed_on_time": "Completed On Time",
    "delayed": "Delayed",
    "failed": "Failed",
}
MINIMUM_ROWS = 30
MINIMUM_PER_CLASS = 10


def database_path():
    configured = os.environ.get("ML_DATABASE_PATH") or os.environ.get("FYP_DB_PATH")
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path(__file__).resolve().parent.parent / "server" / "database" / "fyp.db").resolve()


def _connect_readonly(path):
    resolved = Path(path).expanduser().resolve()
    uri = f"file:{quote(resolved.as_posix(), safe='/:')}?mode=ro"
    return sqlite3.connect(uri, uri=True)


def _empty_report(path, message):
    return {
        "database_path": str(Path(path).expanduser().resolve()),
        "training_status": "insufficient_data",
        "message": message,
        "verified_outcome_count": 0,
        "usable_snapshot_count": 0,
        "class_counts": {status: 0 for status in OUTCOME_LABELS},
        "minimum_rows": MINIMUM_ROWS,
        "minimum_per_class": MINIMUM_PER_CLASS,
        "excluded": {},
        "fingerprint": None,
    }


def prepare_dataset(path=None):
    """Return one verified project row with its latest strictly pre-deadline snapshot."""
    path = Path(path or database_path()).expanduser().resolve()
    if not path.is_file():
        return [], _empty_report(path, "SQLite database file was not found.")

    try:
        connection = _connect_readonly(path)
    except sqlite3.Error as error:
        return [], _empty_report(path, f"Could not open SQLite database read-only: {error}")

    try:
        project_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(projects)")
        }
        required_outcome_columns = {
            "expected_completion_date",
            "actual_completion_date",
            "outcome_status",
            "outcome_verified",
            "verified_by",
            "verified_at",
        }
        if not required_outcome_columns.issubset(project_columns):
            return [], _empty_report(
                path, "Project outcome migrations have not been applied."
            )
        history_exists = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='prediction_history'"
        ).fetchone()
        snapshots_exist = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='project_feature_snapshots'"
        ).fetchone()
        if not history_exists and not snapshots_exist:
            return [], _empty_report(path, "Project feature snapshot history is unavailable.")

        verified_rows = connection.execute(
            """
            SELECT id, expected_completion_date, actual_completion_date,
                   outcome_status, verified_by, verified_at, status
            FROM projects
            WHERE outcome_verified = 1
              AND verified_by IS NOT NULL
              AND verified_at IS NOT NULL
              AND outcome_status IN ('completed_on_time', 'delayed', 'failed')
              AND expected_completion_date IS NOT NULL
            ORDER BY id
            """
        ).fetchall()
        status_counts = {
            row[0]: row[1]
            for row in connection.execute(
                """
                SELECT outcome_status, COUNT(*)
                FROM projects
                WHERE outcome_verified = 1
                  AND verified_by IS NOT NULL
                  AND verified_at IS NOT NULL
                  AND expected_completion_date IS NOT NULL
                  AND outcome_status IS NOT NULL
                GROUP BY outcome_status
                """
            )
        }
        class_counts = {
            status: int(status_counts.get(status, 0))
            for status in OUTCOME_LABELS
        }
        excluded = {
            "missing_pre_deadline_snapshot": 0,
            "invalid_outcome_dates": 0,
            "invalid_feature_snapshot": 0,
        }
        dataset = []
        fingerprint_rows = []

        for project_id, expected, actual, status, _, _, project_status in verified_rows:
            try:
                if date.fromisoformat(expected).isoformat() != expected:
                    raise ValueError("Invalid expected date.")
                if actual and date.fromisoformat(actual).isoformat() != actual:
                    raise ValueError("Invalid actual date.")
            except (TypeError, ValueError):
                excluded["invalid_outcome_dates"] += 1
                continue
            if status in ("completed_on_time", "delayed"):
                if project_status != "completed" or not actual or (
                    (actual <= expected) != (status == "completed_on_time")
                ):
                    excluded["invalid_outcome_dates"] += 1
                    continue
            elif actual is not None or project_status == "completed":
                excluded["invalid_outcome_dates"] += 1
                continue

            snapshots = []
            if history_exists:
                snapshots.extend(connection.execute(
                    """
                    SELECT features_snapshot, created_at, 0
                    FROM prediction_history
                    WHERE project_id = ? AND date(created_at) < date(?)
                    """,
                    (project_id, expected),
                ).fetchall())
            if snapshots_exist:
                snapshots.extend(connection.execute(
                    """
                    SELECT features_snapshot, captured_at, 1
                    FROM project_feature_snapshots
                    WHERE project_id = ? AND date(captured_at) < date(?)
                    """,
                    (project_id, expected),
                ).fetchall())
            snapshot = max(snapshots, key=lambda row: (row[1], row[2])) if snapshots else None
            if not snapshot:
                excluded["missing_pre_deadline_snapshot"] += 1
                continue
            try:
                values = json.loads(snapshot[0])
                features = {
                    name: float(
                        values[name]
                        if name != "github_evidence_available"
                        else bool(values[name])
                    )
                    for name in FEATURES
                }
                if not all(
                    value == value and abs(value) != float("inf")
                    for value in features.values()
                ):
                    raise ValueError("Non-finite feature value.")
            except (TypeError, ValueError, KeyError, json.JSONDecodeError):
                excluded["invalid_feature_snapshot"] += 1
                continue

            record = {
                "project_id": project_id,
                "expected_completion_date": expected,
                "actual_completion_date": actual,
                "features": features,
                "label": status,
                "snapshot_at": snapshot[1],
            }
            dataset.append(record)
            fingerprint_rows.append(record)

        usable_class_counts = {
            status: sum(row["label"] == status for row in dataset)
            for status in OUTCOME_LABELS
        }
        fingerprint = hashlib.sha256(
            json.dumps(fingerprint_rows, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        enough_data = (
            len(dataset) >= MINIMUM_ROWS
            and all(count >= MINIMUM_PER_CLASS for count in usable_class_counts.values())
        )
        report = {
            "database_path": str(path),
            "training_status": "ready" if enough_data else "insufficient_data",
            "message": (
                "Verified historical data meets the training minimum."
                if enough_data
                else (
                    f"Need at least {MINIMUM_ROWS} usable verified projects and "
                    f"{MINIMUM_PER_CLASS} examples of each outcome class; "
                    f"currently have {len(dataset)} usable projects."
                )
            ),
            "verified_outcome_count": len(verified_rows),
            "usable_snapshot_count": len(dataset),
            "class_counts": usable_class_counts,
            "verified_class_counts": class_counts,
            "minimum_rows": MINIMUM_ROWS,
            "minimum_per_class": MINIMUM_PER_CLASS,
            "excluded": excluded,
            "fingerprint": fingerprint,
        }
        return dataset, report
    except sqlite3.Error as error:
        return [], _empty_report(path, f"Could not inspect SQLite training data: {error}")
    finally:
        connection.close()
