import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from dataset import FEATURES, prepare_dataset
from train_model import train_model


class HistoricalDatasetTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory(prefix="fyp-dataset-tests-")
        self.database_path = Path(self.temporary_directory.name) / "projects.sqlite"
        connection = sqlite3.connect(self.database_path)
        try:
            connection.executescript("""
                CREATE TABLE projects (
                    id INTEGER PRIMARY KEY,
                    expected_completion_date TEXT,
                    actual_completion_date TEXT,
                    outcome_status TEXT,
                    outcome_verified INTEGER,
                    verified_by INTEGER,
                    verified_at TEXT,
                    status TEXT
                );
                CREATE TABLE prediction_history (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER,
                    features_snapshot TEXT,
                    created_at TEXT
                );
            """)
        finally:
            connection.close()

    def tearDown(self):
        self.temporary_directory.cleanup()

    def test_unverified_records_are_excluded_and_training_is_blocked(self):
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute(
                """
                INSERT INTO projects
                  (id, expected_completion_date, actual_completion_date,
                   outcome_status, outcome_verified, verified_by, verified_at, status)
                VALUES (1, '2026-03-15', '2026-03-10',
                        'completed_on_time', 0, NULL, NULL, 'completed')
                """
            )
            connection.commit()
        finally:
            connection.close()
        records, report = prepare_dataset(self.database_path)
        self.assertEqual(records, [])
        self.assertEqual(report["verified_outcome_count"], 0)
        self.assertEqual(report["training_status"], "insufficient_data")
        with self.assertRaisesRegex(ValueError, "Need at least"):
            train_model(records, report)

    def test_latest_pre_deadline_snapshot_is_used_without_post_deadline_leakage(self):
        features = {name: 0 for name in FEATURES}
        features["github_evidence_available"] = False
        connection = sqlite3.connect(self.database_path)
        try:
            connection.execute(
                """
                INSERT INTO projects
                  (id, expected_completion_date, actual_completion_date,
                   outcome_status, outcome_verified, verified_by, verified_at, status)
                VALUES (1, '2026-03-15', '2026-03-10',
                        'completed_on_time', 1, 7, '2026-03-20T12:00:00Z', 'completed')
                """
            )
            early_features = {**features, "progress": 30}
            after_deadline_features = {**features, "progress": 100}
            connection.executemany(
                """
                INSERT INTO prediction_history
                  (project_id, features_snapshot, created_at)
                VALUES (1, ?, ?)
                """,
                [
                    (json.dumps(early_features), "2026-03-14 08:00:00"),
                    (json.dumps(after_deadline_features), "2026-03-15 08:00:00"),
                ],
            )
            connection.commit()
        finally:
            connection.close()
        records, report = prepare_dataset(self.database_path)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["features"]["progress"], 30)
        self.assertEqual(records[0]["label"], "completed_on_time")
        self.assertEqual(report["training_status"], "insufficient_data")


if __name__ == "__main__":
    unittest.main()
