import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

model_directory = tempfile.TemporaryDirectory(prefix="fyp-ml-model-tests-")
os.environ["ML_MODEL_PATH"] = str(Path(model_directory.name) / "model.joblib")

from dataset import FEATURES
import synthetic_risk_demo
import app as ml_app


def create_empty_database(path):
    connection = sqlite3.connect(path)
    try:
        connection.executescript("""
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY,
                expected_completion_date TEXT,
                actual_completion_date TEXT,
                outcome_status TEXT,
                outcome_verified INTEGER,
                verified_by INTEGER,
                verified_at TEXT,
                status TEXT
            );
            CREATE TABLE prediction_history (
                id INTEGER PRIMARY KEY,
                project_id INTEGER,
                features_snapshot TEXT,
                created_at TEXT
            );
        """)
    finally:
        connection.close()


class FakeClassifier:
    classes_ = ["completed_on_time", "delayed", "failed"]

    def predict(self, features):
        return ["failed"]

    def predict_proba(self, features):
        return [[0.2, 0.3, 0.5]]


class PredictionServiceTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory(prefix="fyp-ml-tests-")
        os.environ["ML_DATABASE_PATH"] = str(
            Path(self.temporary_directory.name) / "outcomes.sqlite"
        )
        create_empty_database(os.environ["ML_DATABASE_PATH"])
        self.client = ml_app.app.test_client()
        self.features = {name: 0 for name in FEATURES}
        self.features["progress"] = 50

    def tearDown(self):
        self.temporary_directory.cleanup()

    def test_health_reports_loaded_synthetic_model_and_separate_verified_status(self):
        demo_path = Path(self.temporary_directory.name) / "synthetic-demo"
        synthetic_risk_demo.train_and_evaluate(
            synthetic_risk_demo.generate_dataset(),
            demo_path,
        )
        with patch.object(synthetic_risk_demo, "demo_directory", return_value=demo_path):
            response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["model_loaded"])
        active_model = response.json["active_risk_model"]
        self.assertTrue(active_model["model_loaded"])
        self.assertEqual(active_model["model_name"], "Logistic Regression")
        self.assertEqual(active_model["feature_count"], 17)
        self.assertEqual(active_model["class_labels"], ["Low", "Medium", "High"])
        self.assertGreater(active_model["evaluation_metrics"]["accuracy"], 0)
        self.assertEqual(response.json["model_info"], active_model)
        self.assertFalse(response.json["verified_outcome_model"]["model_loaded"])
        self.assertEqual(
            response.json["verified_outcome_model"]["model_info"]["training_status"],
            "insufficient_data",
        )
        self.assertEqual(
            response.json["verified_outcome_model"]["model_info"]["dataset"]["usable_snapshot_count"],
            0,
        )

    def test_health_does_not_claim_model_loaded_when_synthetic_artifacts_are_missing(self):
        missing_path = Path(self.temporary_directory.name) / "missing-model"
        with patch.object(synthetic_risk_demo, "demo_directory", return_value=missing_path):
            response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json["active_risk_model"]["model_loaded"])
        self.assertEqual(
            response.json["active_risk_model"]["training_status"],
            "artifact_missing",
        )
        self.assertIsNone(response.json["active_risk_model"]["evaluation_metrics"])

    def test_prediction_returns_no_rule_based_substitute(self):
        response = self.client.post("/predict", json=self.features)
        self.assertEqual(response.status_code, 503)
        self.assertIn("verified", response.json["error"].lower())

    def test_trained_random_forest_classifies_outcome_probabilities(self):
        metadata = {
            "model_name": "Random Forest Classifier",
            "model_type": "random_forest",
            "training_status": "trained",
            "evaluation_metrics": {"accuracy": 0.75, "macro_f1": 0.7},
        }
        with patch.object(ml_app, "_model_status", return_value=(FakeClassifier(), metadata)):
            response = self.client.post("/predict", json=self.features)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["predicted_outcome"], "failed")
        self.assertEqual(response.json["risk_level"], "high")
        self.assertAlmostEqual(response.json["delay_probability"], 0.3)
        self.assertAlmostEqual(response.json["failure_probability"], 0.5)
        self.assertAlmostEqual(response.json["completion_chance"], 0.5)

    def test_prediction_rejects_non_finite_features_when_model_is_loaded(self):
        metadata = {
            "model_name": "Random Forest Classifier",
            "training_status": "trained",
            "evaluation_metrics": {},
        }
        invalid_features = {**self.features, "progress": float("nan")}
        with patch.object(ml_app, "_model_status", return_value=(FakeClassifier(), metadata)):
            response = self.client.post("/predict", json=invalid_features)
        self.assertEqual(response.status_code, 400)

    def test_synthetic_demo_evaluation_and_prediction_are_isolated(self):
        demo_path = Path(self.temporary_directory.name) / "synthetic-demo"
        synthetic_risk_demo.train_and_evaluate(
            synthetic_risk_demo.generate_dataset(),
            demo_path,
        )
        with patch.object(synthetic_risk_demo, "demo_directory", return_value=demo_path):
            evaluation = self.client.get("/demo/synthetic-risk/evaluation")
            self.assertEqual(evaluation.status_code, 200)
            self.assertEqual(
                evaluation.json["title"],
                "Synthetic Risk Model — Demonstration Only",
            )
            self.assertEqual(evaluation.json["record_count"], 1500)
            self.assertIn("accuracy", evaluation.json["metrics"])

            prediction = self.client.post(
                "/demo/synthetic-risk/predict",
                json={
                    "progress": 60,
                    "completed_milestones": 6,
                    "overdue_milestones": 1,
                    "pending_submissions": 1,
                    "rejected_submissions": 0,
                    "feedback_count": 3,
                    "days_since_activity": 2,
                    "total_commits": 50,
                    "recent_commits": 10,
                    "commit_frequency": 2,
                    "active_days": 35,
                    "recent_activity_days": 12,
                    "pull_requests": 1,
                    "merged_prs": 5,
                    "open_issues": 1,
                    "closed_issues": 3,
                    "github_evidence_available": 1,
                },
            )
            self.assertEqual(prediction.status_code, 200)
            self.assertIn(prediction.json["risk_class"], ["Low", "Medium", "High"])
            self.assertIn(
                "Low",
                prediction.json["risk_probabilities"],
            )
            self.assertIn(
                "Not Real-world Validation",
                prediction.json["disclaimer"],
            )
            self.assertEqual(
                set(prediction.json["risk_probabilities"]),
                {"Low", "Medium", "High"},
            )
            self.assertAlmostEqual(
                sum(prediction.json["risk_probabilities"].values()),
                1.0,
            )

            invalid = self.client.post(
                "/demo/synthetic-risk/predict",
                json={**{
                    name: 0 for name in synthetic_risk_demo.FEATURES
                }, "progress": 101},
            )
            self.assertEqual(invalid.status_code, 400)
            extra_feature = self.client.post(
                "/demo/synthetic-risk/predict",
                json={
                    **{name: 0 for name in synthetic_risk_demo.FEATURES},
                    "unexpected_feature": 1,
                },
            )
            self.assertEqual(extra_feature.status_code, 400)


if __name__ == "__main__":
    unittest.main()
