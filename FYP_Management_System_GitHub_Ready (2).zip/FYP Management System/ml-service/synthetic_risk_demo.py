
"""Reproducible, demonstration-only 17-feature synthetic FYP risk model."""

import json
import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


RANDOM_STATE = 42
RECORD_COUNT = 1500
TEST_SIZE = 0.20

RISK_CLASSES = ["Low", "Medium", "High"]

FEATURES = [
    "progress",
    "completed_milestones",
    "overdue_milestones",
    "pending_submissions",
    "rejected_submissions",
    "feedback_count",
    "days_since_activity",
    "total_commits",
    "recent_commits",
    "commit_frequency",
    "active_days",
    "recent_activity_days",
    "pull_requests",
    "merged_prs",
    "open_issues",
    "closed_issues",
    "github_evidence_available",
]

FEATURE_DESCRIPTIONS = {
    "progress": "Project completion percent, Beta(2.2, 2.0) scaled to 0-100.",
    "completed_milestones": "Completed milestones, Binomial(n=12, p=progress fraction).",
    "overdue_milestones": "Overdue milestones, Poisson(lambda=0.3 + 3.2 * (1-progress fraction)), capped at 10.",
    "pending_submissions": "Pending submissions, Poisson(lambda=0.5 + 2 * (1-progress fraction)), capped at 8.",
    "rejected_submissions": "Rejected submissions, Poisson(lambda=0.2 + 1.6 * (1-progress fraction)), capped at 8.",
    "feedback_count": "Feedback records, Poisson(lambda=1 + 4 * (1-progress fraction)), capped at 20.",
    "days_since_activity": "Days since project activity, Poisson(lambda=1 + 12 * (1-progress fraction)), capped at 30.",
    "total_commits": "Lifetime commits, Poisson(lambda=8 + 65 * (1-progress fraction)), capped at 500.",
    "recent_commits": "Recent commits, Poisson(lambda=1 + 14 * (1-progress fraction)), capped at 100.",
    "commit_frequency": "Commits per active period, Gamma(shape=2, scale=1.5), capped at 20.",
    "active_days": "Lifetime active days, Binomial(n=180, p=0.08 + 0.28 * progress fraction).",
    "recent_activity_days": "Active days in recent period, Binomial(n=30, p=0.08 + 0.42 * progress fraction).",
    "pull_requests": "Open pull requests, Poisson(lambda=0.4 + 1.6 * (1-progress fraction)), capped at 20.",
    "merged_prs": "Merged pull requests, Poisson(lambda=1 + 7 * progress fraction), capped at 100.",
    "open_issues": "Open issues, Poisson(lambda=0.5 + 1.5 * (1-progress fraction)), capped at 30.",
    "closed_issues": "Closed issues, Poisson(lambda=1 + 6 * progress fraction), capped at 100.",
    "github_evidence_available": "Whether a repository is linked, Bernoulli(p=0.75).",
}

LABELING_RULE = (
    "Labels are generated from a synthetic weighted risk score plus seeded Gaussian "
    "noise; they are not observed project outcomes. Score weights: "
    "0.20*(1-progress), "
    "0.04*(1-completed_milestones/12), "
    "0.12*overdue_milestones/10, "
    "0.06*pending_submissions/8, "
    "0.08*rejected_submissions/8, "
    "0.04*(1-feedback_count/20), "
    "0.10*days_since_activity/30, "
    "0.04*(1-total_commits/500), "
    "0.06*(1-recent_commits/100), "
    "0.02*(1-commit_frequency/20), "
    "0.05*(1-active_days/180), "
    "0.04*(1-recent_activity_days/30), "
    "0.02*pull_requests/20, "
    "0.04*(1-merged_prs/100), "
    "0.02*open_issues/30, "
    "0.03*(1-closed_issues/100), "
    "0.04*(1-github_evidence_available). "
    "Low is below 0.34, Medium is 0.34 to below 0.46, High is at least 0.46."
)


def demo_directory():
    configured = os.environ.get("SYNTHETIC_DEMO_DIR")

    return (
        Path(configured).expanduser().resolve()
        if configured
        else Path(__file__).resolve().parent / "synthetic_risk_model"
    )


def generate_dataset(record_count=RECORD_COUNT, seed=RANDOM_STATE):
    """Generate synthetic rows only; does not read or write the production DB."""

    rng = np.random.default_rng(seed)

    progress = rng.beta(2.2, 2.0, record_count)

    features = {
        "progress": progress * 100,

        "completed_milestones": rng.binomial(12, progress),

        "overdue_milestones": np.minimum(
            rng.poisson(0.3 + 3.2 * (1 - progress)), 10
        ),

        "pending_submissions": np.minimum(
            rng.poisson(0.5 + 2 * (1 - progress)), 8
        ),

        "rejected_submissions": np.minimum(
            rng.poisson(0.2 + 1.6 * (1 - progress)), 8
        ),

        "feedback_count": np.minimum(
            rng.poisson(1 + 4 * (1 - progress)), 20
        ),

        "days_since_activity": np.minimum(
            rng.poisson(1 + 12 * (1 - progress)), 30
        ),

        "total_commits": np.minimum(
            rng.poisson(8 + 65 * (1 - progress)), 500
        ),

        "recent_commits": np.minimum(
            rng.poisson(1 + 14 * (1 - progress)), 100
        ),

        "commit_frequency": np.minimum(
            rng.gamma(2, 1.5, record_count), 20
        ),

        "active_days": rng.binomial(
            180, 0.08 + 0.28 * progress
        ),

        "recent_activity_days": rng.binomial(
            30, 0.08 + 0.42 * progress
        ),

        "pull_requests": np.minimum(
            rng.poisson(0.4 + 1.6 * (1 - progress)), 20
        ),

        "merged_prs": np.minimum(
            rng.poisson(1 + 7 * progress), 100
        ),

        "open_issues": np.minimum(
            rng.poisson(0.5 + 1.5 * (1 - progress)), 30
        ),

        "closed_issues": np.minimum(
            rng.poisson(1 + 6 * progress), 100
        ),

        "github_evidence_available": rng.binomial(
            1, 0.75, record_count
        ),
    }

    normalized = {
        name: np.asarray(values, dtype=float)
        for name, values in features.items()
    }

    risk_score = (
        0.20 * (1 - normalized["progress"] / 100)
        + 0.04 * (1 - normalized["completed_milestones"] / 12)
        + 0.12 * normalized["overdue_milestones"] / 10
        + 0.06 * normalized["pending_submissions"] / 8
        + 0.08 * normalized["rejected_submissions"] / 8
        + 0.04 * (1 - normalized["feedback_count"] / 20)
        + 0.10 * normalized["days_since_activity"] / 30
        + 0.04 * (1 - normalized["total_commits"] / 500)
        + 0.06 * (1 - normalized["recent_commits"] / 100)
        + 0.02 * (1 - normalized["commit_frequency"] / 20)
        + 0.05 * (1 - normalized["active_days"] / 180)
        + 0.04 * (1 - normalized["recent_activity_days"] / 30)
        + 0.02 * normalized["pull_requests"] / 20
        + 0.04 * (1 - normalized["merged_prs"] / 100)
        + 0.02 * normalized["open_issues"] / 30
        + 0.03 * (1 - normalized["closed_issues"] / 100)
        + 0.04 * (1 - normalized["github_evidence_available"])
        + rng.normal(0, 0.035, record_count)
    )

    labels = np.select(
        [risk_score < 0.34, risk_score < 0.46],
        ["Low", "Medium"],
        default="High",
    )

    frame = pd.DataFrame({
        name: np.round(normalized[name], 4)
        for name in FEATURES
    })

    frame["risk_class"] = labels

    return frame


def train_and_evaluate(frame, output_directory=None):

    if len(frame) != RECORD_COUNT:
        raise ValueError(
            f"Synthetic demo training requires exactly {RECORD_COUNT} rows."
        )

    if set(frame.columns) != set(FEATURES + ["risk_class"]):
        raise ValueError(
            "Synthetic dataset columns do not match the documented schema."
        )

    if set(frame["risk_class"].unique()) != set(RISK_CLASSES):
        raise ValueError(
            "Synthetic dataset must contain all Low, Medium, and High classes."
        )

    features = frame[FEATURES].to_numpy(dtype=float)
    targets = frame["risk_class"].to_numpy(dtype=str)

    # Same training and testing split for all algorithms
    train_features, test_features, train_targets, test_targets = (
        train_test_split(
            features,
            targets,
            test_size=TEST_SIZE,
            random_state=RANDOM_STATE,
            stratify=targets,
        )
    )

    # Standard scaling for Logistic Regression
    scaler = StandardScaler()

    scaled_train = scaler.fit_transform(train_features)
    scaled_test = scaler.transform(test_features)

    # Three algorithms
    models = {
        "Logistic Regression": LogisticRegression(
            max_iter=2000,
            random_state=RANDOM_STATE,
        ),

        "Decision Tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE,
        ),

        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
    }

    comparison = {}
    trained_models = {}

    # Train and evaluate each algorithm
    for name, current_model in models.items():

        if name == "Logistic Regression":

            current_model.fit(
                scaled_train,
                train_targets,
            )

            predicted = current_model.predict(scaled_test)

        else:

            current_model.fit(
                train_features,
                train_targets,
            )

            predicted = current_model.predict(test_features)

        trained_models[name] = current_model

        comparison[name] = {
            "accuracy": float(
                accuracy_score(test_targets, predicted)
            ),

            "macro_precision": float(
                precision_score(
                    test_targets,
                    predicted,
                    labels=RISK_CLASSES,
                    average="macro",
                    zero_division=0,
                )
            ),

            "macro_recall": float(
                recall_score(
                    test_targets,
                    predicted,
                    labels=RISK_CLASSES,
                    average="macro",
                    zero_division=0,
                )
            ),

            "macro_f1": float(
                f1_score(
                    test_targets,
                    predicted,
                    labels=RISK_CLASSES,
                    average="macro",
                    zero_division=0,
                )
            ),

            "confusion_matrix": confusion_matrix(
                test_targets,
                predicted,
                labels=RISK_CLASSES,
            ).tolist(),

            "per_class": classification_report(
                test_targets,
                predicted,
                labels=RISK_CLASSES,
                output_dict=True,
                zero_division=0,
            ),
        }

    # Keep Logistic Regression as the active model
    model = trained_models["Logistic Regression"]

    metrics = comparison["Logistic Regression"]

    class_counts = {
        label: int(
            (frame["risk_class"] == label).sum()
        )
        for label in RISK_CLASSES
    }

    # Store evaluation results
    evaluation = {
        "title": "Synthetic Risk Model — Demonstration Only",

        "disclaimer": (
            "Synthetic Dataset Evaluation — Not Real-world Validation"
        ),

        "model_name": "Logistic Regression",

        "dataset_type": "synthetic",

        "record_count": len(frame),

        "feature_names": FEATURES,

        "feature_descriptions": FEATURE_DESCRIPTIONS,

        "target": "risk_class",

        "class_distribution": class_counts,

        "labeling_rule": LABELING_RULE,

        "test_size": TEST_SIZE,

        "split_method": "stratified random holdout",

        "random_state": RANDOM_STATE,

        "preprocessing": (
            "StandardScaler fit on training split only for Logistic Regression"
        ),

        "metrics": metrics,

        "algorithm_comparison": comparison,

        "historical_claims": {
            "accuracy": "85% (historical, unverified)",
            "macro_f1": "82% (historical, unverified)",
            "reproduced": False,
            "reason": (
                "The original dataset, generator, and evaluation split "
                "were not available."
            ),
        },
    }

    directory = Path(
        output_directory or demo_directory()
    )

    directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save synthetic dataset
    frame.to_csv(
        directory / "synthetic_risk_17_dataset.csv",
        index=False,
    )

    # Save only Logistic Regression as the active model
    joblib.dump(
        model,
        directory / "synthetic_risk_17_logistic_regression.joblib",
    )

    joblib.dump(
        scaler,
        directory / "synthetic_risk_17_scaler.joblib",
    )

    # Save all algorithm comparison results
    evaluation_path = (
        directory / "synthetic_risk_17_evaluation.json"
    )

    evaluation_path.write_text(
        json.dumps(evaluation, indent=2),
        encoding="utf-8",
    )

    # Display comparison in terminal
    print("\n" + "=" * 55)
    print("     MACHINE LEARNING ALGORITHM COMPARISON")
    print("=" * 55)

    print(
        f"\n{'Algorithm':<25}"
        f"{'Accuracy':<12}"
        f"{'Precision':<12}"
        f"{'Recall':<12}"
        f"{'F1-Score':<12}"
    )

    print("-" * 73)

    for name, result in comparison.items():

        print(
            f"{name:<25}"
            f"{result['accuracy'] * 100:<12.2f}"
            f"{result['macro_precision'] * 100:<12.2f}"
            f"{result['macro_recall'] * 100:<12.2f}"
            f"{result['macro_f1'] * 100:<12.2f}"
        )

    print("-" * 73)

    best_algorithm = max(
        comparison,
        key=lambda name: comparison[name]["accuracy"],
    )

    print(
        f"\nHighest test accuracy: {best_algorithm} "
        f"({comparison[best_algorithm]['accuracy'] * 100:.2f}%)"
    )

    print("\nResults saved in:")
    print(evaluation_path)

    print("\nNote: Results use synthetic data, not real-world validation.")

    return model, scaler, evaluation


def load_demo_artifacts():

    directory = demo_directory()

    model_path = (
        directory / "synthetic_risk_17_logistic_regression.joblib"
    )

    scaler_path = (
        directory / "synthetic_risk_17_scaler.joblib"
    )

    evaluation_path = (
        directory / "synthetic_risk_17_evaluation.json"
    )

    missing = [
        path.name
        for path in (
            model_path,
            scaler_path,
            evaluation_path,
        )
        if not path.is_file()
    ]

    if missing:
        raise FileNotFoundError(
            "Synthetic Logistic Regression artifacts are missing: "
            + ", ".join(missing)
        )

    model = joblib.load(model_path)

    scaler = joblib.load(scaler_path)

    evaluation = json.loads(
        evaluation_path.read_text(encoding="utf-8")
    )

    if (
        not isinstance(model, LogisticRegression)
        or not isinstance(scaler, StandardScaler)
        or set(model.classes_) != set(RISK_CLASSES)
        or getattr(model, "n_features_in_", None) != len(FEATURES)
        or getattr(scaler, "n_features_in_", None) != len(FEATURES)
        or list(evaluation.get("feature_names", [])) != FEATURES
        or not isinstance(evaluation.get("metrics"), dict)
        or evaluation.get("model_name") != "Logistic Regression"
    ):

        raise ValueError(
            "Synthetic Logistic Regression model, scaler, or evaluation "
            "metadata does not match the 17-feature schema."
        )

    return model, scaler, evaluation


def main():

    print("Generating synthetic FYP dataset...")

    frame = generate_dataset()

    print(f"Dataset generated: {len(frame)} records")

    print("\nTraining and evaluating three algorithms...")

    _, _, evaluation = train_and_evaluate(frame)

    print("\nEvaluation completed successfully.")

    print(
        "\nActive model:",
        evaluation["model_name"],
    )


if __name__ == "__main__":
    main()
