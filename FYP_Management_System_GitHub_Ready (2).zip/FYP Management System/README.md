# Smart Student Project Monitoring Platform (FYP Management System)

AI-based Final Year Project management system with predictive analytics.

## Tech Stack

- **Frontend:** React.js, Tailwind CSS, Vite
- **Backend:** Node.js, Express.js
- **Database:** SQLite (default); MySQL setup is optional and not yet fully verified
- **AI/ML:** Python, Flask, Scikit-learn

## Project Structure

```
FYP Management System/
├── client/          # React frontend
├── server/          # Express API + SQLite / optional MySQL support
└── ml-service/      # Python ML prediction service
```

## Setup Instructions

### 1. Database (SQLite default)

The app currently uses SQLite unless `DB_TYPE=mysql` is explicitly set. Its database is `server/database/fyp.db`; the backend initializes the schema on startup.

```powershell
Copy-Item server\.env.example server\.env
```

### MySQL setup (separate database; migration not included)

MySQL setup creates a separate database and does **not** copy data from SQLite. Keep `DB_TYPE=sqlite` until the SQLite data has been backed up, migrated, and reconciled. Do not switch the running app to MySQL expecting the existing projects/users to appear there.

1. Back up `server\database\fyp.db` with the backend stopped. Keep the original file unchanged.
2. Configure `DB_TYPE=mysql`, `DB_HOST`, `DB_USER`, `DB_PASSWORD`, and `DB_NAME` in `server\.env`. The MySQL user needs permission to create the configured database.
3. Run `npm run db:init --prefix server` to create the MySQL schema. This command does not modify the SQLite database; do not run it as a migration/import step.
4. Before switching the app, migrate all SQLite tables while preserving IDs and foreign-key relationships, then compare per-table row counts and verify representative Admin, Supervisor, and Student workflows against MySQL.
5. Only after those checks pass, start the backend with `DB_TYPE=mysql`. Keep the SQLite backup until the migrated system has been accepted.

The project has MySQL-specific schema and connection support, but end-to-end MySQL compatibility and data migration have not yet been verified. In particular, some route queries still contain SQLite-specific SQL. Continue using SQLite until that compatibility work and the data reconciliation are complete.

### 2. Backend API

```bash
npm run server
```

API runs at: `http://localhost:5000`

### 3. Frontend

```bash
cd client
npm install
npm run dev
```

Frontend runs at: `http://localhost:5173`

### 4. ML Service (Optional)

```bash
cd ml-service
pip install -r requirements.txt
python app.py
```

ML service runs at: `http://localhost:5001`. `GET /health` reports the active synthetic Logistic Regression load status, feature count, class labels, and saved evaluation metrics under `active_risk_model`; the verified-outcome model status is separate under `verified_outcome_model`. The authenticated backend proxy is `GET /api/predictions/synthetic-demo/health`. The service reads the SQLite database at `server/database/fyp.db` by default; set `ML_DATABASE_PATH` if the server uses a different SQLite file. The database is opened read-only by the training pipeline.

Supervisors (assigned to the project) and administrators can record a project’s expected completion date and outcome from the Projects screen. Completed outcomes require an actual completion date; the API checks whether that date is on or before the expected date. Failed outcomes must be explicitly selected and verified; unfinished projects are never automatically marked failed. Only verified outcomes are eligible for training.

The isolated verified-outcome pipeline uses the latest feature snapshot captured strictly before each project’s expected completion date. It can train a `RandomForestClassifier` only when there are at least 30 usable verified projects and at least 10 examples of each outcome class. Training uses a stratified 75/25 train/test split and reports accuracy, balanced accuracy, macro-F1, a confusion matrix, and per-class metrics. This outcome model is not used by the AI Insights project-risk workflow.

Feature snapshots are captured once per project per day when project predictions are requested. After enough outcomes and pre-deadline snapshots have been verified, run `python train_model.py` from `ml-service`. The service checks the model artifact on each request. A model becomes unavailable for prediction if the verified dataset changes and the artifact needs retraining.

#### Primary project-risk prediction: Logistic Regression

AI Insights uses Logistic Regression as its sole project-risk classifier, with the three presentation categories Low, Medium, and High. It receives the current 17 project and GitHub activity features. The risk predictions use a synthetic-trained model; they are not real-world validated and must not be interpreted as verified completion, delay, or failure outcomes.

The original 1,500-row dataset, generator, feature mapping, and evaluation split could not be recovered; Git history is unavailable in the workspace. The legacy `logistic_regression.pkl` and `best_model.pkl` files have 17 inputs and numeric classes `[0, 1, 2]`, but do not embed enough metadata to recover the input order or class mapping. Historical 85% accuracy, 82% Macro F1, and comparison results are unverified and were not reproduced. These legacy artifacts remain unchanged.

The replacement dataset is `ml-service/synthetic_risk_model/synthetic_risk_17_dataset.csv`. It contains 1,500 generated rows, the current 17 project/GitHub features, and `risk_class` labels. Feature distributions and the synthetic labeling rule are documented in `ml-service/synthetic_risk_demo.py`. Run `python synthetic_risk_demo.py` from `ml-service` to regenerate and evaluate it. The script uses a stratified 80/20 split (`random_state=42`), fits `StandardScaler` on the training partition only, then trains Logistic Regression. Its scaler and classifier are saved as separate synthetic-only artifacts under `ml-service/synthetic_risk_model/`.

The measured held-out metrics and class distribution are saved to `ml-service/synthetic_risk_model/synthetic_risk_17_evaluation.json`. They are new synthetic evaluation results, not the historical 85%/82% claims and not real-world validation.

The project risk endpoint calls Flask `POST /demo/synthetic-risk/predict`; it returns only risk-class probabilities, not delay/completion/failure predictions. Risk class and feature history retain the existing project/API response shape, while unsupported delay and completion probabilities are cleared. The separate verified-outcome Random Forest pipeline and artifacts are not used in this classification workflow.

### GitHub project analysis

Students or their assigned supervisor can link the repository URL from the Projects screen. Public repositories are fetched without a token. Private repository analysis requires an authorized GitHub token configured only in `server\.env` as `GITHUB_TOKEN`; grant it read-only access to the intended repositories. Do not put this token in frontend environment variables, source control, or logs. Students cannot retrieve private-repository details using the server token; assigned supervisors and administrators can.

The GitHub API integration fetches a bounded number of pages (up to 300 records per list) for commits, branches, pull requests, and issues. Rate limits and unavailable/private repositories are reported as access errors. Evidence estimates and proposal text similarity are advisory indicators, not verified completion or project quality. Supervisors remain responsible for evaluating the work and assigning final marks.

### Text similarity review

Students can upload a PDF, DOCX, or UTF-8 TXT document from **Text Similarity**. The API extracts text in memory, compares it with earlier platform checks, and stores the extracted text and result in the configured database. The source file itself is not retained by this feature. Uploads are limited to 10 MB and extracted text to 100,000 characters.

Students and assigned supervisors can review checks for their project; only administrators can see reference-project names and reference excerpts. Checks use lexical similarity and exact phrase overlap against prior platform checks only; they do not search the public web or repositories and are not proof of plagiarism. Supervisors retain control of academic decisions and final marks.

### Tests

Run the focused checks from the project root:

```powershell
npm test --prefix server
npm test --prefix client
python -m unittest discover -s ml-service -p "test_*.py"
```

The server test runner uses disposable SQLite files under the operating-system temporary directory. It does not write test records into `server\database\fyp.db`.

### Demo Admin and Supervisor Accounts

Public registration creates **Student and Supervisor** accounts. Admin accounts remain provisioned separately. Create demo Admin and Supervisor accounts from the server terminal using strong credentials supplied through environment variables:

```powershell
$env:ADMIN_EMAIL="admin@example.com"
$env:ADMIN_PASSWORD="Your-strong-admin-password"
$env:SUPERVISOR_EMAIL="supervisor@example.com"
$env:SUPERVISOR_PASSWORD="Your-strong-supervisor-password"
npm run seed:demo-users --prefix server
```

The seed command stores bcrypt password hashes and prints emails/status only. All roles use `/login`; successful login redirects Admin to `/admin`, Supervisor to `/supervisor`, and Student to `/student`.

## User Roles

| Role | Features |
|------|----------|
| **Student** | Create project, submit documents, track milestones, view feedback & AI recommendations |
| **Supervisor** | Accept/reject requests, review submissions, give feedback, monitor student risk levels |
| **Admin** | Manage users, monitor requests & assignments, set deadlines, view analytics |

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST   | `/api/auth/register` | Register user |
| POST   | `/api/auth/login` | Login |
| GET    | `/api/projects` | List projects (role-based) |
| POST   | `/api/projects` | Create project (student) |
| POST   | `/api/supervisor-requests` | Student requests a supervisor |
| PUT    | `/api/supervisor-requests/:id/respond` | Supervisor accepts/rejects a request |
| GET    | `/api/milestones/project/:id` | Get milestones for a project |
| POST   | `/api/submissions` | Upload a document for a project |
| POST   | `/api/feedback` | Add feedback (supervisor) |
| GET    | `/api/projects/:id/risk` | Get AI risk prediction for a project |
| GET    | `/api/admin/stats` | Get dashboard analytics for admin |

## Development Flow

1. Register as **Admin** → manage system
2. Register **Students** and **Supervisors**
3. Student creates FYP proposal
4. Student requests a supervisor
5. Supervisor accepts the request
5. Student submits documents & completes milestones
6. Supervisor reviews and gives feedback
7. System predicts risk level and generates recommendations
