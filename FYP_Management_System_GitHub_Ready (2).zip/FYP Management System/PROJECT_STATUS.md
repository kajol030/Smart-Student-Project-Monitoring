# PROJECT_STATUS.md — Smart FYP Platform
## Complete Project Analysis Report

**Report Date:** October 24, 2026  
**Analysis Method:** Full source-code read + live API testing + database inspection  
**No code was modified during this analysis.**

---

## 1. Project Overview

### What is this system?

**Smart FYP Platform** (branded "Smart Student") is a full-stack web application for managing Final Year Projects (FYPs) at the ICT Department (BSCS & BSAI programs). It covers the complete lifecycle from student group formation, topic submission, and supervisor assignment through milestone tracking, weekly logs, document review, meetings, evaluations, AI-powered risk prediction, and admin reporting.

### Three-tier architecture

```
Browser (React 18 + Vite + TailwindCSS)
    ↕ /api/* proxy (Vite dev) or direct (production)
Express.js API Server (Node.js 24, ES Modules, port 5000)
    ↕ node:sqlite (DatabaseSync) or mysql2 pool
SQLite 3 / MySQL 8   ←   fyp.db (live data, 40 tables)
    ↑
Python 3 Flask ML Service (scikit-learn, port 5001) — optional
```

### Users and roles

| Role | Primary capabilities |
|------|----------------------|
| **Student** | Register, form groups, submit topic, track milestones, upload documents, submit weekly logs, view AI risk, attend meetings, receive feedback, manage preferences |
| **Supervisor** | View/review assigned students, approve/reject submissions, give feedback, schedule meetings, submit evaluations, review weekly logs, manage milestones |
| **Admin** | All of the above plus: user management, supervisor assignment, deadlines, academic hierarchy, rubrics, viva scheduling, audit logs, reports, AI analytics, system settings |

---

## 2. Overall Progress

> **Estimated completion: ~87%**

This is based on counting implemented + verified features (40) versus total scoped features (46+). The missing ~13% consists of: no git repository, 5 missing UI pages, 2 open bugs, no automated tests, and unconfigured optional services.

---

## 3. Module-by-Module Report

| Module | Completed | Partially Done | Missing | % Complete | Evidence |
|--------|-----------|----------------|---------|------------|---------|
| **Frontend — Auth** | Login, Register, Forgot/Reset Password, ProtectedRoute, session storage | — | `GET /auth/me` route (404) — api.js calls it but route doesn't exist | 90% | `auth.js`, `Login.jsx`, `Register.jsx`, `api.js` |
| **Frontend — Student** | Dashboard, Projects, Milestones, Documents, Feedback, Weekly Logs, Groups, Meetings, Announcements, Evaluations, AI Insights, Notifications, Preferences, Search | — | Dedicated Profile/Settings UI page | 92% | 28 pages in `client/src/pages/` |
| **Frontend — Supervisor** | Dashboard (students table, risk overview, pending requests), Reviews, Feedback, Meetings, Milestones, Evaluations, AI Insights, Weekly Logs | — | — | 95% | `SupervisorDashboard.jsx`, `SupervisorReviews.jsx` |
| **Frontend — Admin** | Dashboard, Users, Assignments, Deadlines, Analytics (charts + filters), Academic Management, Groups, Audit Logs, Evaluations, Reports | — | Viva Management UI, System Settings UI, Plagiarism UI | 82% | All Admin*.jsx pages |
| **Backend — Auth** | Register, Login, Logout (token blacklist), Forgot/Reset password (SHA-256 token, 15-min expiry), Change password, Rate limiting, JWT | Missing `GET /auth/me` route | — | 95% | `server/routes/auth.js` |
| **Backend — Projects** | CRUD, supervisor assignment, topic review, topic resubmit, progress calculation, github_url, project stats, group linking | — | — | 100% | `server/routes/projects.js` |
| **Backend — Groups** | Create/invite/join/respond, leader/member roles, chat (POST/GET messages), delete with cascade, active-member guard (fixed) | — | — | 100% | `server/routes/projectGroups.js` |
| **Backend — Milestones** | CRUD, status update (auto-recalculates project progress), overdue detection | — | — | 100% | `server/routes/milestones.js` |
| **Backend — Submissions** | Upload (Multer, 10 MB, PDF/DOCX/PPT/image), versioning, status review (approve/reject/revision), file serve | — | — | 100% | `server/routes/submissions.js` |
| **Backend — Evaluations** | Rubrics (CRUD with criteria + weights), evaluations (supervisor + panel marks), auto grade A+→F, rubric score breakdown | viva_id bug fixed (vivas→viva_schedules) | — | 98% | `server/routes/evaluations.js` |
| **Backend — Viva** | Schedule, update, panel management (add/remove), notifications to student + supervisor | — | No admin frontend UI | 95% (backend) | `server/routes/viva.js` |
| **Backend — ML/Predictions** | Feature extraction (17 project/GitHub features), Logistic Regression risk classifications, risk history, recommendations, admin analytics | Original synthetic training data and mappings unavailable; results are not real-world validated | Verified outcome pipeline remains isolated | — | `server/routes/predictions.js`, `server/services/aiService.js` |
| **Backend — GitHub** | Full REST API integration (repo info, commits, PRs, issues, activity metrics), URL validation, IDOR protection, rate limit headers | No GITHUB_TOKEN set — 60 req/hr limit | — | 90% | `server/services/githubService.js`, `server/routes/github.js` |
| **Database** | 40 tables, full schema with FK constraints, WAL mode, additive migrations, seeded ICT Dept + BSCS/BSAI programs, live fyp.db with real data | — | `group_messages` fixed (added), `vivas` bug fixed | 100% | `server/database/sqlite-schema.sql`, `fyp.db` |
| **ML Service** | 17-feature synthetic Logistic Regression risk classifier; separate verified-outcome Random Forest training pipeline | Original synthetic dataset/mapping/evaluation split unavailable; no real-world validation | Gather verified outcomes for the isolated outcome pipeline | — | `ml-service/app.py`, `ml-service/synthetic_risk_demo.py`, `ml-service/train_model.py` |
| **Proposal Alignment** | Jaccard-based title similarity (30% threshold), cross-project submission similarity (40% threshold), both endpoints mounted | No frontend UI for plagiarism check | Real document content comparison (only title text) | 60% | `server/routes/plagiarism.js` |
| **Testing** | 0 automated tests | — | Unit tests, integration tests, E2E tests | 0% | No test files found |
| **Deployment** | `.env` configured, SQLite fyp.db live, Vite proxy set up, nodemailer SMTP keys set | No git repo initialized | Docker/nginx config, production build scripts | 25% | `server/.env`, `client/vite.config.js` |

---

## 4. Frontend Status and Remaining Work

### What's complete (verified by file inspection)

**28 page components exist and build successfully (1777 modules, 0 errors):**

| Page | Role | Status |
|------|------|--------|
| Login.jsx | All | ✅ Complete |
| Register.jsx | Student/Supervisor | ✅ Complete |
| ForgotPassword.jsx | All | ✅ Complete |
| StudentDashboard.jsx | Student | ✅ Complete |
| SupervisorDashboard.jsx | Supervisor | ✅ Complete |
| AdminDashboard.jsx | Admin | ✅ Complete |
| AdminUsers.jsx | Admin | ✅ Complete |
| AdminAssignments.jsx | Admin | ✅ Complete |
| AdminDeadlines.jsx | Admin | ✅ Complete |
| AdminAnalytics.jsx | Admin | ✅ Complete (Recharts bar + donut charts, filters) |
| Projects.jsx | Student | ✅ Complete (GitHub panel + AI prediction cards) |
| Milestones.jsx | All | ✅ Complete |
| Documents.jsx | Student | ✅ Complete |
| FeedbackPage.jsx | Student/Supervisor | ✅ Complete |
| Meetings.jsx | All | ✅ Complete |
| Announcements.jsx | All | ✅ Complete |
| Evaluations.jsx | All | ✅ Complete (rubric builder + eval form + history) |
| AiInsights.jsx | All | ✅ Complete (17-feature display + GitHub signals panel) |
| Groups.jsx | All | ✅ Complete (invite flow fixed, member filtering added) |
| AuditLogs.jsx | Admin | ✅ Complete |
| AcademicManagement.jsx | Admin | ✅ Complete |
| Reports.jsx | Admin | ✅ Complete (JSON/CSV/PDF download) |
| SearchResults.jsx | All | ✅ Complete |
| Notifications.jsx | All | ✅ Complete |
| Preferences.jsx | All | ✅ Complete |
| TopicReview.jsx | Supervisor/Admin | ✅ Complete |
| SupervisorReviews.jsx | Supervisor | ✅ Complete |
| WeeklyLogs.jsx | All | ✅ Complete (recently added) |

**Frontend architecture:**
- Centralized API layer (`api.js`) with 60+ typed methods
- JWT stored in localStorage, auto-cleared on 401
- Role-based routing with `ProtectedRoute` component
- Vite proxy for `/api` → `localhost:5000` in dev
- Framer Motion for animations, Recharts for charts, Lucide React for icons
- TailwindCSS + custom `App.css` design system

### What's missing on frontend

1. **Profile / User Settings page** — no dedicated `/profile` route. Backend `GET/PUT /api/profiles/me` and avatar upload exist and work, but there's no UI for users to view or edit their own profile.
2. **Admin Viva Management page** — backend fully implemented (schedule, update, panel). No frontend UI exists.
3. **System Settings UI** — `GET/PUT /api/settings` now works. No admin page to view/edit system settings.
4. **Plagiarism check UI** — `/api/plagiarism/titles` works. No button or page integrates it.
5. **`api.getMe()`** calls `GET /api/auth/me` which returns 404 (route doesn't exist in auth.js). Any component calling `getMe()` fails silently.

---

## 5. Backend Status and Remaining Work

### What's complete

**30 route files, all mounted in `server/index.js`:**

| Route prefix | File | Key endpoints |
|---|---|---|
| `/api/auth` | auth.js | register, login, logout, forgot-password, reset-password, change-password |
| `/api/users` | users.js | list, students, supervisors, peers, delete |
| `/api/projects` | projects.js | CRUD, assign-supervisor, topic-review, github-url, stats |
| `/api/milestones` | milestones.js | CRUD, status update |
| `/api/submissions` | submissions.js | upload, versioning, status review |
| `/api/feedback` | feedback.js | CRUD with rating |
| `/api/deadlines` | deadlines.js | CRUD, role targeting |
| `/api/vivas` | viva.js | schedule, update, panel management |
| `/api/weekly-logs` | weeklyLogs.js | submit, review, get by project |
| `/api/meetings` | meetings.js | create, update, cancel, minutes |
| `/api/announcements` | announcements.js | CRUD, role targeting |
| `/api/departments` | departments.js | CRUD |
| `/api/batches` | batches.js | CRUD |
| `/api/predictions` | predictions.js | project prediction, history, analytics, explain |
| `/api/profiles` | profiles.js | read/update profile, avatar upload |
| `/api/supervisor-requests` | supervisorRequests.js | send, accept/reject |
| `/api/notifications` | notifications.js | CRUD, unread count, mark read |
| `/api/evaluations` | evaluations.js | rubrics CRUD, evaluations CRUD, grade calc |
| `/api/audit-logs` | auditLogs.js | paginated admin log |
| `/api/project-groups` | projectGroups.js | CRUD, invite, join, chat messages |
| `/api/academic` | academic.js | programs, academic years, semesters, sections |
| `/api/search` | search.js | global search with role filter |
| `/api/preferences` | preferences.js | notification preferences (6 event types) |
| `/api/reports` | reports.js | JSON/CSV/PDF reports |
| `/api/github` | github.js | live GitHub data for project |
| `/api/settings` | settings.js | system settings read/write |
| `/api/plagiarism` | plagiarism.js | title similarity, submission cross-check |

**Middleware stack:** JWT verify + token blacklist check, role authorization, Multer file upload, express-validator, audit log writer, Helmet security headers, CORS, rate limiting.

**Services:** `githubService.js` (full GitHub REST v3 integration), `aiService.js` (feature extraction, ML call, rule-based fallback, recommendations), `email.js` (Nodemailer + 5 email templates), `notifier.js` (in-app + email notification helper).

### Remaining backend work

1. **`GET /api/auth/me` route** — add one route to `auth.js` that returns `req.user` (decoded JWT). Currently 404.
2. **`/explain` endpoint in ML `app.py`** — `predictions.js` calls `POST /explain` on the ML service but `app.py` has no such route. Always returns `{shap_values: null}`.
3. **Socket.IO** — installed (`socket.io` in package.json) but never initialized in `index.js`. No real-time features work.
4. **Email** — SMTP credentials are set in `.env` (Mailtrap). Should work in dev, but never tested.
5. **`server/routes/aiService.js`** — stale duplicate of `services/aiService.js`. Harmless but misleading.
6. **Leftover files** — `server/groupController.js`, `server/meetingController.js`, `server/supervisorRequestController.js`, `server/notificationService.js` are old copies not imported anywhere. Dead code.

---

## 6. Database Status and Remaining Work

### Schema (40 tables in live fyp.db — all verified)

| Category | Tables |
|----------|--------|
| **Core** | users, user_profiles, departments |
| **Academic** | batches, programs, academic_years, semesters, sections |
| **Projects** | projects, project_supervisor_preferences, supervisor_requests, topic_reviews |
| **Groups** | project_groups, project_group_members, group_messages |
| **Work tracking** | milestones, submissions, document_versions, feedback, weekly_logs |
| **Communication** | notifications, announcements, meetings, deadlines |
| **Assessment** | rubrics, rubric_criteria, evaluations, evaluation_scores, viva_schedules, viva_panel |
| **AI/ML** | predictions (via projects columns), prediction_history, recommendations |
| **System** | audit_logs, activity_logs, token_blacklist, password_reset_tokens, email_queue, system_settings, notification_preferences |

**Schema quality:**
- All foreign keys enabled (`PRAGMA foreign_keys = ON`)
- WAL journal mode for concurrent reads
- All additive migrations run on every startup (`ALTER TABLE IF NOT EXISTS` pattern)
- Correct `CHECK` constraints on status/role enums
- `INSERT OR IGNORE` for seed data (ICT dept + BSCS/BSAI programs)
- Dual MySQL/SQLite support via `isMysql` flag

### What's missing

- No dedicated `indexes` beyond PKs and UNIQUEs — large table queries (`submissions`, `audit_logs`, `activity_logs`) could benefit from indexes on `project_id`, `user_id`, `created_at`
- `email_queue` table exists but no queue processor ever reads from it — emails are sent synchronously inline
- No database backup strategy or migration version tracking

---

## 7. GitHub Integration and Progress Tracking

### What's implemented (verified by code)

**`server/services/githubService.js`** — complete, production-quality integration:
- `parseGithubRepoUrl()` — validates and parses `https://github.com/owner/repo` format
- `fetchGithubRepo()` — repo metadata (language, stars, forks, default branch, size)
- `fetchGithubCommits()` — last 30 commits with author, date, message (first line)
- `fetchGithubPullRequests()` — open PRs (100) + recent closed (30), merged count
- `fetchGithubIssues()` — open and closed issues, correctly filters out PRs from issue list
- `fetchGithubActivity()` — derived metrics: active days, commit frequency, days since last push
- `getGithubProjectData()` — parallel fetch of all above in one call
- 8-second timeout per request with AbortController
- `GITHUB_TOKEN` optional authentication (falls back gracefully)
- Consistent error handling: 404 (repo not found), 403 (rate limit), timeout, network error

**`server/routes/github.js`** — IDOR-protected endpoint:
- Requires authenticated user
- Student: must own project or be active group member
- Supervisor: must be assigned supervisor
- Admin: any project
- Returns full `getGithubProjectData()` response

**Frontend `Projects.jsx`:**
- Student can link/update GitHub URL with regex validation
- GitHub Insights card shows: total commits, active days, open/merged PRs, open/closed issues, commit frequency bar, days since push bar, last 5 commits list
- Auto-loads on page load, manual refresh button

**`server/services/aiService.js`** — GitHub feeds into ML:
- `extractProjectFeatures()` fetches 17 features: 7 project DB features + 10 GitHub API features
- GitHub failure never crashes prediction (silent fallback to zeros)

### What's missing / issues

1. **No `GITHUB_TOKEN` in `.env`** — limited to 60 requests/hour. With multiple students this hits quickly. Key name exists in `.env.example` and code, just needs a value.
2. **`files_changed` always 0** — the feature exists in the model schema but the GitHub API would need per-commit diff calls (expensive). Currently hardcoded to 0.
3. **GitHub data is not persisted** — every prediction re-fetches from GitHub API. No caching layer.
4. **Supervisor/admin cannot see GitHub insights from their view** — only `Projects.jsx` (student view) renders the GitHub card. Supervisor dashboard doesn't.

---

## 8. ML Implementation and Remaining Work

### Historical synthetic artifacts (not the production model)

This report previously documented 1,500 generated records, 17 input features, Logistic Regression, Random Forest and Gradient Boosting artifacts, and an 85%/82% performance claim. The current workspace has no Git history and no original dataset or generator. The saved legacy `.pkl` estimators have 17 features and numeric classes `[0, 1, 2]`, but their feature order and label mapping cannot be recovered from the files. There is no saved evaluation report or reproducible original split. **The historical 85% accuracy and 82% Macro F1 are unverified and were not reproduced.**

### Separate verified-outcome pipeline

The verified-outcome pipeline is `ml-service/train_model.py` with the read-only verified SQLite dataset in `ml-service/dataset.py`. It can train a leakage-safe Random Forest from verified outcomes and eligible pre-deadline feature snapshots. It is not called by the project-risk prediction route or AI Insights. When real labeled data is insufficient, it returns an explicit unavailable status.

### Current project-risk workflow

`ml-service/synthetic_risk_demo.py` generates a reproducible 1,500-row, 17-feature dataset under `ml-service/synthetic_risk_model/` and trains the Logistic Regression used for risk classification. It uses a training-only `StandardScaler`, stratified 80/20 split, and fixed seed 42. AI Insights labels the workflow **Synthetic Dataset Evaluation: Not Real-world Validation** and predicts only Low/Medium/High risk classes; it does not generate delay, completion, or failure probabilities.

Measured synthetic held-out results are recorded in `ml-service/synthetic_risk_model/synthetic_risk_17_evaluation.json`. They are new synthetic evaluation results, not real-world validation and not the earlier historical claims. Full assumptions, per-class results, and confusion matrix are included.

---

## 9. Proposal Alignment and Risk Prediction

### Proposal Alignment (Plagiarism Detection)

**What's implemented:**
- `server/routes/plagiarism.js` — two endpoints:
  - `GET /api/plagiarism/titles?title=...&exclude_id=...` — Jaccard similarity on all project titles, returns matches ≥ 30% similarity
  - `GET /api/plagiarism/submissions/:projectId` — cross-project submission title similarity ≥ 40%
- Both endpoints are mounted and verified working (HTTP 200, checked 4 projects in live test)
- Tokenization: lowercase, remove special chars, filter words < 4 chars, then set intersection/union

**Limitations — this is NOT full proposal alignment:**
- Only title text is compared, not the full project description, objectives, or document content
- Jaccard on bag-of-words is a very basic similarity metric (no TF-IDF, no semantic similarity)
- No frontend page to display plagiarism results to students or supervisors
- Cross-submission check only compares document titles, not file contents

**Verdict: Partially implemented — text similarity exists and works, but it is not a real "proposal alignment" feature. It cannot compare a student's proposed objectives against their actual implementation. It can only detect similar project titles.**

### Risk Prediction

**What's implemented (verified working):**
- Project risk prediction uses only the 17-feature synthetic Logistic Regression model for Low/Medium/High classes.
- Risk predictions are explicitly identified as synthetic and not real-world validated; they do not estimate completion, delay, or failure.
- A separate verified-outcome Random Forest pipeline is retained for actual outcomes and is not connected to AI Insights risk classification.
- Prediction history saved per project (`prediction_history` table)
- Predicted risk class and class probabilities are saved in risk history; delay and completion probabilities are not generated.
- Auto-generated recommendations (5 types)

**What's missing:**
- The separate verified-outcome pipeline still needs enough verified historical outcomes and eligible snapshots to train its research model.
- The model is re-called on every page load — no caching

---

## 10. Bugs, Technical Debt, and Integration Issues

### Verified bugs (from live testing and code inspection)

| ID | Severity | File | Issue | Status |
|----|----------|------|-------|--------|
| BUG-001 | ~~Critical~~ | `evaluations.js` line 182 | `FROM vivas` → fixed to `FROM viva_schedules` | ✅ FIXED |
| BUG-002 | ~~High~~ | `sqlite-schema.sql` + `fyp.db` | `group_messages` table missing | ✅ FIXED |
| BUG-003 | Medium | `auth.js` | `GET /auth/me` route missing — api.js calls it but gets 404 | 🐛 OPEN |
| BUG-004 | ~~Medium~~ | `index.js` | `settings` route not mounted | ✅ FIXED |
| BUG-005 | ~~Medium~~ | `index.js` | `plagiarism` route not mounted | ✅ FIXED |
| BUG-006 | ~~Low~~ | `MainLayout.jsx` | Duplicate sidebar nav entries (student + admin) | ✅ FIXED |
| BUG-007 | Medium | `app.py` | `/explain` endpoint missing — shap_values always null | 🐛 OPEN |
| BUG-008 | Low | `Groups.jsx` (old) | Active group member could be downgraded to `invited` status | ✅ FIXED |
| BUG-009 | Low | `ml-service/` | 6 React `.jsx` files (App.jsx, LoginPage.jsx, etc.) placed in ml-service/ — misplaced, unused dead code | 🐛 OPEN (cleanup needed) |

### Technical debt

| Issue | File(s) | Impact |
|-------|---------|--------|
| Dead controller files | `server/groupController.js`, `server/meetingController.js`, `server/supervisorRequestController.js`, `server/notificationService.js` | Confusion — duplicate logic of route files, never imported |
| Stale route file | `server/routes/aiService.js` | Duplicate of `services/aiService.js`, in wrong directory, not mounted |
| No Git repository | Project root | Cannot track changes, no version control history |
| No automated tests | Entire project | Any refactor can break functionality silently |
| Unpinned ML requirements | `ml-service/requirements.txt` | `flask`, `scikit-learn` etc. without version pins — may fail to install in future |
| Socket.IO installed but unused | `server/package.json`, `client/package.json` | `socket.io` and `socket.io-client` add to bundle size with zero benefit currently |
| `api.getMe()` calls non-existent route | `client/src/api/api.js` line ~50 | Silent 404 — any component using this will fail |
| Email queue table never processed | `server/database/sqlite-schema.sql` | `email_queue` table exists but no cron or processor reads it |
| `group_messages` in Group 3 leader | Live `fyp.db` | Student 1 (group_id=3, leader) had `status='invited'` due to old bug — partially fixed in migration but verify manually |

---

## 11. Prioritized Task Checklist

### 🔴 Critical (blocks core functionality)

- [ ] Add `GET /api/auth/me` route to `auth.js` (1 route, ~5 min)
- [ ] Initialize a Git repository (`git init`, `.gitignore`, first commit) — no version control exists
- [ ] Verify Group 3 leader data integrity in `fyp.db` (Student 1, user_id=42 status should be `active`)

### 🟠 High (significant missing features or broken integrations)

- [ ] Add `/explain` endpoint to `ml-service/app.py` (implement SHAP values OR return null gracefully instead of crashing)
- [ ] Build **Profile / User Settings page** — backend ready (`/api/profiles/me`)
- [ ] Add `GITHUB_TOKEN` to `server/.env` (prevents GitHub API rate-limiting)
- [ ] Delete dead controller files: `server/groupController.js`, `server/meetingController.js`, `server/supervisorRequestController.js`, `server/notificationService.js`
- [ ] Delete misplaced React files from `ml-service/` (App.jsx, LoginPage.jsx, AppLayout.jsx, AuthContext.jsx, Overview.jsx, StudentDashboard.jsx, api.js)
- [ ] Delete `server/routes/aiService.js` (stale duplicate)

### 🟡 Medium (improves completeness and UX)

- [ ] Build **Admin Viva Management UI** — backend complete at `/api/vivas`
- [ ] Build **System Settings UI** — backend at `/api/settings` (read/write, 5 settings keys)
- [ ] Build **Plagiarism Check UI** — add button in Projects page using `/api/plagiarism/titles`
- [ ] Add database indexes: `submissions(project_id)`, `audit_logs(user_id, created_at)`, `activity_logs(project_id)`, `notifications(user_id, is_read)`
- [ ] Pin versions in `ml-service/requirements.txt` (e.g., `flask==3.0.3`, `scikit-learn==1.5.1`)
- [ ] Write ML training startup script / add `"ml": "python ml-service/app.py"` to root `package.json`
- [ ] Initialize Socket.IO in `server/index.js` for real-time notifications OR remove the package

### 🟢 Low (polish, optimization, future-proofing)

- [ ] Implement email queue processor (cron or event-based) for `email_queue` table
- [ ] Cache GitHub API responses (Redis or in-memory TTL cache) to avoid rate-limit hits
- [ ] Add Swagger/OpenAPI documentation for the 30 route files
- [ ] Write at least one integration test suite (recommend Vitest for frontend, Supertest for backend)
- [ ] Set up Docker Compose for development environment
- [ ] Add nginx reverse proxy config for production deployment
- [ ] Fix `files_changed` feature (currently always 0 — requires GitHub diff API calls)

---

## 12. Recommended Implementation Order

The following order minimizes risk, unblocks existing features, and builds toward a demo-ready state:

### Phase 1 — Stability & Cleanup (1–2 hours)
1. `git init` + first commit (version control before anything else)
2. Add `GET /api/auth/me` to `auth.js` (~5 min)
3. Delete 7 dead files (controllers + misplaced React + stale route)
4. Add `GITHUB_TOKEN` to `.env`

### Phase 2 — Missing UI Pages (2–4 days)
5. **Profile page** — most-needed by all users
6. **Admin Viva Management UI** — completes the viva workflow
7. **System Settings UI** — simple read/update form for 5 settings keys
8. **Plagiarism check** — add a "Check similarity" button to Projects.jsx

### Phase 3 — ML & Integration (1–2 days)
9. Add `/explain` endpoint to `app.py` (return SHAP values using `shap` library or return null with 200)
10. Pin `requirements.txt` versions
11. Add ML startup to `package.json`

### Phase 4 — Quality & Testing (2–3 days)
12. Add DB indexes (3 ALTER TABLE statements)
13. Write 5–10 Supertest integration tests for the most critical API routes (auth, projects, evaluations)
14. Write 3–5 Vitest component tests for Login, Projects, AiInsights
15. Configure basic CI (GitHub Actions if repo is created)

### Phase 5 — Production Readiness (1 day)
16. Create `.gitignore` to exclude `fyp.db`, `uploads/`, `.env`, `node_modules/`, `*.pkl`
17. Set up environment-specific build configs
18. Document deployment steps in README.md

---

## Appendix A: Environment Variables

| Key | Location | Current State | Required For |
|-----|----------|---------------|-------------|
| `PORT` | `server/.env` | ✅ 5000 | Server startup |
| `DB_TYPE` | `server/.env` | ✅ sqlite | Database mode |
| `JWT_SECRET` | `server/.env` | ✅ Set | Token signing |
| `ML_SERVICE_URL` | `server/.env` | ✅ http://localhost:5001 | ML predictions |
| `EMAIL_HOST` | `server/.env` | ✅ live.smtp.mailtrap.io | Email delivery |
| `EMAIL_USER` | `server/.env` | ✅ Set | Email delivery |
| `EMAIL_PASS` | `server/.env` | ✅ Set | Email delivery |
| `GITHUB_TOKEN` | `server/.env` | ❌ Not set | Higher GitHub rate limit |
| `VITE_API_URL` | `client/.env` | ✅ /api | Frontend API proxy |

## Appendix B: Known Working Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@fyp.edu | Admin@2026Fyp! |

> ⚠️ Do not commit real credentials. This password is in `.env.example` (as a comment) — move it out before making the repository public.

## Appendix C: File Count Summary

| Layer | Key files | Count |
|-------|-----------|-------|
| Frontend pages | `client/src/pages/*.jsx` | 28 |
| Frontend components | `client/src/components/`, `Layout/` | 2 |
| Backend routes | `server/routes/*.js` | 30 |
| Backend middleware | `server/middleware/*.js` | 4 |
| Backend services | `server/services/*.js` | 4 |
| Database tables | `sqlite-schema.sql` | 40 |
| ML models | `ml-service/models/*.pkl` | 4 (+ 4 backups) |
| Dead/misplaced files | Various | 10 (should be deleted) |
