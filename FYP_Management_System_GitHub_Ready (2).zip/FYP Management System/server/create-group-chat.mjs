import pool from "./config/db.js";

try {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS group_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      group_id INTEGER NOT NULL,
      sender_id INTEGER NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (group_id)
        REFERENCES project_groups(id) ON DELETE CASCADE,
      FOREIGN KEY (sender_id)
        REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  console.log("Group messages table ready!");
} catch (error) {
  console.error("Error:", error.message);
}