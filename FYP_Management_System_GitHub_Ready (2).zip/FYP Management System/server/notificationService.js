import pool from '../config/db.js';

/**
 * Creates a notification for a user.
 * @param {number} userId - The ID of the user to notify.
 * @param {string} title - The title of the notification.
 * @param {string} message - The notification message.
 */
export const createNotification = async (userId, title, message) => {
  try {
    await pool.query('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)', [userId, title, message]);
  } catch (error) {
    console.error(`Failed to create notification for user ${userId}:`, error);
  }
};