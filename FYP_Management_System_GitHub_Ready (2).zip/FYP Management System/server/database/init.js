import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function initDatabase() {
  const database = process.env.DB_NAME || "fyp_management";
  if (!/^[A-Za-z0-9_]+$/.test(database)) {
    throw new Error("DB_NAME may contain only letters, numbers, and underscores.");
  }

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    multipleStatements: true,
  });

  try {
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${database}\``);
    await connection.changeUser({ database });
    const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
    await connection.query(schema);
    console.log(`Database "${database}" initialized successfully.`);
  } finally {
    await connection.end();
  }
}

initDatabase().catch((err) => {
  console.error("Database init failed:", err.code || err.message);
  if (err.code === "ECONNREFUSED") {
    console.error("\nMySQL is not running. Install XAMPP or MySQL, start the service, then run: npm run db:init");
  }
  process.exit(1);
});
