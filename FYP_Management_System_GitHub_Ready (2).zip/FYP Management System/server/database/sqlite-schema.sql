-- ============================================================
-- FYP Management System — SQLite Schema (Full Production)
-- ============================================================

PRAGMA foreign_keys = ON;

-- ─── CORE USERS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL,
  email      TEXT    NOT NULL UNIQUE,
  password   TEXT    NOT NULL,
  role       TEXT    NOT NULL DEFAULT 'student'
               CHECK(role IN ('student','supervisor','admin')),
  is_active  INTEGER NOT NULL DEFAULT 1,
  token_version INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    DEFAULT (datetime('now'))
);

-- ─── DEPARTMENTS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS departments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL UNIQUE,
  code       TEXT,
  hod_id     INTEGER,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (hod_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── BATCHES / COHORTS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS batches (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  department_id INTEGER NOT NULL,
  start_date    TEXT,
  end_date      TEXT,
  is_active     INTEGER DEFAULT 1,
  created_at    TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);

-- ─── USER PROFILES ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_profiles (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL UNIQUE,
  department_id  INTEGER,
  batch_id       INTEGER,
  student_id_no  TEXT,
  phone          TEXT,
  avatar_url     TEXT,
  bio            TEXT,
  cgpa           REAL    DEFAULT 0,
  specialization TEXT,
  max_students   INTEGER DEFAULT 5,
  FOREIGN KEY (user_id)       REFERENCES users(id)       ON DELETE CASCADE,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
  FOREIGN KEY (batch_id)      REFERENCES batches(id)     ON DELETE SET NULL
);

-- ─── PROJECTS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS projects (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id         INTEGER NOT NULL,
  supervisor_id      INTEGER,
  title              TEXT    NOT NULL,
  description        TEXT,
  category           TEXT,
  keywords           TEXT,
  domain             TEXT,
  status             TEXT    DEFAULT 'proposal'
                       CHECK(status IN ('proposal','in_progress','review','completed','rejected')),
  progress           INTEGER DEFAULT 0,
  risk_level         TEXT    DEFAULT 'low'
                       CHECK(risk_level IN ('low','medium','high')),
  delay_probability  REAL    DEFAULT 0,
  completion_chance  REAL    DEFAULT 100,
  expected_completion_date TEXT,
  actual_completion_date TEXT,
  outcome_status     TEXT
                       CHECK(outcome_status IN ('completed_on_time','delayed','failed')),
  outcome_verified   INTEGER NOT NULL DEFAULT 0
                       CHECK(outcome_verified IN (0,1)),
  verified_by        INTEGER,
  verified_at        TEXT,
  created_at         TEXT    DEFAULT (datetime('now')),
  updated_at         TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (student_id)    REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (verified_by)   REFERENCES users(id) ON DELETE SET NULL
);

-- ─── PREFERRED SUPERVISORS ─────────────────────────────────
CREATE TABLE IF NOT EXISTS project_supervisor_preferences (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id    INTEGER NOT NULL,
  supervisor_id INTEGER NOT NULL,
  preference_order INTEGER NOT NULL,
  status        TEXT DEFAULT 'pending'
                CHECK(status IN ('pending','accepted','declined','discussion')),
  created_at    TEXT DEFAULT (datetime('now')),
  UNIQUE(project_id, supervisor_id),
  UNIQUE(project_id, preference_order),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── SUPERVISOR REQUESTS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS supervisor_requests (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id       INTEGER NOT NULL,
  supervisor_id    INTEGER NOT NULL,
  project_id       INTEGER NOT NULL,
  status           TEXT    DEFAULT 'pending'
                     CHECK(status IN ('pending', 'accepted', 'rejected')),
  rejection_reason TEXT,
  created_at       TEXT    DEFAULT (datetime('now')),
  updated_at       TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (student_id)    REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id)    REFERENCES projects(id) ON DELETE CASCADE
);

-- ─── MILESTONES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS milestones (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id  INTEGER NOT NULL,
  title       TEXT    NOT NULL,
  description TEXT,
  due_date    TEXT,
  status      TEXT    DEFAULT 'pending'
                CHECK(status IN ('pending','in_progress','completed','overdue')),
  created_at  TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- ─── SUBMISSIONS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS submissions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id   INTEGER NOT NULL,
  student_id   INTEGER NOT NULL,
  type         TEXT    NOT NULL
                 CHECK(type IN ('proposal','report','document','final')),
  title        TEXT    NOT NULL,
  file_path    TEXT,
  notes        TEXT,
  status       TEXT    DEFAULT 'pending'
                 CHECK(status IN ('pending','approved','rejected','revision')),
  submitted_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id)    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS plagiarism_checks (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id         INTEGER NOT NULL,
  uploaded_by        INTEGER NOT NULL,
  original_filename  TEXT NOT NULL,
  word_count         INTEGER NOT NULL,
  similarity_percent INTEGER NOT NULL DEFAULT 0,
  extracted_text     TEXT NOT NULL,
  matches_json       TEXT NOT NULL DEFAULT '[]',
  created_at         TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── DOCUMENT VERSIONS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS document_versions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  submission_id INTEGER NOT NULL,
  file_path     TEXT    NOT NULL,
  version       INTEGER DEFAULT 1,
  uploaded_by   INTEGER,
  uploaded_at   TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE
);

-- ─── FEEDBACK ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id    INTEGER NOT NULL,
  supervisor_id INTEGER NOT NULL,
  submission_id INTEGER,
  message       TEXT    NOT NULL,
  rating        INTEGER DEFAULT 0,
  created_at    TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id)    REFERENCES projects(id)    ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id)       ON DELETE CASCADE,
  FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE SET NULL
);

-- ─── WEEKLY LOGS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS weekly_logs (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id     INTEGER NOT NULL,
  student_id     INTEGER NOT NULL,
  week_number    INTEGER NOT NULL,
  work_done      TEXT    NOT NULL,
  plan_next_week TEXT,
  blockers       TEXT,
  hours_worked   REAL    DEFAULT 0,
  status         TEXT    DEFAULT 'submitted'
                   CHECK(status IN ('submitted','reviewed')),
  supervisor_comment TEXT,
  submitted_at   TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id)    ON DELETE CASCADE
);

-- ─── DEADLINES ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS deadlines (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  description TEXT,
  due_date    TEXT NOT NULL,
  target_role TEXT DEFAULT 'all'
                CHECK(target_role IN ('all','student','supervisor')),
  created_by  INTEGER NOT NULL,
  created_at  TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── NOTIFICATIONS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  title      TEXT    NOT NULL,
  message    TEXT    NOT NULL,
  type       TEXT    DEFAULT 'info'
               CHECK(type IN ('info','warning','success','error')),
  is_read    INTEGER DEFAULT 0,
  link       TEXT,
  created_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── ANNOUNCEMENTS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS announcements (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  target_role TEXT DEFAULT 'all'
                CHECK(target_role IN ('all','student','supervisor','admin')),
  created_by  INTEGER NOT NULL,
  created_at  TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── MEETINGS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS meetings (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id    INTEGER NOT NULL,
  requested_by  INTEGER NOT NULL,
  agenda        TEXT,
  scheduled_at  TEXT,
  location      TEXT,
  meeting_type  TEXT DEFAULT 'in_person'
                  CHECK(meeting_type IN ('online','in_person')),
  status        TEXT DEFAULT 'pending'
                  CHECK(status IN ('pending','confirmed','cancelled','completed')),
  minutes       TEXT,
  created_at    TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (project_id)   REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (requested_by) REFERENCES users(id)    ON DELETE CASCADE
);

-- ─── VIVA SCHEDULES ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS viva_schedules (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id   INTEGER NOT NULL,
  batch_id     INTEGER,
  scheduled_at TEXT    NOT NULL,
  room         TEXT,
  mode         TEXT    DEFAULT 'in_person'
                 CHECK(mode IN ('online','in_person')),
  status       TEXT    DEFAULT 'scheduled'
                 CHECK(status IN ('scheduled','completed','postponed')),
  remarks      TEXT,
  created_at   TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (batch_id)   REFERENCES batches(id)  ON DELETE SET NULL
);

-- ─── VIVA PANEL ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS viva_panel (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  viva_id      INTEGER NOT NULL,
  evaluator_id INTEGER NOT NULL,
  role         TEXT    DEFAULT 'internal'
                 CHECK(role IN ('chair','internal','external')),
  UNIQUE(viva_id, evaluator_id),
  FOREIGN KEY (viva_id)      REFERENCES viva_schedules(id) ON DELETE CASCADE,
  FOREIGN KEY (evaluator_id) REFERENCES users(id)          ON DELETE CASCADE
);

-- ─── RUBRICS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rubrics (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id    INTEGER,
  name        TEXT    NOT NULL,
  total_marks INTEGER DEFAULT 100,
  created_by  INTEGER NOT NULL,
  created_at  TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (batch_id)   REFERENCES batches(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)   ON DELETE CASCADE
);

-- ─── RUBRIC CRITERIA ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rubric_criteria (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  rubric_id INTEGER NOT NULL,
  criterion TEXT    NOT NULL,
  max_marks INTEGER NOT NULL,
  FOREIGN KEY (rubric_id) REFERENCES rubrics(id) ON DELETE CASCADE
);

-- ─── EVALUATIONS / GRADES ───────────────────────────────────
CREATE TABLE IF NOT EXISTS evaluations (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id       INTEGER NOT NULL,
  viva_id          INTEGER,
  evaluator_id     INTEGER NOT NULL,
  rubric_id        INTEGER,
  supervisor_marks REAL,
  panel_marks      REAL,
  total_marks      REAL,
  grade            TEXT,
  comments         TEXT,
  evaluated_at     TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id)   REFERENCES projects(id)       ON DELETE CASCADE,
  FOREIGN KEY (viva_id)      REFERENCES viva_schedules(id) ON DELETE SET NULL,
  FOREIGN KEY (evaluator_id) REFERENCES users(id)          ON DELETE CASCADE,
  FOREIGN KEY (rubric_id)    REFERENCES rubrics(id)        ON DELETE SET NULL
);

-- ─── ACTIVITY LOGS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  project_id INTEGER,
  action     TEXT    NOT NULL,
  created_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
);

-- ─── AUDIT LOGS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER,
  action     TEXT    NOT NULL,
  entity     TEXT,
  entity_id  INTEGER,
  old_value  TEXT,   -- JSON stored as TEXT in SQLite
  new_value  TEXT,
  ip_address TEXT,
  user_agent TEXT,
  created_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── RECOMMENDATIONS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS recommendations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  message    TEXT    NOT NULL,
  priority   TEXT    DEFAULT 'medium'
               CHECK(priority IN ('low','medium','high')),
  created_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- ─── PREDICTION HISTORY ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS prediction_history (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id         INTEGER NOT NULL,
  risk_level         TEXT    CHECK(risk_level IN ('low','medium','high')),
  risk_score         REAL,
  delay_probability  REAL,
  completion_chance  REAL,
  model_version      TEXT,
  features_snapshot  TEXT,   -- JSON as TEXT
  created_at         TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_feature_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  snapshot_date TEXT NOT NULL,
  captured_at TEXT NOT NULL DEFAULT (datetime('now')),
  features_snapshot TEXT NOT NULL,
  UNIQUE(project_id, snapshot_date),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- ─── TOKEN BLACKLIST ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS token_blacklist (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  jti        TEXT    NOT NULL UNIQUE,
  expires_at TEXT    NOT NULL,
  created_at TEXT    DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── EMAIL QUEUE ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_queue (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  to_email   TEXT NOT NULL,
  subject    TEXT NOT NULL,
  body       TEXT NOT NULL,
  status     TEXT DEFAULT 'pending'
               CHECK(status IN ('pending','sent','failed')),
  attempts   INTEGER DEFAULT 0,
  created_at TEXT    DEFAULT (datetime('now')),
  sent_at    TEXT
);

-- ─── SYSTEM SETTINGS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS system_settings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  key_name    TEXT NOT NULL UNIQUE,
  value       TEXT,
  description TEXT,
  updated_at  TEXT DEFAULT (datetime('now'))
);

-- ─── DEFAULT SYSTEM SETTINGS ────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_submissions_project ON submissions(project_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_created ON audit_logs(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_activity_logs_project ON activity_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read);

INSERT OR IGNORE INTO system_settings (key_name, value, description) VALUES
  ('max_students_per_supervisor', '5',      'Maximum students a supervisor can handle'),
  ('allow_student_registration',  'true',   'Allow new student registrations'),
  ('plagiarism_threshold',        '30',     'Similarity % above which a warning is shown'),
  ('system_name',                 'ProjectFlow', 'Display name of the system'),
  ('academic_year',               '2025-2026',   'Current academic year');

CREATE TABLE IF NOT EXISTS programs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, department_id INTEGER NOT NULL,
  name TEXT NOT NULL, code TEXT NOT NULL UNIQUE, is_active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')), FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS academic_years (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, start_date TEXT, end_date TEXT,
  is_active INTEGER DEFAULT 1, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS semesters (
  id INTEGER PRIMARY KEY AUTOINCREMENT, academic_year_id INTEGER NOT NULL, name TEXT NOT NULL,
  number INTEGER NOT NULL, is_active INTEGER DEFAULT 1, FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE,
  UNIQUE(academic_year_id, number)
);
CREATE TABLE IF NOT EXISTS sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL, semester_id INTEGER NOT NULL,
  name TEXT NOT NULL, is_active INTEGER DEFAULT 1, FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
  FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE, UNIQUE(batch_id, semester_id, name)
);
CREATE TABLE IF NOT EXISTS project_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, leader_id INTEGER NOT NULL,
  program_id INTEGER, batch_id INTEGER, section_id INTEGER, status TEXT DEFAULT 'active',
  created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (leader_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE SET NULL,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL, FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS project_group_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  role TEXT DEFAULT 'member' CHECK(role IN ('leader','member')), status TEXT DEFAULT 'active' CHECK(status IN ('invited','active','rejected','removed')),
  invited_by INTEGER, joined_at TEXT DEFAULT (datetime('now')), UNIQUE(group_id,user_id),
  FOREIGN KEY (group_id) REFERENCES project_groups(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (invited_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS topic_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, reviewer_id INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('approved','rejected','changes_requested')), comments TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')), FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY(reviewer_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS evaluation_scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT, evaluation_id INTEGER NOT NULL, criterion_id INTEGER NOT NULL,
  marks REAL NOT NULL, comments TEXT, FOREIGN KEY(evaluation_id) REFERENCES evaluations(id) ON DELETE CASCADE,
  FOREIGN KEY(criterion_id) REFERENCES rubric_criteria(id) ON DELETE CASCADE, UNIQUE(evaluation_id,criterion_id)
);
CREATE TABLE IF NOT EXISTS notification_preferences (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, event_key TEXT NOT NULL,
  in_app INTEGER DEFAULT 1, email INTEGER DEFAULT 0, updated_at TEXT DEFAULT (datetime('now')),
  UNIQUE(user_id,event_key), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
INSERT OR IGNORE INTO departments (name, code) VALUES ('ICT Department', 'ICT');
INSERT OR IGNORE INTO programs (department_id, name, code)
SELECT id, 'Bachelor of Science in Computer Science', 'BSCS' FROM departments WHERE code = 'ICT';
INSERT OR IGNORE INTO programs (department_id, name, code)
SELECT id, 'Bachelor of Science in Artificial Intelligence', 'BSAI' FROM departments WHERE code = 'ICT';

-- ─── GROUP MESSAGES (GROUP CHAT) ────────────────────────────
CREATE TABLE IF NOT EXISTS group_messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id   INTEGER NOT NULL,
  sender_id  INTEGER NOT NULL,
  message    TEXT    NOT NULL,
  created_at TEXT    DEFAULT (datetime('now')),
  FOREIGN KEY (group_id)  REFERENCES project_groups(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id)           ON DELETE CASCADE
);
