CREATE TABLE IF NOT EXISTS group_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    role ENUM('leader', 'member', 'supervisor') NOT NULL DEFAULT 'member',
    status ENUM('active', 'pending', 'left', 'removed') NOT NULL DEFAULT 'active',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY unique_group_user (group_id, user_id),

    INDEX idx_group_members_group (group_id),
    INDEX idx_group_members_user (user_id),

    CONSTRAINT fk_group_members_group
        FOREIGN KEY (group_id)
        REFERENCES groups(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_group_members_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS group_invitations (
    id INT AUTO_INCREMENT PRIMARY KEY,

    group_id INT NOT NULL,
    invited_user_id INT NOT NULL,
    invited_by INT NOT NULL,

    invitation_type ENUM(
        'student',
        'supervisor'
    ) NOT NULL DEFAULT 'student',

    status ENUM(
        'pending',
        'accepted',
        'rejected',
        'cancelled'
    ) NOT NULL DEFAULT 'pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP NULL DEFAULT NULL,

    INDEX idx_group_invitation_group (group_id),
    INDEX idx_group_invitation_user (invited_user_id),
    INDEX idx_group_invitation_status (status),

    CONSTRAINT fk_group_invitation_group
        FOREIGN KEY (group_id)
        REFERENCES groups(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_group_invitation_user
        FOREIGN KEY (invited_user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_group_invitation_sender
        FOREIGN KEY (invited_by)
        REFERENCES users(id)
        ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS group_messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    group_id INT NOT NULL,
    sender_id INT NOT NULL,

    message TEXT NOT NULL,

    message_type ENUM(
        'text',
        'file',
        'system'
    ) NOT NULL DEFAULT 'text',

    file_url VARCHAR(500) NULL,
    file_name VARCHAR(255) NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    edited_at TIMESTAMP NULL DEFAULT NULL,
    deleted_at TIMESTAMP NULL DEFAULT NULL,

    INDEX idx_group_messages_group (group_id),
    INDEX idx_group_messages_sender (sender_id),
    INDEX idx_group_messages_created (created_at),

    CONSTRAINT fk_group_messages_group
        FOREIGN KEY (group_id)
        REFERENCES groups(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_group_messages_sender
        FOREIGN KEY (sender_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS group_message_reads (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,

    message_id BIGINT NOT NULL,
    user_id INT NOT NULL,
    read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY unique_message_reader (message_id, user_id),

    CONSTRAINT fk_message_read_message
        FOREIGN KEY (message_id)
        REFERENCES group_messages(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_message_read_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);