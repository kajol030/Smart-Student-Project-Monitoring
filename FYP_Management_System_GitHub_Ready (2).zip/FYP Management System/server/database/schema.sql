-- ============================================================
-- FYP Management System — Complete MySQL Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
  role ENUM('student','supervisor','admin') NOT NULL DEFAULT 'student',
  is_active TINYINT NOT NULL DEFAULT 1,
  token_version INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS departments (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL UNIQUE,
  code VARCHAR(20), hod_id INT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (hod_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS batches (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
  department_id INT NOT NULL, start_date DATE, end_date DATE,
  is_active TINYINT DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS programs (id INT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL, name VARCHAR(150) NOT NULL, code VARCHAR(30) NOT NULL UNIQUE, is_active TINYINT DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS academic_years (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL UNIQUE, start_date DATE, end_date DATE, is_active TINYINT DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS semesters (id INT AUTO_INCREMENT PRIMARY KEY, academic_year_id INT NOT NULL, name VARCHAR(80) NOT NULL, number INT NOT NULL, is_active TINYINT DEFAULT 1, UNIQUE KEY uq_semester_year(academic_year_id,number), FOREIGN KEY(academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS sections (id INT AUTO_INCREMENT PRIMARY KEY, batch_id INT NOT NULL, semester_id INT NOT NULL, name VARCHAR(50) NOT NULL, is_active TINYINT DEFAULT 1, UNIQUE KEY uq_section(batch_id,semester_id,name), FOREIGN KEY(batch_id) REFERENCES batches(id) ON DELETE CASCADE, FOREIGN KEY(semester_id) REFERENCES semesters(id) ON DELETE CASCADE);
INSERT IGNORE INTO departments (name, code) VALUES ('ICT Department', 'ICT');
INSERT IGNORE INTO programs (department_id, name, code) SELECT id, 'Bachelor of Science in Computer Science', 'BSCS' FROM departments WHERE code = 'ICT';
INSERT IGNORE INTO programs (department_id, name, code) SELECT id, 'Bachelor of Science in Artificial Intelligence', 'BSAI' FROM departments WHERE code = 'ICT';
CREATE TABLE IF NOT EXISTS project_groups (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, leader_id INT NOT NULL, supervisor_id INT NULL, project_title VARCHAR(200) NULL, program_id INT NULL, batch_id INT NULL, section_id INT NULL, status VARCHAR(20) DEFAULT 'active', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(leader_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(supervisor_id) REFERENCES users(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS project_group_members (id INT AUTO_INCREMENT PRIMARY KEY, group_id INT NOT NULL, user_id INT NOT NULL, role ENUM('leader','member') DEFAULT 'member', status ENUM('invited','active','rejected','removed') DEFAULT 'invited', invited_by INT NULL, joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_group_member(group_id,user_id), FOREIGN KEY(group_id) REFERENCES project_groups(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS notification_preferences (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, event_key VARCHAR(80) NOT NULL, in_app TINYINT DEFAULT 1, email TINYINT DEFAULT 0, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_user_event(user_id,event_key), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS user_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL UNIQUE,
  department_id INT NULL, batch_id INT NULL, student_id_no VARCHAR(50),
  program_id INT NULL, semester_id INT NULL, section_id INT NULL,
  phone VARCHAR(20), avatar_url VARCHAR(500), bio TEXT,
  cgpa DECIMAL(3,2) DEFAULT 0, specialization VARCHAR(150), max_students INT DEFAULT 5,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL,
  supervisor_id INT NULL, title VARCHAR(255) NOT NULL, description TEXT,
  category VARCHAR(100), keywords VARCHAR(255), domain VARCHAR(100),
  group_id INT NULL, github_url VARCHAR(500),
  status ENUM('proposal','in_progress','review','completed','rejected') DEFAULT 'proposal',
  progress INT DEFAULT 0, risk_level ENUM('low','medium','high') DEFAULT 'low',
  delay_probability DECIMAL(5,2) DEFAULT 0, completion_chance DECIMAL(5,2) DEFAULT 100,
  expected_completion_date DATE NULL, actual_completion_date DATE NULL,
  outcome_status ENUM('completed_on_time','delayed','failed') NULL,
  outcome_verified TINYINT(1) NOT NULL DEFAULT 0,
  verified_by INT NULL, verified_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS topic_reviews (id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, reviewer_id INT NOT NULL, status ENUM('approved','rejected','changes_requested') NOT NULL, comments TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE, FOREIGN KEY(reviewer_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS project_supervisor_preferences (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  supervisor_id INT NOT NULL, preference_order INT NOT NULL,
  status ENUM('pending','accepted','declined','discussion') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_project_supervisor (project_id, supervisor_id),
  UNIQUE KEY uq_project_preference (project_id, preference_order),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS milestones (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  title VARCHAR(200) NOT NULL, description TEXT, due_date DATE,
  status ENUM('pending','in_progress','completed','overdue') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS submissions (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, student_id INT NOT NULL,
  type ENUM('proposal','report','document','final') NOT NULL,
  title VARCHAR(200) NOT NULL, file_path VARCHAR(500), notes TEXT,
  status ENUM('pending','approved','rejected','revision') DEFAULT 'pending',
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS plagiarism_checks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  uploaded_by INT NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  word_count INT NOT NULL,
  similarity_percent INT NOT NULL DEFAULT 0,
  extracted_text MEDIUMTEXT NOT NULL,
  matches_json JSON NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS document_versions (
  id INT AUTO_INCREMENT PRIMARY KEY, submission_id INT NOT NULL,
  file_path VARCHAR(500) NOT NULL, version INT DEFAULT 1, uploaded_by INT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  supervisor_id INT NOT NULL, submission_id INT NULL, message TEXT NOT NULL,
  rating INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS weekly_logs (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, student_id INT NOT NULL,
  week_number INT NOT NULL, work_done TEXT NOT NULL, plan_next_week TEXT,
  blockers TEXT, hours_worked DECIMAL(4,1) DEFAULT 0,
  status ENUM('submitted','reviewed') DEFAULT 'submitted',
  supervisor_comment TEXT, submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS deadlines (
  id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200) NOT NULL, description TEXT,
  due_date DATE NOT NULL, target_role ENUM('all','student','supervisor') DEFAULT 'all',
  created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
  title VARCHAR(255) NOT NULL, message TEXT NOT NULL,
  type ENUM('info','warning','success','error') DEFAULT 'info',
  is_read TINYINT DEFAULT 0, link VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, body TEXT NOT NULL,
  target_role ENUM('all','student','supervisor','admin') DEFAULT 'all',
  created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS meetings (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  requested_by INT NOT NULL, agenda TEXT, scheduled_at DATETIME,
  location VARCHAR(255), meeting_type ENUM('online','in_person') DEFAULT 'in_person',
  status ENUM('pending','confirmed','cancelled','completed') DEFAULT 'pending',
  minutes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (requested_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS viva_schedules (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, batch_id INT NULL,
  scheduled_at DATETIME NOT NULL, room VARCHAR(100),
  mode ENUM('online','in_person') DEFAULT 'in_person',
  status ENUM('scheduled','completed','postponed') DEFAULT 'scheduled',
  remarks TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS viva_panel (
  id INT AUTO_INCREMENT PRIMARY KEY, viva_id INT NOT NULL, evaluator_id INT NOT NULL,
  role ENUM('chair','internal','external') DEFAULT 'internal',
  UNIQUE KEY uq_viva_eval (viva_id, evaluator_id),
  FOREIGN KEY (viva_id) REFERENCES viva_schedules(id) ON DELETE CASCADE,
  FOREIGN KEY (evaluator_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS rubrics (
  id INT AUTO_INCREMENT PRIMARY KEY, batch_id INT NULL, name VARCHAR(200) NOT NULL,
  total_marks INT DEFAULT 100, created_by INT NOT NULL, is_active TINYINT DEFAULT 1,
  passing_marks DECIMAL(5,2) DEFAULT 50, stage VARCHAR(30) DEFAULT 'final',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS rubric_criteria (
  id INT AUTO_INCREMENT PRIMARY KEY, rubric_id INT NOT NULL,
  criterion VARCHAR(255) NOT NULL, max_marks INT NOT NULL, weight DECIMAL(6,2) DEFAULT 0,
  FOREIGN KEY (rubric_id) REFERENCES rubrics(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS evaluations (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  viva_id INT NULL, evaluator_id INT NOT NULL, rubric_id INT NULL,
  supervisor_marks DECIMAL(5,2), panel_marks DECIMAL(5,2),
  total_marks DECIMAL(5,2), grade VARCHAR(5), comments TEXT,
  evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (viva_id) REFERENCES viva_schedules(id) ON DELETE SET NULL,
  FOREIGN KEY (evaluator_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (rubric_id) REFERENCES rubrics(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS evaluation_scores (id INT AUTO_INCREMENT PRIMARY KEY, evaluation_id INT NOT NULL, criterion_id INT NOT NULL, marks DECIMAL(6,2) NOT NULL, comments TEXT, UNIQUE KEY uq_eval_criterion(evaluation_id,criterion_id), FOREIGN KEY(evaluation_id) REFERENCES evaluations(id) ON DELETE CASCADE, FOREIGN KEY(criterion_id) REFERENCES rubric_criteria(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, project_id INT NULL,
  action VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL,
  action VARCHAR(255) NOT NULL, entity VARCHAR(100), entity_id INT NULL,
  old_value JSON, new_value JSON, ip_address VARCHAR(45), user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS recommendations (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, message TEXT NOT NULL,
  priority ENUM('low','medium','high') DEFAULT 'medium',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS prediction_history (
  id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL,
  risk_level ENUM('low','medium','high'), risk_score DECIMAL(6,4),
  delay_probability DECIMAL(5,2), completion_chance DECIMAL(5,2),
  model_version VARCHAR(50) DEFAULT 'rule_based', features_snapshot JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS project_feature_snapshots (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  snapshot_date DATE NOT NULL,
  captured_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  features_snapshot JSON NOT NULL,
  UNIQUE KEY uq_project_feature_snapshot(project_id, snapshot_date),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
  token_hash VARCHAR(128) NOT NULL UNIQUE, expires_at DATETIME NOT NULL,
  used_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS token_blacklist (
  id INT AUTO_INCREMENT PRIMARY KEY, jti VARCHAR(255) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS email_queue (
  id INT AUTO_INCREMENT PRIMARY KEY, to_email VARCHAR(150) NOT NULL,
  subject VARCHAR(255) NOT NULL, body TEXT NOT NULL,
  status ENUM('pending','sent','failed') DEFAULT 'pending',
  attempts INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, sent_at TIMESTAMP NULL
);
CREATE TABLE IF NOT EXISTS system_settings (
  id INT AUTO_INCREMENT PRIMARY KEY, key_name VARCHAR(100) NOT NULL UNIQUE,
  value TEXT, description VARCHAR(255),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT IGNORE INTO system_settings (key_name,value,description) VALUES
  ('max_students_per_supervisor','5','Max students per supervisor'),
  ('allow_student_registration','true','Allow public student registration'),
  ('plagiarism_threshold','30','Similarity % threshold for warning'),
  ('system_name','ProjectFlow','System display name'),
  ('academic_year','2025-2026','Current academic year');
