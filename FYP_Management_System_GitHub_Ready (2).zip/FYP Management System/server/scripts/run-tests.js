import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const serverDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const temporaryDirectory = mkdtempSync(path.join(os.tmpdir(), "fyp-server-tests-"));
const result = spawnSync(process.execPath, ["--test", "test/*.js"], {
  cwd: serverDirectory,
  env: {
    ...process.env,
    DB_TYPE: "sqlite",
    FYP_DB_PATH: path.join(temporaryDirectory, "test.sqlite"),
    NODE_ENV: "test",
  },
  stdio: "inherit",
});

rmSync(temporaryDirectory, { recursive: true, force: true });
process.exitCode = result.status ?? 1;
