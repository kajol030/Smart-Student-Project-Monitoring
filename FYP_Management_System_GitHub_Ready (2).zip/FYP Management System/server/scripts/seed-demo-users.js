import bcrypt from "bcryptjs";
import pool from "../config/db.js";

const required = ["ADMIN_EMAIL", "ADMIN_PASSWORD", "SUPERVISOR_EMAIL", "SUPERVISOR_PASSWORD"];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(", ")}`);
  console.error("Passwords must be supplied through the terminal environment; they are never stored in source code or printed.");
  process.exit(1);
}

const accounts = [
  { name: process.env.ADMIN_NAME || "FYP Demo Admin", email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: "admin" },
  { name: process.env.SUPERVISOR_NAME || "FYP Demo Supervisor", email: process.env.SUPERVISOR_EMAIL, password: process.env.SUPERVISOR_PASSWORD, role: "supervisor" },
];

for (const account of accounts) {
  if (account.password.length < 8 || !/[A-Z]/.test(account.password) || !/[a-z]/.test(account.password) || !/[0-9]/.test(account.password) || !/[^A-Za-z0-9]/.test(account.password)) {
    console.error(`${account.role} password does not meet the required strength policy.`);
    process.exit(1);
  }
  const hash = await bcrypt.hash(account.password, 12);
  const [[existing]] = await pool.query("SELECT id FROM users WHERE email=?", [account.email]);
  if (existing) {
    await pool.query("UPDATE users SET name=?,password=?,role=?,is_active=1 WHERE id=?", [account.name, hash, account.role, existing.id]);
    await ensureProfile(existing.id);
    console.log(`${account.role} account updated: ${account.email}`);
  } else {
    const [result] = await pool.query("INSERT INTO users (name,email,password,role,is_active) VALUES (?,?,?,?,1)", [account.name, account.email, hash, account.role]);
    await ensureProfile(result.insertId);
    console.log(`${account.role} account created: ${account.email}`);
  }
}

async function ensureProfile(userId) {
  await pool.query("INSERT OR IGNORE INTO user_profiles (user_id) VALUES (?)", [userId])
    .catch(() => pool.query("INSERT IGNORE INTO user_profiles (user_id) VALUES (?)", [userId]));
}

console.log("Demo role accounts seeded with hashed passwords.");
