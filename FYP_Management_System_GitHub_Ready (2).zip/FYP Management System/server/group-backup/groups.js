import express from "express";

import {
    getGroupMembers,
    inviteGroupMember,
    inviteSupervisor,
    getGroupInvitations,
    respondGroupInvitation,
    getMessages,
    sendMessage
} from "../controllers/groupController.js";

const router = express.Router();

router.get("/:groupId/members", getGroupMembers);

router.post(
    "/:groupId/invite",
    inviteGroupMember
);

router.post(
    "/:groupId/invite-supervisor",
    inviteSupervisor
);

router.get(
    "/invitations",
    getGroupInvitations
);

router.patch(
    "/invitations/:id",
    respondGroupInvitation
);

router.get(
    "/:groupId/messages",
    getMessages
);

router.post(
    "/:groupId/messages",
    sendMessage
);

export default router;