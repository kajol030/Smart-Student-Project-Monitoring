import pool from "../config/db.js";

async function isGroupMember(groupId, userId) {
    const [rows] = await pool.query(
        `
        SELECT *
        FROM group_members
        WHERE group_id = ?
          AND user_id = ?
          AND status = 'active'
        LIMIT 1
        `,
        [groupId, userId]
    );

    return rows[0] || null;
}


export async function getGroupMembers(req, res) {
    try {
        const groupId = Number(req.params.groupId);

        const [members] = await pool.query(
            `
            SELECT
                gm.id,
                gm.group_id,
                gm.user_id,
                gm.role,
                gm.status,
                gm.joined_at,
                u.name,
                u.email,
                u.role AS user_role
            FROM group_members gm
            JOIN users u ON u.id = gm.user_id
            WHERE gm.group_id = ?
              AND gm.status = 'active'
            ORDER BY
                FIELD(gm.role, 'leader', 'supervisor', 'member'),
                u.name
            `,
            [groupId]
        );

        res.json(members);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to load group members."
        });
    }
}


export async function inviteGroupMember(req, res) {
    try {
        const groupId = Number(req.params.groupId);
        const { userId } = req.body;

        const inviterId = req.user.id;

        const membership = await isGroupMember(groupId, inviterId);

        if (!membership) {
            return res.status(403).json({
                message: "You are not a member of this group."
            });
        }

        const [existing] = await pool.query(
            `
            SELECT *
            FROM group_members
            WHERE group_id = ?
              AND user_id = ?
            LIMIT 1
            `,
            [groupId, userId]
        );

        if (existing.length && existing[0].status === "active") {
            return res.status(400).json({
                message: "User is already a group member."
            });
        }

        const [pending] = await pool.query(
            `
            SELECT *
            FROM group_invitations
            WHERE group_id = ?
              AND invited_user_id = ?
              AND status = 'pending'
            LIMIT 1
            `,
            [groupId, userId]
        );

        if (pending.length) {
            return res.status(400).json({
                message: "Invitation already pending."
            });
        }

        await pool.query(
            `
            INSERT INTO group_invitations
                (group_id, invited_user_id, invited_by, invitation_type)
            VALUES (?, ?, ?, 'student')
            `,
            [groupId, userId, inviterId]
        );

        res.json({
            message: "Group invitation sent."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to send invitation."
        });
    }
}


export async function inviteSupervisor(req, res) {
    try {
        const groupId = Number(req.params.groupId);
        const supervisorId = Number(req.body.supervisorId);

        const inviterId = req.user.id;

        const membership = await isGroupMember(groupId, inviterId);

        if (!membership) {
            return res.status(403).json({
                message: "You are not a member of this group."
            });
        }

        const [supervisor] = await pool.query(
            `
            SELECT id, name, email
            FROM users
            WHERE id = ?
              AND role = 'supervisor'
            LIMIT 1
            `,
            [supervisorId]
        );

        if (!supervisor.length) {
            return res.status(404).json({
                message: "Supervisor not found."
            });
        }

        const [pending] = await pool.query(
            `
            SELECT id
            FROM group_invitations
            WHERE group_id = ?
              AND invited_user_id = ?
              AND status = 'pending'
            LIMIT 1
            `,
            [groupId, supervisorId]
        );

        if (pending.length) {
            return res.status(400).json({
                message: "Supervisor invitation is already pending."
            });
        }

        await pool.query(
            `
            INSERT INTO group_invitations
                (group_id, invited_user_id, invited_by, invitation_type)
            VALUES (?, ?, ?, 'supervisor')
            `,
            [groupId, supervisorId, inviterId]
        );

        res.json({
            message: "Supervisor invitation sent."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to invite supervisor."
        });
    }
}


export async function getGroupInvitations(req, res) {
    try {
        const userId = req.user.id;

        const [rows] = await pool.query(
            `
            SELECT
                gi.id,
                gi.group_id,
                gi.invitation_type,
                gi.status,
                gi.created_at,

                g.name AS group_name,

                inviter.name AS invited_by_name,

                inviter.id AS invited_by_id

            FROM group_invitations gi

            JOIN groups g
                ON g.id = gi.group_id

            JOIN users inviter
                ON inviter.id = gi.invited_by

            WHERE gi.invited_user_id = ?
              AND gi.status = 'pending'

            ORDER BY gi.created_at DESC
            `,
            [userId]
        );

        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to load invitations."
        });
    }
}


export async function respondGroupInvitation(req, res) {
    try {
        const invitationId = Number(req.params.id);
        const { status } = req.body;

        if (!["accepted", "rejected"].includes(status)) {
            return res.status(400).json({
                message: "Invalid invitation status."
            });
        }

        const userId = req.user.id;

        const [rows] = await pool.query(
            `
            SELECT *
            FROM group_invitations
            WHERE id = ?
              AND invited_user_id = ?
              AND status = 'pending'
            LIMIT 1
            `,
            [invitationId, userId]
        );

        if (!rows.length) {
            return res.status(404).json({
                message: "Invitation not found."
            });
        }

        const invitation = rows[0];

        await pool.query(
            `
            UPDATE group_invitations
            SET status = ?, responded_at = NOW()
            WHERE id = ?
            `,
            [status, invitationId]
        );

        if (status === "accepted") {
            const memberRole =
                invitation.invitation_type === "supervisor"
                    ? "supervisor"
                    : "member";

            await pool.query(
                `
                INSERT INTO group_members
                    (group_id, user_id, role, status)
                VALUES (?, ?, ?, 'active')
                ON DUPLICATE KEY UPDATE
                    role = VALUES(role),
                    status = 'active',
                    joined_at = NOW()
                `,
                [
                    invitation.group_id,
                    userId,
                    memberRole
                ]
            );
        }

        res.json({
            message:
                status === "accepted"
                    ? "Invitation accepted."
                    : "Invitation rejected."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to respond to invitation."
        });
    }
}


export async function getMessages(req, res) {
    try {
        const groupId = Number(req.params.groupId);
        const userId = req.user.id;

        const membership = await isGroupMember(groupId, userId);

        if (!membership) {
            return res.status(403).json({
                message: "You are not a member of this group."
            });
        }

        const [messages] = await pool.query(
            `
            SELECT
                gm.id,
                gm.group_id,
                gm.sender_id,
                gm.message,
                gm.message_type,
                gm.file_url,
                gm.file_name,
                gm.created_at,
                gm.edited_at,

                u.name AS sender_name

            FROM group_messages gm

            JOIN users u
                ON u.id = gm.sender_id

            WHERE gm.group_id = ?
              AND gm.deleted_at IS NULL

            ORDER BY gm.created_at ASC

            LIMIT 300
            `,
            [groupId]
        );

        res.json(messages);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to load messages."
        });
    }
}


export async function sendMessage(req, res) {
    try {
        const groupId = Number(req.params.groupId);
        const userId = req.user.id;
        const { message } = req.body;

        if (!message || !message.trim()) {
            return res.status(400).json({
                message: "Message cannot be empty."
            });
        }

        const membership = await isGroupMember(groupId, userId);

        if (!membership) {
            return res.status(403).json({
                message: "You are not a member of this group."
            });
        }

        const [result] = await pool.query(
            `
            INSERT INTO group_messages
                (group_id, sender_id, message)
            VALUES (?, ?, ?)
            `,
            [
                groupId,
                userId,
                message.trim()
            ]
        );

        const [rows] = await pool.query(
            `
            SELECT
                gm.id,
                gm.group_id,
                gm.sender_id,
                gm.message,
                gm.message_type,
                gm.created_at,
                u.name AS sender_name

            FROM group_messages gm

            JOIN users u
                ON u.id = gm.sender_id

            WHERE gm.id = ?
            `,
            [result.insertId]
        );

        res.status(201).json(rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Unable to send message."
        });
    }
}