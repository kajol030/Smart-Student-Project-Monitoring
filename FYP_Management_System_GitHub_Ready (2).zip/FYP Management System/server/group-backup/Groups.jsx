import { useEffect, useState } from "react";
import { Check, MessageCircle, Plus, Send, UserPlus, Users, X } from "lucide-react";
import { api, getStoredUser } from "../api/api";

export default function Groups() {
  const role = getStoredUser()?.role;
  const [groups, setGroups] = useState([]);
  const [students, setStudents] = useState([]);
  const [invites, setInvites] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "" });
  const [invite, setInvite] = useState({ groupId: "", userId: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatText, setChatText] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

 const load = async () => {
  try {
    setGroups(await api.getGroups());

    if (role === "student") {
      setInvites(await api.getGroupInvitations());
      setStudents(await api.getStudentPeers().catch(() => []));
    }

    if (role === "admin") {
      setStudents(await api.getStudents().catch(() => []));
    }
  } catch (err) {
    setError(err.message);
  }
};

  useEffect(() => {
    let ignore = false;
    async function loadGroups() {
      try {
        const [groupData, studentData, invitationData] = await Promise.all([
          api.getGroups(),
          role === "admin" ? api.getStudents().catch(() => []) : role === "student" ? api.getStudentPeers().catch(() => []) : Promise.resolve([]),
          role === "student" ? api.getGroupInvitations() : Promise.resolve([]),
        ]);
        if (!ignore) { setGroups(groupData || []); setStudents(studentData || []); setInvites(invitationData || []); }
      } catch (err) { if (!ignore) setError(err.message); }
    }
    loadGroups();
    return () => { ignore = true; };
  }, [role]);

  const create = async (event) => { event.preventDefault(); try { await api.createGroup(form); setMessage("Project group created."); setForm({ name: "" }); setOpen(false); load(); } catch (err) { setError(err.message); } };
  const sendInvite = async (event) => { event.preventDefault(); try { await api.inviteGroupMember(invite.groupId, invite.userId); setMessage("Group invitation sent."); setInvite({ groupId: invite.groupId, userId: "" }); } catch (err) { setError(err.message); } };
  const respond = async (id, status) => { try { await api.respondGroupInvitation(id, status); setInvites((current) => current.filter((item) => item.id !== id)); setMessage(`Invitation ${status}.`); } catch (err) { setError(err.message); } };
  const openChat = async (group) => {
    setSelectedGroup(group);
    setChatMessages([]);
    setChatLoading(true);
    setError("");

    try {
      const messages = await api.getGroupMessages(group.id);
      setChatMessages(messages || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setChatLoading(false);
    }
  };

  const sendMessage = async (event) => {
    event.preventDefault();

    if (!selectedGroup || !chatText.trim()) return;

    try {
      const newMessage = await api.sendGroupMessage(
        selectedGroup.id,
        chatText.trim()
      );

      setChatMessages((current) => [...current, newMessage]);
      setChatText("");
    } catch (err) {
      setError(err.message);
    }
  };
  return <div className="space-y-6">
    <div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Collaboration</p><h1 className="page-title">Project groups</h1><p className="page-subtitle">Build your FYP team and keep group membership visible.</p></div>{role === "student" && <button className="auth-submit" style={{ width: "auto", padding: "0 16px" }} onClick={() => setOpen((value) => !value)}><Plus size={16} /> Create group</button>}</div>
    {error && <div className="form-alert error">{error}</div>}{message && <div className="form-alert" style={{ color: "#2c8d7b", background: "#eaf8f4" }}>{message}</div>}
    {open && <form onSubmit={create} className="dashboard-card flex gap-3"><label className="field flex-1"><span>Group name</span><input value={form.name} onChange={(event) => setForm({ name: event.target.value })} placeholder="e.g. Neural North" required /></label><button className="auth-submit" style={{ width: "auto", padding: "0 16px", alignSelf: "end" }}>Create</button></form>}
    {role === "student" && groups.length > 0 && students.length > 0 && <form onSubmit={sendInvite} className="dashboard-card flex flex-wrap gap-3"><select className="border rounded-lg px-3 py-2 flex-1" value={invite.groupId} onChange={(event) => setInvite({ ...invite, groupId: event.target.value })} required><option value="">Select your group</option>{groups.map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}</select><select className="border rounded-lg px-3 py-2 flex-1" value={invite.userId} onChange={(event) => setInvite({ ...invite, userId: event.target.value })} required><option value="">Select student</option>{students.map((student) => <option key={student.id} value={student.id}>{student.name}</option>)}</select><button className="auth-submit" style={{ width: "auto", padding: "0 16px" }}><UserPlus size={16} /> Invite member</button></form>}
    {invites.length > 0 && <section className="dashboard-card"><h2>Pending invitations</h2>{invites.map((item) => <div className="list-row" key={item.id}><div className="list-icon violet"><UserPlus size={16} /></div><div className="list-main"><strong>{item.group_name}</strong><span>Invited by {item.invited_by_name}</span></div><button className="icon-button" title="Accept" onClick={() => respond(item.id, "active")}><Check size={17} /></button><button className="icon-button" title="Reject" onClick={() => respond(item.id, "rejected")}><X size={17} /></button></div>)}</section>}
  
  
  </div>;
}
