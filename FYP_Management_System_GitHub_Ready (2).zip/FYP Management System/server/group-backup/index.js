import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import helmet from "helmet";
import { fileURLToPath } from "url";
import pool, { isMysql } from "./config/db.js";

import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import projectRoutes from "./routes/projects.js";
import milestoneRoutes from "./routes/milestones.js";
import submissionRoutes from "./routes/submissions.js";
import feedbackRoutes from "./routes/feedback.js";
import deadlineRoutes from "./routes/deadlines.js";
import vivaRoutes from "./routes/viva.js";
import weeklyLogRoutes from "./routes/weeklyLogs.js";
import meetingRoutes from "./routes/meetings.js";
import announcementRoutes from "./routes/announcements.js";
import departmentRoutes from "./routes/departments.js";
import batchRoutes from "./routes/batches.js";
import predictionRoutes from "./routes/predictions.js";
import profileRoutes from "./routes/profiles.js"; // Added missing import for profiles
import supervisorRequestRoutes from "./routes/supervisorRequests.js";
import notificationRoutes from "./routes/notifications.js";
import evaluationRoutes from "./routes/evaluations.js";
import auditLogRoutes from "./routes/auditLogs.js";
import projectGroupRoutes from "./routes/projectGroups.js";
import academicRoutes from "./routes/academic.js";
import searchRoutes from "./routes/search.js";
import preferenceRoutes from "./routes/preferences.js";
import reportRoutes from "./routes/reports.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors());
app.use(helmet());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.get("/api/health", (_, res) => {
  res.json({ status: "ok", message: "FYP Management API is running" });
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/milestones", milestoneRoutes);
app.use("/api/submissions", submissionRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/deadlines", deadlineRoutes);
app.use("/api/vivas", vivaRoutes);
app.use("/api/weekly-logs", weeklyLogRoutes);
app.use("/api/meetings", meetingRoutes);
app.use("/api/announcements", announcementRoutes);
app.use("/api/departments", departmentRoutes);
app.use("/api/batches", batchRoutes);
app.use("/api/predictions", predictionRoutes);
app.use("/api/profiles", profileRoutes); // Added missing mount for profiles
app.use("/api/supervisor-requests", supervisorRequestRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/evaluations", evaluationRoutes);
app.use("/api/audit-logs", auditLogRoutes);
app.use("/api/project-groups", projectGroupRoutes);
app.use("/api/academic", academicRoutes);
app.use("/api/search", searchRoutes);
app.use("/api/preferences", preferenceRoutes);
app.use("/api/reports", reportRoutes);

// Centralized error handler
app.use((err, req, res, next) => {
  console.error(`[${new Date().toISOString()}] ERROR on ${req.method} ${req.originalUrl}`);
  console.error(err.stack);

  // Avoid leaking stack trace in production
  res.status(500).json({ message: "An internal server error occurred." });
});

async function checkDatabase() {
  try {
    await pool.query("SELECT 1");
    console.log(isMysql ? "MySQL connected successfully." : "SQLite database ready.");
  } catch (err) {
    console.error("\nDatabase error:", err.code || err.message);
    if (isMysql) {
      console.error("   Start MySQL (XAMPP) and run: npm run db:init\n");
    }
  }
}

app.listen(PORT, async () => {
  console.log(`Server running on http://localhost:${PORT}`);
  await checkDatabase();
});
