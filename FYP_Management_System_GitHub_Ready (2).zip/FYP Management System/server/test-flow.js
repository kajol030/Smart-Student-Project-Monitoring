import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
// This file is for demonstrating the CORRECTED student-driven supervisor request flow.
// This file is for demonstrating the CORRECTED student-driven supervisor request flow.
// The old admin-assignment flow is removed.

dotenv.config();

const secret = process.env.JWT_SECRET || 'secret';

// --- USER TOKENS ---
// In a real scenario, these IDs would come from the database after registration.
const studentToken = jwt.sign({ id: 1, name: 'Student One', email: 'student@test.com', role: 'student' }, secret, { expiresIn: '7d' });
const supervisorToken1 = jwt.sign({ id: 2, name: 'Supervisor One', email: 'supervisor1@test.com', role: 'supervisor' }, secret, { expiresIn: '7d' });
const supervisorToken2 = jwt.sign({ id: 3, name: 'Supervisor Two', email: 'supervisor2@test.com', role: 'supervisor' }, secret, { expiresIn: '7d' });
const adminToken = jwt.sign({ id: 4, name: 'Admin One', email: 'admin@test.com', role: 'admin' }, secret, { expiresIn: '7d' });
const studentToken2 = jwt.sign({ id: 5, name: 'Student Two', email: 'student2@test.com', role: 'student' }, secret, { expiresIn: '7d' });

console.log('--- TEST 1: Student creates a project ---');
const createProjectRes = await fetch('http://localhost:5000/api/projects', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${studentToken}`,
  },
  body: JSON.stringify({ title: 'Test Project by Student', description: 'This is a test project.' }),
});
const project = await createProjectRes.json();
console.log('Create Project (Student 1):', createProjectRes.status, project);
const projectId = project.id;

console.log('\n--- TEST 2: Student requests a supervisor (Supervisor 1) ---');
const supervisorId1 = 2; // The ID of Supervisor One
const requestRes = await fetch('http://localhost:5000/api/supervisor-requests', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${studentToken}`,
  },
  body: JSON.stringify({ supervisor_id: supervisorId1, project_id: projectId }),
});
const requestData = await requestRes.json();
console.log('Send Request (Student 1 to Sup 1):', requestRes.status, requestData);
const requestId = requestData.id;

console.log('\n--- TEST 3: Supervisor 1 accepts the request ---');
const acceptRes = await fetch(`http://localhost:5000/api/supervisor-requests/${requestId}/respond`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${supervisorToken1}` },
    body: JSON.stringify({ status: 'accepted' }),
});
console.log('Accept Request:', acceptRes.status, await acceptRes.json());

console.log('\n--- TEST 4: Verify project supervisor_id updated ---');
const projectDetailsRes = await fetch(`http://localhost:5000/api/projects/${projectId}`, {
    headers: { Authorization: `Bearer ${adminToken}` },
});
console.log('View Project (Admin):', projectDetailsRes.status, await projectDetailsRes.json());

console.log('\n--- TEST 5: Student creates another project (for rejection test) ---');
const createProjectRes2 = await fetch('http://localhost:5000/api/projects', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${studentToken2}`,
  },
  body: JSON.stringify({ title: 'Test Project by Student 2', description: 'This is another test project.' }),
});
const project2 = await createProjectRes2.json();
console.log('Create Project (Student 2):', createProjectRes2.status, project2);
const projectId2 = project2.id;

console.log('\n--- TEST 6: Student 2 requests Supervisor 2 ---');
const supervisorId2 = 3; // The ID of Supervisor Two
const requestRes2 = await fetch('http://localhost:5000/api/supervisor-requests', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${studentToken2}`,
  },
  body: JSON.stringify({ supervisor_id: supervisorId2, project_id: projectId2 }),
});
const requestData2 = await requestRes2.json();
console.log('Send Request (Student 2 to Sup 2):', requestRes2.status, requestData2);
const requestId2 = requestData2.id;

console.log('\n--- TEST 7: Supervisor 2 rejects the request ---');
const rejectRes = await fetch(`http://localhost:5000/api/supervisor-requests/${requestId2}/respond`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${supervisorToken2}` },
    body: JSON.stringify({ status: 'rejected', reason: 'Supervision capacity full.' }),
});
console.log('Reject Request (Sup 2):', rejectRes.status, await rejectRes.json());

console.log('\n--- TEST 8: Verify project supervisor_id NOT updated after rejection ---');
const projectDetailsRes2 = await fetch(`http://localhost:5000/api/projects/${projectId2}`, {
    headers: { Authorization: `Bearer ${adminToken}` },
});
console.log('View Project (Admin after rejection):', projectDetailsRes2.status, await projectDetailsRes2.json());

console.log('\n--- TEST 9: Attempt by unauthorized student to request for another student\'s project ---');
const unauthorizedRequestRes = await fetch('http://localhost:5000/api/supervisor-requests', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${studentToken2}`, // Student 2 trying to request for Project 1
  },
  body: JSON.stringify({ supervisor_id: supervisorId1, project_id: projectId }),
});
console.log('Unauthorized Student Request:', unauthorizedRequestRes.status, await unauthorizedRequestRes.json());

console.log('\n--- TEST 10: Attempt by wrong supervisor (Sup 2) to respond to Sup 1\'s request ---');
const wrongSupervisorRespondRes = await fetch(`http://localhost:5000/api/supervisor-requests/${requestId}/respond`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${supervisorToken2}` }, // Sup 2 trying to respond to Sup 1's request
    body: JSON.stringify({ status: 'accepted' }),
});
console.log('Wrong Supervisor Respond:', wrongSupervisorRespondRes.status, await wrongSupervisorRespondRes.json());

console.log('\n--- TEST 11: Attempt to create a duplicate pending request for Project 1 ---');
const duplicateRequestRes = await fetch('http://localhost:5000/api/supervisor-requests', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${studentToken}` },
  body: JSON.stringify({ supervisor_id: supervisorId2, project_id: projectId }), // Student 1 trying to request again for Project 1
});
console.log('Duplicate Request:', duplicateRequestRes.status, await duplicateRequestRes.json());

console.log('\n--- TEST 12: Get AI Prediction for Project 1 ---');
const aiPredictionRes = await fetch(`http://localhost:5000/api/predictions/project/${projectId}`, {
    headers: { Authorization: `Bearer ${studentToken}` },
});
console.log('AI Prediction (Student 1):', aiPredictionRes.status, await aiPredictionRes.json());

console.log('\n--- TEST 13: Get AI Prediction for Project 1 (Admin) ---');
const aiPredictionAdminRes = await fetch(`http://localhost:5000/api/predictions/project/${projectId}`, {
    headers: { Authorization: `Bearer ${adminToken}` },
});
console.log('AI Prediction (Admin):', aiPredictionAdminRes.status, await aiPredictionAdminRes.json());

console.log('\n--- TEST 14: Get AI Prediction for Project 1 (Unauthorized Student 2) ---');
const aiPredictionUnauthorizedRes = await fetch(`http://localhost:5000/api/predictions/project/${projectId}`, {
    headers: { Authorization: `Bearer ${studentToken2}` },
});
console.log('AI Prediction (Unauthorized Student 2):', aiPredictionUnauthorizedRes.status, await aiPredictionUnauthorizedRes.json());
