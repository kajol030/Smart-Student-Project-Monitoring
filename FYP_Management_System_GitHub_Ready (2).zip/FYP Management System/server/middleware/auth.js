import jwt from "jsonwebtoken";
import pool from "../config/db.js";

export const auth = async (req, res, next) => {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer "))
    return res.status(401).json({ message: "Access denied. No token provided." });
  const token = header.split(" ")[1];
  let decoded;
  try { decoded = jwt.verify(token, process.env.JWT_SECRET); }
  catch { return res.status(401).json({ message: "Invalid or expired token." }); }
  try {
    const [[account]] = await pool.query(
      "SELECT is_active, token_version FROM users WHERE id = ?",
      [decoded.id],
    );
    if (!account || !Number(account.is_active)) {
      return res.status(401).json({ message: "Account is unavailable. Please log in again." });
    }
    if (Number(decoded.token_version ?? 0) !== Number(account.token_version ?? 0)) {
      return res.status(401).json({ message: "Token revoked. Please log in again." });
    }
    if (decoded.jti) {
      const [rows] = await pool.query("SELECT id FROM token_blacklist WHERE jti = ?", [decoded.jti]);
      if (rows.length) return res.status(401).json({ message: "Token revoked. Please log in again." });
    }
  } catch (error) {
    return next(error);
  }
  req.user = decoded;
  next();
};

export const authenticate = auth;

export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role))
      return res.status(403).json({ message: "You do not have permission." });
    next();
  };
};

export const isStudent = authorize('student');
export const isSupervisor = authorize('supervisor');
export const isAdmin = authorize('admin');
