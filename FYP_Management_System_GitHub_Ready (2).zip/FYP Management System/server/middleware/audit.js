import pool from "../config/db.js";

export async function auditLog(req, action, entity = null, entityId = null, oldVal = null, newVal = null) {
  try {
    await pool.query(
      `INSERT INTO audit_logs (user_id,action,entity,entity_id,old_value,new_value,ip_address,user_agent)
       VALUES (?,?,?,?,?,?,?,?)`,
      [req.user?.id||null, action, entity, entityId,
       oldVal ? JSON.stringify(oldVal) : null,
       newVal ? JSON.stringify(newVal) : null,
       req.ip||null, req.headers["user-agent"]||null]
    );
  } catch (e) { console.error("auditLog:", e.message); }
}

export async function notify(userId, title, message, type = "info", link = null) {
  try {
    await pool.query(
      "INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
      [userId, title, message, type, link]
    );
  } catch (e) { console.error("notify:", e.message); }
}
