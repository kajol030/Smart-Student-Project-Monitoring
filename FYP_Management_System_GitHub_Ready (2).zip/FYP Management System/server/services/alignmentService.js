import path from "node:path";
import { fileURLToPath } from "node:url";
import pool from "../config/db.js";
import { cosineSimilarity, extractObjectives, overlapTokens } from "../utils/textSimilarity.js";
import { computeImplementationProgress } from "./progressService.js";
import { getGithubProjectData, fetchGithubTree } from "./githubService.js";
import { extractProposalPdfText } from "./proposalTextService.js";

const uploadsDirectory = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
  "uploads"
);

function evidenceStatus(score) {
  if (score >= 45) return "strong_textual_match";
  if (score >= 25) return "possible_match";
  return "no_textual_evidence";
}

export function calculateAlignmentScore(requirements) {
  if (!requirements.length) return null;
  const mapped = requirements.filter((item) => item.status !== "no_textual_evidence").length;
  const strong = requirements.filter((item) => item.status === "strong_textual_match").length;
  return Math.round((strong * 100 + (mapped - strong) * 55) / requirements.length);
}

function buildEvidenceCorpus(rows, githubData, tree) {
  const items = [];
  for (const m of rows.milestones || []) {
    items.push({
      type: "milestone",
      id: m.id,
      title: m.title,
      text: `${m.title || ""} ${m.description || ""} ${m.status || ""}`,
      status: m.status,
    });
  }
  for (const s of rows.submissions || []) {
    items.push({
      type: "submission",
      id: s.id,
      title: s.title,
      text: `${s.title || ""} ${s.type || ""} ${s.status || ""} ${s.notes || ""}`,
      status: s.status,
    });
  }
  for (const log of rows.logs || []) {
    items.push({
      type: "weekly_log",
      id: log.id,
      title: `Week ${log.week_number || ""}`,
      text: `${log.work_done || ""} ${log.blockers || ""} ${log.plan_next_week || ""}`,
    });
  }
  if (githubData) {
    for (const c of githubData.commits?.commits || []) {
      items.push({ type: "github_commit", id: c.sha, title: c.message, text: c.message });
    }
    for (const pr of githubData.pull_requests?.recent_prs || []) {
      items.push({ type: "github_pr", id: pr.number, title: pr.title, text: pr.title });
    }
    for (const issue of githubData.issues?.open_issues || []) {
      items.push({ type: "github_issue", id: issue.number, title: issue.title, text: issue.title });
    }
    if (githubData.repository?.description) {
      items.push({
        type: "github_repo",
        id: "repo",
        title: githubData.repository.full_name,
        text: githubData.repository.description,
      });
    }
  }
  for (const file of tree?.paths || []) {
    items.push({
      type: "github_file",
      id: file,
      title: file,
      text: file.replace(/[\\/_.:-]+/g, " "),
    });
  }
  return items;
}

function bestMatch(objective, evidenceItems) {
  let best = null;
  for (const item of evidenceItems) {
    const cosine = cosineSimilarity(objective, item.text);
    if (!best || cosine > best.cosine) {
      best = {
        cosine,
        item,
        overlap: overlapTokens(objective, item.text),
      };
    }
  }
  return best;
}

export async function analyzeProposalAlignment(
  project,
  { includeGithub = true, allowPrivateGithub = true } = {}
) {
  const [milestones] = await pool.query(
    "SELECT id, title, description, status FROM milestones WHERE project_id=?",
    [project.id]
  );
  const [submissions] = await pool.query(
    "SELECT id, title, type, status, notes, file_path, submitted_at FROM submissions WHERE project_id=?",
    [project.id]
  );
  const [logs] = await pool.query(
    "SELECT id, week_number, work_done, blockers, plan_next_week FROM weekly_logs WHERE project_id=? ORDER BY id DESC LIMIT 20",
    [project.id]
  );

  let githubData = null;
  let tree = null;
  let githubError = null;
  let githubTreeError = null;
  if (includeGithub && project.github_url) {
    try {
      githubData = await getGithubProjectData(project.github_url, {
        allowPrivate: allowPrivateGithub,
      });
      try {
        tree = await fetchGithubTree(project.github_url);
      } catch (err) {
        githubTreeError = err.message;
      }
    } catch (err) {
      githubError = err.message;
    }
  }

  const approvedProposal = submissions
    .filter((submission) =>
      submission.type === "proposal" &&
      submission.status === "approved" &&
      submission.notes?.trim()
    )
    .sort((a, b) => Number(b.id) - Number(a.id))[0];
  let approvedProposalText = approvedProposal?.notes?.trim() || "";
  let proposalDocumentError = null;
  let extractedProposalDocument = false;
  if (approvedProposal?.file_path) {
    try {
      const extracted = await extractProposalPdfText(
        approvedProposal.file_path,
        uploadsDirectory
      );
      if (extracted.text) {
        approvedProposalText = [approvedProposalText, extracted.text]
          .filter(Boolean)
          .join("\n");
        extractedProposalDocument = true;
      } else {
        proposalDocumentError = "Approved proposal PDF contains no extractable text; scanned documents require OCR.";
      }
    } catch (err) {
      proposalDocumentError = err.message;
    }
  }
  const proposalDescription = approvedProposalText || project.description;
  const alignmentSource = extractedProposalDocument
    ? "approved_proposal_document"
    : approvedProposalText
      ? "approved_proposal_notes"
    : "project_title_description_and_keywords";

  const objectives = extractObjectives({
    title: project.title,
    description: proposalDescription,
    keywords: project.keywords,
  });

  const evidenceItems = buildEvidenceCorpus(
    { milestones, submissions, logs },
    githubData,
    tree
  );

  const requirements = objectives.map((objective, index) => {
    const match = bestMatch(objective, evidenceItems);
    const score = match?.cosine || 0;
    const status = evidenceStatus(score);
    return {
      id: index + 1,
      objective,
      status,
      textual_similarity: score,
      matched_evidence: match?.item
        ? {
            type: match.item.type,
            title: match.item.title,
            status: match.item.status || null,
            overlapping_terms: match.overlap,
          }
        : null,
      explanation:
        status === "no_textual_evidence"
          ? "No sufficiently similar milestone, submission, log, or repository text was found."
          : `Closest ${match.item.type.replaceAll("_", " ")} text scored ${score}% cosine similarity. This is textual overlap, not a test of the feature.`,
    };
  });

  const alignmentScore = calculateAlignmentScore(requirements);

  const implementation = await computeImplementationProgress(project.id, githubData);

  return {
    project_id: project.id,
    title: project.title,
    alignment_score: alignmentScore,
    alignment_source: alignmentSource,
    requirement_counts: {
      total: requirements.length,
      strong_textual_match: requirements.filter((r) => r.status === "strong_textual_match").length,
      possible_match: requirements.filter((r) => r.status === "possible_match").length,
      no_textual_evidence: requirements.filter((r) => r.status === "no_textual_evidence").length,
    },
    requirements,
    implementation_progress: implementation,
    github_error: githubError,
    github_tree_error: githubTreeError,
    proposal_document_error: proposalDocumentError,
    limitations: [
      "Alignment compares proposal wording with available text evidence (milestones, documents, logs, GitHub titles/paths).",
      "The latest approved proposal PDF is text-extracted locally when possible; scanned PDFs require OCR and other file formats are not extracted.",
      "Textual similarity is not the same as a verified working implementation.",
      "Source files in a repository do not prove a feature works without testing it.",
      "Commit counts are not treated as project completion.",
    ],
  };
}
