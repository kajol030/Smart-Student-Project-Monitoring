import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import mammoth from "mammoth";
import { cosineSimilarity } from "../utils/textSimilarity.js";

const MAX_TEXT_LENGTH = 100_000;
const MAX_PDF_PAGES = 100;
const MATCH_NGRAM_SIZE = 8;

function normalizedWords(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

function sentenceList(text) {
  return String(text || "")
    .split(/(?<=[.!?])\s+|\n+/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);
}

function extractExactMatches(submittedText, sourceText) {
  const sourcePhrases = new Map();
  for (const sentence of sentenceList(sourceText)) {
    const words = normalizedWords(sentence);
    for (let i = 0; i <= words.length - MATCH_NGRAM_SIZE; i += 1) {
      const phrase = words.slice(i, i + MATCH_NGRAM_SIZE).join(" ");
      if (!sourcePhrases.has(phrase)) sourcePhrases.set(phrase, sentence);
    }
  }

  const matches = [];
  const seen = new Set();
  for (const sentence of sentenceList(submittedText)) {
    const words = normalizedWords(sentence);
    for (let i = 0; i <= words.length - MATCH_NGRAM_SIZE; i += 1) {
      const phrase = words.slice(i, i + MATCH_NGRAM_SIZE).join(" ");
      const sourceSentence = sourcePhrases.get(phrase);
      if (!sourceSentence || seen.has(phrase)) continue;
      seen.add(phrase);
      matches.push({
        submitted_excerpt: sentence.slice(0, 300),
        source_excerpt: sourceSentence.slice(0, 300),
        matched_phrase: phrase,
      });
      if (matches.length >= 5) return matches;
    }
  }
  return matches;
}

export async function extractDocumentText(file) {
  if (!file?.buffer || !Buffer.isBuffer(file.buffer)) {
    throw new Error("A readable document file is required.");
  }

  const extension = String(file.originalname || "").toLowerCase().split(".").pop();
  let text;

  if (extension === "txt") {
    try {
      text = new TextDecoder("utf-8", { fatal: true }).decode(file.buffer);
    } catch {
      throw new Error("Text file must use valid UTF-8 encoding.");
    }
  } else if (extension === "pdf") {
    if (file.buffer.subarray(0, 5).toString() !== "%PDF-") {
      throw new Error("The uploaded file is not a valid PDF.");
    }

    let document;
    try {
      document = await getDocument({
        data: new Uint8Array(file.buffer),
        isEvalSupported: false,
        useSystemFonts: true,
        verbosity: 0,
      }).promise;
      const pages = [];
      const pageCount = Math.min(document.numPages, MAX_PDF_PAGES);
      for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
        const page = await document.getPage(pageNumber);
        const content = await page.getTextContent();
        pages.push(content.items.map((item) => item.str || "").join(" "));
        if (pages.join(" ").length >= MAX_TEXT_LENGTH) break;
      }
      text = pages.join("\n");
    } catch {
      throw new Error("PDF text could not be extracted. Use a readable, text-based PDF.");
    } finally {
      await document?.destroy();
    }
  } else if (extension === "docx") {
    if (file.buffer.subarray(0, 2).toString() !== "PK") {
      throw new Error("The uploaded file is not a valid DOCX document.");
    }
    try {
      const result = await mammoth.extractRawText({ buffer: file.buffer });
      text = result.value;
    } catch {
      throw new Error("DOCX text could not be extracted. Verify the document is not corrupted.");
    }
  } else {
    throw new Error("Only PDF, DOCX, and UTF-8 text files are supported.");
  }

  const extractedText = String(text || "").replace(/\u0000/g, "").trim().slice(0, MAX_TEXT_LENGTH);
  if (normalizedWords(extractedText).length < 4) {
    throw new Error("The document contains too little readable text to compare.");
  }
  return extractedText;
}

export function compareDocumentText(submittedText, sourceText) {
  return {
    similarity_percent: cosineSimilarity(submittedText, sourceText),
    matched_text: extractExactMatches(submittedText, sourceText),
  };
}

export function presentPlagiarismCheck(check, role) {
  const matches = typeof check.matches_json === "string"
    ? JSON.parse(check.matches_json)
    : check.matches_json || [];
  const visibleMatches = role === "admin"
    ? matches
    : matches.map(({ submitted_excerpt, matched_phrase }) => ({
      submitted_excerpt,
      matched_phrase,
    }));

  return {
    id: Number(check.id),
    project_id: Number(check.project_id),
    original_filename: check.original_filename,
    word_count: Number(check.word_count),
    similarity_percent: Number(check.similarity_percent),
    matched_text: visibleMatches,
    created_at: check.created_at,
  };
}
