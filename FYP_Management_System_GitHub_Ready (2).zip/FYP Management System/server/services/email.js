import nodemailer from "nodemailer";

function createTransport() {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || "smtp.mailtrap.io",
    port: Number(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: { user: process.env.EMAIL_USER || "", pass: process.env.EMAIL_PASS || "" },
  });
}

export async function sendEmail(toEmail, subject, html) {
  if (!process.env.EMAIL_USER) return;
  try {
    await createTransport().sendMail({
      from: `"${process.env.SYSTEM_NAME||"ProjectFlow"}" <${process.env.EMAIL_USER}>`,
      to: toEmail, subject, html,
    });
  } catch (e) { console.error("sendEmail:", e.message); }
}

export const emailTemplates = {
  welcome: (name) => ({
    subject: "Welcome to ProjectFlow",
    html: `<h2>Welcome, ${name}!</h2><p>Your account has been created.</p>`,
  }),
  passwordReset: (token) => ({
    subject: "Reset your ProjectFlow password",
    html: `<h2>Password reset requested</h2><p>Use this one-time verification token within 15 minutes:</p><p><b>${token}</b></p>`,
  }),
  proposalApproved: (name, title) => ({
    subject: "Your FYP Proposal Has Been Approved",
    html: `<h2>Congratulations, ${name}!</h2><p>Your project <b>"${title}"</b> has been approved.</p>`,
  }),
  proposalRejected: (name, title, reason) => ({
    subject: "FYP Proposal Not Approved",
    html: `<h2>Dear ${name},</h2><p>Your project <b>"${title}"</b> was rejected. ${reason||""}</p>`,
  }),
  vivaScheduled: (name, dt, room) => ({
    subject: "Viva Defense Scheduled",
    html: `<h2>Dear ${name},</h2><p>Your viva is on <b>${dt}</b>${room?` in <b>${room}</b>`:""}.</p>`,
  }),
};
