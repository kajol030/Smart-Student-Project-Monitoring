import pool, { isMysql } from "../config/db.js";

/**
 * Evidence-based implementation progress.
 * Milestone completion remains the stored `projects.progress` value.
 * This estimate additionally uses submissions, weekly logs, and GitHub
 * activity. Commit counts are never treated as percent complete.
 */
export function scoreGithubEvidence(githubData) {
  if (!githubData) {
    return {
      score: null,
      reasons: ["No GitHub evidence available."],
    };
  }

  const activity = githubData.activity || {};
  const prs = githubData.pull_requests || {};
  const issues = githubData.issues || {};
  const repo = githubData.repository || {};
  const reasons = [];
  let score = 0;

  const days = activity.recent_activity_days;
  if (days === 0 || days === 1) {
    score += 30;
    reasons.push("Repository was pushed within the last day (recency, not completion).");
  } else if (days != null && days <= 7) {
    score += 22;
    reasons.push("Repository activity within the last week.");
  } else if (days != null && days <= 21) {
    score += 12;
    reasons.push("Some recent repository activity.");
  } else {
    reasons.push("Little recent repository activity.");
  }

  if ((prs.merged_count || 0) > 0) {
    score += 20;
    reasons.push(`${prs.merged_count} merged pull request(s) indicate reviewed code changes.`);
  } else if ((prs.open_count || 0) > 0) {
    score += 8;
    reasons.push("Open pull requests exist but are not merged evidence of completion.");
  }

  if ((issues.recent_closed_count || 0) > 0) {
    score += 15;
    reasons.push("Recently closed issues suggest tracked work items being finished.");
  }
  if ((issues.open_count || 0) > 3) {
    score -= 5;
    reasons.push("Several open issues remain.");
  }

  if ((activity.active_days || 0) >= 5) {
    score += 15;
    reasons.push("Work is spread across multiple days rather than a single burst.");
  } else if ((activity.active_days || 0) >= 2) {
    score += 8;
  }

  if (repo.size > 0) {
    score += 10;
    reasons.push("Repository contains files (size > 0). File presence is not proof the features work.");
  }

  score = Math.max(0, Math.min(100, score));
  reasons.push("GitHub commit counts are not used as a completion percentage.");
  return { score, reasons };
}

export function calculateEvidenceEstimate(parts) {
  let weightedTotal = 0;
  let weightTotal = 0;
  for (const part of parts) {
    weightedTotal += part.value * part.weight;
    weightTotal += part.weight;
  }
  return weightTotal > 0 ? Math.round(weightedTotal / weightTotal) : null;
}

export async function computeImplementationProgress(projectId, githubData = null) {
  const [[milestones]] = await pool.query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed
     FROM milestones WHERE project_id=?`,
    [projectId]
  );
  const [[subs]] = await pool.query(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved,
            SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected
     FROM submissions WHERE project_id=?`,
    [projectId]
  );
  const recentExpr = isMysql
    ? "SUM(CASE WHEN submitted_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) THEN 1 ELSE 0 END)"
    : "SUM(CASE WHEN submitted_at >= datetime('now','-14 days') THEN 1 ELSE 0 END)";
  const [[logs]] = await pool.query(
    `SELECT COUNT(*) AS total, ${recentExpr} AS recent
     FROM weekly_logs WHERE project_id=?`,
    [projectId]
  );

  const mTotal = Number(milestones?.total) || 0;
  const mDone = Number(milestones?.completed) || 0;
  const milestonePct = mTotal ? Math.round((mDone / mTotal) * 100) : null;

  const sTotal = Number(subs?.total) || 0;
  const sApproved = Number(subs?.approved) || 0;
  const submissionPct = sTotal ? Math.round((sApproved / sTotal) * 100) : null;

  const logTotal = Number(logs?.total) || 0;
  const logRecent = Number(logs?.recent) || 0;
  const logPct = logTotal ? Math.min(100, Math.round((logRecent / Math.max(logTotal, 1)) * 100 + (logRecent > 0 ? 20 : 0))) : null;

  const github = scoreGithubEvidence(githubData);

  const parts = [];
  if (milestonePct != null) parts.push({ key: "milestones", weight: 0.4, value: milestonePct });
  if (submissionPct != null) parts.push({ key: "submissions", weight: 0.25, value: submissionPct });
  if (logPct != null) parts.push({ key: "weekly_logs", weight: 0.15, value: Math.min(100, logPct) });
  if (github.score != null) parts.push({ key: "github_evidence", weight: 0.2, value: github.score });

  const estimate = calculateEvidenceEstimate(parts);

  return {
    milestone_progress: milestonePct,
    evidence_estimate: estimate,
    components: {
      milestones: { completed: mDone, total: mTotal, percent: milestonePct },
      submissions: { approved: sApproved, total: sTotal, percent: submissionPct, rejected: Number(subs?.rejected) || 0 },
      weekly_logs: { recent: logRecent, total: logTotal, percent: logPct },
      github: github,
    },
    notes: [
      "Milestone progress is the official stored project progress.",
      "The evidence estimate combines milestones, reviewed submissions, weekly logs, and GitHub activity signals.",
      "Commit counts are not treated as project completion.",
      "Repository files and commit messages are not proof that a feature works without testing.",
    ],
  };
}
