/**
 * githubService.js
 *
 * Reusable service for fetching public GitHub repository data via the
 * GitHub REST API (v3).  No database writes.  No ML changes.
 *
 * Authentication is OPTIONAL:
 *   - Set GITHUB_TOKEN in .env for higher rate-limits (5 000 req/hr vs 60).
 *   - Public repos work without a token.
 *
 * All functions accept a full GitHub repository URL, e.g.:
 *   https://github.com/username/repository-name
 */

const GITHUB_API   = "https://api.github.com";
const FETCH_TIMEOUT_MS = 8000; // 8-second timeout per request
const CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_PAGES = 3;
const responseCache = new Map();

function cacheGet(key) {
  const hit = responseCache.get(key);
  if (!hit) return null;
  if (Date.now() > hit.expires) {
    responseCache.delete(key);
    return null;
  }
  return hit.value;
}

function cacheSet(key, value) {
  responseCache.set(key, { value, expires: Date.now() + CACHE_TTL_MS });
  return value;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/**
 * Build the Authorization header only when a token is present in env.
 * @returns {object} Headers object (may be empty).
 */
function _authHeaders() {
  const headers = {
    "Accept":     "application/vnd.github+json",
    "User-Agent": "FYP-Management-System/1.0",
    "X-GitHub-Api-Version": "2022-11-28",
  };
  if (process.env.GITHUB_TOKEN) {
    headers["Authorization"] = `Bearer ${process.env.GITHUB_TOKEN}`;
  }
  return headers;
}

/**
 * Thin fetch wrapper with AbortController timeout and consistent error
 * handling.  Mirrors the pattern used in aiService.js.
 *
 * @param {string} url - Full GitHub API URL.
 * @returns {Promise<object>} Parsed JSON response.
 * @throws {Error} With a descriptive message on any failure.
 */
async function _githubFetchResponse(url) {
  const parsedUrl = new URL(url);
  if (parsedUrl.origin !== GITHUB_API) {
    throw new Error("GitHub API pagination returned an unexpected host.");
  }

  const cached = cacheGet(url);
  if (cached) return cached;

  const ctrl    = new AbortController();
  const timer   = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);

  let response;
  try {
    response = await fetch(url, {
      headers: _authHeaders(),
      signal:  ctrl.signal,
    });
  } catch (err) {
    if (err.name === "AbortError") {
      throw new Error(`GitHub API request timed out after ${FETCH_TIMEOUT_MS / 1000}s: ${url}`);
    }
    throw new Error(`GitHub API network error: ${err.message}`);
  } finally {
    clearTimeout(timer);
  }

  if (response.status === 404) {
    throw new Error("GitHub repository not found or is not accessible to the configured account.");
  }
  if (response.status === 401) {
    throw new Error("GitHub authentication failed. Check the server-side GITHUB_TOKEN.");
  }
  if (response.status === 403 || response.status === 429) {
    const remaining = response.headers.get("x-ratelimit-remaining");
    const retryAfter = response.headers.get("retry-after");
    let responseMessage = "";
    try {
      responseMessage = (await response.clone().json()).message || "";
    } catch {
      // GitHub may return a non-JSON error body.
    }
    if (response.status === 429 || remaining === "0" || /rate limit/i.test(responseMessage)) {
      throw new Error(
        `GitHub API rate limit exceeded.${retryAfter ? ` Retry after ${retryAfter} seconds.` : " Set GITHUB_TOKEN server-side to increase the limit."}`
      );
    }
    throw new Error("GitHub API access forbidden (HTTP 403).");
  }
  if (!response.ok) {
    throw new Error(`GitHub API responded with HTTP ${response.status}: ${url}`);
  }

  const json = await response.json();
  const nextLink = response.headers.get("link")?.match(/<([^>]+)>;\s*rel="next"/)?.[1] || null;
  const result = { data: json, nextLink };
  return cacheSet(url, result);
}

async function _githubFetch(url) {
  return (await _githubFetchResponse(url)).data;
}

async function _githubFetchPages(url, maxPages = MAX_PAGES) {
  const items = [];
  let nextUrl = url;
  let page = 0;

  while (nextUrl && page < maxPages) {
    const result = await _githubFetchResponse(nextUrl);
    if (!Array.isArray(result.data)) {
      throw new Error("GitHub API returned an unexpected paginated response.");
    }
    items.push(...result.data);
    nextUrl = result.nextLink;
    page += 1;
  }

  return { items, capped: Boolean(nextUrl) };
}

// ---------------------------------------------------------------------------
// 1. parseGithubRepoUrl
// ---------------------------------------------------------------------------

/**
 * Parse a GitHub repository URL into owner and repo name.
 *
 * Accepts:
 *   https://github.com/username/repository
 *   https://github.com/username/repository/
 *
 * @param {string} githubUrl - The full GitHub repository URL.
 * @returns {{ owner: string, repo: string }}
 * @throws {Error} If the URL is not a valid GitHub repository URL.
 */
export function parseGithubRepoUrl(githubUrl) {
  if (!githubUrl || typeof githubUrl !== "string") {
    throw new Error("GitHub URL is required and must be a string.");
  }

  // Strip trailing slash then split
  const clean = githubUrl.trim().replace(/\/$/, "");

  // Must match https://github.com/<owner>/<repo>  (exactly two path segments)
  const match = clean.match(
    /^https:\/\/github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/
  );

  if (!match) {
    throw new Error(
      `Invalid GitHub repository URL: "${githubUrl}". ` +
      "Expected format: https://github.com/username/repository-name"
    );
  }

  return { owner: match[1], repo: match[2] };
}

// ---------------------------------------------------------------------------
// 2. fetchGithubRepo
// ---------------------------------------------------------------------------

/**
 * Fetch basic repository information from the GitHub REST API.
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   full_name: string,
 *   html_url: string,
 *   description: string|null,
 *   default_branch: string,
 *   language: string|null,
 *   stargazers_count: number,
 *   forks_count: number,
 *   open_issues_count: number,
 *   created_at: string,
 *   updated_at: string,
 *   pushed_at: string,
 *   visibility: string,
 *   size: number
 * }>}
 */
export async function fetchGithubRepo(githubUrl) {
  const { owner, repo } = parseGithubRepoUrl(githubUrl);
  const data = await _githubFetch(`${GITHUB_API}/repos/${owner}/${repo}`);

  return {
    full_name:        data.full_name,
    html_url:         data.html_url,
    description:      data.description   ?? null,
    default_branch:   data.default_branch,
    language:         data.language       ?? null,
    stargazers_count: data.stargazers_count,
    forks_count:      data.forks_count,
    open_issues_count: data.open_issues_count,
    created_at:       data.created_at,
    updated_at:       data.updated_at,
    pushed_at:        data.pushed_at,
    visibility:       data.visibility ?? "public",
    size:             data.size,       // disk size in KB
  };
}

// ---------------------------------------------------------------------------
// 3. fetchGithubCommits
// ---------------------------------------------------------------------------

/**
 * Fetch recent commits from the repository's default branch.
 *
 * Returns the last 30 commits (GitHub default page size).
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   total_fetched: number,
 *   commits: Array<{
 *     sha: string,
 *     message: string,
 *     author_name: string|null,
 *     author_login: string|null,
 *     date: string|null
 *   }>
 * }>}
 */
export async function fetchGithubCommits(githubUrl) {
  const { owner, repo } = parseGithubRepoUrl(githubUrl);

  const { items, capped } = await _githubFetchPages(
    `${GITHUB_API}/repos/${owner}/${repo}/commits?per_page=100`
  );

  const commits = items.map((item) => ({
    sha:          item.sha,
    message:      item.commit?.message?.split("\n")[0] ?? "", // first line only
    author_name:  item.commit?.author?.name  ?? null,
    author_login: item.author?.login         ?? null,
    date:         item.commit?.author?.date  ?? null,
  }));

  return {
    total_fetched: commits.length,
    capped,
    commits,
  };
}

export async function fetchGithubBranches(githubUrl) {
  const { owner, repo } = parseGithubRepoUrl(githubUrl);
  const { items, capped } = await _githubFetchPages(
    `${GITHUB_API}/repos/${owner}/${repo}/branches?per_page=100`
  );
  return {
    total_fetched: items.length,
    capped,
    branches: items.map((branch) => ({
      name: branch.name,
      protected: Boolean(branch.protected),
      commit_sha: branch.commit?.sha ?? null,
    })),
  };
}

// ---------------------------------------------------------------------------
// 4. fetchGithubPullRequests
// ---------------------------------------------------------------------------

/**
 * Fetch open and recently closed/merged pull requests.
 *
 * GitHub's PR API does not return a total count directly; we fetch up to
 * 100 open and 100 closed PRs (the maximum per_page allowed) and count them.
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   open_count: number,
 *   recent_closed_count: number,
 *   merged_count: number,
 *   recent_prs: Array<{
 *     number: number,
 *     title: string,
 *     state: string,
 *     merged: boolean,
 *     created_at: string,
 *     closed_at: string|null,
 *     merged_at: string|null,
 *     author_login: string|null
 *   }>
 * }>}
 */
export async function fetchGithubPullRequests(githubUrl) {
  const { owner, repo } = parseGithubRepoUrl(githubUrl);

  // Fetch open PRs and recently closed PRs in parallel
  const [openResult, closedResult] = await Promise.all([
    _githubFetchPages(
      `${GITHUB_API}/repos/${owner}/${repo}/pulls?state=open&per_page=100`
    ),
    _githubFetchPages(
      `${GITHUB_API}/repos/${owner}/${repo}/pulls?state=closed&per_page=100&sort=updated&direction=desc`
    ),
  ]);
  const { items: openItems } = openResult;
  const { items: closedItems } = closedResult;

  const mapPr = (pr) => ({
    number:       pr.number,
    title:        pr.title,
    state:        pr.state,
    merged:       Boolean(pr.merged_at),
    created_at:   pr.created_at,
    closed_at:    pr.closed_at   ?? null,
    merged_at:    pr.merged_at   ?? null,
    author_login: pr.user?.login ?? null,
  });

  const merged_count = closedItems.filter((pr) => pr.merged_at).length;

  return {
    open_count:          openItems.length,
    recent_closed_count: closedItems.length,
    merged_count,
    capped: openResult.capped || closedResult.capped,
    recent_prs:          [...openItems, ...closedItems].map(mapPr),
  };
}

// ---------------------------------------------------------------------------
// 5. fetchGithubIssues
// ---------------------------------------------------------------------------

/**
 * Fetch open and recently closed issues.
 *
 * The GitHub Issues API includes pull requests unless explicitly filtered
 * with `filter=issues` (which is not a standard param).  We use
 * `pulls` field presence to exclude PRs from the count.
 *
 * NOTE: GitHub's `/issues` endpoint returns both issues AND pull requests
 * unless the `pulls` field is absent.  We filter client-side by checking
 * `pull_request` key.
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   open_count: number,
 *   recent_closed_count: number,
 *   open_issues: Array<{
 *     number: number,
 *     title: string,
 *     state: string,
 *     created_at: string,
 *     closed_at: string|null,
 *     author_login: string|null
 *   }>
 * }>}
 */
export async function fetchGithubIssues(githubUrl) {
  const { owner, repo } = parseGithubRepoUrl(githubUrl);

  const [openResult, closedResult] = await Promise.all([
    _githubFetchPages(
      `${GITHUB_API}/repos/${owner}/${repo}/issues?state=open&per_page=100`
    ),
    _githubFetchPages(
      `${GITHUB_API}/repos/${owner}/${repo}/issues?state=closed&per_page=100&sort=updated&direction=desc`
    ),
  ]);
  const { items: openItems } = openResult;
  const { items: closedItems } = closedResult;

  // Exclude pull requests — GitHub issues API returns PRs too
  const isIssue     = (item) => !item.pull_request;
  const openIssues  = openItems.filter(isIssue);
  const closedIssues = closedItems.filter(isIssue);

  const mapIssue = (item) => ({
    number:       item.number,
    title:        item.title,
    state:        item.state,
    created_at:   item.created_at,
    closed_at:    item.closed_at   ?? null,
    author_login: item.user?.login ?? null,
  });

  return {
    open_count:          openIssues.length,
    recent_closed_count: closedIssues.length,
    capped: openResult.capped || closedResult.capped,
    open_issues:         openIssues.map(mapIssue),
  };
}

// ---------------------------------------------------------------------------
// 6. fetchGithubActivity
// ---------------------------------------------------------------------------

/**
 * Calculate development activity metrics from recent commits.
 *
 * Derived metrics (no extra API calls — uses commit data already fetched):
 *   - recent_commits:     number of commits returned (last 30)
 *   - active_days:        number of distinct calendar days with a commit
 *   - commit_frequency:   commits per active day (rounded to 2 dp)
 *   - recent_activity_days: days since the most recent commit
 *   - last_commit_date:   ISO date string of the most recent commit
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   recent_commits: number,
 *   active_days: number,
 *   commit_frequency: number,
 *   recent_activity_days: number,
 *   last_commit_date: string|null
 * }>}
 */
export async function fetchGithubActivity(githubUrl) {
  const { commits } = await fetchGithubCommits(githubUrl);

  if (commits.length === 0) {
    return {
      recent_commits:       0,
      active_days:          0,
      commit_frequency:     0,
      recent_activity_days: null,
      last_commit_date:     null,
    };
  }

  // Distinct calendar days that have at least one commit
  const daySet = new Set(
    commits
      .filter((c) => c.date)
      .map((c) => c.date.slice(0, 10)) // "YYYY-MM-DD"
  );
  const active_days = daySet.size;

  // Days since most recent commit
  const sortedDates = commits
    .filter((c) => c.date)
    .map((c) => new Date(c.date))
    .sort((a, b) => b - a);                // descending

  const lastDate   = sortedDates[0] ?? null;
  const now        = new Date();
  const recent_activity_days = lastDate
    ? Math.floor((now - lastDate) / (1000 * 60 * 60 * 24))
    : null;

  const commit_frequency =
    active_days > 0
      ? Math.round((commits.length / active_days) * 100) / 100
      : 0;

  return {
    recent_commits:       commits.length,
    active_days,
    commit_frequency,
    recent_activity_days,
    last_commit_date:     lastDate ? lastDate.toISOString() : null,
  };
}

// ---------------------------------------------------------------------------
// 7. getGithubProjectData  (combined entry-point)
// ---------------------------------------------------------------------------

/**
 * Fetch all available GitHub data for a repository in one call.
 *
 * Runs independent API calls in parallel where possible to minimise
 * total response time.
 *
 * @param {string} githubUrl - GitHub repository URL.
 * @returns {Promise<{
 *   repository: object,
 *   commits: object,
 *   pull_requests: object,
 *   issues: object,
 *   activity: object
 * }>}
 */
export async function fetchGithubTree(githubUrl) {
  const repo = await fetchGithubRepo(githubUrl);
  const { owner, repo: name } = parseGithubRepoUrl(githubUrl);
  const branch = repo.default_branch || "main";
  const tree = await _githubFetch(
    `${GITHUB_API}/repos/${owner}/${name}/git/trees/${encodeURIComponent(branch)}?recursive=1`
  );
  const paths = (tree.tree || [])
    .filter((item) => item.type === "blob")
    .map((item) => item.path)
    .slice(0, 250);
  return {
    truncated: Boolean(tree.truncated),
    file_count: paths.length,
    paths,
  };
}

export async function getGithubProjectData(githubUrl, { allowPrivate = true } = {}) {
  // Validate URL first — fail fast before any network calls
  parseGithubRepoUrl(githubUrl);
  const combinedKey = `project-data:${githubUrl}`;
  if (allowPrivate) {
    const cached = cacheGet(combinedKey);
    if (cached) return cached;
  }

  const repository = await fetchGithubRepo(githubUrl);
  if (repository.visibility !== "public" && !allowPrivate) {
    throw new Error("Private repository data is available only to the assigned supervisor or an administrator.");
  }

  // repo info, PRs and issues can be fetched in parallel.
  // commits must complete before activity (activity derives from commit data).
  const [branches, pull_requests, issues, commitsData] = await Promise.all([
    fetchGithubBranches(githubUrl),
    fetchGithubPullRequests(githubUrl),
    fetchGithubIssues(githubUrl),
    fetchGithubCommits(githubUrl),
  ]);

  // Activity is derived from commits already in memory — compute synchronously
  const commits = commitsData;

  // Recompute activity from the commits we already have (no extra API call)
  const activity = await _activityFromCommits(commits.commits);

  const result = {
    repository,
    branches,
    commits,
    pull_requests,
    issues,
    activity,
    cached: false,
    cache_ttl_seconds: CACHE_TTL_MS / 1000,
  };
  return allowPrivate ? cacheSet(combinedKey, result) : result;
}

// ---------------------------------------------------------------------------
// Internal: compute activity from a pre-fetched commits array
// (avoids a second fetchGithubCommits call inside getGithubProjectData)
// ---------------------------------------------------------------------------

/**
 * @param {Array} commitList - Array of mapped commit objects.
 * @returns {object}
 */
async function _activityFromCommits(commitList) {
  if (!commitList || commitList.length === 0) {
    return {
      recent_commits: 0, active_days: 0, commit_frequency: 0,
      recent_activity_days: null, last_commit_date: null,
    };
  }

  const daySet = new Set(
    commitList.filter((c) => c.date).map((c) => c.date.slice(0, 10))
  );
  const active_days = daySet.size;

  const sortedDates = commitList
    .filter((c) => c.date)
    .map((c) => new Date(c.date))
    .sort((a, b) => b - a);

  const lastDate = sortedDates[0] ?? null;
  const now      = new Date();
  const recent_activity_days = lastDate
    ? Math.floor((now - lastDate) / (1000 * 60 * 60 * 24))
    : null;

  return {
    recent_commits:       commitList.length,
    active_days,
    commit_frequency:     active_days > 0
      ? Math.round((commitList.length / active_days) * 100) / 100
      : 0,
    recent_activity_days,
    last_commit_date:     lastDate ? lastDate.toISOString() : null,
  };
}
