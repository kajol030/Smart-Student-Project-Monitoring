import pool from "../config/db.js";
import { notify } from "../middleware/audit.js";
import { sendEmail, emailTemplates } from "./email.js";

/**
 * Fetches user details and sends a notification.
 * @param {number} userId - The ID of the user to notify.
 * @param {string} title - The notification title.
 * @param {string} message - The notification message.
 * @param {string} type - The notification type (e.g., 'info', 'success').
 * @param {string} link - An optional link for the notification.
 */
export async function notifyUser(userId, title, message, type = "info", link = null) {
  if (!userId) return;
  try {
    await notify(userId, title, message, type, link);
  } catch (e) {
    console.error(`Failed to send notification to user ${userId}:`, e);
  }
}

/**
 * Fetches a student's email from a project ID and sends them an email.
 * @param {number} projectId - The ID of the project.
 * @param {(name: string, title: string, reason?: string) => {subject: string, html: string}} templateFn - A function from emailTemplates.
 * @param {string} reason - Optional reason, for rejection emails.
 */
export async function sendEmailToStudent(projectId, templateFn, reason = "") {
  if (!projectId) return;
  try {
    const [[project]] = await pool.query(
      `SELECT u.email, u.name, p.title FROM projects p
       JOIN users u ON p.student_id = u.id
       WHERE p.id = ?`, [projectId]
    );
    if (project?.email) {
      const { subject, html } = templateFn(project.name, project.title, reason);
      await sendEmail(project.email, subject, html);
    }
  } catch (e) {
    console.error(`Failed to send email for project ${projectId}:`, e);
  }
}