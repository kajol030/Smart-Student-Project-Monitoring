import pool from '../config/db.js';
import { isMysql } from '../config/db.js';
import { getGithubProjectData } from './githubService.js';

const ML_URL = process.env.ML_SERVICE_URL || "http://localhost:5001";

/**
 * Calls the external Flask ML service for predictions.
 * @param {object} payload - The features to send to the ML service.
 * @returns {Promise<object|null>} The ML service result or null if it is unreachable.
 */
export async function callMLService(payload) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  try {
    const r = await fetch(`${ML_URL}/demo/synthetic-risk/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: ctrl.signal,
    });
    if (!r.ok) {
      const body = await r.json().catch(() => ({}));
      if (r.status === 503 && body.model_info) {
        return { ...body, http_status: r.status };
      }
      console.error(`ML service responded with status ${r.status}: ${JSON.stringify(body)}`);
      return null;
    }
    return await r.json();
  } catch (error) {
    console.error("Error calling ML service:", error.message);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Safe default values for GitHub features when github_url is absent or
 * the GitHub API call fails.  Every field is 0 so downstream consumers
 * always receive a consistent shape.
 */
const GITHUB_DEFAULTS = {
  total_commits:        0,
  recent_commits:       0,
  commit_frequency:     0,
  active_days:          0,
  recent_activity_days: 0,
  pull_requests:        0,
  merged_prs:           0,
  open_issues:          0,
  closed_issues:        0,
  files_changed:        0,  // not available via current GitHub service; always 0
  github_evidence_available: false,
  github_evidence_note: null,
};

/**
 * Attempt to fetch GitHub metrics for a project.
 * Returns GITHUB_DEFAULTS on any failure — prediction system never crashes.
 *
 * @param {string|null} githubUrl
 * @returns {Promise<object>} GitHub feature object (always a complete shape).
 */
async function fetchGithubFeatures(githubUrl, allowPrivate = true) {
  if (!githubUrl || typeof githubUrl !== "string" || !githubUrl.trim()) {
    return { ...GITHUB_DEFAULTS, github_evidence_note: "No GitHub repository is linked." };
  }

  try {
    const gh = await getGithubProjectData(githubUrl, { allowPrivate });

    return {
      // commits
      total_commits:        gh.commits?.total_fetched                ?? 0,
      recent_commits:       gh.activity?.recent_commits              ?? 0,
      commit_frequency:     gh.activity?.commit_frequency            ?? 0,
      active_days:          gh.activity?.active_days                 ?? 0,
      recent_activity_days: gh.activity?.recent_activity_days        ?? 0,
      // pull requests — total open PRs as the primary "pull_requests" metric
      pull_requests:        gh.pull_requests?.open_count             ?? 0,
      merged_prs:           gh.pull_requests?.merged_count           ?? 0,
      // issues — open and recently closed (closed as a positive signal)
      open_issues:          gh.issues?.open_count                    ?? 0,
      closed_issues:        gh.issues?.recent_closed_count           ?? 0,
      // files_changed: not available from current githubService without
      // per-commit diff API calls (would multiply rate-limit usage).
      // Kept as 0 — no fake value generated.
      files_changed:        0,
      github_evidence_available: true,
      github_evidence_note: null,
    };
  } catch (err) {
    console.warn(`GitHub feature fetch failed for "${githubUrl}": ${err.message}`);
    return {
      ...GITHUB_DEFAULTS,
      github_evidence_note: err.message.includes("Private repository data")
        ? "Private repository evidence is unavailable to this viewer."
        : "GitHub evidence could not be fetched; risk prediction uses non-GitHub project data.",
    };
  }
}

/**
 * Extracts relevant project features from the database for AI prediction.
 *
 * Returns the original 7 features (unchanged) PLUS 10 GitHub features.
 * GitHub features default to 0 when github_url is absent or the API fails.
 *
 * @param {number} projectId - The ID of the project.
 * @returns {Promise<object>} An object containing all extracted features.
 * @throws {Error} If the project is not found.
 */
export async function extractProjectFeatures(projectId, { allowPrivateGithub = true } = {}) {
  const daysSinceActivityQuery = isMysql
    ? "DATEDIFF(NOW(), MAX(al.created_at))"
    : "CAST(julianday('now') - julianday(MAX(al.created_at)) AS INTEGER)";

  const [rows] = await pool.query(`
    SELECT
      p.progress,
      p.github_url,
      (SELECT COUNT(*) FROM milestones WHERE project_id = p.id AND status = 'completed') AS completedMilestones,
      (SELECT COUNT(*) FROM milestones WHERE project_id = p.id AND status = 'overdue') AS overdueMilestones,
      (SELECT COUNT(*) FROM submissions WHERE project_id = p.id AND status = 'pending') AS pendingSubmissions,
      (SELECT COUNT(*) FROM submissions WHERE project_id = p.id AND status = 'rejected') AS rejectedSubmissions,
      (SELECT COUNT(*) FROM feedback WHERE project_id = p.id) AS feedbackCount,
      (SELECT ${daysSinceActivityQuery} FROM activity_logs al WHERE al.project_id = p.id) AS daysSinceActivity
    FROM projects p
    WHERE p.id = ?
  `, [projectId]);

  if (!rows.length) throw new Error("Project not found.");
  const f = rows[0];

  // ── Original 7 features — logic completely unchanged ─────────────────────
  const coreFeatures = {
    progress:             Number(f.progress) || 0,
    completed_milestones: Number(f.completedMilestones) || 0,
    overdue_milestones:   Number(f.overdueMilestones) || 0,
    pending_submissions:  Number(f.pendingSubmissions) || 0,
    rejected_submissions: Number(f.rejectedSubmissions) || 0,
    feedback_count:       Number(f.feedbackCount) || 0,
    days_since_activity:  Number(f.daysSinceActivity ?? 30),
  };

  // ── GitHub features — fetched in parallel; falls back silently ────────────
  const githubFeatures = await fetchGithubFeatures(
    f.github_url || null,
    allowPrivateGithub
  );

  return {
    ...coreFeatures,
    ...githubFeatures,
  };
}

/**
/**
 * Generates human-readable recommendations based on project features.
 * @param {object} features - The project features.
 * @returns {Array<object>} A list of recommendations.
 */
export function generateRecommendations(features) {
  const recs = [];
  if (features.overdue_milestones > 0) recs.push({message:`${features.overdue_milestones} overdue milestone(s). Prioritize completing them.`,priority:"high"});
  if (features.days_since_activity > 10) recs.push({message:`No activity in ${features.days_since_activity} days. Update your progress.`,priority:"high"});
  if (features.pending_submissions > 2) recs.push({message:`${features.pending_submissions} submissions pending review. Follow up with supervisor.`,priority:"medium"});
  if (features.rejected_submissions > 0) recs.push({message:`${features.rejected_submissions} submission(s) rejected. Review feedback and resubmit.`,priority:"high"});
  if (features.feedback_count === 0) recs.push({message:"No feedback received. Schedule a meeting with your supervisor.",priority:"medium"});
  if (!recs.length) recs.push({message:"Great progress! Keep maintaining consistent submissions.",priority:"low"});
  return recs;
}