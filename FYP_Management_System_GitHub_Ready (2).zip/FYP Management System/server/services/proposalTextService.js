import { stat, readFile } from "node:fs/promises";
import path from "node:path";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

const MAX_PDF_BYTES = 10 * 1024 * 1024;
const MAX_PAGES = 100;
const MAX_TEXT_LENGTH = 50_000;

export async function extractProposalPdfText(storedPath, uploadsDirectory) {
  const normalizedPath = String(storedPath || "").replaceAll("\\", "/");
  const uploadsMarker = normalizedPath.lastIndexOf("/uploads/");
  const relativeName = uploadsMarker >= 0
    ? normalizedPath.slice(uploadsMarker + "/uploads/".length)
    : normalizedPath.startsWith("uploads/")
      ? normalizedPath.slice("uploads/".length)
      : "";

  if (!relativeName || relativeName.includes("/")) {
    throw new Error("Approved proposal file path is invalid.");
  }
  if (path.extname(relativeName).toLowerCase() !== ".pdf") {
    throw new Error("Approved proposal is not a PDF; its contents could not be extracted.");
  }

  const uploadsRoot = path.resolve(uploadsDirectory);
  const pdfPath = path.resolve(uploadsRoot, path.basename(relativeName));
  const relativePath = path.relative(uploadsRoot, pdfPath);
  if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
    throw new Error("Approved proposal file path is outside the uploads directory.");
  }

  let fileInfo;
  try {
    fileInfo = await stat(pdfPath);
  } catch {
    throw new Error("Approved proposal PDF is unavailable on the server.");
  }
  if (!fileInfo.isFile() || fileInfo.size > MAX_PDF_BYTES) {
    throw new Error("Approved proposal PDF is not a valid file or exceeds the 10 MB limit.");
  }

  const data = new Uint8Array(await readFile(pdfPath));
  let document;
  try {
    document = await getDocument({
      data,
      isEvalSupported: false,
      useSystemFonts: true,
      verbosity: 0,
    }).promise;

    const text = [];
    const pagesToRead = Math.min(document.numPages, MAX_PAGES);
    for (let pageNumber = 1; pageNumber <= pagesToRead; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      text.push(content.items.map((item) => item.str || "").join(" "));
      if (text.join(" ").length >= MAX_TEXT_LENGTH) break;
    }

    return {
      text: text.join("\n").replace(/\s+/g, " ").trim().slice(0, MAX_TEXT_LENGTH),
      pages_read: pagesToRead,
      truncated: document.numPages > pagesToRead,
    };
  } catch {
    throw new Error("Approved proposal PDF text could not be extracted.");
  } finally {
    await document?.destroy();
  }
}
