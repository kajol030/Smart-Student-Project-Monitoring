﻿import pool from "./config/db.js";

const tables = [
  "project_groups",
  "project_group_members",
  "supervisor_requests",
  "notifications"
];

for (const table of tables) {
  const [rows] = await pool.query(
    "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?",
    [table]
  );

  console.log(`\n===== ${table} =====`);
  console.log(rows[0]?.sql || "Table not found");
}
