import express from "express";
import pool from "../config/db.js";
import { authenticate } from "../middleware/auth.js";
const router = express.Router();
const defaults = [
  "deadline_reminders",
  "feedback",
  "project_updates",
  "evaluation_updates",
  "announcements",
  "ai_risk_alerts",
  "weekly_log_notifications",
  "meeting_reminders",
];
router.get("/", authenticate, async (req, res, next) => { try { const [rows] = await pool.query("SELECT event_key,in_app,email FROM notification_preferences WHERE user_id=?", [req.user.id]); const map = Object.fromEntries(rows.map((row) => [row.event_key, row])); res.json(defaults.map((event_key) => map[event_key] || { event_key, in_app: 1, email: 0 })); } catch (e) { next(e); } });
router.put("/", authenticate, async (req, res, next) => { try { const { event_key, in_app, email } = req.body; if (!defaults.includes(event_key)) return res.status(400).json({ message: "Unknown notification type." }); const [[existing]] = await pool.query("SELECT id FROM notification_preferences WHERE user_id=? AND event_key=?", [req.user.id, event_key]); if (existing) await pool.query("UPDATE notification_preferences SET in_app=?,email=?,updated_at=datetime('now') WHERE id=?", [in_app ? 1 : 0, email ? 1 : 0, existing.id]); else await pool.query("INSERT INTO notification_preferences (user_id,event_key,in_app,email) VALUES (?,?,?,?)", [req.user.id, event_key, in_app ? 1 : 0, email ? 1 : 0]); res.json({ message: "Preference updated." }); } catch (e) { next(e); } });
export default router;
