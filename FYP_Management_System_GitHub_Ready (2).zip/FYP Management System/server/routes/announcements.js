import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog } from "../middleware/audit.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const page=Math.max(1,parseInt(req.query.page)||1), limit=Math.min(20,parseInt(req.query.limit)||10), offset=(page-1)*limit;
    const [rows] = await pool.query(
      `SELECT a.*,u.name AS created_by_name FROM announcements a JOIN users u ON a.created_by=u.id
       WHERE a.target_role='all' OR a.target_role=? ORDER BY a.created_at DESC LIMIT ? OFFSET ?`,
      [req.user.role,limit,offset]);
    const [[{total}]] = await pool.query(
      "SELECT COUNT(*) AS total FROM announcements WHERE target_role='all' OR target_role=?",[req.user.role]);
    res.json({ announcements:rows, total, page, limit });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { title, body, target_role } = req.body;
    const [r] = await pool.query("INSERT INTO announcements (title,body,target_role,created_by) VALUES (?,?,?,?)",
      [title,body,target_role||"all",req.user.id]);
    await auditLog(req,"ANNOUNCEMENT_CREATED","announcements",r.insertId);
    res.status(201).json({ message: "Announcement posted.", id: r.insertId });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { title, body, target_role } = req.body;
    await pool.query("UPDATE announcements SET title=?,body=?,target_role=? WHERE id=?",
      [title,body,target_role||"all",req.params.id]);
    res.json({ message: "Updated." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    await pool.query("DELETE FROM announcements WHERE id=?", [req.params.id]);
    res.json({ message: "Deleted." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
