import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();

router.get("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const page=Math.max(1,parseInt(req.query.page)||1), limit=Math.min(100,parseInt(req.query.limit)||20);
    const offset=(page-1)*limit, action=req.query.action||"", userId=req.query.user_id||"";
    let where="WHERE 1=1"; const p=[];
    if (action)  { where+=" AND al.action LIKE ?"; p.push(`%${action}%`); }
    if (userId)  { where+=" AND al.user_id=?";     p.push(userId); }
    const [rows] = await pool.query(
      `SELECT al.*,u.name AS user_name,u.email AS user_email FROM audit_logs al
       LEFT JOIN users u ON al.user_id=u.id ${where} ORDER BY al.created_at DESC LIMIT ? OFFSET ?`,
      [...p,limit,offset]);
    const [[{total}]] = await pool.query(`SELECT COUNT(*) AS total FROM audit_logs al ${where}`,p);
    res.json({ logs:rows, total, page, limit });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
