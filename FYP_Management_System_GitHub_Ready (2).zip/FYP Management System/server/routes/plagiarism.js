import express from "express";
import multer from "multer";
import path from "node:path";
import { param } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { assertProjectAccess } from "../utils/projectAccess.js";
import {
  compareDocumentText,
  extractDocumentText,
  presentPlagiarismCheck,
} from "../services/plagiarismService.js";

const router = express.Router();
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const allowedTypes = new Map([
  [".pdf", new Set(["application/pdf", "application/octet-stream"])],
  [".docx", new Set([
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/octet-stream",
  ])],
  [".txt", new Set(["text/plain", "application/octet-stream"])],
]);
const documentUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (_req, file, callback) => {
    const extension = path.extname(file.originalname).toLowerCase();
    if (!allowedTypes.get(extension)?.has(file.mimetype)) {
      return callback(new Error("Upload a PDF, DOCX, or UTF-8 text file."));
    }
    callback(null, true);
  },
});

function safeFilename(filename) {
  return path.basename(String(filename || "document"))
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .slice(0, 255);
}

router.get(
  "/project/:projectId",
  authenticate,
  [param("projectId").isInt({ min: 1 }).withMessage("Project ID must be a positive integer.")],
  validate,
  async (req, res, next) => {
    try {
      const project = await assertProjectAccess(req, res, req.params.projectId);
      if (!project) return;
      const [rows] = await pool.query(
        `SELECT id, project_id, original_filename, word_count, similarity_percent,
                matches_json, created_at
         FROM plagiarism_checks
         WHERE project_id = ?
         ORDER BY created_at DESC, id DESC`,
        [project.id],
      );
      res.json({
        checks: rows.map((row) => presentPlagiarismCheck(row, req.user.role)),
        advisory: "Text similarity is a review signal, not proof of plagiarism or a substitute for supervisor judgment.",
      });
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/project/:projectId/check",
  authenticate,
  authorize("student"),
  [param("projectId").isInt({ min: 1 }).withMessage("Project ID must be a positive integer.")],
  validate,
  documentUpload.single("file"),
  async (req, res, next) => {
    try {
      const project = await assertProjectAccess(req, res, req.params.projectId);
      if (!project) return;
      if (!req.file) {
        return res.status(400).json({ message: "Choose a PDF, DOCX, or text file to check." });
      }

      let extractedText;
      try {
        extractedText = await extractDocumentText(req.file);
      } catch (error) {
        return res.status(400).json({ message: error.message });
      }
      let sourceQuery = `SELECT c.id, c.project_id, c.original_filename, c.extracted_text,
                                p.title AS project_title
                         FROM plagiarism_checks c
                         JOIN projects p ON p.id = c.project_id`;
      const params = [];
      if (req.user.role === "supervisor") {
        sourceQuery += " WHERE p.supervisor_id = ? OR p.id = ?";
        params.push(req.user.id, project.id);
      }
      sourceQuery += " ORDER BY c.created_at DESC, c.id DESC LIMIT 200";
      const [sources] = await pool.query(sourceQuery, params);

      const matches = sources
        .map((source) => ({
          source_project_id: Number(source.project_id),
          source_project_title: source.project_title,
          source_filename: source.original_filename,
          ...compareDocumentText(extractedText, source.extracted_text),
        }))
        .filter((match) => match.similarity_percent >= 20 || match.matched_text.length > 0)
        .sort((a, b) => b.similarity_percent - a.similarity_percent)
        .slice(0, 20);
      const similarityPercent = matches[0]?.similarity_percent || 0;
      const wordCount = extractedText.split(/\s+/).filter(Boolean).length;
      const originalFilename = safeFilename(req.file.originalname);
      const [inserted] = await pool.query(
        `INSERT INTO plagiarism_checks
         (project_id, uploaded_by, original_filename, word_count, similarity_percent, extracted_text, matches_json)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          project.id,
          req.user.id,
          originalFilename,
          wordCount,
          similarityPercent,
          extractedText,
          JSON.stringify(matches),
        ],
      );

      const check = {
        id: inserted.insertId,
        project_id: project.id,
        original_filename: originalFilename,
        word_count: wordCount,
        similarity_percent: similarityPercent,
        matches_json: JSON.stringify(matches),
        created_at: new Date().toISOString(),
      };
      res.status(201).json({
        check: presentPlagiarismCheck(check, req.user.role),
        comparisons_made: sources.length,
        advisory: "Similarity is based on text overlap in earlier platform checks; review the excerpts and source documents before drawing conclusions.",
      });
    } catch (error) {
      next(error);
    }
  },
);

router.use((error, _req, res, next) => {
  if (error instanceof multer.MulterError) {
    const status = error.code === "LIMIT_FILE_SIZE" ? 413 : 400;
    return res.status(status).json({
      message: status === 413 ? "File exceeds the 10 MB limit." : error.message,
    });
  }
  if (error instanceof Error) {
    const message = error.message || "Unsupported upload. Please select a valid file.";
    if (/Upload a PDF, DOCX, or UTF-8 text file|not a valid PDF|valid UTF-8|too little readable text|PDF text could not be extracted|DOCX text could not be extracted/.test(message)) {
      return res.status(400).json({ message });
    }
  }
  if (error && typeof error === "object" && error.status === 400) {
    return res.status(400).json({ message: error.message || "Invalid upload." });
  }
  next(error);
});

export default router;
