import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog, notify } from "../middleware/audit.js";
import { assertProjectAccess } from "../utils/projectAccess.js";

const router = express.Router();

function grade(m) {
  if (m >= 90) return "A+";
  if (m >= 85) return "A";
  if (m >= 80) return "A-";
  if (m >= 75) return "B+";
  if (m >= 70) return "B";
  if (m >= 65) return "B-";
  if (m >= 60) return "C+";
  if (m >= 55) return "C";
  if (m >= 50) return "D";
  return "F";
}

/*
|--------------------------------------------------------------------------
| GET EVALUATIONS FOR PROJECT
|--------------------------------------------------------------------------
*/
router.get("/project/:projectId", authenticate, async (req, res, next) => {
  try {
    const project = await assertProjectAccess(req, res, req.params.projectId);
    if (!project) return;
    const [rows] = await pool.query(
      `SELECT
        e.*,
        u.name AS evaluator_name,
        r.name AS rubric_name
       FROM evaluations e
       JOIN users u ON e.evaluator_id = u.id
       LEFT JOIN rubrics r ON e.rubric_id = r.id
       WHERE e.project_id = ?
       ORDER BY e.evaluated_at DESC`,
      [req.params.projectId]
    );

    res.json(rows);
  } catch (e) { next(e); }
});

/*
|--------------------------------------------------------------------------
| CREATE EVALUATION
|--------------------------------------------------------------------------
*/
router.post(
  "/",
  authenticate,
  authorize("supervisor"),
  async (req, res, next) => {
    try {
      const {
        project_id,
        viva_id,
        rubric_id,
        supervisor_marks,
        panel_marks,
        comments
      } = req.body;

      /*
      |--------------------------------------------------------------------------
      | Validate project_id
      |--------------------------------------------------------------------------
      */

      if (
        project_id === undefined ||
        project_id === null ||
        project_id === "" ||
        Number.isNaN(Number(project_id))
      ) {
        return res.status(400).json({
          message: "Please select a valid project."
        });
      }

      const projectId = Number(project_id);

      const [[project]] = await pool.query(
        `SELECT id, student_id, supervisor_id, title
         FROM projects
         WHERE id = ?`,
        [projectId]
      );

      if (!project) {
        return res.status(400).json({
          message: `Invalid project_id: ${projectId}. The selected project does not exist.`
        });
      }
      if (
        req.user.role === "supervisor" &&
        Number(project.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({ message: "Access denied." });
      }

      /*
      |--------------------------------------------------------------------------
      | Validate logged-in evaluator
      |--------------------------------------------------------------------------
      */

      if (
        !req.user ||
        req.user.id === undefined ||
        req.user.id === null
      ) {
        return res.status(401).json({
          message: "Your login session is invalid. Please log in again."
        });
      }

      const evaluatorId = Number(req.user.id);

      const [[evaluator]] = await pool.query(
        `SELECT id, name, role
         FROM users
         WHERE id = ?`,
        [evaluatorId]
      );

      if (!evaluator) {
        return res.status(400).json({
          message: `Invalid evaluator_id: ${evaluatorId}. The logged-in user does not exist.`
        });
      }

      /*
      |--------------------------------------------------------------------------
      | Validate rubric if provided
      |--------------------------------------------------------------------------
      */

      let rubricId = null;

      if (
        rubric_id !== undefined &&
        rubric_id !== null &&
        rubric_id !== "" &&
        Number(rubric_id) > 0
      ) {
        rubricId = Number(rubric_id);

        const [[rubric]] = await pool.query(
          `SELECT id, name
           FROM rubrics
           WHERE id = ?`,
          [rubricId]
        );

        if (!rubric) {
          return res.status(400).json({
            message: `Invalid rubric_id: ${rubricId}. The selected rubric does not exist.`
          });
        }
      }

      /*
      |--------------------------------------------------------------------------
      | Validate viva if provided
      |--------------------------------------------------------------------------
      */

      let vivaId = null;

      if (
        viva_id !== undefined &&
        viva_id !== null &&
        viva_id !== "" &&
        Number(viva_id) > 0
      ) {
        vivaId = Number(viva_id);

        const [[viva]] = await pool.query(
          `SELECT id
           FROM viva_schedules
           WHERE id = ?`,
          [vivaId]
        );

        if (!viva) {
          return res.status(400).json({
            message: `Invalid viva_id: ${vivaId}. The selected viva does not exist.`
          });
        }
      }

      /*
      |--------------------------------------------------------------------------
      | Convert Marks
      |--------------------------------------------------------------------------
      */

      const sm =
        supervisor_marks !== undefined &&
        supervisor_marks !== null &&
        supervisor_marks !== ""
          ? Number(supervisor_marks)
          : null;

      const pm =
        panel_marks !== undefined &&
        panel_marks !== null &&
        panel_marks !== ""
          ? Number(panel_marks)
          : null;

      /*
      |--------------------------------------------------------------------------
      | Validate Marks
      |--------------------------------------------------------------------------
      */

      if (sm !== null && Number.isNaN(sm)) {
        return res.status(400).json({
          message: "Supervisor marks must be a valid number."
        });
      }

      if (pm !== null && Number.isNaN(pm)) {
        return res.status(400).json({
          message: "Panel marks must be a valid number."
        });
      }

      if (sm !== null && (sm < 0 || sm > 100)) {
        return res.status(400).json({
          message: "Supervisor marks must be between 0 and 100."
        });
      }

      if (pm !== null && (pm < 0 || pm > 100)) {
        return res.status(400).json({
          message: "Panel marks must be between 0 and 100."
        });
      }

      /*
      |--------------------------------------------------------------------------
      | Calculate Total + Grade
      |--------------------------------------------------------------------------
      */

      const total =
        sm !== null && pm !== null
          ? Math.round(((sm + pm) / 2) * 100) / 100
          : (sm ?? pm ?? null);

      const g = total !== null ? grade(total) : null;

      /*
      |--------------------------------------------------------------------------
      | Insert Evaluation
      |--------------------------------------------------------------------------
      */

      const [result] = await pool.query(
        `INSERT INTO evaluations
        (
          project_id,
          viva_id,
          evaluator_id,
          rubric_id,
          supervisor_marks,
          panel_marks,
          total_marks,
          grade,
          comments
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          projectId,
          vivaId,
          evaluatorId,
          rubricId,
          sm,
          pm,
          total,
          g,
          comments || null
        ]
      );

      /*
      |--------------------------------------------------------------------------
      | Mark Project Completed
      |--------------------------------------------------------------------------
      */

      if (g && g !== "F") {
        await pool.query(
          `UPDATE projects
           SET status = 'completed'
           WHERE id = ?`,
          [projectId]
        );
      }

      /*
      |--------------------------------------------------------------------------
      | Notify Student
      |--------------------------------------------------------------------------
      */

      if (project.student_id) {
        try {
          await notify(
            project.student_id,
            "Evaluation Submitted",
            `"${project.title}" evaluated. Grade: ${g || "Pending"}`,
            "success"
          );
        } catch (notifyError) {
          console.error(
            "Evaluation notification failed:",
            notifyError.message
          );
        }
      }

      /*
      |--------------------------------------------------------------------------
      | Audit Log
      |--------------------------------------------------------------------------
      */

      try {
        await auditLog(
          req,
          "EVALUATION_SUBMITTED",
          "evaluations",
          result.insertId,
          null,
          {
            project_id: projectId,
            rubric_id: rubricId,
            viva_id: vivaId,
            evaluator_id: evaluatorId,
            total_marks: total,
            grade: g
          }
        );
      } catch (auditError) {
        console.error(
          "Evaluation audit log failed:",
          auditError.message
        );
      }

      /*
      |--------------------------------------------------------------------------
      | Success Response
      |--------------------------------------------------------------------------
      */

      res.status(201).json({
        message: "Evaluation submitted.",
        id: result.insertId,
        grade: g,
        total_marks: total
      });

    } catch (e) {
      next(e);
    }
  }
);

/*
|--------------------------------------------------------------------------
| UPDATE EVALUATION
|--------------------------------------------------------------------------
*/
router.put(
  "/:id",
  authenticate,
  authorize("supervisor"),
  async (req, res, next) => {
    try {
      const [[evaluation]] = await pool.query(
        `SELECT e.id, p.supervisor_id
         FROM evaluations e
         JOIN projects p ON p.id = e.project_id
         WHERE e.id = ?`,
        [req.params.id]
      );
      if (!evaluation) {
        return res.status(404).json({ message: "Evaluation not found." });
      }
      if (
        req.user.role === "supervisor" &&
        Number(evaluation.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({ message: "Access denied." });
      }

      const {
        supervisor_marks,
        panel_marks,
        comments
      } = req.body;

      const sm =
        supervisor_marks !== undefined &&
        supervisor_marks !== null &&
        supervisor_marks !== ""
          ? Number(supervisor_marks)
          : null;

      const pm =
        panel_marks !== undefined &&
        panel_marks !== null &&
        panel_marks !== ""
          ? Number(panel_marks)
          : null;

      if (sm !== null && Number.isNaN(sm)) {
        return res.status(400).json({
          message: "Supervisor marks must be a valid number."
        });
      }

      if (pm !== null && Number.isNaN(pm)) {
        return res.status(400).json({
          message: "Panel marks must be a valid number."
        });
      }

      if (sm !== null && (sm < 0 || sm > 100)) {
        return res.status(400).json({
          message: "Supervisor marks must be between 0 and 100."
        });
      }

      if (pm !== null && (pm < 0 || pm > 100)) {
        return res.status(400).json({
          message: "Panel marks must be between 0 and 100."
        });
      }

      const total =
        sm !== null && pm !== null
          ? Math.round(((sm + pm) / 2) * 100) / 100
          : (sm ?? pm ?? null);

      const g = total !== null ? grade(total) : null;

      const [result] = await pool.query(
        `UPDATE evaluations
         SET
           supervisor_marks = COALESCE(?, supervisor_marks),
           panel_marks = COALESCE(?, panel_marks),
           total_marks = COALESCE(?, total_marks),
           grade = COALESCE(?, grade),
           comments = COALESCE(?, comments)
         WHERE id = ?`,
        [
          sm,
          pm,
          total,
          g,
          comments || null,
          req.params.id
        ]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({
          message: "Evaluation not found."
        });
      }

      res.json({
        message: "Updated.",
        grade: g,
        total_marks: total
      });

    } catch (e) {
      next(e);
    }
  }
);

/*
|--------------------------------------------------------------------------
| GET ACTIVE RUBRICS
|--------------------------------------------------------------------------
*/
router.get("/rubrics", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT
        r.*,
        u.name AS created_by_name,
        COUNT(rc.id) AS criteria_count
       FROM rubrics r
       LEFT JOIN users u ON r.created_by = u.id
       LEFT JOIN rubric_criteria rc ON rc.rubric_id = r.id
       WHERE COALESCE(r.is_active, 1) = 1
       GROUP BY r.id
       ORDER BY r.created_at DESC`
    );

    res.json(rows);
  } catch (e) {
    console.error("GET RUBRICS ERROR:", e);

    res.status(500).json({
      message: e.sqlMessage || e.message || "Failed to load rubrics."
    });
  }
});

/*
|--------------------------------------------------------------------------
| GET SINGLE RUBRIC
|--------------------------------------------------------------------------
*/
router.get("/rubrics/:id", authenticate, async (req, res) => {
  try {
    const [[rubric]] = await pool.query(
      `SELECT *
       FROM rubrics
       WHERE id = ?`,
      [req.params.id]
    );

    if (!rubric) {
      return res.status(404).json({
        message: "Rubric not found."
      });
    }

    const [criteria] = await pool.query(
      `SELECT *
       FROM rubric_criteria
       WHERE rubric_id = ?
       ORDER BY id`,
      [req.params.id]
    );

    res.json({
      ...rubric,
      criteria
    });

  } catch (e) {
    console.error("GET RUBRIC ERROR:", e);

    res.status(500).json({
      message: e.sqlMessage || e.message || "Failed to load rubric."
    });
  }
});

/*
|--------------------------------------------------------------------------
| CREATE RUBRIC
|--------------------------------------------------------------------------
*/
router.post(
  "/rubrics",
  authenticate,
  authorize("admin"),
  async (req, res) => {
    try {
      const {
        name,
        batch_id,
        total_marks,
        passing_marks,
        stage,
        criteria
      } = req.body;

      if (!name || !String(name).trim()) {
        return res.status(400).json({
          message: "Rubric name is required."
        });
      }

      const totalMarks =
        total_marks !== undefined &&
        total_marks !== null &&
        total_marks !== ""
          ? Number(total_marks)
          : 100;

      const passingMarks =
        passing_marks !== undefined &&
        passing_marks !== null &&
        passing_marks !== ""
          ? Number(passing_marks)
          : 50;

      const batchId =
        batch_id !== undefined &&
        batch_id !== null &&
        batch_id !== "" &&
        Number(batch_id) > 0
          ? Number(batch_id)
          : null;

      /*
      |--------------------------------------------------------------------------
      | Validate batch if supplied
      |--------------------------------------------------------------------------
      */

      if (batchId !== null) {
        const [[batch]] = await pool.query(
          `SELECT id
           FROM batches
           WHERE id = ?`,
          [batchId]
        );

        if (!batch) {
          return res.status(400).json({
            message: `Invalid batch_id: ${batchId}. The selected batch does not exist.`
          });
        }
      }

      /*
      |--------------------------------------------------------------------------
      | Validate creator
      |--------------------------------------------------------------------------
      */

      const [[creator]] = await pool.query(
        `SELECT id
         FROM users
         WHERE id = ?`,
        [req.user.id]
      );

      if (!creator) {
        return res.status(400).json({
          message: `Invalid created_by user: ${req.user.id}.`
        });
      }

      const [result] = await pool.query(
        `INSERT INTO rubrics
        (
          name,
          batch_id,
          total_marks,
          passing_marks,
          stage,
          created_by
        )
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
          String(name).trim(),
          batchId,
          totalMarks,
          passingMarks,
          stage || "final",
          req.user.id
        ]
      );

      /*
      |--------------------------------------------------------------------------
      | Insert Rubric Criteria
      |--------------------------------------------------------------------------
      */

      if (Array.isArray(criteria)) {
        for (const c of criteria) {
          if (!c || !c.criterion || !String(c.criterion).trim()) {
            continue;
          }

          await pool.query(
            `INSERT INTO rubric_criteria
            (
              rubric_id,
              criterion,
              max_marks,
              weight
            )
            VALUES (?, ?, ?, ?)`,
            [
              result.insertId,
              String(c.criterion).trim(),
              c.max_marks != null ? Number(c.max_marks) : 10,
              c.weight != null ? Number(c.weight) : 0
            ]
          );
        }
      }

      res.status(201).json({
        message: "Rubric created.",
        id: result.insertId
      });

    } catch (e) {
      console.error("CREATE RUBRIC ERROR:", e);

      res.status(500).json({
        message: e.sqlMessage || e.message || "Failed to create rubric."
      });
    }
  }
);

/*
|--------------------------------------------------------------------------
| UPDATE RUBRIC
|--------------------------------------------------------------------------
*/
router.put(
  "/rubrics/:id",
  authenticate,
  authorize("admin"),
  async (req, res) => {
    try {
      const {
        name,
        total_marks,
        passing_marks,
        stage,
        criteria
      } = req.body;

      const [rubricResult] = await pool.query(
        `UPDATE rubrics
         SET
           name = COALESCE(?, name),
           total_marks = COALESCE(?, total_marks),
           passing_marks = COALESCE(?, passing_marks),
           stage = COALESCE(?, stage)
         WHERE id = ?`,
        [
          name || null,
          total_marks !== undefined ? total_marks : null,
          passing_marks !== undefined ? passing_marks : null,
          stage || null,
          req.params.id
        ]
      );

      if (rubricResult.affectedRows === 0) {
        return res.status(404).json({
          message: "Rubric not found."
        });
      }

      /*
      |--------------------------------------------------------------------------
      | Update / Add Criteria
      |--------------------------------------------------------------------------
      */

      if (Array.isArray(criteria)) {
        for (const criterion of criteria) {
          if (
            !criterion ||
            !criterion.criterion ||
            !String(criterion.criterion).trim()
          ) {
            continue;
          }

          if (criterion.id) {
            await pool.query(
              `UPDATE rubric_criteria
               SET
                 criterion = COALESCE(?, criterion),
                 max_marks = COALESCE(?, max_marks),
                 weight = COALESCE(?, weight)
               WHERE id = ?
                 AND rubric_id = ?`,
              [
                String(criterion.criterion).trim(),
                criterion.max_marks != null
                  ? Number(criterion.max_marks)
                  : null,
                criterion.weight != null
                  ? Number(criterion.weight)
                  : 0,
                criterion.id,
                req.params.id
              ]
            );
          } else {
            await pool.query(
              `INSERT INTO rubric_criteria
              (
                rubric_id,
                criterion,
                max_marks,
                weight
              )
              VALUES (?, ?, ?, ?)`,
              [
                req.params.id,
                String(criterion.criterion).trim(),
                criterion.max_marks != null
                  ? Number(criterion.max_marks)
                  : 10,
                criterion.weight != null
                  ? Number(criterion.weight)
                  : 0
              ]
            );
          }
        }
      }

      res.json({
        message: "Rubric updated."
      });

    } catch (e) {
      console.error("UPDATE RUBRIC ERROR:", e);

      res.status(500).json({
        message: e.sqlMessage || e.message || "Failed to update rubric."
      });
    }
  }
);

/*
|--------------------------------------------------------------------------
| DEACTIVATE RUBRIC
|--------------------------------------------------------------------------
*/
router.delete(
  "/rubrics/:id",
  authenticate,
  authorize("admin"),
  async (req, res) => {
    try {
      const [result] = await pool.query(
        `UPDATE rubrics
         SET is_active = 0
         WHERE id = ?`,
        [req.params.id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({
          message: "Rubric not found."
        });
      }

      res.json({
        message: "Rubric deactivated."
      });

    } catch (e) {
      console.error("DEACTIVATE RUBRIC ERROR:", e);

      res.status(500).json({
        message: e.sqlMessage || e.message || "Failed to deactivate rubric."
      });
    }
  }
);

export default router;