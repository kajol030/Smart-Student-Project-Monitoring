
import express from "express";
import { body, param } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { notify } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";

const router = express.Router();

/*
  Project feedback access:
  - Admin: any project
  - Supervisor: only assigned project
  - Student: project owner or active group member
*/

async function canViewFeedback(project, user) {
  if (user.role === "admin") {
    return true;
  }

  if (user.role === "supervisor") {
    return Number(project.supervisor_id) === Number(user.id);
  }

  if (user.role !== "student") {
    return false;
  }

  if (Number(project.student_id) === Number(user.id)) {
    return true;
  }

  if (!project.group_id) {
    return false;
  }

  const [[member]] = await pool.query(
    `SELECT id
     FROM project_group_members
     WHERE group_id = ?
       AND user_id = ?
       AND status = 'active'
     LIMIT 1`,
    [project.group_id, user.id]
  );

  return Boolean(member);
}

/* GET PROJECT FEEDBACK */
router.get(
  "/project/:projectId",
  authenticate,
  [
    param("projectId")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { projectId } = req.params;

      const [[project]] = await pool.query(
        `SELECT id, student_id, supervisor_id, group_id
         FROM projects
         WHERE id = ?`,
        [projectId]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      const allowed = await canViewFeedback(project, req.user);

      if (!allowed) {
        return res.status(403).json({
          message: "Access denied to this project's feedback.",
        });
      }

      const [rows] = await pool.query(
        `SELECT
           f.*,
           u.name AS supervisor_name
         FROM feedback f
         JOIN users u ON u.id = f.supervisor_id
         WHERE f.project_id = ?
         ORDER BY f.created_at DESC`,
        [projectId]
      );

      res.json(rows);
    } catch (e) {
      next(e);
    }
  }
);

/* SUPERVISOR: SUBMIT FEEDBACK */
router.post(
  "/",
  authenticate,
  authorize("supervisor"),
  [
    body("project_id")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),

    body("submission_id")
      .optional({ nullable: true, checkFalsy: true })
      .isInt({ min: 1 })
      .withMessage("Submission ID must be a positive integer."),

    body("message")
      .trim()
      .isLength({ min: 1, max: 1000 })
      .withMessage(
        "Feedback message must be between 1 and 1000 characters."
      ),

    body("rating")
      .optional({ nullable: true, checkFalsy: true })
      .isInt({ min: 0, max: 5 })
      .withMessage("Rating must be between 0 and 5."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const {
        project_id,
        submission_id,
        message,
        rating,
      } = req.body;

      const supervisorId = req.user.id;

      const [[project]] = await pool.query(
        `SELECT
           id,
           student_id,
           supervisor_id,
           group_id,
           title
         FROM projects
         WHERE id = ?`,
        [project_id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (
        Number(project.supervisor_id) !== Number(supervisorId)
      ) {
        return res.status(403).json({
          message:
            "Access denied. You are not the supervisor for this project.",
        });
      }

      // If feedback is for a submission, ensure that
      // submission belongs to this same project.
      if (submission_id) {
        const [[submission]] = await pool.query(
          `SELECT id
           FROM submissions
           WHERE id = ?
             AND project_id = ?`,
          [submission_id, project_id]
        );

        if (!submission) {
          return res.status(400).json({
            message:
              "The selected submission does not belong to this project.",
          });
        }
      }

      const [result] = await pool.query(
        `INSERT INTO feedback
         (project_id, supervisor_id, submission_id, message, rating)
         VALUES (?, ?, ?, ?, ?)`,
        [
          project_id,
          supervisorId,
          submission_id || null,
          message,
          rating ?? 0,
        ]
      );

      // Collect project owner and all active group members.
      const recipientIds = new Set();

      if (project.student_id) {
        recipientIds.add(Number(project.student_id));
      }

      if (project.group_id) {
        const [members] = await pool.query(
          `SELECT user_id
           FROM project_group_members
           WHERE group_id = ?
             AND status = 'active'`,
          [project.group_id]
        );

        for (const member of members) {
          recipientIds.add(Number(member.user_id));
        }
      }

      // Send each student one notification.
      for (const studentId of recipientIds) {
        await notify(
          studentId,
          "New Feedback",
          `Your supervisor left feedback on "${project.title}".`,
          "info",
          "/app/feedback"
        );
      }

      await pool.query(
        `INSERT INTO activity_logs
         (user_id, project_id, action)
         VALUES (?, ?, ?)`,
        [
          supervisorId,
          project_id,
          "Provided feedback",
        ]
      );

      res.status(201).json({
        message: "Feedback submitted.",
        id: result.insertId,
      });
    } catch (e) {
      next(e);
    }
  }
);

export default router;