import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import { body } from "express-validator";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import pool from "../config/db.js";
import { validate } from "../middleware/validate.js";
import { authenticate } from "../middleware/auth.js";
import { auditLog } from "../middleware/audit.js";
import { sendEmail, emailTemplates } from "../services/email.js";

const router = express.Router();
const authLimiter = rateLimit({ windowMs: 15*60*1000, max: 10,
  message: { message: "Too many attempts. Try again in 15 min." } });

async function resolveStudentAcademicIds({ program, batch, semester, section }) {
  const semesterNumber = Number(semester.match(/^\s*(\d+)(?:st|nd|rd|th)?\s*$/i)?.[1]);
  if (!Number.isInteger(semesterNumber) || semesterNumber < 1 || semesterNumber > 8) {
    throw new Error("Semester must be a number from 1 to 8, such as 7th.");
  }

  const [[programRow]] = await pool.query(
    `SELECT p.id AS program_id, d.id AS department_id
     FROM programs p
     JOIN departments d ON d.id = p.department_id
     WHERE p.code = ? AND d.code = 'ICT' AND p.is_active = 1
     LIMIT 1`,
    [program],
  );
  if (!programRow) throw new Error("Selected ICT program is not configured.");

  let [[batchRow]] = await pool.query(
    "SELECT id FROM batches WHERE department_id = ? AND name = ? LIMIT 1",
    [programRow.department_id, batch.trim()],
  );
  if (!batchRow) {
    const [result] = await pool.query(
      "INSERT INTO batches (name, department_id) VALUES (?, ?)",
      [batch.trim(), programRow.department_id],
    );
    batchRow = { id: result.insertId };
  }

  let [[yearRow]] = await pool.query(
    "SELECT id FROM academic_years WHERE is_active = 1 ORDER BY start_date DESC, id DESC LIMIT 1",
  );
  if (!yearRow) {
    const [[setting]] = await pool.query(
      "SELECT value FROM system_settings WHERE key_name = 'academic_year' LIMIT 1",
    );
    if (!setting?.value) throw new Error("No active academic year is configured.");
    let [[existingYear]] = await pool.query(
      "SELECT id FROM academic_years WHERE name = ? LIMIT 1",
      [setting.value],
    );
    if (!existingYear) {
      const [result] = await pool.query(
        "INSERT INTO academic_years (name, is_active) VALUES (?, 1)",
        [setting.value],
      );
      existingYear = { id: result.insertId };
    }
    yearRow = existingYear;
  }

  let [[semesterRow]] = await pool.query(
    "SELECT id FROM semesters WHERE academic_year_id = ? AND number = ? LIMIT 1",
    [yearRow.id, semesterNumber],
  );
  if (!semesterRow) {
    const [result] = await pool.query(
      "INSERT INTO semesters (academic_year_id, name, number) VALUES (?, ?, ?)",
      [yearRow.id, semester.trim(), semesterNumber],
    );
    semesterRow = { id: result.insertId };
  }

  let [[sectionRow]] = await pool.query(
    "SELECT id FROM sections WHERE batch_id = ? AND semester_id = ? AND name = ? LIMIT 1",
    [batchRow.id, semesterRow.id, section.trim()],
  );
  if (!sectionRow) {
    const [result] = await pool.query(
      "INSERT INTO sections (batch_id, semester_id, name) VALUES (?, ?, ?)",
      [batchRow.id, semesterRow.id, section.trim()],
    );
    sectionRow = { id: result.insertId };
  }

  return {
    departmentId: programRow.department_id,
    programId: programRow.program_id,
    batchId: batchRow.id,
    semesterId: semesterRow.id,
    sectionId: sectionRow.id,
  };
}

router.post("/register", authLimiter,
  [
    // ── Shared fields ──────────────────────────────────────────
    body("name").trim().isLength({ min: 2, max: 100 }).withMessage("Name must be 2–100 characters."),
    body("email").isEmail().normalizeEmail().withMessage("A valid email address is required."),
    body("password")
      .isLength({ min: 8 }).withMessage("Password must be at least 8 characters.")
      .matches(/[A-Z]/).withMessage("Password needs at least one uppercase letter.")
      .matches(/[a-z]/).withMessage("Password needs at least one lowercase letter.")
      .matches(/[0-9]/).withMessage("Password needs at least one number.")
      .matches(/[^A-Za-z0-9]/).withMessage("Password needs at least one special character."),
    body("role")
      .optional()
      .isIn(["student", "supervisor"])
      .withMessage("Public registration is available for student and supervisor accounts. Admin accounts are provisioned by administrators."),
    body("phone").optional().trim(),

    // ── Student-specific fields ────────────────────────────────
    body("studentId")
      .if(body("role").equals("student"))
      .trim().notEmpty().withMessage("Student ID is required for student accounts."),
    body("program")
      .if(body("role").equals("student"))
      .isIn(["BSCS", "BSAI"]).withMessage("Select a valid ICT program."),
    body("batch")
      .if(body("role").equals("student"))
      .trim().notEmpty().withMessage("Batch is required for student accounts."),
    body("semester")
      .if(body("role").equals("student"))
      .trim().matches(/^[1-8](?:st|nd|rd|th)?$/i)
      .withMessage("Semester must be a number from 1 to 8, such as 7th."),
    body("section")
      .if(body("role").equals("student"))
      .trim().notEmpty().withMessage("Section is required for student accounts."),

    // ── Supervisor-specific fields ─────────────────────────────
    body("employeeId")
      .if(body("role").equals("supervisor"))
      .trim().notEmpty().withMessage("Employee ID is required for supervisor accounts."),
    body("department")
      .if(body("role").equals("supervisor"))
      .trim().notEmpty().withMessage("Department is required for supervisor accounts."),
    body("designation")
      .if(body("role").equals("supervisor"))
      .trim().notEmpty().withMessage("Designation is required for supervisor accounts."),
    body("specialization").optional().trim(),
  ],
  validate,
  async (req, res, next) => {
    try {
      const {
        name, email, password, phone,
        // student
        studentId, program, batch, semester, section,
        // supervisor
        employeeId, department, designation, specialization,
      } = req.body;

      // Admin registration is forbidden through the public endpoint
      const role = req.body.role === "supervisor" ? "supervisor" : "student";

      // ── Check for duplicate email ──────────────────────────
      const [existing] = await pool.query("SELECT id FROM users WHERE email=?", [email]);
      if (existing.length) return res.status(409).json({ message: "This email is already registered." });

      const academicIds = role === "student"
        ? await resolveStudentAcademicIds({ program, batch, semester, section })
        : null;

      // ── Hash password ──────────────────────────────────────
      const hashed = await bcrypt.hash(password, 12);

      // ── Insert user ────────────────────────────────────────
      const [result] = await pool.query(
        "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
        [name, email, hashed, role],
      );
      const userId = result.insertId;

      // ── Resolve department_id for supervisors ──────────────
      let departmentId = null;
      if (role === "supervisor" && department) {
        const [deptRows] = await pool.query(
          "SELECT id FROM departments WHERE name=? OR code=?",
          [department, department],
        );
        if (deptRows.length) {
          departmentId = deptRows[0].id;
        } else {
          // Create department if it doesn't exist yet
          const [newDept] = await pool.query(
            "INSERT INTO departments (name, code) VALUES (?, ?)",
            [department, department.substring(0, 10).toUpperCase()],
          );
          departmentId = newDept.insertId;
        }
      }

      // ── Upsert user_profiles row with role-specific data ───
      const profileSql = `
        INSERT INTO user_profiles
          (user_id, phone, student_id_no, specialization, department_id,
           batch_id, program_id, semester_id, section_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          phone          = excluded.phone,
          student_id_no  = excluded.student_id_no,
          specialization = excluded.specialization,
          department_id  = excluded.department_id,
          batch_id       = excluded.batch_id,
          program_id     = excluded.program_id,
          semester_id    = excluded.semester_id,
          section_id     = excluded.section_id
      `;
      const profileParams = [
        userId,
        phone || null,
        role === "student"     ? (studentId || null)     : (employeeId || null),
        role === "supervisor"  ? (specialization || null) : null,
        academicIds?.departmentId ?? departmentId,
        academicIds?.batchId ?? null,
        academicIds?.programId ?? null,
        academicIds?.semesterId ?? null,
        academicIds?.sectionId ?? null,
      ];

      await pool.query(profileSql, profileParams).catch(() =>
        // MySQL fallback
        pool.query(
          `INSERT INTO user_profiles
             (user_id, phone, student_id_no, specialization, department_id,
              batch_id, program_id, semester_id, section_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             phone=VALUES(phone), student_id_no=VALUES(student_id_no),
             specialization=VALUES(specialization), department_id=VALUES(department_id),
             batch_id=VALUES(batch_id), program_id=VALUES(program_id),
             semester_id=VALUES(semester_id), section_id=VALUES(section_id)`,
          profileParams,
        ),
      );

      // ── Build token ────────────────────────────────────────
      const user  = { id: userId, name, email, role };
      const jti   = uuidv4();
      const token = jwt.sign(
        { ...user, jti, token_version: 0 },
        process.env.JWT_SECRET,
        { expiresIn: "1d" },
      );

      // ── Welcome email (fire-and-forget) ────────────────────
      const { subject, html } = emailTemplates.welcome(name);
      sendEmail(email, subject, html).catch(() => {});

      // ── Audit log ──────────────────────────────────────────
      await auditLog(req, "USER_REGISTERED", "users", userId);

      res.status(201).json({
        message: `${role.charAt(0).toUpperCase() + role.slice(1)} account created successfully.`,
        user,
        token,
      });
    } catch (e) { next(e); }
  },
);

router.post("/login", authLimiter,
  [body("email").isEmail().normalizeEmail(), body("password").notEmpty()],
  validate, async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const [rows] = await pool.query("SELECT * FROM users WHERE email=? AND is_active=1", [email]);
      if (!rows.length || !(await bcrypt.compare(password, rows[0].password)))
        return res.status(401).json({ message: "Invalid email or password." });
      const u = rows[0];
      const payload = { id: u.id, name: u.name, email: u.email, role: u.role };
      const jti = uuidv4();
      const token = jwt.sign(
        { ...payload, jti, token_version: Number(u.token_version) || 0 },
        process.env.JWT_SECRET,
        { expiresIn: "1d" },
      );
      await auditLog(req, "USER_LOGIN", "users", u.id);
      res.json({ message: "Login successful.", user: payload, token });
    } catch (e) { next(e); }
  }
);

router.get("/me", authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, email, role, created_at FROM users WHERE id=? AND is_active=1",
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ message: "User not found." });
    res.json({ user: rows[0] });
  } catch (e) { next(e); }
});

router.post("/logout", authenticate, async (req, res, next) => {
  try {
    if (req.user?.jti) {
      const exp = req.user.exp ? new Date(req.user.exp*1000).toISOString()
        : new Date(Date.now()+86400000).toISOString();
      await pool.query("INSERT OR IGNORE INTO token_blacklist (jti,expires_at) VALUES (?,?)", [req.user.jti, exp])
        .catch(() => pool.query("INSERT IGNORE INTO token_blacklist (jti,expires_at) VALUES (?,?)", [req.user.jti, exp]));
    }
    res.json({ message: "Logged out successfully." });
  } catch (e) { next(e); }
});

router.post("/forgot-password", authLimiter, [body("email").isEmail().normalizeEmail()], validate, async (req, res, next) => {
  try {
    const [rows] = await pool.query("SELECT id, email FROM users WHERE email=? AND is_active=1", [req.body.email]);
    if (rows.length) {
      const rawToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
      await pool.query("DELETE FROM password_reset_tokens WHERE user_id=? OR expires_at < CURRENT_TIMESTAMP", [rows[0].id]);
      await pool.query("INSERT INTO password_reset_tokens (user_id,token_hash,expires_at) VALUES (?,?,?)", [rows[0].id, tokenHash, new Date(Date.now() + 15 * 60 * 1000).toISOString()]);
      // In production this token is delivered only through the configured mail provider.
      const { subject, html } = emailTemplates.passwordReset(rawToken);
      sendEmail(rows[0].email, subject, html).catch(() => {});
    }
    res.json({ message: "If that account exists, a password reset link has been sent." });
  } catch (e) { next(e); }
});

router.post("/reset-password", authLimiter, [body("token").isHexadecimal().isLength({ min: 64, max: 64 }), body("password").isLength({ min: 8 }).matches(/[A-Z]/).matches(/[a-z]/).matches(/[0-9]/).matches(/[^A-Za-z0-9]/)], validate, async (req, res, next) => {
  try {
    const tokenHash = crypto.createHash("sha256").update(req.body.token).digest("hex");
    const [[reset]] = await pool.query("SELECT id,user_id FROM password_reset_tokens WHERE token_hash=? AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP", [tokenHash]);
    if (!reset) return res.status(400).json({ message: "Reset link is invalid or expired." });

    // Update password and revoke every previously issued session.
    await pool.query(
      "UPDATE users SET password=?, token_version=token_version+1 WHERE id=?",
      [await bcrypt.hash(req.body.password, 12), reset.user_id],
    );
    // Mark token as used
    await pool.query("UPDATE password_reset_tokens SET used_at=CURRENT_TIMESTAMP WHERE id=?", [reset.id]);

    res.json({ message: "Password reset successfully. You can now sign in." });
  } catch (e) { next(e); }
});

router.post("/change-password", authenticate,
  [body("currentPassword").notEmpty(), body("newPassword").isLength({min:8}).matches(/[A-Z]/).matches(/[0-9]/)],
  validate, async (req, res, next) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const [rows] = await pool.query("SELECT password FROM users WHERE id=?", [req.user.id]);
      if (!rows.length) return res.status(404).json({ message: "User not found." });
      if (!(await bcrypt.compare(currentPassword, rows[0].password)))
        return res.status(400).json({ message: "Current password incorrect." });
      await pool.query(
        "UPDATE users SET password=?, token_version=token_version+1 WHERE id=?",
        [await bcrypt.hash(newPassword, 12), req.user.id],
      );
      if (req.user?.jti) {
        const exp = req.user.exp ? new Date(req.user.exp*1000).toISOString() : new Date(Date.now()+86400000).toISOString();
        await pool.query("INSERT OR IGNORE INTO token_blacklist (jti,expires_at) VALUES (?,?)", [req.user.jti,exp])
          .catch(() => pool.query("INSERT IGNORE INTO token_blacklist (jti,expires_at) VALUES (?,?)", [req.user.jti,exp]));
      }
      await auditLog(req, "PASSWORD_CHANGED", "users", req.user.id);
      res.json({ message: "Password changed. Please log in again." });
    } catch (e) { next(e); }
  }
);

export default router;
