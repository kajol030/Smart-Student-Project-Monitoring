import express from "express";
import pool, { isMysql } from "../config/db.js";
import { auth, authorize } from "../middleware/auth.js";

const router = express.Router();
const OUTCOMES = new Set(["completed_on_time", "delayed", "failed"]);
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function isValidDate(value) {
  if (typeof value !== "string" || !DATE_PATTERN.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function validateOutcome({ project, expectedDate, actualDate, outcomeStatus }) {
  if (!isValidDate(expectedDate)) {
    return "Expected completion date must be a valid YYYY-MM-DD date.";
  }
  if (actualDate !== null && !isValidDate(actualDate)) {
    return "Actual completion date must be a valid YYYY-MM-DD date or null.";
  }
  if (!outcomeStatus) {
    return actualDate === null
      ? null
      : "Choose an outcome status when providing an actual completion date.";
  }
  if (!OUTCOMES.has(outcomeStatus)) {
    return "Outcome status must be completed_on_time, delayed, or failed.";
  }

  if (outcomeStatus === "failed") {
    if (actualDate !== null) {
      return "Failed projects cannot have an actual completion date.";
    }
    if (project.status === "completed") {
      return "A completed project cannot be recorded as failed.";
    }
    return null;
  }

  if (project.status !== "completed" || actualDate === null) {
    return "Completed outcome labels require a completed project and an actual completion date.";
  }

  const derivedOutcome = actualDate <= expectedDate
    ? "completed_on_time"
    : "delayed";
  if (outcomeStatus !== derivedOutcome) {
    return `The dates indicate ${derivedOutcome}; update the outcome label to match.`;
  }
  return null;
}

async function getAuthorizedProject(req, res) {
  const projectId = Number(req.params.projectId);
  if (!Number.isInteger(projectId) || projectId <= 0) {
    res.status(400).json({ message: "Invalid project ID." });
    return null;
  }

  const [[project]] = await pool.query(
    `SELECT id, supervisor_id, status, expected_completion_date,
            actual_completion_date, outcome_status, outcome_verified,
            verified_by, verified_at
     FROM projects WHERE id = ?`,
    [projectId],
  );
  if (!project) {
    res.status(404).json({ message: "Project not found." });
    return null;
  }
  if (
    req.user.role === "supervisor"
    && Number(project.supervisor_id) !== Number(req.user.id)
  ) {
    res.status(403).json({ message: "Access denied." });
    return null;
  }
  return project;
}

router.get(
  "/:projectId",
  auth,
  authorize("admin", "supervisor"),
  async (req, res, next) => {
    try {
      const project = await getAuthorizedProject(req, res);
      if (!project) return;
      res.json(project);
    } catch (error) {
      next(error);
    }
  },
);

router.put(
  "/:projectId",
  auth,
  authorize("admin", "supervisor"),
  async (req, res, next) => {
    try {
      const project = await getAuthorizedProject(req, res);
      if (!project) return;

      const expectedDate = req.body.expected_completion_date;
      const actualDate = req.body.actual_completion_date || null;
      const outcomeStatus = req.body.outcome_status || null;
      const validationError = validateOutcome({
        project,
        expectedDate,
        actualDate,
        outcomeStatus,
      });
      if (validationError) {
        return res.status(422).json({ message: validationError });
      }

      await pool.query(
        `UPDATE projects
         SET expected_completion_date = ?,
             actual_completion_date = ?,
             outcome_status = ?,
             outcome_verified = 0,
             verified_by = NULL,
             verified_at = NULL
         WHERE id = ?`,
        [expectedDate, actualDate, outcomeStatus, project.id],
      );
      const [[updated]] = await pool.query(
        `SELECT id, expected_completion_date, actual_completion_date,
                outcome_status, outcome_verified, verified_by, verified_at
         FROM projects WHERE id = ?`,
        [project.id],
      );
      return res.json(updated);
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/:projectId/verify",
  auth,
  authorize("admin", "supervisor"),
  async (req, res, next) => {
    try {
      const project = await getAuthorizedProject(req, res);
      if (!project) return;

      if (!project.outcome_status) {
        return res.status(422).json({
          message: "Record an outcome before verifying it.",
        });
      }
      const validationError = validateOutcome({
        project,
        expectedDate: project.expected_completion_date,
        actualDate: project.actual_completion_date,
        outcomeStatus: project.outcome_status,
      });
      if (validationError) {
        return res.status(422).json({ message: validationError });
      }

      await pool.query(
        `UPDATE projects
         SET outcome_verified = 1, verified_by = ?, verified_at = ?
         WHERE id = ?`,
        [
          req.user.id,
          isMysql ? new Date() : new Date().toISOString(),
          project.id,
        ],
      );
      const [[updated]] = await pool.query(
        `SELECT id, expected_completion_date, actual_completion_date,
                outcome_status, outcome_verified, verified_by, verified_at
         FROM projects WHERE id = ?`,
        [project.id],
      );
      return res.json(updated);
    } catch (error) {
      next(error);
    }
  },
);

export default router;
