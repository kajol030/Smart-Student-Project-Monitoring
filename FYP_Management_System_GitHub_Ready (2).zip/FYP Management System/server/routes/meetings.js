
import express from "express";
import pool from "../config/db.js";
import { authenticate } from "../middleware/auth.js";
import { notify } from "../middleware/audit.js";

const router = express.Router();

async function getProject(projectId) {
  const [[project]] = await pool.query(
    `SELECT id, student_id, supervisor_id, group_id, title
     FROM projects WHERE id = ?`,
    [projectId]
  );
  return project;
}

async function canAccessProject(project, user) {
  if (!project) return false;

  if (user.role === "admin") return true;

  if (user.role === "supervisor") {
    return Number(project.supervisor_id) === Number(user.id);
  }

  if (user.role !== "student") return false;

  // For group projects, every student must be active.
  if (project.group_id) {
    const [[member]] = await pool.query(
      `SELECT id FROM project_group_members
       WHERE group_id = ?
         AND user_id = ?
         AND status = 'active'
       LIMIT 1`,
      [project.group_id, user.id]
    );
    return Boolean(member);
  }

  return Number(project.student_id) === Number(user.id);
}

async function getMeeting(meetingId) {
  const [[meeting]] = await pool.query(
    `SELECT m.*, p.student_id, p.supervisor_id,
            p.group_id, p.title AS project_title
     FROM meetings m
     JOIN projects p ON p.id = m.project_id
     WHERE m.id = ?`,
    [meetingId]
  );
  return meeting;
}

async function notifyProjectParticipants(
  project,
  sender,
  title,
  message
) {
  const recipients = new Set();

  if (project.supervisor_id) {
    recipients.add(Number(project.supervisor_id));
  }

  if (project.group_id) {
    const [members] = await pool.query(
      `SELECT user_id FROM project_group_members
       WHERE group_id = ? AND status = 'active'`,
      [project.group_id]
    );

    for (const member of members) {
      recipients.add(Number(member.user_id));
    }
  } else if (project.student_id) {
    recipients.add(Number(project.student_id));
  }

  recipients.delete(Number(sender.id));

  for (const userId of recipients) {
    await notify(
      userId,
      title,
      message,
      "info",
      "/app/meetings"
    );
  }
}

// GET: Meetings for the logged-in user.
router.get("/my", authenticate, async (req, res, next) => {
  try {
    let sql;
    let params = [];

    if (req.user.role === "student") {
      sql = `
        SELECT m.*, u.name AS requested_by_name,
               p.title AS project_title
        FROM meetings m
        JOIN users u ON u.id = m.requested_by
        JOIN projects p ON p.id = m.project_id
        WHERE (
          (p.group_id IS NULL AND p.student_id = ?)
          OR EXISTS (
            SELECT 1 FROM project_group_members gm
            WHERE gm.group_id = p.group_id
              AND gm.user_id = ?
              AND gm.status = 'active'
          )
        )
        ORDER BY m.scheduled_at DESC, m.id DESC
      `;
      params = [req.user.id, req.user.id];
    } else if (req.user.role === "supervisor") {
      sql = `
        SELECT m.*, u.name AS requested_by_name,
               p.title AS project_title
        FROM meetings m
        JOIN users u ON u.id = m.requested_by
        JOIN projects p ON p.id = m.project_id
        WHERE p.supervisor_id = ?
        ORDER BY m.scheduled_at DESC, m.id DESC
      `;
      params = [req.user.id];
    } else if (req.user.role === "admin") {
      sql = `
        SELECT m.*, u.name AS requested_by_name,
               p.title AS project_title
        FROM meetings m
        JOIN users u ON u.id = m.requested_by
        JOIN projects p ON p.id = m.project_id
        ORDER BY m.scheduled_at DESC, m.id DESC
        LIMIT 50
      `;
    } else {
      return res.status(403).json({
        message: "Access denied.",
      });
    }

    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

// GET: Meetings for a specific project.
router.get(
  "/project/:projectId",
  authenticate,
  async (req, res, next) => {
    try {
      const projectId = Number(req.params.projectId);

      if (!Number.isInteger(projectId) || projectId < 1) {
        return res.status(400).json({
          message: "Invalid project ID.",
        });
      }

      const project = await getProject(projectId);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (!(await canAccessProject(project, req.user))) {
        return res.status(403).json({
          message:
            "Access denied to this project's meetings.",
        });
      }

      const [rows] = await pool.query(
        `SELECT m.*, u.name AS requested_by_name
         FROM meetings m
         JOIN users u ON u.id = m.requested_by
         WHERE m.project_id = ?
         ORDER BY m.scheduled_at DESC, m.id DESC`,
        [projectId]
      );

      res.json(rows);
    } catch (error) {
      next(error);
    }
  }
);

// POST: Request a meeting.
router.post("/", authenticate, async (req, res, next) => {
  try {
    const {
      project_id,
      agenda,
      scheduled_at,
      location,
      meeting_type,
    } = req.body;

    const projectId = Number(project_id);

    if (!Number.isInteger(projectId) || projectId < 1) {
      return res.status(400).json({
        message: "Valid project ID is required.",
      });
    }

    if (
      typeof agenda !== "string" ||
      !agenda.trim() ||
      agenda.length > 1000
    ) {
      return res.status(400).json({
        message: "A valid meeting agenda is required.",
      });
    }

    const project = await getProject(projectId);

    if (!project) {
      return res.status(404).json({
        message: "Project not found.",
      });
    }

    if (!(await canAccessProject(project, req.user))) {
      return res.status(403).json({
        message:
          "You cannot request a meeting for this project.",
      });
    }

    const [result] = await pool.query(
      `INSERT INTO meetings
       (
         project_id,
         requested_by,
         agenda,
         scheduled_at,
         location,
         meeting_type
       )
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        projectId,
        req.user.id,
        agenda.trim(),
        scheduled_at || null,
        location || null,
        meeting_type || "in_person",
      ]
    );

    await notifyProjectParticipants(
      project,
      req.user,
      "Meeting Request",
      `${req.user.name} requested a meeting: ${agenda.trim()}`
    );

    res.status(201).json({
      message: "Meeting requested.",
      id: result.insertId,
    });
  } catch (error) {
    next(error);
  }
});

// PUT: Update an existing meeting.
router.put("/:id", authenticate, async (req, res, next) => {
  try {
    const meetingId = Number(req.params.id);

    if (!Number.isInteger(meetingId) || meetingId < 1) {
      return res.status(400).json({
        message: "Invalid meeting ID.",
      });
    }

    const {
      status,
      minutes,
      scheduled_at,
      location,
    } = req.body;

    const allowedStatuses = [
      "pending",
      "completed",
      "cancelled",
    ];

    if (status && !allowedStatuses.includes(status)) {
      return res.status(400).json({
        message: "Invalid meeting status.",
      });
    }

    const meeting = await getMeeting(meetingId);

    if (!meeting) {
      return res.status(404).json({
        message: "Meeting not found.",
      });
    }

    const project = await getProject(meeting.project_id);

    if (!(await canAccessProject(project, req.user))) {
      return res.status(403).json({
        message:
          "You are not allowed to update this meeting.",
      });
    }

    // Students may update only meetings they requested.
    // Assigned supervisors and admins may update any
    // meeting associated with the project.
    if (
      req.user.role === "student" &&
      Number(meeting.requested_by) !== Number(req.user.id)
    ) {
      return res.status(403).json({
        message:
          "Only the student who requested this meeting can update it.",
      });
    }

    await pool.query(
      `UPDATE meetings
       SET status = COALESCE(?, status),
           minutes = COALESCE(?, minutes),
           scheduled_at = COALESCE(?, scheduled_at),
           location = COALESCE(?, location)
       WHERE id = ?`,
      [
        status || null,
        minutes ?? null,
        scheduled_at || null,
        location || null,
        meetingId,
      ]
    );

    res.json({
      message: "Meeting updated.",
    });
  } catch (error) {
    next(error);
  }
});

// DELETE: Requester, assigned supervisor or admin only.
router.delete("/:id", authenticate, async (req, res, next) => {
  try {
    const meetingId = Number(req.params.id);

    if (!Number.isInteger(meetingId) || meetingId < 1) {
      return res.status(400).json({
        message: "Invalid meeting ID.",
      });
    }

    const meeting = await getMeeting(meetingId);

    if (!meeting) {
      return res.status(404).json({
        message: "Meeting not found.",
      });
    }

    const project = await getProject(meeting.project_id);

    if (!(await canAccessProject(project, req.user))) {
      return res.status(403).json({
        message:
          "You are not allowed to cancel this meeting.",
      });
    }

    if (
      req.user.role === "student" &&
      Number(meeting.requested_by) !== Number(req.user.id)
    ) {
      return res.status(403).json({
        message:
          "Only the student who requested this meeting can cancel it.",
      });
    }

    await pool.query(
      "DELETE FROM meetings WHERE id = ?",
      [meetingId]
    );

    res.json({
      message: "Meeting cancelled.",
    });
   } catch (error) {
    next(error);
  }
});

export default router;