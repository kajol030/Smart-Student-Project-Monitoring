import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();

router.get("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const [users] = await pool.query(
      "SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC"
    );
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/supervisors", authenticate, async (req, res) => {
  try {
    const [supervisors] = await pool.query(
      `SELECT u.id, u.name, u.email, COALESCE(up.specialization, '') AS specialization,
        COALESCE(up.max_students, 5) AS max_students,
        (SELECT COUNT(*) FROM projects p WHERE p.supervisor_id = u.id) AS assigned_count
       FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id
       WHERE u.role = 'supervisor' AND u.is_active = 1 ORDER BY u.name`
    );
    res.json(supervisors);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/students", authenticate, authorize("admin", "supervisor", "student"), async (req, res) => {
  try {
    const [students] = await pool.query(
      "SELECT id, name, email FROM users WHERE role = 'student' AND is_active = 1"
    );
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/peers", authenticate, authorize("student"), async (req, res) => {
  try {
    const [students] = await pool.query("SELECT id, name, email FROM users WHERE role='student' AND is_active=1 AND id<>? ORDER BY name", [req.user.id]);
    res.json(students);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

router.delete("/:id", authenticate, authorize("admin"), async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await pool.query("DELETE FROM users WHERE id = ?", [id]);

    // pool implementations return affectedRows for mysql and affectedRows for sqlite wrapper
    const affected = result.affectedRows ?? result.changes ?? 0;

    if (!affected) return res.status(404).json({ message: "User not found" });

    res.json({ message: "User deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
