import express from "express";
import { param } from "express-validator";
import pool from "../config/db.js";
import { auth } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { getGithubProjectData } from "../services/githubService.js";
import { computeImplementationProgress } from "../services/progressService.js";

const router = express.Router();

/**
 * GET /api/github/project/:projectId
 *
 * Fetch live GitHub repository data for an FYP project.
 *
 * Authorization:
 *   - Student      : own project OR active member of the project group
 *   - Supervisor   : only their assigned project
 *   - Admin        : any project
 *
 * The route does NOT write to the database.
 */
router.get(
  "/project/:projectId",
  auth,
  [
    param("projectId")
      .isInt({ min: 1 })
      .withMessage("projectId must be a positive integer."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const projectId = Number(req.params.projectId);

      // ── 1. Fetch project ────────────────────────────────────────────────
      const [[project]] = await pool.query(
        `SELECT
          id,
          student_id,
          supervisor_id,
          group_id,
          title,
          github_url
         FROM projects
         WHERE id = ?`,
        [projectId]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      // ── 2. Authorization / IDOR check ───────────────────────────────────
      if (req.user.role === "admin") {
        // Admin can access any project.
      } else if (req.user.role === "supervisor") {
        // Supervisor can access only their assigned project.
        if (
          Number(project.supervisor_id) !== Number(req.user.id)
        ) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      } else if (req.user.role === "student") {
        // Solo project
        if (!project.group_id) {
          if (
            Number(project.student_id) !== Number(req.user.id)
          ) {
            return res.status(403).json({
              message: "Access denied.",
            });
          }
        }

        // Group project
        else {
          const [[member]] = await pool.query(
            `SELECT id
             FROM project_group_members
             WHERE group_id = ?
               AND user_id = ?
               AND status = 'active'
             LIMIT 1`,
            [project.group_id, req.user.id]
          );

          if (!member) {
            return res.status(403).json({
              message: "Access denied.",
            });
          }
        }
      } else {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      // ── 3. Check GitHub URL ─────────────────────────────────────────────
      if (!project.github_url) {
        return res.status(400).json({
          message:
            "No GitHub repository URL is configured for this project. " +
            "Please add a GitHub repository URL to your project first.",
        });
      }

      // ── 4. Fetch live GitHub data ───────────────────────────────────────
      let githubData;

      try {
        githubData = await getGithubProjectData(project.github_url, {
          allowPrivate: req.user.role !== "student",
        });
      } catch (githubErr) {
        const msg = githubErr.message || "";

        // Repository not found
        if (msg.toLowerCase().includes("not found") || msg.includes("404")) {
          return res.status(404).json({
            message:
              "GitHub repository not found or is not accessible to the configured account. " +
              "Verify the URL and, for private repositories, configure an authorized server-side GITHUB_TOKEN.",
          });
        }

        if (msg.toLowerCase().includes("invalid github repository url") ||
            msg.toLowerCase().includes("github url is required")) {
          return res.status(400).json({ message: msg });
        }
        if (msg.toLowerCase().includes("private repository data")) {
          return res.status(403).json({ message: msg });
        }
        if (msg.toLowerCase().includes("authentication failed")) {
          return res.status(503).json({
            message: "GitHub authentication failed. Check the server-side GITHUB_TOKEN configuration.",
          });
        }
        if (msg.toLowerCase().includes("rate limit")) {
          return res.status(429).json({ message: msg });
        }
        if (msg.includes("403")) {
          return res.status(403).json({ message: msg });
        }
        if (msg.toLowerCase().includes("timed out") ||
            msg.toLowerCase().includes("network error")) {
          return res.status(502).json({
            message:
              "Unable to reach GitHub API at this time. Please try again later.",
          });
        }

        // Other GitHub errors
        return res.status(502).json({
          message:
            "GitHub API request failed. Please try again later.",
        });
      }

      // ── 5. Return GitHub data ───────────────────────────────────────────
      const implementation = await computeImplementationProgress(projectId, githubData);

      return res.json({
        github_url: project.github_url,
        data: githubData,
        implementation_progress: implementation,
        notes: [
          "Commit counts describe recent fetched activity (up to 30 commits), not percent complete.",
          "Use implementation_progress for an evidence-based estimate alongside milestone progress.",
        ],
      });
    } catch (e) {
      next(e);
    }
  }
);

export default router;