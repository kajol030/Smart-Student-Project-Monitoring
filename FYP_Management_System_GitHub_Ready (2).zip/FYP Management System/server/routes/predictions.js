import express from "express";
import dotenv from "dotenv";
import pool, { isMysql } from "../config/db.js";
import {
  auth,
  authenticate,
  authorize,
} from "../middleware/auth.js";
import {
  callMLService,
  extractProjectFeatures,
  generateRecommendations,
} from "../services/aiService.js";
import { assertProjectAccess } from "../utils/projectAccess.js";

dotenv.config();

const ML_URL =
  process.env.ML_SERVICE_URL || "http://localhost:5001";

const router = express.Router();

async function forwardSyntheticDemo(req, res, next, pathname) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(`${ML_URL}${pathname}`, {
      method: req.method,
      headers: req.method === "POST" ? { "Content-Type": "application/json" } : undefined,
      body: req.method === "POST" ? JSON.stringify(req.body) : undefined,
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => ({}));
    return res.status(response.status).json(payload);
  } catch (error) {
    if (error.name === "AbortError") {
      return res.status(504).json({ message: "Synthetic Logistic Regression service timed out." });
    }
    return next(error);
  } finally {
    clearTimeout(timeout);
  }
}

router.get(
  "/synthetic-demo/health",
  authenticate,
  (req, res, next) => forwardSyntheticDemo(req, res, next, "/health"),
);

router.get(
  "/synthetic-demo/evaluation",
  authenticate,
  (req, res, next) => forwardSyntheticDemo(
    req, res, next, "/demo/synthetic-risk/evaluation"
  ),
);

router.post(
  "/synthetic-demo/predict",
  authenticate,
  (req, res, next) => forwardSyntheticDemo(
    req, res, next, "/demo/synthetic-risk/predict"
  ),
);

/* =========================================================
   GET PREDICTION FOR PROJECT
   ========================================================= */

router.get("/project/:projectId", auth, async (req, res, next) => {
  const connection = isMysql ? await pool.getConnection() : pool;

  try {
    const projectId = Number(req.params.projectId);

    if (!Number.isInteger(projectId) || projectId <= 0) {
      return res.status(400).json({
        message: "Invalid project ID.",
      });
    }

    /* -------------------------------------------------------
       GET PROJECT
       ------------------------------------------------------- */

    const [[projectCheck]] = await pool.query(
      `SELECT student_id, supervisor_id, group_id
       FROM projects
       WHERE id = ?`,
      [projectId]
    );

    if (!projectCheck) {
      return res.status(404).json({
        message: "Project not found.",
      });
    }

    /* -------------------------------------------------------
       ACCESS CONTROL
       ------------------------------------------------------- */

    // ADMIN
    if (req.user.role === "admin") {
      // Admin can access all projects.
    }

    // SUPERVISOR
    else if (req.user.role === "supervisor") {
      if (
        Number(projectCheck.supervisor_id) !==
        Number(req.user.id)
      ) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }
    }

    // STUDENT
    else if (req.user.role === "student") {

      /* -----------------------------------------------------
         SOLO PROJECT
         ----------------------------------------------------- */

      if (!projectCheck.group_id) {
        if (
          Number(projectCheck.student_id) !==
          Number(req.user.id)
        ) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      }

      /* -----------------------------------------------------
         GROUP PROJECT
         ----------------------------------------------------- */

      else {
        const [[member]] = await pool.query(
          `SELECT id
           FROM project_group_members
           WHERE group_id = ?
             AND user_id = ?
             AND status = 'active'
           LIMIT 1`,
          [
            projectCheck.group_id,
            req.user.id,
          ]
        );

        if (!member) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      }
    }

    // OTHER / UNKNOWN ROLE
    else {
      return res.status(403).json({
        message: "Access denied.",
      });
    }

    /* -------------------------------------------------------
       EXTRACT PROJECT FEATURES
       ------------------------------------------------------- */

    let features;
    try {
      features = await extractProjectFeatures(projectId, {
        allowPrivateGithub: req.user.role !== "student",
      });
    } catch (error) {
      if (error.message.includes("Private repository data")) {
        return res.status(403).json({ message: error.message });
      }
      throw error;
    }

    await connection.query(
      isMysql
        ? `INSERT INTO project_feature_snapshots
             (project_id, snapshot_date, captured_at, features_snapshot)
           VALUES (?, CURRENT_DATE, NOW(), ?)
           ON DUPLICATE KEY UPDATE id = id`
        : `INSERT OR IGNORE INTO project_feature_snapshots
             (project_id, snapshot_date, captured_at, features_snapshot)
           VALUES (?, date('now'), datetime('now'), ?)
           `,
      [projectId, JSON.stringify(features)],
    );

    /* -------------------------------------------------------
       ML PAYLOAD
       ------------------------------------------------------- */

    const mlPayload = {
      // Current model's 7 core features
      progress: features.progress,
      completed_milestones:
        features.completed_milestones,
      overdue_milestones:
        features.overdue_milestones,
      pending_submissions:
        features.pending_submissions,
      rejected_submissions:
        features.rejected_submissions,
      feedback_count:
        features.feedback_count,
      days_since_activity:
        features.days_since_activity,

      // GitHub features
      total_commits:
        features.total_commits,
      recent_commits:
        features.recent_commits,
      commit_frequency:
        features.commit_frequency,
      active_days:
        features.active_days,
      recent_activity_days:
        features.recent_activity_days,
      pull_requests:
        features.pull_requests,
      merged_prs:
        features.merged_prs,
      open_issues:
        features.open_issues,
      closed_issues:
        features.closed_issues,
      github_evidence_available: Number(features.github_evidence_available),
    };

    /* -------------------------------------------------------
       CALL ML SERVICE
       ------------------------------------------------------- */

    let pred = await callMLService(mlPayload);

    if (!pred) {
      return res.json({
        prediction_available: false,
        model_info: {
          model_name: null,
          model_type: "logistic_regression",
          training_status: "service_unavailable",
          evaluation_metrics: null,
          message: "The ML service is unavailable. No prediction was generated.",
        },
        features,
      });
    }

    if (pred.http_status === 503 || pred.error) {
      return res.json({
        prediction_available: false,
        model_info: pred.model_info || {
          model_name: null,
          model_type: "logistic_regression",
          training_status: "insufficient_data",
          evaluation_metrics: null,
          message: pred.error || "The synthetic Logistic Regression model is not available.",
        },
        features,
      });
    }

    const evaluationMetrics = pred.model_info?.evaluation_metrics;
    const hasEvaluatedModel = pred.model_info?.training_status === "trained"
      && typeof pred.model_info.model_name === "string"
      && evaluationMetrics !== null
      && typeof evaluationMetrics === "object"
      && !Array.isArray(evaluationMetrics);
    if (!hasEvaluatedModel) {
      return res.json({
        prediction_available: false,
        model_info: {
          model_name: null,
          model_type: "logistic_regression",
          training_status: "insufficient_data",
          evaluation_metrics: null,
          message: "No synthetic Logistic Regression model is available. No prediction was generated.",
        },
        features,
      });
    }

    /* -------------------------------------------------------
       PREDICTION VALUES
       ------------------------------------------------------- */

    const riskLevel = typeof pred.risk_level === "string"
      && ["low", "medium", "high"].includes(pred.risk_level.toLowerCase())
      ? pred.risk_level.toLowerCase()
      : null;
    if (!riskLevel || typeof pred.predicted_outcome !== "string") {
      return res.status(502).json({
        message: "The ML service returned an invalid classification.",
      });
    }

    const riskScore = Number.isFinite(Number(pred.risk_score))
      ? Number(pred.risk_score)
      : null;
    const optionalProbability = (value) => {
      if (value === null || value === undefined || value === "") return null;
      const probability = Number(value);
      return Number.isFinite(probability)
        ? Math.min(Math.max(probability, 0), 1)
        : null;
    };
    const delayProb = optionalProbability(pred.delay_probability);
    const failureProb = optionalProbability(pred.failure_probability);
    const compChance = optionalProbability(
      pred.completion_chance ?? pred.completion_probability
    );
    const modelUsed = pred.model_used || pred.model_info.model_name;
    const modelInfo = pred.model_info;
    const riskProbabilities = {};
    for (const [label, probability] of Object.entries(pred.risk_probabilities || {})) {
      const normalizedLabel = label.toLowerCase();
      const normalizedProbability = optionalProbability(probability);
      if (
        ["low", "medium", "high"].includes(normalizedLabel)
        && normalizedProbability !== null
      ) {
        riskProbabilities[normalizedLabel] = normalizedProbability;
      }
    }
    if (Object.keys(riskProbabilities).length !== 3) {
      return res.status(502).json({
        message: "The Logistic Regression service returned invalid risk probabilities.",
      });
    }

    /* -------------------------------------------------------
       TRANSACTION
       ------------------------------------------------------- */

    if (isMysql) {
      await connection.beginTransaction();
    }

    /* -------------------------------------------------------
       SAVE PREDICTION HISTORY
       ------------------------------------------------------- */

    await connection.query(
      `INSERT INTO prediction_history
       (
         project_id,
         risk_level,
         risk_score,
         delay_probability,
         completion_chance,
         model_version,
         features_snapshot
       )
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        projectId,
        riskLevel,
        riskScore,
        delayProb,
        compChance,
        modelUsed,
        JSON.stringify(features),
      ]
    );

    /* -------------------------------------------------------
       UPDATE PROJECT
       ------------------------------------------------------- */

    await connection.query(
      isMysql
        ? `UPDATE projects
           SET risk_level = ?,
               delay_probability = ?,
               completion_chance = ?,
               updated_at = NOW()
           WHERE id = ?`
        : `UPDATE projects
           SET risk_level = ?,
               delay_probability = ?,
               completion_chance = ?,
               updated_at = datetime('now')
           WHERE id = ?`,
      [
        riskLevel,
        delayProb,
        compChance,
        projectId,
      ]
    );

    /* -------------------------------------------------------
       RECOMMENDATIONS
       ------------------------------------------------------- */

    await connection.query(
      `DELETE FROM recommendations
       WHERE project_id = ?`,
      [projectId]
    );

    const recs =
      generateRecommendations(features);

    for (const r of recs) {
      await connection.query(
        `INSERT INTO recommendations
         (
           project_id,
           message,
           priority
         )
         VALUES (?, ?, ?)`,
        [
          projectId,
          r.message,
          r.priority,
        ]
      );
    }

    /* -------------------------------------------------------
       COMMIT
       ------------------------------------------------------- */

    if (isMysql) {
      await connection.commit();
    }

    /* -------------------------------------------------------
       RESPONSE
       ------------------------------------------------------- */

    return res.json({
      prediction_available: true,
      predicted_outcome: pred.predicted_outcome,
      risk_class: pred.risk_class || riskLevel,
      risk_probabilities: riskProbabilities,
      risk_level: riskLevel,
      risk_score: riskScore,
      delay_probability: delayProb,
      completion_chance: compChance,
      failure_probability: failureProb,
      model_used: modelUsed,
      model_info: modelInfo,
      features,
      disclaimer: "Synthetic Dataset Evaluation — Not Real-world Validation",
      recommendations: recs,
      shap_values:
        pred.shap_values || null,
    });

  } catch (e) {

    if (isMysql) {
      try {
        await connection.rollback();
      } catch {}
    }

    next(e);

  } finally {

    if (isMysql) {
      connection.release();
    }
  }
});

/* =========================================================
   PREDICTION HISTORY
   ========================================================= */

router.get(
  "/history/:projectId",
  authenticate,
  async (req, res, next) => {
    try {
      const project = await assertProjectAccess(req, res, req.params.projectId);
      if (!project) return;
      const [rows] = await pool.query(
        `SELECT
           id,
           risk_level,
           risk_score,
           delay_probability,
           completion_chance,
           model_version,
           created_at
         FROM prediction_history
         WHERE project_id = ?
         ORDER BY created_at DESC
         LIMIT 20`,
        [req.params.projectId]
      );

      return res.json(
        rows.reverse()
      );

    } catch (e) {
      next(e);
    }
  }
);

/* =========================================================
   ADMIN ANALYTICS
   ========================================================= */

router.get(
  "/analytics",
  authenticate,
  authorize("admin"),
  async (req, res, next) => {
    try {
      const {
        program_id,
        batch_id,
        supervisor_id,
        status,
        risk,
        category,
      } = req.query;

      let where = "WHERE 1=1";
      const filters = [];

      if (program_id) {
        where += " AND up.program_id=?";
        filters.push(program_id);
      }

      if (batch_id) {
        where += " AND up.batch_id=?";
        filters.push(batch_id);
      }

      if (supervisor_id) {
        where += " AND p.supervisor_id=?";
        filters.push(supervisor_id);
      }

      if (status) {
        where += " AND p.status=?";
        filters.push(status);
      }

      if (risk) {
        where += " AND p.risk_level=?";
        filters.push(risk);
      }

      if (category) {
        where += " AND p.category=?";
        filters.push(category);
      }

      const projectJoin =
        `FROM projects p
         LEFT JOIN user_profiles up
         ON up.user_id=p.student_id`;

      const [[stats]] =
        await pool.query(
          `
          SELECT
            COUNT(*) AS total_projects,

            SUM(
              CASE
                WHEN p.status='completed'
                THEN 1 ELSE 0
              END
            ) AS completed,

            SUM(
              CASE
                WHEN p.status='in_progress'
                THEN 1 ELSE 0
              END
            ) AS in_progress,

            SUM(
              CASE
                WHEN p.status='proposal'
                THEN 1 ELSE 0
              END
            ) AS proposals,

            SUM(
              CASE
                WHEN p.risk_level='high'
                THEN 1 ELSE 0
              END
            ) AS high_risk,

            SUM(
              CASE
                WHEN p.risk_level='medium'
                THEN 1 ELSE 0
              END
            ) AS medium_risk,

            SUM(
              CASE
                WHEN p.risk_level='low'
                THEN 1 ELSE 0
              END
            ) AS low_risk,

            ROUND(
              AVG(p.progress),
              1
            ) AS avg_progress

          ${projectJoin}
          ${where}
          `,
          filters
        );

      const [riskDistribution] =
        await pool.query(
          `
          SELECT
            p.risk_level,
            COUNT(*) AS count

          ${projectJoin}
          ${where}

          GROUP BY p.risk_level
          `,
          filters
        );

      const [statusDistribution] =
        await pool.query(
          `
          SELECT
            p.status,
            COUNT(*) AS count

          ${projectJoin}
          ${where}

          GROUP BY p.status
          `,
          filters
        );

      const [submissionTrend] =
        await pool.query(
          isMysql
            ? `
              SELECT
                YEARWEEK(
                  submitted_at,
                  1
                ) AS week_key,
                COUNT(*) AS count
              FROM submissions
              WHERE submitted_at >=
                DATE_SUB(
                  NOW(),
                  INTERVAL 8 WEEK
                )
              GROUP BY week_key
              ORDER BY week_key
              `
            : `
              SELECT
                strftime(
                  '%Y-%W',
                  submitted_at
                ) AS week_key,
                COUNT(*) AS count
              FROM submissions
              WHERE submitted_at >=
                datetime(
                  'now',
                  '-56 days'
                )
              GROUP BY week_key
              ORDER BY week_key
              `
        );

      return res.json({
        stats,
        riskDistribution,
        statusDistribution,
        submissionTrend,
      });

    } catch (e) {
      next(e);
    }
  }
);

/* =========================================================
   EXPLAIN PREDICTION
   ========================================================= */

router.get(
  "/explain/:projectId",
  auth,
  async (req, res, next) => {
    try {
      const { assertProjectAccess } = await import("../utils/projectAccess.js");
      const project = await assertProjectAccess(req, res, req.params.projectId);
      if (!project) return;

      const features =
        await extractProjectFeatures(
          req.params.projectId
        );

      const ctrl =
        new AbortController();

      const t = setTimeout(
        () => ctrl.abort(),
        8000
      );

      const r = await fetch(
        `${ML_URL}/explain`,
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body:
            JSON.stringify(features),
          signal: ctrl.signal,
        }
      ).catch(() => null);

      clearTimeout(t);

      if (!r || !r.ok) {
        return res.json({
          message:
            "ML service unavailable.",
          shap_values: null,
        });
      }

      return res.json(
        await r.json()
      );

    } catch (e) {
      next(e);
    }
  }
);

export default router;