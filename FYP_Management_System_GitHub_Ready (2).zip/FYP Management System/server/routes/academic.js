import express from "express";
import { body, param } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";

const router = express.Router();
const admin = [authenticate, authorize("admin")];
const resources = {
  programs: { table: "programs", fields: ["department_id", "name", "code"] },
  academicYears: { table: "academic_years", fields: ["name", "start_date", "end_date"] },
  semesters: { table: "semesters", fields: ["academic_year_id", "name", "number"] },
  sections: { table: "sections", fields: ["batch_id", "semester_id", "name"] },
  batches: { table: "batches", fields: ["name", "department_id", "start_date", "end_date"] },
};
for (const [path, resource] of Object.entries(resources)) {
  router.get(`/${path}`, authenticate, async (req, res, next) => { try { const [rows] = await pool.query(`SELECT * FROM ${resource.table} ORDER BY id DESC`); res.json(rows); } catch (e) { next(e); } });
  router.post(`/${path}`, ...admin, resource.fields.map((field) => body(field).trim().notEmpty()), validate, async (req, res, next) => {
    try { const values = resource.fields.map((field) => req.body[field]); const [result] = await pool.query(`INSERT INTO ${resource.table} (${resource.fields.join(",")}) VALUES (${resource.fields.map(() => "?").join(",")})`, values); res.status(201).json({ id: result.insertId, message: "Created." }); } catch (e) { next(e); }
  });
  router.put(`/${path}/:id`, ...admin, param("id").isInt({ min: 1 }), validate, async (req, res, next) => {
    try { const fields = resource.fields.filter((field) => req.body[field] !== undefined); if (!fields.length) return res.status(400).json({ message: "No fields to update." }); await pool.query(`UPDATE ${resource.table} SET ${fields.map((field) => `${field}=?`).join(",")} WHERE id=?`, [...fields.map((field) => req.body[field]), req.params.id]); res.json({ message: "Updated." }); } catch (e) { next(e); }
  });
  router.delete(`/${path}/:id`, ...admin, param("id").isInt({ min: 1 }), validate, async (req, res, next) => { try { await pool.query(`UPDATE ${resource.table} SET is_active=0 WHERE id=?`, [req.params.id]); res.json({ message: "Deactivated." }); } catch (e) { next(e); } });
}
router.get("/hierarchy", authenticate, async (req, res, next) => { try { const [[department]] = await pool.query("SELECT * FROM departments WHERE name='ICT Department' LIMIT 1"); const [programs] = await pool.query("SELECT * FROM programs WHERE is_active=1 ORDER BY name"); const [years] = await pool.query("SELECT * FROM academic_years WHERE is_active=1 ORDER BY name DESC"); const [batches] = await pool.query("SELECT * FROM batches WHERE is_active=1 ORDER BY name"); const [semesters] = await pool.query("SELECT * FROM semesters WHERE is_active=1 ORDER BY number"); const [sections] = await pool.query("SELECT * FROM sections WHERE is_active=1 ORDER BY name"); res.json({ department, programs, years, batches, semesters, sections }); } catch (e) { next(e); } });
export default router;
