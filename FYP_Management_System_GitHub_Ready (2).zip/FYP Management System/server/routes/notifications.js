import express from "express";
import pool from "../config/db.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

router.get("/", authenticate, async (req, res, next) => {
  try {
    const page=Math.max(1,parseInt(req.query.page)||1), limit=Math.min(50,parseInt(req.query.limit)||20);
    const offset=(page-1)*limit;
    const [rows] = await pool.query(
      "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?",
      [req.user.id,limit,offset]);
    const [[{total}]] = await pool.query("SELECT COUNT(*) AS total FROM notifications WHERE user_id=?",[req.user.id]);
    const [[{unread}]] = await pool.query("SELECT COUNT(*) AS unread FROM notifications WHERE user_id=? AND is_read=0",[req.user.id]);
    res.json({ notifications:rows, total, unread, page, limit });
  } catch (e) { next(e); }
});

router.get("/unread-count", authenticate, async (req, res, next) => {
  try {
    const [[{count}]] = await pool.query("SELECT COUNT(*) AS count FROM notifications WHERE user_id=? AND is_read=0",[req.user.id]);
    res.json({ count });
  } catch (e) { next(e); }
});

router.put("/read-all", authenticate, async (req, res, next) => {
  try {
    await pool.query("UPDATE notifications SET is_read=1 WHERE user_id=?", [req.user.id]);
    res.json({ message: "All marked read." });
  } catch (e) { next(e); }
});

router.put("/:id/read", authenticate, async (req, res, next) => {
  try {
    await pool.query("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?", [req.params.id,req.user.id]);
    res.json({ message: "Marked as read." });
  } catch (e) { next(e); }
});

router.delete("/:id", authenticate, async (req, res, next) => {
  try {
    await pool.query("DELETE FROM notifications WHERE id=? AND user_id=?", [req.params.id,req.user.id]);
    res.json({ message: "Notification deleted." });
  } catch (e) { next(e); }
});

export default router;
