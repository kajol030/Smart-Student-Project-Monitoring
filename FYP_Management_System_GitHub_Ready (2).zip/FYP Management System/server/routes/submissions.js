
import express from "express";
import { body, param, query } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { upload } from "../middleware/upload.js";
import { notify } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";
import { SUBMISSION_STATUS } from "./constants.js";

const router = express.Router();

/*
 * Project access:
 * - Admin: any project
 * - Supervisor: assigned project
 * - Student: project owner OR active member of
 *   the group linked through projects.group_id
 */
async function canAccessProject(project, user) {
  if (user.role === "admin") return true;

  if (user.role === "supervisor") {
    return Number(project.supervisor_id) === Number(user.id);
  }

  if (user.role !== "student") return false;

  if (Number(project.student_id) === Number(user.id)) {
    return true;
  }

  if (!project.group_id) return false;

  const [[member]] = await pool.query(
    `SELECT id
     FROM project_group_members
     WHERE group_id = ?
       AND user_id = ?
       AND status = 'active'
     LIMIT 1`,
    [project.group_id, user.id]
  );

  return Boolean(member);
}

async function getProject(projectId) {
  const [[project]] = await pool.query(
    `SELECT id, student_id, supervisor_id, group_id, title
     FROM projects
     WHERE id = ?`,
    [projectId]
  );

  return project;
}

/* GET PROJECT SUBMISSIONS */
router.get(
  "/project/:projectId",
  authenticate,
  [
    param("projectId")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),

    query("page")
      .optional()
      .isInt({ min: 1 })
      .toInt(),

    query("limit")
      .optional()
      .isInt({ min: 1, max: 50 })
      .toInt(),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { projectId } = req.params;
      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 10;
      const offset = (page - 1) * limit;

      const project = await getProject(projectId);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (!(await canAccessProject(project, req.user))) {
        return res.status(403).json({
          message:
            "Access denied to this project's submissions.",
        });
      }

      const [rows] = await pool.query(
        `SELECT s.*, u.name AS student_name
         FROM submissions s
         JOIN users u ON u.id = s.student_id
         WHERE s.project_id = ?
         ORDER BY s.submitted_at DESC
         LIMIT ? OFFSET ?`,
        [projectId, limit, offset]
      );

      const [[count]] = await pool.query(
        `SELECT COUNT(*) AS total
         FROM submissions
         WHERE project_id = ?`,
        [projectId]
      );

      res.json({
        submissions: rows,
        total: Number(count.total),
        page,
        limit,
      });
    } catch (e) {
      next(e);
    }
  }
);

/* UPLOAD NEW SUBMISSION */
router.post(
  "/",
  authenticate,
  authorize("student"),
  upload.single("file"),
  [
    body("project_id")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),

    body("type")
      .isIn(["proposal", "report", "document", "final"])
      .withMessage("Invalid submission type."),

    body("title")
      .trim()
      .isLength({ min: 3, max: 200 })
      .withMessage(
        "Title must be between 3 and 200 characters."
      ),

    body("notes")
      .optional()
      .trim()
      .isLength({ max: 1000 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { project_id, type, title, notes } = req.body;
      const studentId = req.user.id;

      const project = await getProject(project_id);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (!(await canAccessProject(project, req.user))) {
        return res.status(403).json({
          message:
            "You are not authorized to submit to this project.",
        });
      }

      const filePath = req.file
        ? `/uploads/${req.file.filename}`
        : null;

      const [result] = await pool.query(
        `INSERT INTO submissions
         (project_id, student_id, type, title, file_path, notes)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          project_id,
          studentId,
          type,
          title,
          filePath,
          notes || "",
        ]
      );

      if (filePath) {
        await pool.query(
          `INSERT INTO document_versions
           (submission_id, file_path, version, uploaded_by)
           VALUES (?, ?, 1, ?)`,
          [result.insertId, filePath, studentId]
        );
      }

      if (project.supervisor_id) {
        await notify(
          project.supervisor_id,
          "New Document Submitted",
          `${req.user.name} submitted ${type}: "${title}" for project "${project.title}"`,
          "info",
          "/app/supervisor/reviews"
        );
      }

      await pool.query(
        `INSERT INTO activity_logs
         (user_id, project_id, action)
         VALUES (?, ?, ?)`,
        [
          studentId,
          project_id,
          `Submitted ${type}: ${title}`,
        ]
      );

      res.status(201).json({
        message: "Submission uploaded.",
        id: result.insertId,
      });
    } catch (e) {
      next(e);
    }
  }
);

/* SUPERVISOR / ADMIN REVIEW */
router.put(
  "/:id/status",
  authenticate,
  authorize("supervisor", "admin"),
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage(
        "Submission ID must be a positive integer."
      ),

    body("status")
      .isIn(Object.values(SUBMISSION_STATUS))
      .withMessage("Invalid submission status."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { status } = req.body;
      const submissionId = req.params.id;

      const [[submission]] = await pool.query(
        `SELECT
           s.student_id,
           s.project_id,
           s.title,
           p.supervisor_id,
           p.title AS project_title
         FROM submissions s
         JOIN projects p ON p.id = s.project_id
         WHERE s.id = ?`,
        [submissionId]
      );

      if (!submission) {
        return res.status(404).json({
          message: "Submission not found.",
        });
      }

      if (
        req.user.role === "supervisor" &&
        Number(submission.supervisor_id) !==
          Number(req.user.id)
      ) {
        return res.status(403).json({
          message:
            "Access denied. Not your assigned project's submission.",
        });
      }

      await pool.query(
        `UPDATE submissions
         SET status = ?
         WHERE id = ?`,
        [status, submissionId]
      );

      if (submission.student_id) {
        await notify(
          submission.student_id,
          `Submission ${status}`,
          `Your document "${submission.title}" for project "${submission.project_title}" is ${status}.`,
          status === SUBMISSION_STATUS.APPROVED
            ? "success"
            : status === SUBMISSION_STATUS.REJECTED
              ? "error"
              : "warning"
        );
      }

      res.json({
        message: "Submission status updated.",
      });
    } catch (e) {
      next(e);
    }
  }
);

/* GET DOCUMENT VERSIONS */
router.get(
  "/:id/versions",
  authenticate,
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage(
        "Submission ID must be a positive integer."
      ),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[submission]] = await pool.query(
        `SELECT s.id, s.project_id
         FROM submissions s
         WHERE s.id = ?`,
        [req.params.id]
      );

      if (!submission) {
        return res.status(404).json({
          message: "Submission not found.",
        });
      }

      const project = await getProject(
        submission.project_id
      );

      if (
        !project ||
        !(await canAccessProject(project, req.user))
      ) {
        return res.status(403).json({
          message:
            "Access denied to this submission's versions.",
        });
      }

      const [rows] = await pool.query(
        `SELECT
           dv.*,
           u.name AS uploaded_by_name
         FROM document_versions dv
         LEFT JOIN users u ON u.id = dv.uploaded_by
         WHERE dv.submission_id = ?
         ORDER BY dv.version DESC`,
        [req.params.id]
      );

      res.json(rows);
    } catch (e) {
      next(e);
    }
  }
);

/* UPLOAD NEW DOCUMENT VERSION */
router.post(
  "/:id/new-version",
  authenticate,
  authorize("student"),
  upload.single("file"),
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage(
        "Submission ID must be a positive integer."
      ),
  ],
  validate,
  async (req, res, next) => {
    try {
      const submissionId = req.params.id;
      const studentId = req.user.id;

      const [[submission]] = await pool.query(
        `SELECT id, project_id
         FROM submissions
         WHERE id = ?`,
        [submissionId]
      );

      if (!submission) {
        return res.status(404).json({
          message: "Submission not found.",
        });
      }

      const project = await getProject(
        submission.project_id
      );

      if (
        !project ||
        !(await canAccessProject(project, req.user))
      ) {
        return res.status(403).json({
          message:
            "You are not authorized to add a new version to this submission.",
        });
      }

      if (!req.file) {
        return res.status(400).json({
          message:
            "File is required for a new version.",
        });
      }

      const filePath =
        `/uploads/${req.file.filename}`;

      const [[versionRow]] = await pool.query(
        `SELECT COALESCE(MAX(version), 0) AS maxVer
         FROM document_versions
         WHERE submission_id = ?`,
        [submissionId]
      );

      const newVersion =
        Number(versionRow.maxVer) + 1;

      await pool.query(
        `INSERT INTO document_versions
         (submission_id, file_path, version, uploaded_by)
         VALUES (?, ?, ?, ?)`,
        [
          submissionId,
          filePath,
          newVersion,
          studentId,
        ]
      );

      await pool.query(
        `UPDATE submissions
         SET file_path = ?, status = 'pending'
         WHERE id = ?`,
        [filePath, submissionId]
      );

      res.status(201).json({
        message: "New version uploaded.",
        version: newVersion,
      });
    } catch (e) {
      next(e);
    }
  }
);

export default router;