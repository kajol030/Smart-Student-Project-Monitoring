import express from "express";
import { param } from "express-validator";
import pool, { isMysql } from "../config/db.js";
import { authenticate } from "../middleware/auth.js";
import { avatarUpload } from "../middleware/upload.js";
import { auditLog } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";

const router = express.Router();

const profileSelect = `
  SELECT u.id,u.name,u.email,u.role,u.created_at,p.phone,p.avatar_url,p.bio,p.cgpa,
         p.specialization,p.student_id_no,p.max_students,p.department_id,p.batch_id,
         p.program_id,p.semester_id,p.section_id,
         d.name AS department_name,b.name AS batch_name,
         pr.code AS program_code,pr.name AS program_name,
         sem.name AS semester_name,sec.name AS section_name
  FROM users u LEFT JOIN user_profiles p ON u.id=p.user_id
  LEFT JOIN departments d ON p.department_id=d.id LEFT JOIN batches b ON p.batch_id=b.id
  LEFT JOIN programs pr ON p.program_id=pr.id
  LEFT JOIN semesters sem ON p.semester_id=sem.id
  LEFT JOIN sections sec ON p.section_id=sec.id
`;

async function canViewProfile(viewer, target) {
  if (viewer.role === "admin" || Number(viewer.id) === Number(target.id)) return true;
  if (viewer.role !== "supervisor" || target.role !== "student") return false;

  const [[assignment]] = await pool.query(
    `SELECT p.id
     FROM projects p
     WHERE p.supervisor_id = ?
       AND (
         p.student_id = ?
         OR EXISTS (
           SELECT 1 FROM project_group_members gm
           WHERE gm.group_id = p.group_id
             AND gm.user_id = ?
             AND gm.status = 'active'
         )
       )
     LIMIT 1`,
    [viewer.id, target.id, target.id],
  );
  return Boolean(assignment);
}

function profileUpsertSql(columns) {
  const fields = ["user_id", ...columns];
  const placeholders = fields.map(() => "?").join(",");
  const updates = columns.map((column) => `${column}=VALUES(${column})`).join(",");
  if (isMysql) {
    return `INSERT INTO user_profiles (${fields.join(",")}) VALUES (${placeholders})
            ON DUPLICATE KEY UPDATE ${updates}`;
  }
  const sqliteUpdates = columns.map((column) => `${column}=excluded.${column}`).join(",");
  return `INSERT INTO user_profiles (${fields.join(",")}) VALUES (${placeholders})
          ON CONFLICT(user_id) DO UPDATE SET ${sqliteUpdates}`;
}

router.get("/me", authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.query(`${profileSelect} WHERE u.id=?`, [req.user.id]);
    if (!rows.length) return res.status(404).json({ message: "Profile not found." });
    res.json(rows[0]);
  } catch (error) {
    next(error);
  }
});

router.get(
  "/:userId",
  authenticate,
  [param("userId").isInt({ min: 1 }).withMessage("User ID must be a positive integer.")],
  validate,
  async (req, res, next) => {
    try {
      const [[target]] = await pool.query(
        "SELECT id, role FROM users WHERE id=?",
        [req.params.userId],
      );
      if (!target) return res.status(404).json({ message: "User not found." });
      if (!(await canViewProfile(req.user, target))) {
        return res.status(403).json({ message: "Access denied." });
      }

      const [rows] = await pool.query(`${profileSelect} WHERE u.id=?`, [target.id]);
      if (!rows.length) return res.status(404).json({ message: "User not found." });
      res.json(rows[0]);
    } catch (error) {
      next(error);
    }
  },
);

router.put("/me", authenticate, async (req, res, next) => {
  try {
    const body = req.body && typeof req.body === "object" && !Array.isArray(req.body)
      ? req.body
      : {};
    const allowed = new Set(["name", "phone", "bio"]);
    if (req.user.role === "student") allowed.add("cgpa");
    if (req.user.role === "supervisor") {
      allowed.add("specialization");
      allowed.add("max_students");
    }

    const unknownFields = Object.keys(body).filter((key) => !allowed.has(key));
    if (unknownFields.length) {
      return res.status(400).json({
        message: `Profile fields cannot be changed here: ${unknownFields.join(", ")}.`,
      });
    }
    if (!Object.keys(body).length) {
      return res.status(400).json({ message: "Provide at least one profile field to update." });
    }

    let name;
    if (Object.hasOwn(body, "name")) {
      if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
        return res.status(400).json({ message: "Name must be between 2 and 100 characters." });
      }
      name = body.name.trim();
    }

    const profile = {};
    for (const field of ["phone", "bio", "specialization"]) {
      if (!Object.hasOwn(body, field)) continue;
      const maxLength = field === "bio" ? 2000 : field === "specialization" ? 200 : 30;
      if (body[field] !== null && typeof body[field] !== "string") {
        return res.status(400).json({ message: `${field} must be text.` });
      }
      const value = typeof body[field] === "string" ? body[field].trim() : "";
      if (value.length > maxLength) {
        return res.status(400).json({ message: `${field} must be at most ${maxLength} characters.` });
      }
      profile[field] = value || null;
    }

    if (Object.hasOwn(body, "cgpa")) {
      const cgpa = Number(body.cgpa);
      if (!Number.isFinite(cgpa) || cgpa < 0 || cgpa > 4) {
        return res.status(400).json({ message: "CGPA must be between 0 and 4." });
      }
      profile.cgpa = cgpa;
    }
    if (Object.hasOwn(body, "max_students")) {
      const maxStudents = Number(body.max_students);
      if (!Number.isInteger(maxStudents) || maxStudents < 1 || maxStudents > 100) {
        return res.status(400).json({ message: "Maximum students must be an integer from 1 to 100." });
      }
      profile.max_students = maxStudents;
    }

    if (name !== undefined) {
      await pool.query("UPDATE users SET name=? WHERE id=?", [name, req.user.id]);
    }
    const columns = Object.keys(profile);
    if (columns.length) {
      await pool.query(
        profileUpsertSql(columns),
        [req.user.id, ...columns.map((column) => profile[column])],
      );
    }

    await auditLog(req, "PROFILE_UPDATED", "user_profiles", req.user.id);
    res.json({ message: "Profile updated." });
  } catch (error) {
    next(error);
  }
});

router.post("/me/avatar", authenticate, avatarUpload.single("avatar"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded." });
    const avatarUrl = `/uploads/${req.file.filename}`;
    const sql = isMysql
      ? `INSERT INTO user_profiles (user_id,avatar_url) VALUES (?,?)
         ON DUPLICATE KEY UPDATE avatar_url=VALUES(avatar_url)`
      : `INSERT INTO user_profiles (user_id,avatar_url) VALUES (?,?)
         ON CONFLICT(user_id) DO UPDATE SET avatar_url=excluded.avatar_url`;
    await pool.query(sql, [req.user.id, avatarUrl]);
    res.json({ message: "Avatar updated.", avatar_url: avatarUrl });
  } catch (error) {
    next(error);
  }
});

router.get(
  "/supervisor/:supervisorId/stats",
  authenticate,
  [param("supervisorId").isInt({ min: 1 }).withMessage("Supervisor ID must be a positive integer.")],
  validate,
  async (req, res, next) => {
    try {
      const supervisorId = Number(req.params.supervisorId);
      if (req.user.role !== "admin" &&
          (req.user.role !== "supervisor" || Number(req.user.id) !== supervisorId)) {
        return res.status(403).json({ message: "Access denied." });
      }

      const [[supervisor]] = await pool.query(
        "SELECT id FROM users WHERE id=? AND role='supervisor'",
        [supervisorId],
      );
      if (!supervisor) return res.status(404).json({ message: "Supervisor not found." });

      const [[workload]] = await pool.query(
        `SELECT COUNT(*) AS total_students,
                SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN risk_level='high' THEN 1 ELSE 0 END) AS high_risk,
                ROUND(AVG(progress),1) AS avg_progress
         FROM projects WHERE supervisor_id=?`,
        [supervisorId],
      );
      const [[profile]] = await pool.query(
        "SELECT max_students FROM user_profiles WHERE user_id=?",
        [supervisorId],
      );
      const maxStudents = Number(profile?.max_students) || 5;
      res.json({
        ...workload,
        max_students: maxStudents,
        available_slots: maxStudents - Number(workload.total_students || 0),
      });
    } catch (error) {
      next(error);
    }
  },
);

export default router;
