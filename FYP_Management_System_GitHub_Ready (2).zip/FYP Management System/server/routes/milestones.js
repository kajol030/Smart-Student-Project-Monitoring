
import express from "express";
import { body, param } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { MILESTONE_STATUS } from "./constants.js";

const router = express.Router();

/*
  Access rules:
  Admin: view and create milestones for any project.
  Supervisor: view, create and update assigned projects.
  Student: view and update own project or an active
           group project.
*/

async function getProject(projectId) {
  const [[project]] = await pool.query(
    `SELECT id, student_id, supervisor_id, group_id
     FROM projects
     WHERE id = ?`,
    [projectId]
  );

  return project;
}

async function canAccessProject(project, user) {
  if (!project) return false;

  if (user.role === "admin") {
    return true;
  }

  if (user.role === "supervisor") {
    return (
      Number(project.supervisor_id) === Number(user.id)
    );
  }

  if (user.role !== "student") {
    return false;
  }

  if (Number(project.student_id) === Number(user.id)) {
    return true;
  }

  if (!project.group_id) {
    return false;
  }

  const [[member]] = await pool.query(
    `SELECT id
     FROM project_group_members
     WHERE group_id = ?
       AND user_id = ?
       AND status = 'active'
     LIMIT 1`,
    [project.group_id, user.id]
  );

  return Boolean(member);
}

/*
  GET PROJECT MILESTONES

  is_overdue is calculated from the due date.
  Completed milestones are not considered overdue.
*/
router.get(
  "/project/:projectId",
  authenticate,
  [
    param("projectId")
      .isInt({ min: 1 })
      .withMessage("Invalid project ID."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { projectId } = req.params;

      const project = await getProject(projectId);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      const allowed = await canAccessProject(
        project,
        req.user
      );

      if (!allowed) {
        return res.status(403).json({
          message:
            "Access denied to this project's milestones.",
        });
      }

      const [milestones] = await pool.query(
        `SELECT *
         FROM milestones
         WHERE project_id = ?
         ORDER BY due_date ASC, id ASC`,
        [projectId]
      );

      const today = new Date().toISOString().slice(0, 10);

      const result = milestones.map((milestone) => {
        const dueDate = milestone.due_date
          ? String(milestone.due_date).slice(0, 10)
          : null;

        const isOverdue =
          Boolean(dueDate) &&
          dueDate < today &&
          milestone.status !== "completed";

        return {
          ...milestone,
          is_overdue: isOverdue,
        };
      });

      res.json(result);
    } catch (error) {
      next(error);
    }
  }
);

/*
  CREATE MILESTONE

  Only admin or the assigned supervisor can create.
*/
router.post(
  "/",
  authenticate,
  authorize("admin", "supervisor"),
  [
    body("project_id")
      .isInt({ min: 1 })
      .withMessage("Invalid project ID."),

    body("title")
      .trim()
      .isLength({ min: 3, max: 100 })
      .withMessage(
        "Title must contain 3 to 100 characters."
      ),

    body("description")
      .optional()
      .trim()
      .isLength({ max: 1000 }),

    body("due_date")
      .optional({ nullable: true, checkFalsy: true })
      .isISO8601()
      .toDate(),
  ],
  validate,
  async (req, res, next) => {
    try {
      const {
        project_id,
        title,
        description,
        due_date,
      } = req.body;

      const project = await getProject(project_id);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (
        !(await canAccessProject(project, req.user))
      ) {
        return res.status(403).json({
          message:
            "You cannot create milestones for this project.",
        });
      }

      const [result] = await pool.query(
        `INSERT INTO milestones
         (project_id, title, description, due_date)
         VALUES (?, ?, ?, ?)`,
        [
          project_id,
          title,
          description || "",
          due_date || null,
        ]
      );

      // Recalculate progress after adding a milestone.
      await updateProjectProgress(project_id);

      res.status(201).json({
        message: "Milestone created.",
        id: result.insertId,
        title,
      });
    } catch (error) {
      next(error);
    }
  }
);

/*
  UPDATE PROJECT PROGRESS

  One milestone = one record.
  Progress = completed milestones / total milestones * 100.
*/
async function updateProjectProgress(projectId) {
  const [[counts]] = await pool.query(
    `SELECT
       COUNT(*) AS total,
       SUM(
         CASE WHEN status = 'completed'
         THEN 1 ELSE 0 END
       ) AS completed
     FROM milestones
     WHERE project_id = ?`,
    [projectId]
  );

  const total = Number(counts.total) || 0;
  const completed = Number(counts.completed) || 0;

  const progress =
    total > 0
      ? Math.round((completed / total) * 100)
      : 0;

  await pool.query(
    `UPDATE projects
     SET progress = ?
     WHERE id = ?`,
    [progress, projectId]
  );

  return {
    total,
    completed,
    progress,
  };
}

/*
  UPDATE MILESTONE STATUS

  Assigned supervisor, project owner or active group
  members can update the milestone.
*/
router.put(
  "/:id/status",
  authenticate,
  authorize("supervisor", "student"),
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("Invalid milestone ID."),

    body("status")
      .isIn(Object.values(MILESTONE_STATUS))
      .withMessage("Invalid milestone status."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const milestoneId = req.params.id;
      const { status } = req.body;

      const [[milestone]] = await pool.query(
        `SELECT id, project_id
         FROM milestones
         WHERE id = ?`,
        [milestoneId]
      );

      if (!milestone) {
        return res.status(404).json({
          message: "Milestone not found.",
        });
      }

      const project = await getProject(
        milestone.project_id
      );

      if (
        !(await canAccessProject(project, req.user))
      ) {
        return res.status(403).json({
          message:
            "You are not authorized to update this milestone.",
        });
      }

      await pool.query(
        `UPDATE milestones
         SET status = ?
         WHERE id = ?`,
        [status, milestoneId]
      );

      const progressData =
        await updateProjectProgress(
          milestone.project_id
        );

      res.json({
        message: "Milestone status updated.",
        project_id: milestone.project_id,
        total_milestones: progressData.total,
        completed_milestones: progressData.completed,
        progress: progressData.progress,
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;