import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT key_name,value,description FROM system_settings ORDER BY key_name");
    const settings = {};
    rows.forEach((r) => { settings[r.key_name] = r.value; });
    res.json({ settings, raw: rows });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const updates = Array.isArray(req.body) ? req.body : [req.body];
    for (const { key_name, value } of updates) {
      if (!key_name) continue;
      await pool.query("UPDATE system_settings SET value=? WHERE key_name=?", [String(value),key_name]);
    }
    res.json({ message: "Settings updated." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
