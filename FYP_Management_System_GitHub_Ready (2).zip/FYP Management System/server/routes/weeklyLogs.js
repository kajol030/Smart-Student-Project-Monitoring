
import express from "express";
import { body, param, query } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { notify } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";

const router = express.Router();

// Get the project associated with a weekly log.
async function getProject(projectId) {
  const [[project]] = await pool.query(
    `SELECT id, student_id, supervisor_id, group_id, title
     FROM projects
     WHERE id = ?`,
    [projectId]
  );

  return project;
}

// Group projects require active membership.
// Individual projects require ownership.
async function canAccessProject(project, user) {
  if (!project) return false;

  if (user.role === "admin") return true;

  if (user.role === "supervisor") {
    return Number(project.supervisor_id) === Number(user.id);
  }

  if (user.role !== "student") return false;

  if (project.group_id) {
    const [[member]] = await pool.query(
      `SELECT id
       FROM project_group_members
       WHERE group_id = ?
         AND user_id = ?
         AND status = 'active'
       LIMIT 1`,
      [project.group_id, user.id]
    );

    return Boolean(member);
  }

  return Number(project.student_id) === Number(user.id);
}

// GET: All weekly reports for an accessible project.
router.get(
  "/project/:projectId",
  authenticate,
  [
    param("projectId").isInt({ min: 1 }),
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 20 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const project = await getProject(req.params.projectId);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (!(await canAccessProject(project, req.user))) {
        return res.status(403).json({
          message:
            "Access denied to this project's weekly progress.",
        });
      }

      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 10;
      const offset = (page - 1) * limit;

      const [logs] = await pool.query(
        `SELECT
           wl.*,
           u.name AS student_name
         FROM weekly_logs wl
         JOIN users u ON u.id = wl.student_id
         WHERE wl.project_id = ?
         ORDER BY wl.week_number DESC, wl.id DESC
         LIMIT ? OFFSET ?`,
        [project.id, limit, offset]
      );

      const [[counts]] = await pool.query(
        `SELECT
           COUNT(*) AS total,
           COUNT(DISTINCT student_id) AS contributing_students,
           COUNT(DISTINCT week_number) AS reported_weeks,
           COALESCE(SUM(hours_worked), 0) AS total_hours,
           SUM(
             CASE WHEN status = 'reviewed'
             THEN 1 ELSE 0 END
           ) AS reviewed_logs
         FROM weekly_logs
         WHERE project_id = ?`,
        [project.id]
      );

      res.json({
        logs,
        total: Number(counts.total) || 0,
        page,
        limit,
        summary: {
          total_reports: Number(counts.total) || 0,
          contributing_students:
            Number(counts.contributing_students) || 0,
          reported_weeks:
            Number(counts.reported_weeks) || 0,
          total_hours: Number(counts.total_hours) || 0,
          reviewed_reports:
            Number(counts.reviewed_logs) || 0,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

// POST: Each active student can submit one log per week.
router.post(
  "/",
  authenticate,
  authorize("student"),
  [
    body("project_id").isInt({ min: 1 }),
    body("week_number").isInt({ min: 1 }),
    body("work_done")
      .trim()
      .isLength({ min: 1, max: 5000 }),
    body("plan_next_week")
      .optional({ nullable: true })
      .isString()
      .isLength({ max: 5000 }),
    body("blockers")
      .optional({ nullable: true })
      .isString()
      .isLength({ max: 5000 }),
    body("hours_worked")
      .optional()
      .isFloat({ min: 0, max: 168 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const {
        project_id,
        week_number,
        work_done,
        plan_next_week,
        blockers,
        hours_worked,
      } = req.body;

      const project = await getProject(project_id);

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (!(await canAccessProject(project, req.user))) {
        return res.status(403).json({
          message:
            "You are not an active member of this project.",
        });
      }

      const [[existing]] = await pool.query(
        `SELECT id
         FROM weekly_logs
         WHERE project_id = ?
           AND student_id = ?
           AND week_number = ?
         LIMIT 1`,
        [project_id, req.user.id, week_number]
      );

      if (existing) {
        return res.status(409).json({
          message:
            `Your Week ${week_number} report is already submitted.`,
        });
      }

      const [result] = await pool.query(
        `INSERT INTO weekly_logs
         (
           project_id,
           student_id,
           week_number,
           work_done,
           plan_next_week,
           blockers,
           hours_worked
         )
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          project_id,
          req.user.id,
          week_number,
          work_done,
          plan_next_week || null,
          blockers || null,
          Number(hours_worked) || 0,
        ]
      );

      await pool.query(
        `INSERT INTO activity_logs
         (user_id, project_id, action)
         VALUES (?, ?, ?)`,
        [
          req.user.id,
          project_id,
          `Submitted weekly log for Week ${week_number}`,
        ]
      );

      if (project.supervisor_id) {
        await notify(
          project.supervisor_id,
          "Weekly Log Submitted",
          `${req.user.name} submitted Week ${week_number} log for "${project.title}".`,
          "info",
          "/app/supervisor/reviews"
        );
      }

      res.status(201).json({
        message: "Weekly log submitted.",
        id: result.insertId,
      });
    } catch (error) {
      next(error);
    }
  }
);

// PUT: Only the assigned supervisor can review a log.
router.put(
  "/:id/review",
  authenticate,
  authorize("supervisor"),
  [
    param("id").isInt({ min: 1 }),
    body("supervisor_comment")
      .optional({ nullable: true })
      .isString()
      .isLength({ max: 5000 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[log]] = await pool.query(
        `SELECT
           wl.id,
           wl.student_id,
           wl.week_number,
           wl.project_id,
           p.supervisor_id,
           p.title
         FROM weekly_logs wl
         JOIN projects p ON p.id = wl.project_id
         WHERE wl.id = ?`,
        [req.params.id]
      );

      if (!log) {
        return res.status(404).json({
          message: "Weekly log not found.",
        });
      }

      if (
        Number(log.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({
          message:
            "You are not the assigned supervisor for this project.",
        });
      }

      await pool.query(
        `UPDATE weekly_logs
         SET status = 'reviewed',
             supervisor_comment = ?
         WHERE id = ?`,
        [
          req.body.supervisor_comment || "",
          log.id,
        ]
      );

      await notify(
        log.student_id,
        "Weekly Log Reviewed",
        `Your Week ${log.week_number} log for "${log.title}" was reviewed.`,
        "success",
        "/app/weekly-logs"
      );

      res.json({
        message: "Log reviewed.",
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;