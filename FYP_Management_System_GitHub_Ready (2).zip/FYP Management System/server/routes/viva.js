import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog, notify } from "../middleware/audit.js";
import { emailTemplates } from "../services/email.js";
import { sendEmailToStudent } from "../services/notifier.js";

const router = express.Router();

router.get("/", authenticate, async (req, res, next) => {
  try {
    let q=`SELECT v.*,p.title AS project_title,s.name AS student_name,sup.name AS supervisor_name
           FROM viva_schedules v JOIN projects p ON v.project_id=p.id
           JOIN users s ON p.student_id=s.id LEFT JOIN users sup ON p.supervisor_id=sup.id`;
    const params=[];
    if (req.user.role==="student")    { q+=" WHERE p.student_id=?";    params.push(req.user.id); }
    else if (req.user.role==="supervisor") { q+=" WHERE p.supervisor_id=?"; params.push(req.user.id); }
    q+=" ORDER BY v.scheduled_at ASC";
    const [rows] = await pool.query(q, params);

    if (rows.length > 0) {
      const vivaIds = rows.map(v => v.id);
      const [panelMembers] = await pool.query(
        `SELECT vp.*, u.name AS evaluator_name, u.email AS evaluator_email
         FROM viva_panel vp JOIN users u ON vp.evaluator_id = u.id
         WHERE vp.viva_id IN (?)`, [vivaIds]
      );

      const panelMap = panelMembers.reduce((acc, member) => {
        (acc[member.viva_id] = acc[member.viva_id] || []).push(member);
        return acc;
      }, {});

      rows.forEach(viva => {
        viva.panel = panelMap[viva.id] || [];
      });
    }
    res.json(rows);
  } catch (e) { next(e); }
});

router.post("/", authenticate, authorize("admin"), async (req, res, next) => {
  try {
    const { project_id, batch_id, scheduled_at, room, mode, remarks } = req.body;
    const [r] = await pool.query(
      "INSERT INTO viva_schedules (project_id,batch_id,scheduled_at,room,mode,remarks) VALUES (?,?,?,?,?,?)",
      [project_id,batch_id||null,scheduled_at,room||null,mode||"in_person",remarks||null]);
    const [[p]] = await pool.query("SELECT student_id,supervisor_id,title FROM projects WHERE id=?",[project_id]);
    if (p) {
      const dt = new Date(scheduled_at).toLocaleString();
      if (p.student_id) {
        await notify(p.student_id,"Viva Scheduled",`Your viva for "${p.title}" is on ${dt}${room?` in ${room}`:""}. `,"info");
        sendEmailToStudent(project_id, (name, title) => emailTemplates.vivaScheduled(name, dt, room)).catch(console.error);
      }
      if (p.supervisor_id) await notify(p.supervisor_id,"Viva Scheduled",`Viva for "${p.title}" on ${dt}.`,"info");
    }
    await auditLog(req,"VIVA_SCHEDULED","viva_schedules",r.insertId);
    res.status(201).json({ message: "Viva scheduled.", id: r.insertId });
  } catch (e) { next(e); }
});

router.put("/:id", authenticate, authorize("admin"), async (req, res, next) => {
  try {
    const { scheduled_at, room, mode, status, remarks } = req.body;
    await pool.query(
      `UPDATE viva_schedules SET scheduled_at=COALESCE(?,scheduled_at),room=COALESCE(?,room),
       mode=COALESCE(?,mode),status=COALESCE(?,status),remarks=COALESCE(?,remarks) WHERE id=?`,
      [scheduled_at||null,room||null,mode||null,status||null,remarks||null,req.params.id]);
    res.json({ message: "Viva updated." });
  } catch (e) { next(e); }
});

router.post("/:id/panel", authenticate, authorize("admin"), async (req, res, next) => {
  try {
    const { evaluator_id, role } = req.body;
    await pool.query("INSERT OR IGNORE INTO viva_panel (viva_id,evaluator_id,role) VALUES (?,?,?)",
      [req.params.id,evaluator_id,role||"internal"])
      .catch(() => pool.query("INSERT IGNORE INTO viva_panel (viva_id,evaluator_id,role) VALUES (?,?,?)",
        [req.params.id,evaluator_id,role||"internal"]));
    res.status(201).json({ message: "Panel member added." });
  } catch (e) { next(e); }
});

router.delete("/:id/panel/:evaluatorId", authenticate, authorize("admin"), async (req, res, next) => {
  try {
    await pool.query("DELETE FROM viva_panel WHERE viva_id=? AND evaluator_id=?",[req.params.id,req.params.evaluatorId]);
    res.json({ message: "Panel member removed." });
  } catch (e) { next(e); }
});

export default router;
