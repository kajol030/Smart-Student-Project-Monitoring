import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog } from "../middleware/audit.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const deptId = req.query.department_id;
    let q = `SELECT b.*,d.name AS department_name,COUNT(DISTINCT up.user_id) AS student_count
             FROM batches b LEFT JOIN departments d ON b.department_id=d.id
             LEFT JOIN user_profiles up ON up.batch_id=b.id`;
    const p = [];
    if (deptId) { q += " WHERE b.department_id=?"; p.push(deptId); }
    q += " GROUP BY b.id ORDER BY b.created_at DESC";
    const [rows] = await pool.query(q, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get("/:id", authenticate, async (req, res) => {
  try {
    const [[b]] = await pool.query(
      `SELECT b.*,d.name AS department_name FROM batches b LEFT JOIN departments d ON b.department_id=d.id WHERE b.id=?`,
      [req.params.id]);
    if (!b) return res.status(404).json({ message: "Batch not found." });
    res.json(b);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { name, department_id, start_date, end_date } = req.body;
    const [r] = await pool.query("INSERT INTO batches (name,department_id,start_date,end_date) VALUES (?,?,?,?)",
      [name,department_id,start_date||null,end_date||null]);
    await auditLog(req,"BATCH_CREATED","batches",r.insertId);
    res.status(201).json({ message: "Batch created.", id: r.insertId });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { name, department_id, start_date, end_date, is_active } = req.body;
    await pool.query("UPDATE batches SET name=?,department_id=?,start_date=?,end_date=?,is_active=? WHERE id=?",
      [name,department_id,start_date||null,end_date||null,is_active!==undefined?is_active:1,req.params.id]);
    res.json({ message: "Batch updated." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    await pool.query("DELETE FROM batches WHERE id=?", [req.params.id]);
    res.json({ message: "Batch deleted." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
