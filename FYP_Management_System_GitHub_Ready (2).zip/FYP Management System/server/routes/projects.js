
import express from "express";
import { body, query, param } from "express-validator";
import pool, { isMysql } from "../config/db.js";
import {
  auth,
  authorize,
  isStudent,
} from "../middleware/auth.js";
import { auditLog, notify } from "../middleware/audit.js";
import { sendEmailToStudent } from "../services/notifier.js";
import { emailTemplates } from "../services/email.js";
import { validate } from "../middleware/validate.js";
import { PROJECT_STATUS } from "./constants.js";

const router = express.Router();

// Check whether a student belongs to the project's existing group.
async function canStudentAccessProject(userId, project) {
  if (Number(project.student_id) === Number(userId)) {
    return true;
  }

  if (!project.group_id) {
    return false;
  }

  const [[member]] = await pool.query(
    `SELECT id
     FROM project_group_members
     WHERE group_id = ?
       AND user_id = ?
       AND status = 'active'
     LIMIT 1`,
    [project.group_id, userId]
  );

  return Boolean(member);
}

async function logAct(uid, pid, action) {
  await pool
    .query(
      "INSERT INTO activity_logs (user_id, project_id, action) VALUES (?, ?, ?)",
      [uid, pid, action]
    )
    .catch(console.error);
}


// --------------------------------------------------
// GET ALL PROJECTS
// --------------------------------------------------

router.get(
  "/",
  auth,
  [
    query("page").optional().isInt({ min: 1 }).toInt(),
    query("limit").optional().isInt({ min: 1, max: 100 }).toInt(),
    query("search").optional().isString().trim(),
    query("status").optional().isIn(Object.values(PROJECT_STATUS)),
    query("risk").optional().isIn(["low", "medium", "high"]),
  ],
  validate,
  async (req, res, next) => {
    try {
      const {
        page = 1,
        limit = 20,
        search = "",
        status = "",
        risk = "",
      } = req.query;

      const offset = (page - 1) * limit;

      let where = "WHERE 1=1";
      const p = [];

      if (req.user.role === "student") {
        where += `
          AND (
            p.student_id = ?
            OR p.group_id IN (
              SELECT group_id
              FROM project_group_members
              WHERE user_id = ?
                AND status = 'active'
            )
          )
        `;

        p.push(req.user.id, req.user.id);
      } else if (req.user.role === "supervisor") {
        where += " AND p.supervisor_id = ?";
        p.push(req.user.id);
      }

      if (search) {
        where += " AND (p.title LIKE ? OR p.description LIKE ?)";
        p.push(`%${search}%`, `%${search}%`);
      }

      if (status) {
        where += " AND p.status = ?";
        p.push(status);
      }

      if (risk) {
        where += " AND p.risk_level = ?";
        p.push(risk);
      }

      // Fetch projects with student preference
      // and separately assigned supervisor.
      const [projects] = await pool.query(
        `
        SELECT
          p.*,
          s.name AS student_name,
          s.email AS student_email,

          -- Admin assigned supervisor
          sup.name AS supervisor_name,

          -- Student preferred supervisor
          pref.supervisor_id AS preferred_supervisor_id,
          preferred_sup.name AS preferred_supervisor_name,

          pg.name AS group_name

        FROM projects p

        JOIN users s
          ON p.student_id = s.id

        LEFT JOIN users sup
          ON p.supervisor_id = sup.id

        LEFT JOIN project_supervisor_preferences pref
          ON pref.project_id = p.id
          AND pref.preference_order = 1

        LEFT JOIN users preferred_sup
          ON preferred_sup.id = pref.supervisor_id

        LEFT JOIN project_groups pg
          ON p.group_id = pg.id

        ${where}

        ORDER BY p.updated_at DESC
        LIMIT ? OFFSET ?
        `,
        [...p, Number(limit), Number(offset)]
      );

      const [[{ total }]] = await pool.query(
        `
        SELECT COUNT(*) AS total
        FROM projects p
        ${where}
        `,
        p
      );

      res.json({
        projects,
        total,
        page: Number(page),
        limit: Number(limit),
      });

    } catch (e) {
      next(e);
    }
  }
);


// --------------------------------------------------
// GET SINGLE PROJECT
// --------------------------------------------------

router.get(
  "/:id",
  auth,
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[project]] = await pool.query(
        `
        SELECT
          p.*,
          s.name AS student_name,
          sup.name AS supervisor_name,
          pg.name AS group_name
        FROM projects p
        JOIN users s ON p.student_id = s.id
        LEFT JOIN users sup ON p.supervisor_id = sup.id
        LEFT JOIN project_groups pg ON p.group_id = pg.id
        WHERE p.id = ?
        `,
        [req.params.id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (req.user.role === "student") {
        const allowed = await canStudentAccessProject(
          req.user.id,
          project
        );

        if (!allowed) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      }

      if (
        req.user.role === "supervisor" &&
        Number(project.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      res.json(project);
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// CREATE PROJECT WITH EXISTING GROUP
// --------------------------------------------------

router.post(
  "/",
  auth,
  isStudent,
  [
    body("group_id")
      .isInt({ min: 1 })
      .withMessage("Please select a project group."),

    body("title")
      .trim()
      .isLength({ min: 5, max: 200 })
      .withMessage("Title must be between 5 and 200 characters."),

    body("description")
      .optional()
      .trim()
      .isLength({ max: 5000 }),

    body("category")
      .optional()
      .isString()
      .trim()
      .isLength({ max: 50 }),

    body("keywords")
      .optional()
      .isString()
      .trim()
      .isLength({ max: 255 }),

    body("domain")
      .optional()
      .isString()
      .trim()
      .isLength({ max: 100 }),

    body("github_url")
      .optional({ nullable: true, checkFalsy: true })
      .trim()
      .matches(
        /^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/
      )
      .withMessage(
        "github_url must be a valid GitHub repository URL."
      ),
  ],
  validate,
  async (req, res, next) => {
    let connection;
    let transactionStarted = false;

    try {
      const {
        title,
        description,
        category,
        keywords,
        domain,
        group_id,
        preferred_supervisors = [],
        github_url,
      } = req.body;

      const groupId = Number(group_id);

      const preferences = [
        ...new Set(
          preferred_supervisors
            .map(Number)
            .filter(Number.isInteger)
            .filter((id) => id > 0)
        ),
      ].slice(0, 3);

      // Check whether the student already has a project.
      const [existingProjects] = await pool.query(
        "SELECT id FROM projects WHERE student_id = ?",
        [req.user.id]
      );

      if (existingProjects.length) {
        return res.status(409).json({
          message: "You already have a project.",
        });
      }

      // Verify that the selected group exists.
      const [[group]] = await pool.query(
        `
        SELECT id, name, leader_id
        FROM project_groups
        WHERE id = ?
        `,
        [groupId]
      );

      if (!group) {
        return res.status(404).json({
          message: "Selected group not found.",
        });
      }

      // Only the existing group's leader may submit its topic.
      if (Number(group.leader_id) !== Number(req.user.id)) {
        return res.status(403).json({
          message:
            "Only the group leader can submit the FYP topic.",
        });
      }

      // Prevent multiple projects for the same group.
      const [existingGroupProjects] = await pool.query(
        "SELECT id FROM projects WHERE group_id = ?",
        [groupId]
      );

      if (existingGroupProjects.length) {
        return res.status(409).json({
          message: "This group already has a project.",
        });
      }

      // Prevent selecting a group whose active member
      // already belongs to another project.
      const [membersWithProjects] = await pool.query(
        `
        SELECT p.id
        FROM projects p
        WHERE p.student_id IN (
          SELECT user_id
          FROM project_group_members
          WHERE group_id = ?
            AND status = 'active'
        )
        LIMIT 1
        `,
        [groupId]
      );

      if (membersWithProjects.length) {
        return res.status(409).json({
          message:
            "A group member already owns another project.",
        });
      }

      const status = PROJECT_STATUS.PROPOSAL;

      connection = isMysql
        ? await pool.getConnection()
        : pool;

      if (isMysql) {
        await connection.beginTransaction();
        transactionStarted = true;
      }

      // Save the existing group ID with the project.
      const [result] = await connection.query(
        `
        INSERT INTO projects (
          student_id,
          group_id,
          title,
          description,
          category,
          keywords,
          domain,
          status,
          github_url
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          req.user.id,
          groupId,
          title,
          description || "",
          category || null,
          keywords || null,
          domain || null,
          status,
          github_url || null,
        ]
      );

      const projectId = result.insertId;

      const milestones = [
        [
          "Proposal Submission",
          "Submit initial project proposal",
        ],
        [
          "Literature Review",
          "Complete background research",
        ],
        [
          "System Design",
          "Design architecture",
        ],
        [
          "Implementation",
          "Develop core features",
        ],
        [
          "Testing & QA",
          "Test and fix bugs",
        ],
        [
          "Final Report",
          "Submit final documentation",
        ],
        [
          "Viva Presentation",
          "Prepare and deliver viva",
        ],
      ];

      for (const [milestoneTitle, milestoneDescription] of milestones) {
        await connection.query(
          `
          INSERT INTO milestones (
            project_id,
            title,
            description
          )
          VALUES (?, ?, ?)
          `,
          [
            projectId,
            milestoneTitle,
            milestoneDescription,
          ]
        );
      }

      for (
        let index = 0;
        index < preferences.length;
        index += 1
      ) {
        const supervisorId = preferences[index];

        await connection.query(
          `
          INSERT INTO project_supervisor_preferences (
            project_id,
            supervisor_id,
            preference_order
          )
          VALUES (?, ?, ?)
          `,
          [
            projectId,
            supervisorId,
            index + 1,
          ]
        );

        await connection.query(
          `
          INSERT INTO supervisor_requests (
            student_id,
            supervisor_id,
            project_id,
            status
          )
          VALUES (?, ?, ?, ?)
          `,
          [
            req.user.id,
            supervisorId,
            projectId,
            "pending",
          ]
        );
      }

      if (isMysql) {
        await connection.commit();
        transactionStarted = false;
      }

      await logAct(
        req.user.id,
        projectId,
        "Created group project proposal"
      );

      await auditLog(
        req,
        "PROJECT_CREATED",
        "projects",
        projectId,
        null,
        {
          title,
          group_id: groupId,
        }
      );

      res.status(201).json({
        message: "Group project created successfully.",
        projectId,
        groupId,
      });
    } catch (e) {
      if (isMysql && transactionStarted) {
        await connection.rollback().catch(console.error);
      }

      next(e);
    } finally {
      if (isMysql && connection) {
        connection.release();
      }
    }
  }
);

// --------------------------------------------------
// UPDATE PROJECT STATUS
// --------------------------------------------------

router.put(
  "/:id/status",
  auth,
  authorize("supervisor", "admin"),
  [
    param("id").isInt({ min: 1 }),
    body("status")
      .isIn(Object.values(PROJECT_STATUS))
      .withMessage("Invalid status value."),
    body("reason")
      .optional()
      .isString()
      .trim()
      .isLength({ max: 500 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[projectCheck]] = await pool.query(
        `
        SELECT student_id, supervisor_id
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (!projectCheck) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (
        req.user.role === "supervisor" &&
        Number(projectCheck.supervisor_id) !==
          Number(req.user.id)
      ) {
        return res.status(403).json({
          message:
            "Access denied. Not your assigned project.",
        });
      }

      const { status, reason } = req.body;

      await pool.query(
        `
        UPDATE projects
        SET status = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [status, req.params.id]
      );

      const [[project]] = await pool.query(
        `
        SELECT student_id, title, group_id
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (project?.student_id) {
        let message =
          `Your project "${project.title}" status: ${status}`;

        let type = "info";

        if (status === PROJECT_STATUS.IN_PROGRESS) {
          type = "success";

          message =
            `Your proposal "${project.title}" has been approved!`;

          sendEmailToStudent(
            req.params.id,
            emailTemplates.proposalApproved
          ).catch(console.error);
        } else if (status === PROJECT_STATUS.REJECTED) {
          type = "error";

          message =
            `Your proposal "${project.title}" was rejected. ` +
            (reason || "");

          sendEmailToStudent(
            req.params.id,
            emailTemplates.proposalRejected,
            reason
          ).catch(console.error);
        }

        // Notify the leader and active group members.
        const recipientIds = new Set([
          Number(project.student_id),
        ]);

        if (project.group_id) {
          const [members] = await pool.query(
            `
            SELECT user_id
            FROM project_group_members
            WHERE group_id = ?
              AND status = 'active'
            `,
            [project.group_id]
          );

          members.forEach((member) => {
            recipientIds.add(Number(member.user_id));
          });
        }

        for (const userId of recipientIds) {
          await notify(
            userId,
            "Project Status Updated",
            message,
            type
          );
        }
      }

      await logAct(
        req.user.id,
        req.params.id,
        `Status → ${status}`
      );

      res.json({
        message: `Status set to ${status}.`,
      });
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// ASSIGN SUPERVISOR
// --------------------------------------------------

router.put(
  "/:id/assign-supervisor",
  auth,
  authorize("admin"),
  [
    param("id").isInt({ min: 1 }),
    body("supervisor_id")
      .isInt({ min: 1 })
      .withMessage("Supervisor is required."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[project]] = await pool.query(
        `
        SELECT id, title, supervisor_id
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      const [[supervisor]] = await pool.query(
        `
        SELECT
          u.id,
          u.name,
          COALESCE(up.max_students, 5) AS max_students,
          (
            SELECT COUNT(*)
            FROM projects p
            WHERE p.supervisor_id = u.id
          ) AS assigned_count
        FROM users u
        LEFT JOIN user_profiles up
          ON up.user_id = u.id
        WHERE u.id = ?
          AND u.role = 'supervisor'
          AND u.is_active = 1
        `,
        [req.body.supervisor_id]
      );

      if (!supervisor) {
        return res.status(404).json({
          message: "Active supervisor not found.",
        });
      }

      if (
        Number(supervisor.assigned_count) >=
          Number(supervisor.max_students) &&
        Number(project.supervisor_id) !==
          Number(supervisor.id)
      ) {
        return res.status(409).json({
          message:
            `${supervisor.name} has reached their capacity ` +
            `of ${supervisor.max_students} projects.`,
        });
      }

      await pool.query(
        `
        UPDATE projects
        SET
          supervisor_id = ?,
          status = CASE
            WHEN status = 'proposal' THEN 'review'
            ELSE status
          END,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [supervisor.id, req.params.id]
      );

      await notify(
        supervisor.id,
        "Project assigned",
        `You have been assigned to review project "${project.title}".`,
        "info",
        "/supervisor"
      );

      await auditLog(
        req,
        "SUPERVISOR_ASSIGNED",
        "projects",
        project.id,
        {
          supervisor_id: project.supervisor_id,
        },
        {
          supervisor_id: supervisor.id,
        }
      );

      res.json({
        message: "Supervisor assigned successfully.",
        supervisor,
      });
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// UPDATE PROGRESS
// --------------------------------------------------

router.put(
  "/:id/progress",
  auth,
  [
    param("id").isInt({ min: 1 }),
    body("progress")
      .isInt({ min: 0, max: 100 })
      .withMessage("Progress must be between 0 and 100."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [[project]] = await pool.query(
        `
        SELECT student_id, supervisor_id
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      const allowed =
        req.user.role === "admin" ||
        (
          req.user.role === "student" &&
          Number(project.student_id) === Number(req.user.id)
        ) ||
        (
          req.user.role === "supervisor" &&
          Number(project.supervisor_id) === Number(req.user.id)
        );

      if (!allowed) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      await pool.query(
        `
        UPDATE projects
        SET progress = ?
        WHERE id = ?
        `,
        [req.body.progress, req.params.id]
      );

      res.json({
        message: "Progress updated.",
      });
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// PROJECT STATISTICS
// --------------------------------------------------

router.get(
  "/:id/stats",
  auth,
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("Project ID must be a positive integer."),
  ],
  validate,
  async (req, res, next) => {
    try {
      const projectId = req.params.id;

      const [[project]] = await pool.query(
        `
        SELECT student_id, supervisor_id, group_id
        FROM projects
        WHERE id = ?
        `,
        [projectId]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (req.user.role === "student") {
        const allowed = await canStudentAccessProject(
          req.user.id,
          project
        );

        if (!allowed) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      }

      if (
        req.user.role === "supervisor" &&
        Number(project.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      const [[stats]] = await pool.query(
        `
        SELECT
          (
            SELECT COUNT(*)
            FROM milestones
            WHERE project_id = ?
          ) AS total_milestones,

          (
            SELECT COUNT(*)
            FROM milestones
            WHERE project_id = ?
              AND status = 'completed'
          ) AS completed_milestones,

          (
            SELECT COUNT(*)
            FROM submissions
            WHERE project_id = ?
          ) AS total_submissions,

          (
            SELECT COUNT(*)
            FROM feedback
            WHERE project_id = ?
          ) AS total_feedback,

          (
            SELECT COUNT(*)
            FROM weekly_logs
            WHERE project_id = ?
          ) AS total_weekly_logs
        `,
        [
          projectId,
          projectId,
          projectId,
          projectId,
          projectId,
        ]
      );

      const [activities] = await pool.query(
        `
        SELECT a.*, u.name AS user_name
        FROM activity_logs a
        JOIN users u ON a.user_id = u.id
        WHERE a.project_id = ?
        ORDER BY a.created_at DESC
        LIMIT 10
        `,
        [projectId]
      );

      const [recommendations] = await pool.query(
        `
        SELECT *
        FROM recommendations
        WHERE project_id = ?
        ORDER BY created_at DESC
        LIMIT 5
        `,
        [projectId]
      );

      res.json({
        milestones: {
          total: stats.total_milestones,
          completed: stats.completed_milestones,
        },
        submissions: {
          total: stats.total_submissions,
        },
        feedback: {
          total: stats.total_feedback,
        },
        weeklyLogs: {
          total: stats.total_weekly_logs,
        },
        activities,
        recommendations,
      });
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// GET TOPIC REVIEWS
// --------------------------------------------------

router.get(
  "/:id/topic-reviews",
  auth,
  async (req, res, next) => {
    try {
      const [[project]] = await pool.query(
        `
        SELECT student_id, supervisor_id, group_id
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (req.user.role === "student") {
        const allowed = await canStudentAccessProject(
          req.user.id,
          project
        );

        if (!allowed) {
          return res.status(403).json({
            message: "Access denied.",
          });
        }
      }

      if (
        req.user.role === "supervisor" &&
        Number(project.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      const [reviews] = await pool.query(
        `
        SELECT
          tr.*,
          u.name AS reviewer_name
        FROM topic_reviews tr
        JOIN users u ON u.id = tr.reviewer_id
        WHERE tr.project_id = ?
        ORDER BY tr.created_at DESC
        `,
        [req.params.id]
      );

      res.json(reviews);
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// SUBMIT TOPIC REVIEW
// --------------------------------------------------

router.post(
  "/:id/topic-reviews",
  auth,
  authorize("supervisor", "admin"),
  [
    param("id").isInt({ min: 1 }),
    body("status").isIn([
      "approved",
      "rejected",
      "changes_requested",
    ]),
    body("comments")
      .trim()
      .isLength({ min: 3, max: 2000 })
      .withMessage("Review comments are required."),
  ],
  validate,
  async (req, res, next) => {
    let connection;
    let transactionStarted = false;

    try {
      const [[project]] = await pool.query(
        `
        SELECT
          student_id,
          supervisor_id,
          group_id,
          title
        FROM projects
        WHERE id = ?
        `,
        [req.params.id]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      if (
        req.user.role === "supervisor" &&
        Number(project.supervisor_id) !== Number(req.user.id)
      ) {
        return res.status(403).json({
          message: "Access denied.",
        });
      }

      connection = isMysql
        ? await pool.getConnection()
        : pool;

      if (isMysql) {
        await connection.beginTransaction();
        transactionStarted = true;
      }

      await connection.query(
        `
        INSERT INTO topic_reviews (
          project_id,
          reviewer_id,
          status,
          comments
        )
        VALUES (?, ?, ?, ?)
        `,
        [
          req.params.id,
          req.user.id,
          req.body.status,
          req.body.comments,
        ]
      );

      const projectStatus =
        req.body.status === "approved"
          ? PROJECT_STATUS.IN_PROGRESS
          : "review";

      await connection.query(
        `
        UPDATE projects
        SET
          status = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [
          projectStatus,
          req.params.id,
        ]
      );

      if (isMysql) {
        await connection.commit();
        transactionStarted = false;
      }

      const recipientIds = new Set([
        Number(project.student_id),
      ]);

      if (project.group_id) {
        const [members] = await pool.query(
          `
          SELECT user_id
          FROM project_group_members
          WHERE group_id = ?
            AND status = 'active'
          `,
          [project.group_id]
        );

        members.forEach((member) => {
          recipientIds.add(Number(member.user_id));
        });
      }

      for (const userId of recipientIds) {
        await notify(
          userId,
          "Topic review updated",
          `Your topic "${project.title}" was ` +
            `${req.body.status.replace("_", " ")}: ` +
            req.body.comments,
          req.body.status === "approved"
            ? "success"
            : "warning",
          "/projects"
        );
      }

      await auditLog(
        req,
        "TOPIC_REVIEWED",
        "projects",
        req.params.id,
        null,
        {
          status: req.body.status,
        }
      );

      res.status(201).json({
        message: "Topic review recorded.",
      });
    } catch (e) {
      if (isMysql && transactionStarted) {
        await connection.rollback().catch(console.error);
      }

      next(e);
    } finally {
      if (isMysql && connection) {
        connection.release();
      }
    }
  }
);

// --------------------------------------------------
// RESUBMIT TOPIC
// --------------------------------------------------

router.put(
  "/:id/resubmit-topic",
  auth,
  isStudent,
  [
    param("id").isInt({ min: 1 }),

    body("title")
      .trim()
      .isLength({ min: 5, max: 200 }),

    body("description")
      .trim()
      .isLength({ min: 10, max: 5000 }),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [result] = await pool.query(
        `
        UPDATE projects
        SET
          title = ?,
          description = ?,
          status = 'review',
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
          AND student_id = ?
        `,
        [
          req.body.title,
          req.body.description,
          req.params.id,
          req.user.id,
        ]
      );

      if (!result.affectedRows) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      res.json({
        message: "Topic resubmitted for review.",
      });
    } catch (e) {
      next(e);
    }
  }
);

// --------------------------------------------------
// UPDATE GITHUB REPOSITORY URL
// --------------------------------------------------

router.put(
  "/:id/github-url",
  auth,
  authorize("student", "supervisor"),
  [
    param("id").isInt({ min: 1 }),

    body("github_url")
      .trim()
      .matches(
        /^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/
      )
      .withMessage(
        "github_url must be a valid GitHub repository URL."
      ),
  ],
  validate,
  async (req, res, next) => {
    try {
      const projectId = Number(req.params.id);

      const [[project]] = await pool.query(
        `
        SELECT id, student_id, supervisor_id, title
        FROM projects
        WHERE id = ?
        `,
        [projectId]
      );

      if (!project) {
        return res.status(404).json({
          message: "Project not found.",
        });
      }

      const canUpdate = req.user.role === "supervisor"
        ? Number(project.supervisor_id) === Number(req.user.id)
        : Number(project.student_id) === Number(req.user.id);
      if (!canUpdate) {
        return res.status(403).json({
          message:
            "Access denied. Only the project leader or assigned supervisor can update the GitHub URL.",
        });
      }

      const github_url = req.body.github_url
        .trim()
        .replace(/\/$/, "");

      await pool.query(
        `
        UPDATE projects
        SET
          github_url = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [
          github_url,
          projectId,
        ]
      );

      await logAct(
        req.user.id,
        projectId,
        `GitHub repository URL updated: ${github_url}`
      );

      res.json({
        message: "GitHub repository URL saved.",
        github_url,
      });
    } catch (e) {
      next(e);
    }
  }
);

export default router;