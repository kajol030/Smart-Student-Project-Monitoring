import express from 'express';
import {
  createSupervisorRequest,
  respondToSupervisorRequest,
} from '../supervisorRequestController.js';
import pool from '../config/db.js';
import { auth, authorize, isStudent, isSupervisor } from '../middleware/auth.js';

const router = express.Router();

router.get('/', auth, authorize('supervisor', 'admin'), async (req, res, next) => {
  try {
    const filter = req.user.role === 'supervisor' ? 'AND sr.supervisor_id = ?' : '';
    const params = req.user.role === 'supervisor' ? [req.user.id] : [];
    const [rows] = await pool.query(
      `SELECT sr.*, p.title, u.name AS student_name, sup.name AS supervisor_name,
        psp.preference_order, psp.status AS preference_status
       FROM supervisor_requests sr
       JOIN projects p ON p.id = sr.project_id
       JOIN users u ON u.id = sr.student_id
       JOIN users sup ON sup.id = sr.supervisor_id
       LEFT JOIN project_supervisor_preferences psp ON psp.project_id=sr.project_id AND psp.supervisor_id=sr.supervisor_id
       WHERE 1=1 ${filter} ORDER BY sr.created_at DESC`, params);
    res.json(rows);
  } catch (error) { next(error); }
});

// @route   POST /api/supervisor-requests
// @desc    Student creates a new supervisor request
router.post('/', auth, isStudent, createSupervisorRequest);

// @route   PUT /api/supervisor-requests/:id/respond
// @desc    Supervisor accepts or rejects a request
router.put('/:id/respond', auth, isSupervisor, respondToSupervisorRequest);

export default router;