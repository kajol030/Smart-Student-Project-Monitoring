import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog } from "../middleware/audit.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT d.*,u.name AS created_by_name FROM deadlines d JOIN users u ON d.created_by=u.id
       WHERE d.target_role='all' OR d.target_role=? ORDER BY d.due_date ASC`, [req.user.role]);
    res.json(rows);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { title, description, due_date, target_role } = req.body;
    const [r] = await pool.query(
      "INSERT INTO deadlines (title,description,due_date,target_role,created_by) VALUES (?,?,?,?,?)",
      [title,description||null,due_date,target_role||"all",req.user.id]);
    await auditLog(req,"DEADLINE_CREATED","deadlines",r.insertId);
    res.status(201).json({ message: "Deadline created.", id: r.insertId });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { title, description, due_date, target_role } = req.body;
    await pool.query("UPDATE deadlines SET title=?,description=?,due_date=?,target_role=? WHERE id=?",
      [title,description||null,due_date,target_role||"all",req.params.id]);
    res.json({ message: "Deadline updated." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    await pool.query("DELETE FROM deadlines WHERE id=?", [req.params.id]);
    res.json({ message: "Deadline deleted." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
