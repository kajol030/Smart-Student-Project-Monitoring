import express from "express";
import pool from "../config/db.js";
import { authenticate } from "../middleware/auth.js";
const router = express.Router();
router.get("/", authenticate, async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim(); if (!q) return res.json({ results: [], total: 0 }); const like = `%${q}%`; const role = req.user.role;
    const [results] = await pool.query(`SELECT id, 'project' AS type, title AS name, description AS detail FROM projects WHERE (title LIKE ? OR description LIKE ?) AND (?='admin' OR (?='student' AND student_id=?) OR (?='supervisor' AND supervisor_id=?)) UNION ALL SELECT id, 'user' AS type, name, email AS detail FROM users WHERE (name LIKE ? OR email LIKE ?) AND (?='admin' OR role='supervisor') UNION ALL SELECT id, 'document' AS type, title AS name, notes AS detail FROM submissions WHERE (title LIKE ? OR notes LIKE ?) AND (?='admin' OR student_id=?) UNION ALL SELECT id, 'announcement' AS type, title AS name, body AS detail FROM announcements WHERE title LIKE ? OR body LIKE ? ORDER BY type,name LIMIT 50`, [like, like, role, role, req.user.id, role, req.user.id, like, like, role, like, like, role, req.user.id, like, like]);
    res.json({ results, total: results.length });
  } catch (e) { next(e); }
});
export default router;
