import express from "express";
import { authenticate } from "../middleware/auth.js";
import { assertProjectAccess } from "../utils/projectAccess.js";
import { analyzeProposalAlignment } from "../services/alignmentService.js";
import { computeImplementationProgress } from "../services/progressService.js";
import { getGithubProjectData } from "../services/githubService.js";

const router = express.Router();

router.get("/project/:projectId", authenticate, async (req, res, next) => {
  try {
    const project = await assertProjectAccess(req, res, req.params.projectId);
    if (!project) return;
    const result = await analyzeProposalAlignment(project, {
      allowPrivateGithub: req.user.role !== "student",
    });
    res.json(result);
  } catch (e) { next(e); }
});

router.get("/project/:projectId/progress", authenticate, async (req, res, next) => {
  try {
    const project = await assertProjectAccess(req, res, req.params.projectId);
    if (!project) return;
    let githubData = null;
    if (project.github_url) {
      try { githubData = await getGithubProjectData(project.github_url); }
      catch { githubData = null; }
    }
    const progress = await computeImplementationProgress(project.id, githubData);
    res.json({ project_id: project.id, stored_milestone_progress: project.progress, ...progress });
  } catch (e) { next(e); }
});

export default router;
