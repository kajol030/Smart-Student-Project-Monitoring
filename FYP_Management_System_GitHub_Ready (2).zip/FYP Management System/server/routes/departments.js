import express from "express";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { auditLog } from "../middleware/audit.js";

const router = express.Router();

router.get("/", authenticate, async (req, res) => {
  try {
    const search = req.query.search||"";
    const [rows] = await pool.query(
      `SELECT d.*,u.name AS hod_name,COUNT(DISTINCT p.user_id) AS student_count
       FROM departments d LEFT JOIN users u ON d.hod_id=u.id
       LEFT JOIN user_profiles p ON p.department_id=d.id
       WHERE d.name LIKE ? GROUP BY d.id ORDER BY d.name`, [`%${search}%`]);
    res.json(rows);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get("/:id", authenticate, async (req, res) => {
  try {
    const [[dept]] = await pool.query(
      `SELECT d.*,u.name AS hod_name FROM departments d LEFT JOIN users u ON d.hod_id=u.id WHERE d.id=?`,
      [req.params.id]);
    if (!dept) return res.status(404).json({ message: "Department not found." });
    const [batches] = await pool.query("SELECT * FROM batches WHERE department_id=? ORDER BY created_at DESC",[req.params.id]);
    res.json({ ...dept, batches });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post("/", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { name, code, hod_id } = req.body;
    const [r] = await pool.query("INSERT INTO departments (name,code,hod_id) VALUES (?,?,?)",
      [name,code||null,hod_id||null]);
    await auditLog(req,"DEPARTMENT_CREATED","departments",r.insertId);
    res.status(201).json({ message: "Department created.", id: r.insertId });
  } catch (e) {
    if (e.message?.includes("UNIQUE")||e.code==="ER_DUP_ENTRY")
      return res.status(409).json({ message: "Department name already exists." });
    res.status(500).json({ message: e.message });
  }
});

router.put("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    const { name, code, hod_id } = req.body;
    await pool.query("UPDATE departments SET name=?,code=?,hod_id=? WHERE id=?",
      [name,code||null,hod_id||null,req.params.id]);
    res.json({ message: "Department updated." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete("/:id", authenticate, authorize("admin"), async (req, res) => {
  try {
    await pool.query("DELETE FROM departments WHERE id=?", [req.params.id]);
    await auditLog(req,"DEPARTMENT_DELETED","departments",req.params.id);
    res.json({ message: "Department deleted." });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

export default router;
