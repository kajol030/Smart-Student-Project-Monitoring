import express from "express";
import { body, param } from "express-validator";
import pool from "../config/db.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { notify, auditLog } from "../middleware/audit.js";
import { validate } from "../middleware/validate.js";

const router = express.Router();

/* ── helper: check active membership ─────────────────────── */
async function membership(groupId, userId) {
  const [[row]] = await pool.query(
    "SELECT * FROM project_group_members WHERE group_id=? AND user_id=? AND status='active'",
    [groupId, userId]
  );
  return row;
}

async function supervisorCanViewGroup(groupId, supervisorId) {
  const [[assignment]] = await pool.query(
    `SELECT g.id
     FROM project_groups g
     WHERE g.id = ?
       AND (
         g.supervisor_id = ?
         OR EXISTS (
           SELECT 1 FROM projects p
           WHERE p.group_id = g.id AND p.supervisor_id = ?
         )
       )
     LIMIT 1`,
    [groupId, supervisorId, supervisorId],
  );
  return Boolean(assignment);
}

/* ── GET /  — list groups ─────────────────────────────────── */
router.get("/", authenticate, async (req, res, next) => {
  try {
    let rows;
    if (req.user.role === "admin") {
      [rows] = await pool.query(
        `SELECT g.*,
                u.name  AS leader_name,
                sv.name AS supervisor_name,
                COUNT(DISTINCT gm.user_id) AS member_count
         FROM project_groups g
         JOIN users u  ON u.id  = g.leader_id
         LEFT JOIN users sv ON sv.id = g.supervisor_id
         LEFT JOIN project_group_members gm ON gm.group_id = g.id AND gm.status = 'active'
         GROUP BY g.id
         ORDER BY g.created_at DESC`
      );
    } else if (req.user.role === "supervisor") {
      /* supervisor sees groups where they are assigned */
      [rows] = await pool.query(
        `SELECT g.*,
                u.name  AS leader_name,
                sv.name AS supervisor_name,
                COUNT(DISTINCT gm.user_id) AS member_count
         FROM project_groups g
         JOIN users u  ON u.id  = g.leader_id
         LEFT JOIN users sv ON sv.id = g.supervisor_id
         LEFT JOIN project_group_members gm ON gm.group_id = g.id AND gm.status = 'active'
         WHERE g.supervisor_id = ?
            OR EXISTS (
              SELECT 1 FROM projects p
              WHERE p.group_id = g.id AND p.supervisor_id = ?
            )
         GROUP BY g.id
         ORDER BY g.created_at DESC`,
        [req.user.id, req.user.id]
      );
    } else {
      /* student sees only their own groups */
      [rows] = await pool.query(
        `SELECT g.*,
                u.name  AS leader_name,
                sv.name AS supervisor_name,
                COUNT(DISTINCT gm2.user_id) AS member_count
         FROM project_groups g
         JOIN users u  ON u.id  = g.leader_id
         LEFT JOIN users sv ON sv.id = g.supervisor_id
         JOIN project_group_members gm  ON gm.group_id  = g.id AND gm.user_id = ? AND gm.status = 'active'
         LEFT JOIN project_group_members gm2 ON gm2.group_id = g.id AND gm2.status = 'active'
         GROUP BY g.id
         ORDER BY g.created_at DESC`,
        [req.user.id]
      );
    }
    res.json(rows);
  } catch (e) { next(e); }
});

/* ── GET /invitations/mine ────────────────────────────────── */
router.get("/invitations/mine", authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT gm.*, g.name AS group_name, u.name AS invited_by_name
       FROM project_group_members gm
       JOIN project_groups g ON g.id = gm.group_id
       JOIN users u           ON u.id = gm.invited_by
       WHERE gm.user_id = ? AND gm.status = 'invited'`,
      [req.user.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

/* ── GET /:id — single group with members ─────────────────── */
router.get("/:id", authenticate, [param("id").isInt()], validate, async (req, res, next) => {
  try {
    const [[group]] = await pool.query(
      `SELECT g.*, u.name AS leader_name, sv.name AS supervisor_name
       FROM project_groups g
       JOIN users u ON u.id = g.leader_id
       LEFT JOIN users sv ON sv.id = g.supervisor_id
       WHERE g.id = ?`,
      [req.params.id]
    );
    if (!group) return res.status(404).json({ message: "Group not found." });

    if (req.user.role === "supervisor") {
      if (!(await supervisorCanViewGroup(req.params.id, req.user.id))) {
        return res.status(403).json({ message: "Access denied." });
      }
    } else if (req.user.role !== "admin" &&
               !(await membership(req.params.id, req.user.id))) {
      return res.status(403).json({ message: "Access denied." });
    }

    const [members] = await pool.query(
      `SELECT gm.*, u.name, u.email
       FROM project_group_members gm
       JOIN users u ON u.id = gm.user_id
       WHERE gm.group_id = ?
       ORDER BY gm.role DESC, u.name`,
      [req.params.id]
    );
    res.json({ ...group, members });
  } catch (e) { next(e); }
});

/* ── POST /  — create group ───────────────────────────────── */
/* Admin: full FYP group (name, project_title, supervisor_id, leader_id, members[])
   Student: simple group (name only — leader = self) */
router.post(
  "/",
  authenticate,
  authorize("student", "admin"),
  [
    body("name").trim().isLength({ min: 2, max: 120 }),
    body("project_title").optional().trim().isLength({ max: 200 }),
    body("supervisor_id").optional({ nullable: true }).isInt(),
    body("leader_id").optional({ nullable: true }).isInt(),
    body("members").optional().isArray(),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { name, project_title, supervisor_id, leader_id, members = [] } = req.body;

      /* Determine leader */
      const actualLeaderId = req.user.role === "admin"
        ? (leader_id || req.user.id)
        : req.user.id;
      const actualSupervisorId = req.user.role === "admin"
        ? (supervisor_id || null)
        : null;

      /* Validation: leader cannot appear in members list */
      const memberIds = (members || []).map(Number).filter((id) => id !== actualLeaderId);
      if (memberIds.length !== new Set(memberIds).size) {
        return res.status(400).json({ message: "Duplicate members are not allowed." });
      }

      /* Insert group */
      const [result] = await pool.query(
        `INSERT INTO project_groups
           (name, leader_id, supervisor_id, project_title)
         VALUES (?, ?, ?, ?)`,
        [name, actualLeaderId, actualSupervisorId, project_title || null]
      );
      const groupId = result.insertId;

      /* Insert leader as active member */
      await pool.query(
        "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?,?,?,?,?)",
        [groupId, actualLeaderId, "leader", "active", req.user.id]
      );

      /* Insert members (admin adds directly as active; student sends invites) */
      for (const uid of memberIds) {
        /* verify student exists */
        const [[student]] = await pool.query(
          "SELECT id FROM users WHERE id=? AND role='student' AND is_active=1",
          [uid]
        );
        if (!student) continue;

        if (req.user.role === "admin") {
          /* Admin adds directly — no invitation needed */
          await pool.query(
            `INSERT OR IGNORE INTO project_group_members
               (group_id, user_id, role, status, invited_by)
             VALUES (?,?,?,?,?)`,
            [groupId, uid, "member", "active", req.user.id]
          );
          /* Notify the student */
          await notify(
            uid,
            "Added to FYP Group",
            `You have been added to the group "${name}" by admin.`,
            "info",
            "/groups"
          );
        } else {
          /* Student flow — send invitation */
          await pool.query(
            `INSERT OR IGNORE INTO project_group_members
               (group_id, user_id, role, status, invited_by)
             VALUES (?,?,?,?,?)`,
            [groupId, uid, "member", "invited", req.user.id]
          );
          await notify(
            uid,
            "Group invitation",
            `You have been invited to join the group "${name}".`,
            "info",
            "/groups"
          );
        }
      }

      await auditLog(req, "GROUP_CREATED", "project_groups", groupId);
      res.status(201).json({ id: groupId, message: "Group created." });
    } catch (e) { next(e); }
  }
);

/* ── PUT /:id — update group (admin only) ─────────────────── */
router.put(
  "/:id",
  authenticate,
  authorize("admin"),
  [
    param("id").isInt(),
    body("name").optional().trim().isLength({ min: 2, max: 120 }),
    body("project_title").optional().trim().isLength({ max: 200 }),
    body("supervisor_id").optional({ nullable: true }),
    body("leader_id").optional({ nullable: true }).isInt(),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { name, project_title, supervisor_id, leader_id } = req.body;
      await pool.query(
        `UPDATE project_groups SET
           name          = COALESCE(?, name),
           project_title = COALESCE(?, project_title),
           supervisor_id = COALESCE(?, supervisor_id),
           leader_id     = COALESCE(?, leader_id),
           updated_at    = datetime('now')
         WHERE id = ?`,
        [name || null, project_title || null, supervisor_id ?? null, leader_id || null, req.params.id]
      );

      /* If leader changed — update member role */
      if (leader_id) {
        await pool.query(
          "UPDATE project_group_members SET role='member' WHERE group_id=? AND role='leader'",
          [req.params.id]
        );
        /* Upsert new leader */
        const [[existing]] = await pool.query(
          "SELECT id FROM project_group_members WHERE group_id=? AND user_id=?",
          [req.params.id, leader_id]
        );
        if (existing) {
          await pool.query(
            "UPDATE project_group_members SET role='leader', status='active' WHERE group_id=? AND user_id=?",
            [req.params.id, leader_id]
          );
        } else {
          await pool.query(
            "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?,?,?,?,?)",
            [req.params.id, leader_id, "leader", "active", req.user.id]
          );
        }
      }

      res.json({ message: "Group updated." });
    } catch (e) { next(e); }
  }
);
/* ── DELETE /:id — delete group (admin only) ─────────────── */
router.delete(
  "/:id",
  authenticate,
  authorize("admin"),
  [param("id").isInt()],
  validate,
  async (req, res, next) => {
    try {
      const groupId = Number(req.params.id);

      const [[group]] = await pool.query(
        "SELECT id, name FROM project_groups WHERE id = ?",
        [groupId]
      );

      if (!group) {
        return res.status(404).json({
          message: "Group not found.",
        });
      }

      await pool.query(
        "DELETE FROM project_group_members WHERE group_id = ?",
        [groupId]
      );

      await pool.query(
        "DELETE FROM group_messages WHERE group_id = ?",
        [groupId]
      );

      const [result] = await pool.query(
        "DELETE FROM project_groups WHERE id = ?",
        [groupId]
      );

      if (!result.affectedRows) {
        return res.status(404).json({
          message: "Group not found.",
        });
      }

      await auditLog(
        req,
        "GROUP_DELETED",
        "project_groups",
        groupId
      );

      res.json({
        message: `Group "${group.name}" deleted successfully.`,
      });
    } catch (e) {
      next(e);
    }
  }
);
/* ── POST /:id/members — admin adds member directly ──────── */
router.post(
  "/:id/members",
  authenticate,
  authorize("admin"),
  [param("id").isInt(), body("user_id").isInt()],
  validate,
  async (req, res, next) => {
    try {
      const [[student]] = await pool.query(
        "SELECT id, name FROM users WHERE id=? AND role='student' AND is_active=1",
        [req.body.user_id]
      );
      if (!student) return res.status(404).json({ message: "Student not found." });

      /* check not already active leader */
      const [[existing]] = await pool.query(
        "SELECT id, role FROM project_group_members WHERE group_id=? AND user_id=?",
        [req.params.id, student.id]
      );
      if (existing?.role === "leader") {
        return res.status(400).json({ message: "This student is already the group leader." });
      }

      if (existing) {
        await pool.query(
          "UPDATE project_group_members SET status='active', role='member' WHERE group_id=? AND user_id=?",
          [req.params.id, student.id]
        );
      } else {
        await pool.query(
          "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?,?,?,?,?)",
          [req.params.id, student.id, "member", "active", req.user.id]
        );
      }

      const [[group]] = await pool.query("SELECT name FROM project_groups WHERE id=?", [req.params.id]);
      await notify(student.id, "Added to FYP Group", `You have been added to group "${group?.name}".`, "info", "/groups");
      res.status(201).json({ message: "Member added." });
    } catch (e) { next(e); }
  }
);

/* ── DELETE /:id/members/:userId ─────────────────────────── */
router.delete(
  "/:id/members/:userId",
  authenticate,
  authorize("student", "admin"),
  async (req, res, next) => {
    try {
      if (req.user.role === "student") {
        const group = await membership(req.params.id, req.user.id);
        if (!group || group.role !== "leader")
          return res.status(403).json({ message: "Only the group leader can remove members." });
      }
      await pool.query(
        "UPDATE project_group_members SET status='removed' WHERE group_id=? AND user_id=? AND role='member'",
        [req.params.id, req.params.userId]
      );
      res.json({ message: "Member removed." });
    } catch (e) { next(e); }
  }
);

/* ── POST /:id/invite (student flow) ─────────────────────── */
router.post(
  "/:id/invite",
  authenticate,
  authorize("student"),
  [param("id").isInt(), body("user_id").isInt()],
  validate,
  async (req, res, next) => {
    try {
      const group = await membership(req.params.id, req.user.id);
      if (!group || group.role !== "leader")
        return res.status(403).json({ message: "Only the group leader can invite members." });

      const [[student]] = await pool.query(
        "SELECT id, name FROM users WHERE id=? AND role='student' AND is_active=1",
        [req.body.user_id]
      );
      if (!student) return res.status(404).json({ message: "Student not found." });

      // Prevent leader from inviting themselves
      if (Number(student.id) === Number(req.user.id)) {
        return res.status(400).json({ message: "You cannot invite yourself." });
      }

      const [[existing]] = await pool.query(
        "SELECT id, status FROM project_group_members WHERE group_id=? AND user_id=?",
        [req.params.id, student.id]
      );

      if (existing) {
        // Already an active member — do not downgrade to 'invited'
        if (existing.status === "active") {
          return res.status(409).json({ message: `${student.name} is already an active member of this group.` });
        }
        // Already has a pending invitation
        if (existing.status === "invited") {
          return res.status(409).json({ message: `${student.name} already has a pending invitation.` });
        }
      }

      const [[groupSize]] = await pool.query(
        `SELECT COUNT(*) AS member_count
         FROM project_group_members
         WHERE group_id = ?
           AND status IN ('active', 'invited')`,
        [req.params.id],
      );
      if (Number(groupSize?.member_count) >= 3) {
        return res.status(409).json({
          message: "This group has reached its maximum size of 3 students, including pending invitations.",
        });
      }

      if (existing) {
        // Rejected or removed — re-invite them
        await pool.query(
          "UPDATE project_group_members SET status='invited', invited_by=? WHERE id=?",
          [req.user.id, existing.id]
        );
      } else {
        await pool.query(
          "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?,?,?,?,?)",
          [req.params.id, student.id, "member", "invited", req.user.id]
        );
      }
      await notify(student.id, "Group invitation", `You have been invited to join a project group by ${req.user.name}.`, "info", "/groups");
      res.status(201).json({ message: `Invitation sent to ${student.name}.` });
    } catch (e) { next(e); }
  }
);

/* ── PUT /:invitationId/invitation (student responds) ────── */
router.put(
  "/:invitationId/invitation",
  authenticate,
  authorize("student"),
  [
    param("invitationId").isInt({ min: 1 }),
    body("status").isIn(["active", "rejected"]),
  ],
  validate,
  async (req, res, next) => {
    try {
      const [result] = await pool.query(
        "UPDATE project_group_members SET status=? WHERE id=? AND user_id=? AND status='invited'",
        [req.body.status, req.params.invitationId, req.user.id]
      );
      if (!result.affectedRows) return res.status(404).json({ message: "Invitation not found." });
      res.json({ message: `Invitation ${req.body.status}.` });
    } catch (e) { next(e); }
  }
);

/* ── Group chat ───────────────────────────────────────────── */
async function canAccessChat(groupId, userId) {
  const [[member]] = await pool.query(
    "SELECT id FROM project_group_members WHERE group_id=? AND user_id=? AND status='active'",
    [groupId, userId]
  );
  return Boolean(member);
}

router.get("/:id/messages", authenticate, [param("id").isInt()], validate, async (req, res, next) => {
  try {
    if (!(await canAccessChat(req.params.id, req.user.id)))
      return res.status(403).json({ message: "Only active group members can view messages." });
    const [messages] = await pool.query(
      `SELECT m.id, m.group_id, m.sender_id, u.name AS sender_name, m.message, m.created_at
       FROM group_messages m JOIN users u ON u.id = m.sender_id
       WHERE m.group_id = ? ORDER BY m.created_at ASC, m.id ASC LIMIT 300`,
      [req.params.id]
    );
    res.json(messages);
  } catch (e) { next(e); }
});

router.post("/:id/messages", authenticate,
  [param("id").isInt(), body("message").trim().isLength({ min: 1, max: 5000 })], validate,
  async (req, res, next) => {
    try {
      if (!(await canAccessChat(req.params.id, req.user.id)))
        return res.status(403).json({ message: "Only active group members can send messages." });
      const [result] = await pool.query(
        "INSERT INTO group_messages (group_id, sender_id, message) VALUES (?,?,?)",
        [req.params.id, req.user.id, req.body.message]
      );
      res.status(201).json({
        id: result.insertId, group_id: Number(req.params.id),
        sender_id: req.user.id, sender_name: req.user.name,
        message: req.body.message, message_status: "sent",
      });
    } catch (e) { next(e); }
  }
);

export default router;
