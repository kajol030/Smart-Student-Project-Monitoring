import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { DatabaseSync } from "node:sqlite";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_TYPE   = process.env.DB_TYPE || "sqlite";

let pool;
let sqliteDatabase;

if (DB_TYPE === "mysql") {
  const mysql = await import("mysql2/promise");
  pool = mysql.default.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "fyp_management",
    waitForConnections: true,
    connectionLimit: 10,
  });
  const mysqlMigrations = [
    ["users", "token_version", "INT NOT NULL DEFAULT 0"],
    ["user_profiles", "program_id", "INT NULL"],
    ["user_profiles", "semester_id", "INT NULL"],
    ["user_profiles", "section_id", "INT NULL"],
    ["projects", "group_id", "INT NULL"],
    ["projects", "github_url", "VARCHAR(500) NULL"],
    ["project_groups", "supervisor_id", "INT NULL"],
    ["project_groups", "project_title", "VARCHAR(200) NULL"],
    ["rubrics", "is_active", "TINYINT DEFAULT 1"],
    ["rubrics", "passing_marks", "DECIMAL(5,2) DEFAULT 50"],
    ["rubrics", "stage", "VARCHAR(30) DEFAULT 'final'"],
    ["rubric_criteria", "weight", "DECIMAL(6,2) DEFAULT 0"],
  ];
  for (const [table, column, definition] of mysqlMigrations) {
    try {
      await pool.query(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    } catch (error) {
      if (error.code !== "ER_DUP_FIELDNAME") throw error;
    }
  }
  const outcomeMigrations = [
    ["expected_completion_date", "DATE NULL"],
    ["actual_completion_date", "DATE NULL"],
    ["outcome_status", "ENUM('completed_on_time','delayed','failed') NULL"],
    ["outcome_verified", "TINYINT(1) NOT NULL DEFAULT 0"],
    ["verified_by", "INT NULL"],
    ["verified_at", "TIMESTAMP NULL"],
  ];
  for (const [column, definition] of outcomeMigrations) {
    try {
      await pool.query(`ALTER TABLE projects ADD COLUMN ${column} ${definition}`);
    } catch (error) {
      if (error.code !== "ER_DUP_FIELDNAME") throw error;
    }
  }
  await pool.query(`
    CREATE TABLE IF NOT EXISTS plagiarism_checks (
      id INT AUTO_INCREMENT PRIMARY KEY,
      project_id INT NOT NULL,
      uploaded_by INT NOT NULL,
      original_filename VARCHAR(255) NOT NULL,
      word_count INT NOT NULL,
      similarity_percent INT NOT NULL DEFAULT 0,
      extracted_text MEDIUMTEXT NOT NULL,
      matches_json JSON NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
      FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS project_feature_snapshots (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      project_id INT NOT NULL,
      snapshot_date DATE NOT NULL,
      captured_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      features_snapshot JSON NOT NULL,
      UNIQUE KEY uq_project_feature_snapshot(project_id, snapshot_date),
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
  `);
} else {
  const dbPath     = process.env.FYP_DB_PATH
    ? path.resolve(process.env.FYP_DB_PATH)
    : path.join(__dirname, "..", "database", "fyp.db");
  const schemaPath = path.join(__dirname, "..", "database", "sqlite-schema.sql");
  sqliteDatabase = new DatabaseSync(dbPath);
  sqliteDatabase.exec("PRAGMA foreign_keys = ON");
  sqliteDatabase.exec("PRAGMA journal_mode = WAL");

  // Always run schema (all CREATE TABLE IF NOT EXISTS — safe to repeat)
  const schema = fs.readFileSync(schemaPath, "utf8");
  sqliteDatabase.exec(schema);

  // Additive column migrations
  const migrations = [
    "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE deadlines ADD COLUMN target_role TEXT DEFAULT 'all'",
    "ALTER TABLE projects ADD COLUMN category TEXT",
    "ALTER TABLE projects ADD COLUMN keywords TEXT",
    "ALTER TABLE projects ADD COLUMN domain TEXT",
    "ALTER TABLE user_profiles ADD COLUMN program_id INTEGER",
    "ALTER TABLE user_profiles ADD COLUMN semester_id INTEGER",
    "ALTER TABLE user_profiles ADD COLUMN section_id INTEGER",
    "ALTER TABLE projects ADD COLUMN group_id INTEGER",
    "ALTER TABLE rubrics ADD COLUMN is_active INTEGER DEFAULT 1",
    "ALTER TABLE rubrics ADD COLUMN passing_marks REAL DEFAULT 50",
    "ALTER TABLE rubrics ADD COLUMN stage TEXT DEFAULT 'final'",
    "ALTER TABLE rubric_criteria ADD COLUMN weight REAL DEFAULT 0",
    // FYP Group extended fields
    "ALTER TABLE project_groups ADD COLUMN supervisor_id INTEGER REFERENCES users(id) ON DELETE SET NULL",
    "ALTER TABLE project_groups ADD COLUMN project_title TEXT",
    // GitHub repository URL per project
    "ALTER TABLE projects ADD COLUMN github_url TEXT",
    "CREATE INDEX IF NOT EXISTS idx_submissions_project ON submissions(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_audit_logs_user_created ON audit_logs(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_activity_logs_project ON activity_logs(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read)",
  ];
  for (const sql of migrations) {
    try { sqliteDatabase.prepare(sql).run(); } catch (_) {}
  }
  const projectColumns = new Set(
    sqliteDatabase.prepare("PRAGMA table_info(projects)").all().map(({ name }) => name)
  );
  const outcomeMigrations = [
    ["expected_completion_date", "TEXT"],
    ["actual_completion_date", "TEXT"],
    ["outcome_status", "TEXT CHECK(outcome_status IN ('completed_on_time','delayed','failed'))"],
    ["outcome_verified", "INTEGER NOT NULL DEFAULT 0 CHECK(outcome_verified IN (0,1))"],
    ["verified_by", "INTEGER REFERENCES users(id) ON DELETE SET NULL"],
    ["verified_at", "TEXT"],
  ];
  for (const [column, definition] of outcomeMigrations) {
    if (!projectColumns.has(column)) {
      sqliteDatabase.exec(`ALTER TABLE projects ADD COLUMN ${column} ${definition}`);
    }
  }

  pool = {
    query: async (sql, params = []) => {
      const trimmed = sql.trim().toUpperCase();
      if (trimmed.startsWith("SELECT") || trimmed.startsWith("WITH")) {
        return [sqliteDatabase.prepare(sql).all(...params)];
      }
      const info = sqliteDatabase.prepare(sql).run(...params);
      return [{ insertId: Number(info.lastInsertRowid ?? 0), affectedRows: info.changes ?? 0 }];
    },
  };
}

export const isMysql = DB_TYPE === "mysql";
export function closeDatabase() {
  sqliteDatabase?.close();
  sqliteDatabase = undefined;
}
export default pool;
