/**
 * Local text-similarity helpers used by proposal alignment and
 * document similarity checks. These scores are indicators only.
 */

const STOPWORDS = new Set([
  "this", "that", "with", "from", "have", "will", "were", "been", "they",
  "them", "then", "than", "also", "into", "over", "such", "using", "used",
  "based", "system", "project", "student", "students", "application",
]);

export function tokenize(text) {
  if (!text || typeof text !== "string") return new Set();
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 3 && !STOPWORDS.has(w))
  );
}

export function termFrequency(text) {
  const counts = new Map();
  if (!text || typeof text !== "string") return counts;
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 3 && !STOPWORDS.has(w));
  for (const w of words) counts.set(w, (counts.get(w) || 0) + 1);
  return counts;
}

export function jaccard(a, b) {
  const setA = a instanceof Set ? a : tokenize(String(a || ""));
  const setB = b instanceof Set ? b : tokenize(String(b || ""));
  if (!setA.size || !setB.size) return 0;
  let inter = 0;
  for (const x of setA) if (setB.has(x)) inter += 1;
  const union = setA.size + setB.size - inter;
  return union ? Math.round((inter / union) * 100) : 0;
}

export function cosineSimilarity(textA, textB) {
  const fa = termFrequency(textA);
  const fb = termFrequency(textB);
  if (!fa.size || !fb.size) return 0;
  let dot = 0;
  let magA = 0;
  let magB = 0;
  for (const [term, ca] of fa) {
    magA += ca * ca;
    const cb = fb.get(term) || 0;
    dot += ca * cb;
  }
  for (const cb of fb.values()) magB += cb * cb;
  if (!magA || !magB) return 0;
  return Math.round((dot / (Math.sqrt(magA) * Math.sqrt(magB))) * 100);
}

export function overlapTokens(textA, textB, limit = 12) {
  const a = tokenize(textA);
  const b = tokenize(textB);
  const shared = [...a].filter((t) => b.has(t));
  return shared.slice(0, limit);
}

/**
 * Split proposal/description text into identifiable objectives.
 */
export function extractObjectives({ title = "", description = "", keywords = "" } = {}) {
  const raw = String(description || "").replace(/\r/g, "");
  const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);
  const collected = [];

  for (const line of lines) {
    const cleaned = line
      .replace(/^(objectives?|requirements?|aims?|goals?)\s*[:.-]?\s*/i, "")
      .replace(/^[-*•]+\s*/, "")
      .replace(/^\d+[.)]\s*/, "")
      .trim();
    if (cleaned.length >= 12) collected.push(cleaned);
  }

  if (!collected.length && raw.length) {
    const sentences = raw
      .split(/[.!?]\s+/)
      .map((s) => s.trim())
      .filter((s) => s.length >= 20);
    collected.push(...sentences.slice(0, 8));
  }

  if (!collected.length && title) collected.push(String(title).trim());
  if (keywords) {
    const extra = String(keywords)
      .split(/[,;]+/)
      .map((k) => k.trim())
      .filter((k) => k.length >= 4);
    for (const k of extra) {
      if (!collected.some((c) => c.toLowerCase().includes(k.toLowerCase()))) {
        collected.push(`Cover ${k} as stated in the proposal keywords.`);
      }
    }
  }

  const unique = [];
  const seen = new Set();
  for (const item of collected) {
    const key = item.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(item);
  }
  return unique.slice(0, 12);
}
