import pool from "../config/db.js";

export async function getProjectForAccess(projectId) {
  const [[project]] = await pool.query(
    `SELECT id, student_id, supervisor_id, group_id, title, description,
            keywords, category, domain, github_url, progress, status
     FROM projects WHERE id = ?`,
    [projectId]
  );
  return project || null;
}

export async function canAccessProject(user, project) {
  if (!user || !project) return false;
  if (user.role === "admin") return true;
  if (user.role === "supervisor") {
    return Number(project.supervisor_id) === Number(user.id);
  }
  if (user.role === "student") {
    if (!project.group_id) {
      return Number(project.student_id) === Number(user.id);
    }
    const [[member]] = await pool.query(
      `SELECT id FROM project_group_members
       WHERE group_id = ? AND user_id = ? AND status = 'active' LIMIT 1`,
      [project.group_id, user.id]
    );
    return Boolean(member);
  }
  return false;
}

export async function assertProjectAccess(req, res, projectId) {
  const id = Number(projectId);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ message: "Invalid project ID." });
    return null;
  }
  const project = await getProjectForAccess(id);
  if (!project) {
    res.status(404).json({ message: "Project not found." });
    return null;
  }
  const ok = await canAccessProject(req.user, project);
  if (!ok) {
    res.status(403).json({ message: "Access denied." });
    return null;
  }
  return project;
}
