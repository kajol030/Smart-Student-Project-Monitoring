import fs from 'fs';
import { DatabaseSync } from 'node:sqlite';

const schema = fs.readFileSync('./database/sqlite-schema.sql', 'utf8');
const db = new DatabaseSync('./database/fyp.db');
db.exec(schema);
console.log('schema initialized');
console.log(JSON.stringify(db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all()));
