import assert from "node:assert/strict";
import { createServer } from "node:http";
import { once } from "node:events";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import test from "node:test";

const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), "fyp-workflows-"));
process.env.FYP_DB_PATH = path.join(temporaryDirectory, "workflows.sqlite");
process.env.DB_TYPE = "sqlite";
process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "test-only-secret-for-isolated-workflow-tests";
process.env.GITHUB_TOKEN = "test-only-github-token";
process.env.ML_SERVICE_URL = "http://mock-ml";
process.env.EMAIL_USER = "";

const [{ app }, database, { default: pool }] = await Promise.all([
  import("../index.js"),
  import("../config/db.js"),
  import("../config/db.js"),
]);

const server = createServer(app);
server.listen(0, "127.0.0.1");
await once(server, "listening");
const baseUrl = `http://127.0.0.1:${server.address().port}`;
const originalFetch = globalThis.fetch;
let failMlRequest = false;
let privateRepository = false;
let privateRequests = 0;

function response(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json" },
  });
}

globalThis.fetch = async (input, options = {}) => {
  const url = new URL(input);
  if (url.origin === "http://mock-ml") {
    if (url.pathname === "/health") {
      return response({
        status: "ok",
        model_loaded: true,
        active_risk_model: {
          model_loaded: true,
          model_name: "Logistic Regression",
          model_type: "logistic_regression",
          training_status: "trained",
          feature_count: 17,
          evaluation_metrics: { accuracy: 0.776, macro_f1: 0.762 },
        },
        verified_outcome_model: {
          model_loaded: false,
          model_info: { training_status: "insufficient_data" },
        },
      });
    }
    if (url.pathname === "/demo/synthetic-risk/evaluation") {
      return response({
        title: "Synthetic Risk Model — Demonstration Only",
        record_count: 1500,
        metrics: { accuracy: 0.776, macro_f1: 0.762 },
      });
    }
    if (failMlRequest) return response({
      error: "Synthetic Logistic Regression artifacts are unavailable.",
      model_info: {
        model_name: null,
        model_type: "logistic_regression",
        training_status: "model_unavailable",
        evaluation_metrics: null,
        message: "Synthetic Logistic Regression artifacts are unavailable.",
      },
    }, 503);
    if (url.pathname === "/demo/synthetic-risk/predict") return response({
      risk_class: "High",
      risk_level: "high",
      predicted_outcome: "high",
      risk_score: 0.9,
      risk_probabilities: { Low: 0.1, Medium: 0.2, High: 0.7 },
      model_used: "Logistic Regression",
      model_info: {
        model_name: "Logistic Regression",
        model_type: "logistic_regression",
        training_status: "trained",
        dataset_type: "synthetic",
        evaluation_metrics: {
          accuracy: 0.776,
          macro_f1: 0.762,
          macro_precision: 0.774,
          macro_recall: 0.752,
          test_class_counts: { Low: 60, Medium: 160, High: 80 },
        },
        dataset: { record_count: 1500 },
        message: "Synthetic Dataset Evaluation — Not Real-world Validation",
      },
    });
    return response({
      predicted_outcome: "failed",
      risk_level: "high",
      risk_score: 0.82,
      delay_probability: 0.12,
      failure_probability: 0.70,
      completion_chance: 0.30,
      outcome_probabilities: {
        completed_on_time: 0.10,
        delayed: 0.20,
        failed: 0.70,
      },
      model_used: "Random Forest Classifier",
      model_info: {
        model_name: "Random Forest Classifier",
        model_type: "random_forest",
        training_status: "trained",
        evaluation_metrics: { accuracy: 0.91, macro_f1: 0.88 },
      },
    });
  }
  if (url.hostname !== "api.github.com") return originalFetch(input, options);

  if (url.pathname.endsWith("/private-repo")) {
    privateRequests += 1;
    if (options.headers?.Authorization !== "Bearer test-only-github-token") {
      return response({ message: "Authentication required" }, 401);
    }
    return response({
      full_name: "test-org/private-repo",
      html_url: "https://github.com/test-org/private-repo",
      description: "Private FYP repository",
      default_branch: "main",
      language: "JavaScript",
      stargazers_count: 0,
      forks_count: 0,
      open_issues_count: 0,
      created_at: "2026-01-01T00:00:00Z",
      updated_at: "2026-01-01T00:00:00Z",
      pushed_at: "2026-01-01T00:00:00Z",
      visibility: "private",
      size: 10,
    });
  }
  if (url.pathname.endsWith("/git/trees/main")) {
    return response({
      tree: [{ path: "src/milestone-monitor.js", type: "blob" }],
      truncated: false,
    });
  }
  if (url.pathname.endsWith("/branches")) {
    return response([{ name: "main", protected: true, commit: { sha: "branch-sha" } }]);
  }
  if (url.pathname.endsWith("/commits")) {
    return response([{
      sha: "commit-sha",
      commit: {
        message: "Implement milestone monitoring evidence",
        author: { name: "Student", date: new Date().toISOString() },
      },
      author: { login: "student" },
    }]);
  }
  if (url.pathname.endsWith("/pulls")) {
    return response(url.searchParams.get("state") === "open"
      ? [{ number: 7, title: "Add milestone tracking", state: "open", user: { login: "student" } }]
      : [{
        number: 3,
        title: "Document progress evidence",
        state: "closed",
        merged_at: "2026-02-01T00:00:00Z",
        user: { login: "student" },
      }]);
  }
  if (url.pathname.endsWith("/issues")) {
    return response(url.searchParams.get("state") === "open"
      ? [{ number: 9, title: "Review evidence mapping", state: "open", user: { login: "student" } }]
      : []);
  }
  if (url.pathname.startsWith("/repos/")) {
    return response({
      full_name: "test-org/public-fyp",
      html_url: "https://github.com/test-org/public-fyp",
      description: "Milestone monitoring evidence implementation",
      default_branch: "main",
      language: "JavaScript",
      stargazers_count: 0,
      forks_count: 0,
      open_issues_count: 1,
      created_at: "2026-01-01T00:00:00Z",
      updated_at: "2026-01-01T00:00:00Z",
      pushed_at: "2026-01-01T00:00:00Z",
      visibility: "public",
      size: 10,
    });
  }
  return response({ message: `Unexpected mock path: ${url.pathname}` }, 404);
};

async function request(endpoint, userToken) {
  return originalFetch(`${baseUrl}${endpoint}`, {
    headers: userToken ? { Authorization: `Bearer ${userToken}` } : {},
  });
}

async function uploadDocument(projectId, userToken, filename, text, mimeType = "text/plain") {
  const form = new FormData();
  form.append("file", new Blob([text], { type: mimeType }), filename);
  return originalFetch(`${baseUrl}/api/plagiarism/project/${projectId}/check`, {
    method: "POST",
    headers: { Authorization: `Bearer ${userToken}` },
    body: form,
  });
}

test("isolated student, supervisor, and admin monitoring workflows enforce project scope", async (t) => {
  t.after(async () => {
    globalThis.fetch = originalFetch;
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    database.closeDatabase();
    await rm(temporaryDirectory, { recursive: true, force: true });
  });

  const users = {};
  for (const [key, name, role] of [
    ["student1", "Student One", "student"],
    ["student2", "Student Two", "student"],
    ["supervisor", "Assigned Supervisor", "supervisor"],
    ["otherSupervisor", "Other Supervisor", "supervisor"],
    ["admin", "Test Administrator", "admin"],
  ]) {
    const [result] = await pool.query(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
      [name, `${key}@example.com`, "not-used-by-token-workflow-test", role],
    );
    users[key] = { id: result.insertId, name, role };
  }

  const projectIds = [];
  for (const [studentKey, title] of [
    ["student1", "Milestone Monitoring Project"],
    ["student2", "Evidence-Based Project Monitoring"],
  ]) {
    const [result] = await pool.query(
      `INSERT INTO projects (student_id, supervisor_id, title, description, github_url)
       VALUES (?, ?, ?, ?, ?)`,
      [
        users[studentKey].id,
        users.supervisor.id,
        title,
        "Objective: implement milestone monitoring and evidence-based project progress.",
        "https://github.com/test-org/public-fyp",
      ],
    );
    projectIds.push(result.insertId);
  }

  const [assignedGroupResult] = await pool.query(
    `INSERT INTO project_groups (name, leader_id, supervisor_id, project_title)
     VALUES (?, ?, ?, ?)`,
    ["Assigned project group", users.student2.id, users.supervisor.id, "Evidence monitoring"],
  );
  const assignedGroupId = assignedGroupResult.insertId;
  await pool.query(
    "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?, ?, 'leader', 'active', ?)",
    [assignedGroupId, users.student2.id, users.admin.id],
  );
  await pool.query("UPDATE projects SET group_id=? WHERE id=?", [assignedGroupId, projectIds[1]]);

  const [otherGroupResult] = await pool.query(
    `INSERT INTO project_groups (name, leader_id, supervisor_id, project_title)
     VALUES (?, ?, ?, ?)`,
    ["Other supervisor group", users.student1.id, users.otherSupervisor.id, "Other project"],
  );
  const otherGroupId = otherGroupResult.insertId;
  await pool.query(
    "INSERT INTO project_group_members (group_id, user_id, role, status, invited_by) VALUES (?, ?, 'leader', 'active', ?)",
    [otherGroupId, users.student1.id, users.admin.id],
  );

  const login = (user) => jwt.sign({
    id: user.id,
    name: user.name,
    email: `${user.role}@example.com`,
    role: user.role,
    jti: `test-session-${user.id}`,
    token_version: 0,
  }, process.env.JWT_SECRET);
  const studentToken = login(users.student2);
  const supervisorToken = login(users.supervisor);
  const otherSupervisorToken = login(users.otherSupervisor);
  const adminToken = login(users.admin);
  const [unassignedProjectId, assignedProjectId] = projectIds;

  const preferenceResponse = await request("/api/preferences", studentToken);
  assert.equal(preferenceResponse.status, 200);
  const preferences = await preferenceResponse.json();
  assert.deepEqual(preferences.map(({ event_key }) => event_key), [
    "deadline_reminders",
    "feedback",
    "project_updates",
    "evaluation_updates",
    "announcements",
    "ai_risk_alerts",
    "weekly_log_notifications",
    "meeting_reminders",
  ]);
  const updatePreferenceResponse = await originalFetch(`${baseUrl}/api/preferences`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${studentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      event_key: "meeting_reminders",
      in_app: 0,
      email: 1,
    }),
  });
  assert.equal(updatePreferenceResponse.status, 200);
  const updatedPreferencesResponse = await request("/api/preferences", studentToken);
  const updatedPreferences = await updatedPreferencesResponse.json();
  assert.deepEqual(
    updatedPreferences.find(({ event_key }) => event_key === "meeting_reminders"),
    { event_key: "meeting_reminders", in_app: 0, email: 1 },
  );

  const supervisorPassword = "StrongPassword@2026";
  const supervisorRegistration = await originalFetch(`${baseUrl}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Unapproved Supervisor",
      email: "unapproved-supervisor@example.com",
      password: supervisorPassword,
      role: "supervisor",
      employeeId: "UNAPPROVED-1",
      department: "ICT Department",
      designation: "Lecturer",
    }),
  });
  assert.equal(supervisorRegistration.status, 201);
  const registeredSupervisor = await supervisorRegistration.json();
  assert.equal(registeredSupervisor.user.role, "supervisor");
  const [[storedSupervisor]] = await pool.query(
    "SELECT role, password FROM users WHERE id=?",
    [registeredSupervisor.user.id],
  );
  assert.equal(storedSupervisor.role, "supervisor");
  assert.equal(await bcrypt.compare(supervisorPassword, storedSupervisor.password), true);

  const supervisorLogin = await originalFetch(`${baseUrl}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: "unapproved-supervisor@example.com",
      password: supervisorPassword,
    }),
  });
  assert.equal(supervisorLogin.status, 200);
  assert.equal((await supervisorLogin.json()).user.role, "supervisor");

  const adminPassword = "AdminPassword@2026";
  const [adminLoginUser] = await pool.query(
    "INSERT INTO users (name, email, password, role, is_active) VALUES (?, ?, ?, ?, 1)",
    [
      "Isolated Login Administrator",
      "isolated-admin@example.com",
      await bcrypt.hash(adminPassword, 12),
      "admin",
    ],
  );
  const adminLogin = await originalFetch(`${baseUrl}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: "isolated-admin@example.com",
      password: adminPassword,
    }),
  });
  assert.equal(adminLogin.status, 200);
  assert.equal((await adminLogin.json()).user.role, "admin");
  const [[unchangedAdmin]] = await pool.query(
    "SELECT role FROM users WHERE id=?",
    [adminLoginUser.insertId],
  );
  assert.equal(unchangedAdmin.role, "admin");

  const publicAdminRegistration = await originalFetch(`${baseUrl}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Public Admin Attempt",
      email: "public-admin@example.com",
      password: "StrongPassword@2026",
      role: "admin",
    }),
  });
  assert.equal(publicAdminRegistration.status, 422);

  const inactiveStudentResult = await pool.query(
    "INSERT INTO users (name, email, password, role, is_active) VALUES (?, ?, ?, 'student', 0)",
    ["Inactive Student", "inactive-student@example.com", "not-used-by-token-workflow-test"],
  );
  const inactiveStudentId = inactiveStudentResult[0].insertId;
  const availableStudentsResponse = await request("/api/users/students", studentToken);
  assert.equal(availableStudentsResponse.status, 200);
  const availableStudents = await availableStudentsResponse.json();
  assert.ok(!availableStudents.some((student) => Number(student.id) === inactiveStudentId));

  const [topicStudentResult] = await pool.query(
    "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'student')",
    ["Topic Submission Student", "topic-student@example.com", "not-used-by-token-workflow-test"],
  );
  const topicStudent = {
    id: topicStudentResult.insertId,
    name: "Topic Submission Student",
    role: "student",
  };
  const topicStudentToken = login(topicStudent);
  const newGroupResponse = await originalFetch(`${baseUrl}/api/project-groups`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${topicStudentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name: "Topic and Invitation Group" }),
  });
  assert.equal(newGroupResponse.status, 201);
  const newGroup = await newGroupResponse.json();

  const invalidTopicResponse = await originalFetch(`${baseUrl}/api/projects`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${topicStudentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      title: "Valid FYP Topic",
      description: "A valid project proposal description.",
      category: "Web Application",
      domain: "Computer Science",
    }),
  });
  assert.equal(invalidTopicResponse.status, 422);
  const invalidTopic = await invalidTopicResponse.json();
  assert.ok(invalidTopic.errors.some((error) => error.group_id === "Please select a project group."));

  const topicResponse = await originalFetch(`${baseUrl}/api/projects`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${topicStudentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      group_id: Number(newGroup.id),
      title: "Valid FYP Topic",
      description: "A valid project proposal description.",
      category: "Web Application",
      domain: "Computer Science",
      keywords: "monitoring, validation",
      preferred_supervisors: [],
    }),
  });
  assert.equal(topicResponse.status, 201);
  const createdTopic = await topicResponse.json();
  const [[storedTopic]] = await pool.query(
    "SELECT student_id, group_id, title, status FROM projects WHERE id=?",
    [createdTopic.projectId],
  );
  assert.equal(Number(storedTopic.student_id), topicStudent.id);
  assert.equal(Number(storedTopic.group_id), Number(newGroup.id));
  assert.equal(storedTopic.title, "Valid FYP Topic");
  assert.equal(storedTopic.status, "proposal");

  const inviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${newGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${topicStudentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(users.student1.id) }),
    },
  );
  assert.equal(inviteResponse.status, 201);
  const [[storedInvitation]] = await pool.query(
    "SELECT user_id, status, invited_by FROM project_group_members WHERE group_id=? AND user_id=?",
    [newGroup.id, users.student1.id],
  );
  assert.equal(Number(storedInvitation.user_id), users.student1.id);
  assert.equal(storedInvitation.status, "invited");
  assert.equal(Number(storedInvitation.invited_by), topicStudent.id);

  const duplicateInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${newGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${topicStudentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(users.student1.id) }),
    },
  );
  assert.equal(duplicateInviteResponse.status, 409);

  const inactiveInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${newGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${topicStudentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: inactiveStudentId }),
    },
  );
  assert.equal(inactiveInviteResponse.status, 404);

  const registerStudent = async (name, email, studentId) => {
    const response = await originalFetch(`${baseUrl}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        email,
        password: "StrongPassword@2026",
        role: "student",
        studentId,
        program: "BSCS",
        batch: "2026",
        semester: "7th",
        section: "A",
      }),
    });
    assert.equal(response.status, 201);
    return response.json();
  };

  const registeredLeader = await registerStudent(
    "Registered Group Leader",
    "registered-leader@example.com",
    "REG-LEADER-1",
  );
  const registeredInvitee = await registerStudent(
    "Registered Invitee",
    "registered-invitee@example.com",
    "REG-INVITEE-1",
  );
  const registeredRejectee = await registerStudent(
    "Registered Rejectee",
    "registered-rejectee@example.com",
    "REG-REJECTEE-1",
  );
  const registeredStudentListResponse = await request(
    "/api/users/students",
    registeredLeader.token,
  );
  assert.equal(registeredStudentListResponse.status, 200);
  const registeredStudentList = await registeredStudentListResponse.json();
  assert.ok(registeredStudentList.some(
    (student) => Number(student.id) === Number(registeredInvitee.user.id),
  ));

  const registeredGroupResponse = await originalFetch(`${baseUrl}/api/project-groups`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${registeredLeader.token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name: "Registered Student Invitation Group" }),
  });
  assert.equal(registeredGroupResponse.status, 201);
  const registeredGroup = await registeredGroupResponse.json();

  const registeredInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${registeredLeader.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(registeredInvitee.user.id) }),
    },
  );
  assert.equal(registeredInviteResponse.status, 201);
  const [[registeredMembership]] = await pool.query(
    "SELECT id, user_id, status, invited_by FROM project_group_members WHERE group_id=? AND user_id=?",
    [registeredGroup.id, registeredInvitee.user.id],
  );
  assert.equal(registeredMembership.status, "invited");
  assert.equal(Number(registeredMembership.invited_by), Number(registeredLeader.user.id));
  const [[invitationNotification]] = await pool.query(
    "SELECT user_id, title FROM notifications WHERE user_id=? AND title='Group invitation' ORDER BY id DESC LIMIT 1",
    [registeredInvitee.user.id],
  );
  assert.equal(Number(invitationNotification.user_id), Number(registeredInvitee.user.id));
  const inviteeNotificationsResponse = await request(
    "/api/notifications",
    registeredInvitee.token,
  );
  assert.equal(inviteeNotificationsResponse.status, 200);
  const inviteeNotifications = await inviteeNotificationsResponse.json();
  assert.ok(inviteeNotifications.notifications.some(
    (notification) => notification.title === "Group invitation",
  ));

  const inviteePendingResponse = await request(
    "/api/project-groups/invitations/mine",
    registeredInvitee.token,
  );
  assert.equal(inviteePendingResponse.status, 200);
  const inviteePending = await inviteePendingResponse.json();
  assert.equal(inviteePending.length, 1);
  assert.equal(Number(inviteePending[0].id), Number(registeredMembership.id));
  assert.equal(inviteePending[0].group_name, "Registered Student Invitation Group");
  const leaderPendingResponse = await request(
    "/api/project-groups/invitations/mine",
    registeredLeader.token,
  );
  assert.deepEqual(await leaderPendingResponse.json(), []);

  const respondToInvitation = (invitationId, token, status) => originalFetch(
    `${baseUrl}/api/project-groups/${invitationId}/invitation`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status }),
    },
  );
  const invalidInvitationResponse = await respondToInvitation(
    999999,
    registeredInvitee.token,
    "active",
  );
  assert.equal(invalidInvitationResponse.status, 404);

  const unauthorizedAcceptResponse = await respondToInvitation(
    registeredMembership.id,
    registeredLeader.token,
    "active",
  );
  assert.equal(unauthorizedAcceptResponse.status, 404);
  const [[stillPendingMembership]] = await pool.query(
    "SELECT status FROM project_group_members WHERE id=?",
    [registeredMembership.id],
  );
  assert.equal(stillPendingMembership.status, "invited");

  const acceptInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredMembership.id}/invitation`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${registeredInvitee.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status: "active" }),
    },
  );
  assert.equal(acceptInviteResponse.status, 200);
  const [[acceptedMembership]] = await pool.query(
    "SELECT group_id, user_id, status FROM project_group_members WHERE id=?",
    [registeredMembership.id],
  );
  assert.equal(Number(acceptedMembership.group_id), Number(registeredGroup.id));
  assert.equal(Number(acceptedMembership.user_id), Number(registeredInvitee.user.id));
  assert.equal(acceptedMembership.status, "active");
  const [[activeMembershipCount]] = await pool.query(
    "SELECT COUNT(*) AS count FROM project_group_members WHERE group_id=? AND user_id=? AND status='active'",
    [registeredGroup.id, registeredInvitee.user.id],
  );
  assert.equal(Number(activeMembershipCount.count), 1);
  const alreadyAcceptedResponse = await respondToInvitation(
    registeredMembership.id,
    registeredInvitee.token,
    "active",
  );
  assert.equal(alreadyAcceptedResponse.status, 404);

  const duplicateAcceptedInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${registeredLeader.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(registeredInvitee.user.id) }),
    },
  );
  assert.equal(duplicateAcceptedInviteResponse.status, 409);

  const rejecteeInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${registeredLeader.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(registeredRejectee.user.id) }),
    },
  );
  assert.equal(rejecteeInviteResponse.status, 201);
  const [[rejecteeMembership]] = await pool.query(
    "SELECT id FROM project_group_members WHERE group_id=? AND user_id=?",
    [registeredGroup.id, registeredRejectee.user.id],
  );
  const duplicatePendingInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${registeredLeader.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(registeredRejectee.user.id) }),
    },
  );
  assert.equal(duplicatePendingInviteResponse.status, 409);

  const fullGroupInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${registeredGroup.id}/invite`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${registeredLeader.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: Number(users.student1.id) }),
    },
  );
  assert.equal(fullGroupInviteResponse.status, 409);
  assert.match((await fullGroupInviteResponse.json()).message, /maximum size of 3/i);

  const rejectInviteResponse = await originalFetch(
    `${baseUrl}/api/project-groups/${rejecteeMembership.id}/invitation`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${registeredRejectee.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status: "rejected" }),
    },
  );
  assert.equal(rejectInviteResponse.status, 200);
  const [[rejectedMembership]] = await pool.query(
    "SELECT status FROM project_group_members WHERE id=?",
    [rejecteeMembership.id],
  );
  assert.equal(rejectedMembership.status, "rejected");

  const meResponse = await request("/api/auth/me", studentToken);
  assert.equal(meResponse.status, 200);
  assert.equal((await meResponse.json()).user.role, "student");

  const githubResponse = await request(`/api/github/project/${assignedProjectId}`, studentToken);
  assert.equal(githubResponse.status, 200);
  const github = (await githubResponse.json()).data;
  assert.equal(github.commits.total_fetched, 1);
  assert.equal(github.pull_requests.merged_count, 1);
  assert.equal(github.issues.open_count, 1);

  const alignmentResponse = await request(`/api/alignment/project/${assignedProjectId}`, studentToken);
  assert.equal(alignmentResponse.status, 200);
  const alignment = await alignmentResponse.json();
  assert.equal(alignment.project_id, assignedProjectId);
  assert.ok(alignment.requirements.length > 0);
  assert.equal(alignment.alignment_source, "project_title_description_and_keywords");

  const syntheticEvaluationResponse = await request(
    "/api/predictions/synthetic-demo/evaluation",
    studentToken,
  );
  assert.equal(syntheticEvaluationResponse.status, 200);
  assert.equal((await syntheticEvaluationResponse.json()).record_count, 1500);
  const syntheticHealthResponse = await request(
    "/api/predictions/synthetic-demo/health",
    studentToken,
  );
  assert.equal(syntheticHealthResponse.status, 200);
  const syntheticHealth = await syntheticHealthResponse.json();
  assert.equal(syntheticHealth.active_risk_model.model_loaded, true);
  assert.equal(syntheticHealth.active_risk_model.model_name, "Logistic Regression");
  assert.equal(syntheticHealth.active_risk_model.feature_count, 17);
  assert.equal(syntheticHealth.verified_outcome_model.model_loaded, false);
  const syntheticPredictionResponse = await originalFetch(
    `${baseUrl}/api/predictions/synthetic-demo/predict`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${studentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ progress_percent: 60 }),
    },
  );
  assert.equal(syntheticPredictionResponse.status, 200);

  const predictionResponse = await request(`/api/predictions/project/${assignedProjectId}`, studentToken);
  assert.equal(predictionResponse.status, 200);
  const prediction = await predictionResponse.json();
  assert.equal(prediction.prediction_available, true);
  assert.equal(prediction.predicted_outcome, "high");
  assert.equal(prediction.model_used, "Logistic Regression");
  assert.equal(prediction.risk_level, "high");
  assert.equal(prediction.delay_probability, null);
  assert.equal(prediction.failure_probability, null);
  assert.equal(prediction.completion_chance, null);
  assert.equal(prediction.risk_probabilities.high, 0.7);
  assert.equal(prediction.model_info.model_name, "Logistic Regression");
  assert.equal(prediction.model_info.evaluation_metrics.accuracy, 0.776);

  failMlRequest = true;
  const fallbackResponse = await request(`/api/predictions/project/${assignedProjectId}`, studentToken);
  assert.equal(fallbackResponse.status, 200);
  const unavailablePrediction = await fallbackResponse.json();
  assert.equal(unavailablePrediction.prediction_available, false);
  assert.equal(unavailablePrediction.model_info.training_status, "model_unavailable");
  assert.equal(unavailablePrediction.model_info.model_type, "logistic_regression");
  assert.equal(unavailablePrediction.delay_probability, undefined);
  assert.equal(unavailablePrediction.completion_chance, undefined);
  failMlRequest = false;

  await pool.query("UPDATE projects SET status='completed' WHERE id=?", [assignedProjectId]);
  const outcomeBody = {
    expected_completion_date: "2026-03-15",
    actual_completion_date: "2026-03-10",
    outcome_status: "completed_on_time",
  };
  const saveOutcome = (projectId, token, body) => originalFetch(
    `${baseUrl}/api/project-outcomes/${projectId}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    },
  );
  const verifyOutcome = (projectId, token) => originalFetch(
    `${baseUrl}/api/project-outcomes/${projectId}/verify`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    },
  );
  const mismatchedOutcomeResponse = await saveOutcome(
    assignedProjectId,
    supervisorToken,
    { ...outcomeBody, outcome_status: "delayed" },
  );
  assert.equal(mismatchedOutcomeResponse.status, 422);
  assert.match((await mismatchedOutcomeResponse.json()).message, /dates indicate completed_on_time/);
  assert.equal((await saveOutcome(assignedProjectId, studentToken, outcomeBody)).status, 403);
  assert.equal((await saveOutcome(assignedProjectId, otherSupervisorToken, outcomeBody)).status, 403);

  const expectedDateOnly = await saveOutcome(assignedProjectId, supervisorToken, {
    expected_completion_date: "2026-03-15",
    actual_completion_date: null,
    outcome_status: null,
  });
  assert.equal(expectedDateOnly.status, 200);
  assert.equal((await expectedDateOnly.json()).outcome_status, null);
  assert.equal((await verifyOutcome(assignedProjectId, supervisorToken)).status, 422);
  const savedOutcomeResponse = await saveOutcome(assignedProjectId, supervisorToken, outcomeBody);
  assert.equal(savedOutcomeResponse.status, 200);
  assert.equal((await savedOutcomeResponse.json()).outcome_verified, 0);
  assert.equal((await verifyOutcome(assignedProjectId, otherSupervisorToken)).status, 403);
  const verifiedOutcomeResponse = await verifyOutcome(assignedProjectId, supervisorToken);
  assert.equal(verifiedOutcomeResponse.status, 200);
  const verifiedOutcome = await verifiedOutcomeResponse.json();
  assert.equal(verifiedOutcome.outcome_verified, 1);
  assert.equal(verifiedOutcome.verified_by, users.supervisor.id);

  const failedOutcomeResponse = await saveOutcome(unassignedProjectId, supervisorToken, {
    expected_completion_date: "2026-03-15",
    actual_completion_date: null,
    outcome_status: "failed",
  });
  assert.equal(failedOutcomeResponse.status, 200);
  assert.equal((await verifyOutcome(unassignedProjectId, supervisorToken)).status, 200);
  const [[failedProject]] = await pool.query(
    "SELECT outcome_status, actual_completion_date, outcome_verified FROM projects WHERE id=?",
    [unassignedProjectId],
  );
  assert.deepEqual({ ...failedProject }, {
    outcome_status: "failed",
    actual_completion_date: null,
    outcome_verified: 1,
  });

  assert.equal((await request(`/api/github/project/${unassignedProjectId}`, studentToken)).status, 403);
  assert.equal((await request(`/api/github/project/${unassignedProjectId}`, otherSupervisorToken)).status, 403);
  assert.equal((await request(`/api/github/project/${assignedProjectId}`, supervisorToken)).status, 200);
  assert.equal((await request(`/api/github/project/${unassignedProjectId}`, adminToken)).status, 200);

  assert.equal((await request(`/api/project-groups/${assignedGroupId}`, supervisorToken)).status, 200);
  assert.equal((await request(`/api/project-groups/${otherGroupId}`, supervisorToken)).status, 403);
  assert.equal((await request(`/api/project-groups/${otherGroupId}`, otherSupervisorToken)).status, 200);
  const supervisorGroupsResponse = await request("/api/project-groups", supervisorToken);
  assert.equal(supervisorGroupsResponse.status, 200);
  const supervisorGroups = await supervisorGroupsResponse.json();
  assert.ok(supervisorGroups.some((group) => Number(group.id) === assignedGroupId));
  assert.ok(!supervisorGroups.some((group) => Number(group.id) === otherGroupId));
  const spoofedGroupResponse = await originalFetch(`${baseUrl}/api/project-groups`, {
    method: "POST",
    headers: { Authorization: `Bearer ${studentToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Student-created group",
      supervisor_id: users.supervisor.id,
    }),
  });
  assert.equal(spoofedGroupResponse.status, 201);
  const spoofedGroup = await spoofedGroupResponse.json();
  const [[storedSpoofedGroup]] = await pool.query(
    "SELECT supervisor_id FROM project_groups WHERE id=?",
    [spoofedGroup.id],
  );
  assert.equal(storedSpoofedGroup.supervisor_id, null);
  assert.equal((await request(`/api/project-groups/${spoofedGroup.id}`, supervisorToken)).status, 403);

  assert.equal((await request(`/api/profiles/${users.student2.id}`, studentToken)).status, 200);
  assert.equal((await request(`/api/profiles/${users.student1.id}`, studentToken)).status, 403);
  assert.equal((await request(`/api/profiles/${users.student2.id}`, supervisorToken)).status, 200);
  assert.equal((await request(`/api/profiles/${users.student2.id}`, otherSupervisorToken)).status, 403);
  assert.equal((await request(`/api/profiles/${users.student1.id}`, adminToken)).status, 200);
  assert.equal((await request(`/api/profiles/supervisor/${users.supervisor.id}/stats`, studentToken)).status, 403);
  assert.equal((await request(`/api/profiles/supervisor/${users.supervisor.id}/stats`, otherSupervisorToken)).status, 403);
  assert.equal((await request(`/api/profiles/supervisor/${users.supervisor.id}/stats`, supervisorToken)).status, 200);
  assert.equal((await request(`/api/profiles/supervisor/${users.supervisor.id}/stats`, adminToken)).status, 200);

  const profileUpdate = await originalFetch(`${baseUrl}/api/profiles/me`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${studentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ bio: "Updated test profile" }),
  });
  assert.equal(profileUpdate.status, 200);
  const forbiddenProfileUpdate = await originalFetch(`${baseUrl}/api/profiles/me`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${studentToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ department_id: 1 }),
  });
  assert.equal(forbiddenProfileUpdate.status, 400);

  const adminEvaluationAttempt = await originalFetch(`${baseUrl}/api/evaluations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${adminToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ project_id: assignedProjectId, supervisor_marks: 90 }),
  });
  assert.equal(adminEvaluationAttempt.status, 403);
  const unrelatedSupervisorAttempt = await originalFetch(`${baseUrl}/api/evaluations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${otherSupervisorToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ project_id: assignedProjectId, supervisor_marks: 90 }),
  });
  assert.equal(unrelatedSupervisorAttempt.status, 403);
  const evaluationResponse = await originalFetch(`${baseUrl}/api/evaluations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${supervisorToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ project_id: assignedProjectId, supervisor_marks: 88 }),
  });
  assert.equal(evaluationResponse.status, 201);
  const evaluation = await evaluationResponse.json();
  const adminMarkUpdate = await originalFetch(`${baseUrl}/api/evaluations/${evaluation.id}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${adminToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ supervisor_marks: 100 }),
  });
  assert.equal(adminMarkUpdate.status, 403);
  const supervisorMarkUpdate = await originalFetch(`${baseUrl}/api/evaluations/${evaluation.id}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${supervisorToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ supervisor_marks: 91 }),
  });
  assert.equal(supervisorMarkUpdate.status, 200);

  await pool.query(
    "UPDATE projects SET github_url = ? WHERE id = ?",
    ["https://github.com/test-org/private-repo", assignedProjectId],
  );
  assert.equal((await request(`/api/github/project/${assignedProjectId}`, studentToken)).status, 403);
  assert.equal((await request(`/api/github/project/${assignedProjectId}`, supervisorToken)).status, 200);
  assert.ok(privateRequests >= 1);

  const unauthenticated = await request(`/api/github/project/${assignedProjectId}`);
  assert.equal(unauthenticated.status, 401);

  const proposalText = "The monitoring platform records milestone evidence and analyzes project activity to help supervisors identify risks and guide student teams.";
  const firstCheckResponse = await uploadDocument(
    unassignedProjectId,
    login(users.student1),
    "proposal.txt",
    proposalText,
  );
  assert.equal(firstCheckResponse.status, 201);
  const firstCheck = await firstCheckResponse.json();
  assert.equal(firstCheck.check.similarity_percent, 0);

  const secondCheckResponse = await uploadDocument(
    assignedProjectId,
    studentToken,
    "updated-proposal.txt",
    `${proposalText} Additional section documenting the planned evaluation workflow.`,
  );
  assert.equal(secondCheckResponse.status, 201);
  const secondCheck = await secondCheckResponse.json();
  assert.equal(secondCheck.comparisons_made, 1);
  assert.ok(secondCheck.check.similarity_percent > 0);
  assert.ok(secondCheck.check.matched_text.length > 0);
  assert.equal("source_excerpt" in secondCheck.check.matched_text[0], false);

  const studentHistory = await request(`/api/plagiarism/project/${assignedProjectId}`, studentToken);
  assert.equal(studentHistory.status, 200);
  const studentChecks = await studentHistory.json();
  assert.equal(studentChecks.checks.length, 1);
  assert.equal("source_project_title" in studentChecks.checks[0].matched_text[0], false);
  assert.equal((await request(`/api/plagiarism/project/${unassignedProjectId}`, studentToken)).status, 403);

  const supervisorHistory = await request(`/api/plagiarism/project/${assignedProjectId}`, supervisorToken);
  assert.equal(supervisorHistory.status, 200);
  const supervisorChecks = await supervisorHistory.json();
  assert.equal("source_excerpt" in supervisorChecks.checks[0].matched_text[0], false);

  const adminHistory = await request(`/api/plagiarism/project/${assignedProjectId}`, adminToken);
  assert.equal(adminHistory.status, 200);
  const adminChecks = await adminHistory.json();
  assert.equal(adminChecks.checks[0].matched_text[0].source_project_title, "Milestone Monitoring Project");

  const supervisorUpload = await uploadDocument(
    assignedProjectId,
    supervisorToken,
    "review.txt",
    proposalText,
  );
  assert.equal(supervisorUpload.status, 403);
  const invalidFile = await uploadDocument(
    assignedProjectId,
    studentToken,
    "unsupported.exe",
    proposalText,
    "application/octet-stream",
  );
  assert.equal(invalidFile.status, 400);
  const malformedPdf = await uploadDocument(
    assignedProjectId,
    studentToken,
    "broken.pdf",
    "This file is not a real PDF document but includes enough words for text extraction.",
    "application/pdf",
  );
  assert.equal(malformedPdf.status, 400);

  const logoutResponse = await originalFetch(`${baseUrl}/api/auth/logout`, {
    method: "POST",
    headers: { Authorization: `Bearer ${supervisorToken}` },
  });
  assert.equal(logoutResponse.status, 200);
  assert.equal((await request(`/api/projects/${assignedProjectId}`, supervisorToken)).status, 401);
});
