import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";

const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), "fyp-outcome-migration-"));
const databasePath = path.join(temporaryDirectory, "legacy.sqlite");
const legacyDatabase = new DatabaseSync(databasePath);
legacyDatabase.exec(`
  CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT NOT NULL);
  CREATE TABLE projects (
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL,
    supervisor_id INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'proposal',
    progress INTEGER DEFAULT 0,
    risk_level TEXT DEFAULT 'low',
    delay_probability REAL DEFAULT 0,
    completion_chance REAL DEFAULT 100,
    created_at TEXT,
    updated_at TEXT
  );
  INSERT INTO users (id, name) VALUES (9, 'Existing student');
  INSERT INTO projects (id, student_id, title, status, progress)
    VALUES (42, 9, 'Existing project', 'in_progress', 37);
`);
legacyDatabase.close();

process.env.DB_TYPE = "sqlite";
process.env.FYP_DB_PATH = databasePath;
process.env.NODE_ENV = "test";
const { default: pool, closeDatabase } = await import("../config/db.js");

test("SQLite migration adds outcome fields without changing existing project data", async (t) => {
  t.after(async () => {
    closeDatabase();
    await rm(temporaryDirectory, { recursive: true, force: true });
  });

  const [columns] = await pool.query("SELECT name FROM pragma_table_info('projects')");
  const names = new Set(columns.map((column) => column.name));
  for (const column of [
    "expected_completion_date",
    "actual_completion_date",
    "outcome_status",
    "outcome_verified",
    "verified_by",
    "verified_at",
  ]) {
    assert.ok(names.has(column), `Missing migrated column ${column}`);
  }
  const [[project]] = await pool.query(
    "SELECT id, student_id, title, status, progress, outcome_verified FROM projects WHERE id=42",
  );
  assert.deepEqual({ ...project }, {
    id: 42,
    student_id: 9,
    title: "Existing project",
    status: "in_progress",
    progress: 37,
    outcome_verified: 0,
  });
  const [snapshotTables] = await pool.query(
    "SELECT name FROM sqlite_master WHERE type='table' AND name='project_feature_snapshots'",
  );
  assert.equal(snapshotTables.length, 1);
});
