import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import PDFDocument from "pdfkit";
import {
  getGithubProjectData,
  parseGithubRepoUrl,
} from "../services/githubService.js";
import { calculateAlignmentScore } from "../services/alignmentService.js";
import {
  calculateEvidenceEstimate,
  scoreGithubEvidence,
} from "../services/progressService.js";
import {
  cosineSimilarity,
  extractObjectives,
} from "../utils/textSimilarity.js";
import { canAccessProject } from "../utils/projectAccess.js";
import { extractProposalPdfText } from "../services/proposalTextService.js";
import {
  compareDocumentText,
  extractDocumentText,
  presentPlagiarismCheck,
} from "../services/plagiarismService.js";

const originalFetch = globalThis.fetch;
const apiResponse = (body, status = 200, headers = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", ...headers },
  });

test("GitHub repository URLs are restricted to repository paths", () => {
  assert.deepEqual(
    parseGithubRepoUrl("https://github.com/example-owner/fyp-monitoring/"),
    { owner: "example-owner", repo: "fyp-monitoring" }
  );
  assert.throws(() => parseGithubRepoUrl("http://github.com/example/repo"));
  assert.throws(() => parseGithubRepoUrl("https://github.com/example/repo/issues"));
  assert.throws(() => parseGithubRepoUrl("https://github.com.evil.example/example/repo"));
});

test("GitHub lists follow bounded pagination and return activity evidence", async () => {
  const requestedPages = [];
  globalThis.fetch = async (input) => {
    const url = new URL(input);
    const page = Number(url.searchParams.get("page") || 1);
    requestedPages.push(`${url.pathname}:${page}`);

    if (url.pathname === "/repos/test-owner/fyp-monitoring") {
      return apiResponse({
        full_name: "test-owner/fyp-monitoring",
        html_url: "https://github.com/test-owner/fyp-monitoring",
        description: "FYP monitoring platform",
        default_branch: "main",
        language: "JavaScript",
        stargazers_count: 0,
        forks_count: 0,
        open_issues_count: 0,
        created_at: "2025-01-01T00:00:00Z",
        updated_at: "2025-01-01T00:00:00Z",
        pushed_at: "2025-01-01T00:00:00Z",
        visibility: "public",
        size: 10,
      });
    }

    if (url.pathname.endsWith("/branches")) {
      return apiResponse(
        [{ name: `branch-${page}`, protected: false, commit: { sha: `sha-${page}` } }],
        200,
        page === 1
          ? { link: `<${url.origin}${url.pathname}?per_page=100&page=2>; rel="next"` }
          : {}
      );
    }
    if (url.pathname.endsWith("/commits")) {
      return apiResponse(
        [{
          sha: `commit-${page}`,
          commit: {
            message: `Objective implementation ${page}`,
            author: { name: "Student", date: "2026-10-27T00:00:00Z" },
          },
          author: { login: "student" },
        }],
        200,
        page === 1
          ? { link: `<${url.origin}${url.pathname}?per_page=100&page=2>; rel="next"` }
          : {}
      );
    }
    if (url.pathname.endsWith("/pulls") || url.pathname.endsWith("/issues")) {
      return apiResponse([]);
    }
    throw new Error(`Unexpected request: ${url.pathname}`);
  };

  try {
    const data = await getGithubProjectData(
      "https://github.com/test-owner/fyp-monitoring"
    );
    assert.equal(data.branches.total_fetched, 2);
    assert.equal(data.commits.total_fetched, 2);
    assert.equal(data.activity.active_days, 1);
    assert.equal(data.pull_requests.open_count, 0);
    assert.equal(data.issues.open_count, 0);
    assert.ok(requestedPages.includes("/repos/test-owner/fyp-monitoring/branches:2"));
    assert.ok(requestedPages.includes("/repos/test-owner/fyp-monitoring/commits:2"));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("private repository data is denied before activity endpoints are requested", async () => {
  const requested = [];
  globalThis.fetch = async (input) => {
    const url = new URL(input);
    requested.push(url.pathname);
    return apiResponse({
      full_name: "test-owner/private-fyp",
      html_url: "https://github.com/test-owner/private-fyp",
      description: null,
      default_branch: "main",
      language: null,
      stargazers_count: 0,
      forks_count: 0,
      open_issues_count: 0,
      created_at: "2025-01-01T00:00:00Z",
      updated_at: "2025-01-01T00:00:00Z",
      pushed_at: "2025-01-01T00:00:00Z",
      visibility: "private",
      size: 0,
    });
  };
  try {
    await assert.rejects(
      getGithubProjectData("https://github.com/test-owner/private-fyp", {
        allowPrivate: false,
      }),
      /Private repository data/
    );
    assert.deepEqual(requested, ["/repos/test-owner/private-fyp"]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("GitHub rate limits are surfaced distinctly", async () => {
  globalThis.fetch = async () =>
    apiResponse({ message: "API rate limit exceeded" }, 403, {
      "x-ratelimit-remaining": "0",
      "retry-after": "60",
    });
  try {
    await assert.rejects(
      getGithubProjectData("https://github.com/test-owner/rate-limited-fyp"),
      /rate limit exceeded.*60 seconds/
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("proposal alignment score weights strong, possible, and missing evidence", () => {
  assert.equal(calculateAlignmentScore([
    { status: "strong_textual_match" },
    { status: "possible_match" },
    { status: "no_textual_evidence" },
  ]), 52);
  assert.equal(calculateAlignmentScore([]), null);
  assert.equal(
    cosineSimilarity("student attendance dashboard", "student attendance dashboard"),
    100
  );
  assert.deepEqual(extractObjectives({
    title: "Monitoring system",
    description: "Objectives:\n1. Predict project delays\n2. Track milestone evidence",
  }), ["Predict project delays", "Track milestone evidence"]);
});

test("approved proposal PDF text is extracted locally and path traversal is rejected", async () => {
  const uploadsDirectory = await mkdtemp(path.join(os.tmpdir(), "fyp-proposal-test-"));
  try {
    const pdf = new PDFDocument();
    const chunks = [];
    const finished = new Promise((resolve, reject) => {
      pdf.on("data", (chunk) => chunks.push(chunk));
      pdf.on("end", resolve);
      pdf.on("error", reject);
    });
    pdf.text("Objectives: predict project delays and track milestone evidence.");
    pdf.end();
    await finished;
    await writeFile(path.join(uploadsDirectory, "approved-proposal.pdf"), Buffer.concat(chunks));

    const result = await extractProposalPdfText(
      "/uploads/approved-proposal.pdf",
      uploadsDirectory
    );
    assert.match(result.text, /predict project delays/);
    assert.equal(result.pages_read, 1);
    await assert.rejects(
      extractProposalPdfText("/uploads/../outside.pdf", uploadsDirectory),
      /path is invalid/
    );
  } finally {
    await rm(uploadsDirectory, { recursive: true, force: true });
  }
});

test("GitHub evidence score uses activity signals, not commit counts", () => {
  const evidence = {
    activity: { recent_activity_days: 3, active_days: 5 },
    pull_requests: { merged_count: 1, open_count: 0 },
    issues: { recent_closed_count: 1, open_count: 0 },
    repository: { size: 1 },
    commits: { total_fetched: 1 },
  };
  const score = scoreGithubEvidence(evidence);
  assert.equal(score.score, 82);
  assert.equal(score.score, scoreGithubEvidence({
    ...evidence,
    commits: { total_fetched: 300 },
  }).score);
  assert.equal(scoreGithubEvidence(null).score, null);
});

test("evidence estimate is null when no measurable inputs exist", () => {
  assert.equal(calculateEvidenceEstimate([]), null);
  assert.equal(calculateEvidenceEstimate([
    { weight: 0.4, value: 50 },
    { weight: 0.2, value: 100 },
  ]), 67);
});

test("project access rules limit supervisor and student scope", async () => {
  const project = { id: 8, student_id: 21, supervisor_id: 34, group_id: null };
  assert.equal(await canAccessProject({ id: 34, role: "supervisor" }, project), true);
  assert.equal(await canAccessProject({ id: 35, role: "supervisor" }, project), false);
  assert.equal(await canAccessProject({ id: 21, role: "student" }, project), true);
  assert.equal(await canAccessProject({ id: 22, role: "student" }, project), false);
  assert.equal(await canAccessProject({ id: 9, role: "admin" }, project), true);
});

test("plagiarism text extraction supports TXT, DOCX, and PDF and rejects malformed input", async () => {
  const text = "The monitoring platform records milestone evidence and analyzes project activity to help supervisors identify risks and guide student teams.";
  assert.equal(await extractDocumentText({
    originalname: "proposal.txt",
    buffer: Buffer.from(text, "utf8"),
  }), text);

  const docxFixture = await readFile(new URL(
    "../node_modules/mammoth/test/test-data/single-paragraph.docx",
    import.meta.url,
  ));
  const docxText = await extractDocumentText({
    originalname: "proposal.docx",
    buffer: docxFixture,
  });
  assert.ok(docxText.length > 0);

  const pdf = new PDFDocument();
  const chunks = [];
  const finished = new Promise((resolve, reject) => {
    pdf.on("data", (chunk) => chunks.push(chunk));
    pdf.on("end", resolve);
    pdf.on("error", reject);
  });
  pdf.text(text);
  pdf.end();
  await finished;
  const pdfText = await extractDocumentText({
    originalname: "proposal.pdf",
    buffer: Buffer.concat(chunks),
  });
  assert.match(pdfText, /milestone evidence/);

  await assert.rejects(
    extractDocumentText({ originalname: "broken.pdf", buffer: Buffer.from("not pdf") }),
    /not a valid PDF/,
  );
  await assert.rejects(
    extractDocumentText({ originalname: "broken.txt", buffer: Buffer.from([0xff, 0xfe]) }),
    /valid UTF-8/,
  );
});

test("plagiarism review uses similarity and exact phrase evidence with role-based redaction", () => {
  const source = "The monitoring platform records milestone evidence and analyzes project activity to help supervisors identify risks.";
  const submitted = `${source} It also reports review progress to the supervisor.`;
  const comparison = compareDocumentText(submitted, source);
  assert.ok(comparison.similarity_percent > 0);
  assert.ok(comparison.matched_text.some((match) => match.matched_phrase.includes("milestone evidence")));

  const check = {
    id: 7,
    project_id: 3,
    original_filename: "proposal.txt",
    word_count: 21,
    similarity_percent: comparison.similarity_percent,
    matches_json: JSON.stringify([{
      source_project_id: 2,
      source_project_title: "Reference project",
      source_filename: "reference.txt",
      submitted_excerpt: submitted,
      source_excerpt: source,
      matched_phrase: "milestone evidence and analyzes project activity",
    }]),
    created_at: "2026-10-27T00:00:00.000Z",
  };
  const studentResult = presentPlagiarismCheck(check, "student");
  assert.equal(studentResult.matched_text[0].submitted_excerpt, submitted);
  assert.equal("source_excerpt" in studentResult.matched_text[0], false);
  assert.equal("source_project_title" in studentResult.matched_text[0], false);
  assert.equal(presentPlagiarismCheck(check, "admin").matched_text[0].source_excerpt, source);
});
