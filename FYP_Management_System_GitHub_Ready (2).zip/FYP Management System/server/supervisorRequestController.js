import pool from './config/db.js';
import { notify } from './middleware/audit.js';

// @desc    Create a new supervisor request
// @route   POST /api/supervisor-requests
// @access  Private (Student)
export const createSupervisorRequest = async (req, res, next) => {
  const { supervisor_id, project_id } = req.body;
  const student_id = req.user.id;

  if (!supervisor_id || !project_id) {
    return res.status(400).json({ message: 'Supervisor ID and Project ID are required.' });
  }

  try {
    // 1. Check if the project belongs to the student
    const [projectRows] = await pool.query('SELECT student_id FROM projects WHERE id = ?', [project_id]);
    if (projectRows.length === 0 || projectRows[0].student_id !== student_id) {
      return res.status(403).json({ message: 'You are not authorized to make a request for this project.' });
    }

    // 2. Check for existing pending/accepted requests for this project
    const [existingRequests] = await pool.query(
      "SELECT id FROM supervisor_requests WHERE project_id = ? AND status IN ('pending', 'accepted')",
      [project_id]
    );
    if (existingRequests.length > 0) {
      return res.status(409).json({ message: 'This project already has a pending or accepted supervisor request.' });
    }

    // 3. Create the new request
    const [result] = await pool.query(
      'INSERT INTO supervisor_requests (student_id, supervisor_id, project_id, status) VALUES (?, ?, ?, ?)',
      [student_id, supervisor_id, project_id, 'pending']
    );

    // 4. Create notifications
    await notify(supervisor_id, 'New Supervisor Request', `You have a new supervisor request from student ID ${student_id}.`, 'info', `/supervisor/requests`);
    // Find an admin to notify
    const [[admin]] = await pool.query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    if (admin) {
      await notify(admin.id, 'New Supervisor Request', `A new supervisor request was created by student ID ${student_id}.`, 'info', `/admin/requests`);
    }

    res.status(201).json({ id: result.insertId, message: 'Supervisor request sent successfully.' });
  } catch (error) {
    next(error);
  }
};

// @desc    Respond to a supervisor request
// @route   PUT /api/supervisor-requests/:id/respond
// @access  Private (Supervisor)

export const respondToSupervisorRequest = async (req, res, next) => {
  const { id } = req.params;
  const { status, reason } = req.body; // status: 'accepted' or 'rejected'
  const supervisor_id = req.user.id;

  if (!['accepted', 'rejected'].includes(status)) {
    return res.status(400).json({
      message: 'Invalid status. Must be "accepted" or "rejected".'
    });
  }

  try {
    const [requestRows] = await pool.query(
      'SELECT * FROM supervisor_requests WHERE id = ?',
      [id]
    );

    if (requestRows.length === 0) {
      return res.status(404).json({
        message: 'Request not found.'
      });
    }

    const request = requestRows[0];

    // 1. Verify the request belongs to the logged-in supervisor
    if (Number(request.supervisor_id) !== Number(supervisor_id)) {
      return res.status(403).json({
        message: 'You are not authorized to respond to this request.'
      });
    }

    // 2. Verify request is still pending
    if (request.status !== 'pending') {
      return res.status(409).json({
        message: 'This request has already been responded to.'
      });
    }

    // 3. Update supervisor request
    await pool.query(
      `UPDATE supervisor_requests
       SET status = ?, rejection_reason = ?
       WHERE id = ?`,
      [
        status,
        status === 'rejected' ? (reason || null) : null,
        id
      ]
    );

    // 4. Update project supervisor preference
    await pool.query(
      `UPDATE project_supervisor_preferences
       SET status = ?
       WHERE project_id = ? AND supervisor_id = ?`,
      [
        status === 'accepted' ? 'accepted' : 'declined',
        request.project_id,
        supervisor_id
      ]
    );

    // 5. Notify student
    const notificationMessage =
      `Your supervisor request for project ID ${request.project_id} has been ${status}.`;

    await notify(
      request.student_id,
      'Supervisor Request Update',
      notificationMessage,
      status === 'accepted' ? 'success' : 'error',
      '/projects'
    );

    // 6. Notify admin
    const [adminRows] = await pool.query(
      "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
    );

    if (adminRows.length > 0) {
      await notify(
        adminRows[0].id,
        'Supervisor Request Responded',
        `Request ID ${id} was ${status} by supervisor ID ${supervisor_id}.`,
        'info',
        '/admin/requests'
      );
    }

    return res.status(200).json({
      message: `Request successfully ${status}.`
    });

  } catch (error) {
    next(error);
  }
};

